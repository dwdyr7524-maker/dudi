package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.model.SystemShortcutId
import com.example.data.system.NexusNotificationHelper
import com.example.data.system.SystemControlHelper
import com.example.ui.components.FloatingAssistantHud
import com.example.ui.components.NexusCommandHeader
import com.example.ui.components.NexusParticleSplash
import com.example.ui.components.ReminderAndNotificationSheet
import com.example.ui.navigation.NexusDestination
import com.example.ui.screens.AccountsHubScreen
import com.example.ui.screens.AiFileManagerScreen
import com.example.ui.screens.ApprovalCenterScreen
import com.example.ui.screens.AppsScreen
import com.example.ui.screens.AssistantScreen
import com.example.ui.screens.AutomationScreen
import com.example.ui.screens.BatteryScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DeepCleanScreen
import com.example.ui.screens.DeviceDoctorScreen
import com.example.ui.screens.DownloadsManagerScreen
import com.example.ui.screens.PersonalLifeScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SecurityScreen
import com.example.ui.screens.SelfDiagnosticsScreen
import com.example.ui.screens.SmartStorageScreen
import com.example.ui.screens.SystemControlScreen
import com.example.ui.theme.LocalMotionConfig
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.viewmodel.NexusViewModel

class MainActivity : ComponentActivity() {
  private var externalRouteRequest by mutableStateOf<String?>(null)

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    configureAppCheck(this, intent)
    extractRouteFromIntent(intent)
    enableEdgeToEdge()
    setContent {
      NexusRoot(
        externalRouteRequest = externalRouteRequest,
        onConsumeExternalRoute = { externalRouteRequest = null }
      )
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    configureAppCheck(this, intent)
    extractRouteFromIntent(intent)
  }

  private fun extractRouteFromIntent(intent: Intent?) {
    val requested = intent?.getStringExtra(NexusNotificationHelper.EXTRA_TARGET_ROUTE)
    if (!requested.isNullOrBlank()) {
      externalRouteRequest = requested
      intent.removeExtra(NexusNotificationHelper.EXTRA_TARGET_ROUTE)
    }
  }
}

@Composable
fun NexusRoot(
  externalRouteRequest: String? = null,
  onConsumeExternalRoute: () -> Unit = {},
  viewModel: NexusViewModel = viewModel()
) {
  val performanceMode by viewModel.performanceMode.collectAsStateWithLifecycle()
  val darkThemeEnabled by viewModel.darkThemeEnabled.collectAsStateWithLifecycle()
  var showSplash by rememberSaveable { mutableStateOf(true) }

  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
    MyApplicationTheme(performanceMode = performanceMode, darkTheme = darkThemeEnabled) {
      AnimatedContent(
        targetState = showSplash,
        transitionSpec = {
          (fadeIn(tween(450)) + scaleIn(initialScale = 0.96f, animationSpec = tween(450))) togetherWith
            fadeOut(tween(350))
        },
        label = "splash_to_main"
      ) { splash ->
        if (splash) {
          NexusParticleSplash(onSplashFinished = { showSplash = false })
        } else {
          NexusCommandShell(
            viewModel = viewModel,
            performanceMode = performanceMode,
            darkThemeEnabled = darkThemeEnabled,
            externalRouteRequest = externalRouteRequest,
            onConsumeExternalRoute = onConsumeExternalRoute
          )
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NexusCommandShell(
  viewModel: NexusViewModel,
  performanceMode: Boolean,
  darkThemeEnabled: Boolean,
  externalRouteRequest: String?,
  onConsumeExternalRoute: () -> Unit
) {
  val context = LocalContext.current
  val navController = rememberNavController()
  val backStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = backStackEntry?.destination?.route ?: NexusDestination.DASHBOARD.route

  val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
  val isRefreshing by viewModel.isRefreshingTelemetry.collectAsStateWithLifecycle()
  val deepCleanState by viewModel.deepCleanState.collectAsStateWithLifecycle()
  val appsState by viewModel.appsState.collectAsStateWithLifecycle()
  val securityReport by viewModel.securityReport.collectAsStateWithLifecycle()
  val assistantState by viewModel.assistantState.collectAsStateWithLifecycle()
  val assistantMessages by viewModel.assistantMessages.collectAsStateWithLifecycle()
  val automations by viewModel.automations.collectAsStateWithLifecycle()
  val pendingAutomation by viewModel.pendingAutomationRun.collectAsStateWithLifecycle()
  val cleanHistory by viewModel.cleanHistory.collectAsStateWithLifecycle()
  val telemetrySnapshots by viewModel.telemetrySnapshots.collectAsStateWithLifecycle()
  val auditLogs by viewModel.actionAuditLogs.collectAsStateWithLifecycle()
  val safFolders by viewModel.safTreeUris.collectAsStateWithLifecycle()
  val ttsEnabled by viewModel.ttsEnabled.collectAsStateWithLifecycle()
  val cloudAiEnabled by viewModel.cloudAiEnabled.collectAsStateWithLifecycle()
  val shareTelemetryWithAi by viewModel.shareTelemetryWithAi.collectAsStateWithLifecycle()
  val transcriptionState by viewModel.transcriptionState.collectAsStateWithLifecycle()
  val liveVoiceState by viewModel.liveVoiceState.collectAsStateWithLifecycle()
  val visualDiagnosisState by viewModel.visualDiagnosisState.collectAsStateWithLifecycle()
  val cloudHealthCheckState by viewModel.cloudHealthCheckState.collectAsStateWithLifecycle()
  val aiDiagnosticsReport by viewModel.aiDiagnosticsReport.collectAsStateWithLifecycle()
  val backgroundAlertsEnabled by viewModel.backgroundAlertsEnabled.collectAsStateWithLifecycle()
  val alertIntervalMinutes by viewModel.alertIntervalMinutes.collectAsStateWithLifecycle()
  val centralError by viewModel.centralError.collectAsStateWithLifecycle()
  val lastMaintenance by viewModel.lastMaintenanceMillis.collectAsStateWithLifecycle()
  val bannerMessage by viewModel.uiBannerMessage.collectAsStateWithLifecycle()
  val navigateEvent by viewModel.navigateEvent.collectAsStateWithLifecycle()

  // AI DEVICE COMMANDER StateFlows
  val lastFullScanMillis by viewModel.lastFullScanMillis.collectAsStateWithLifecycle()
  val smartStorageReport by viewModel.smartStorageReport.collectAsStateWithLifecycle()
  val isScanningFullDevice by viewModel.isScanningFullDevice.collectAsStateWithLifecycle()
  val deviceDoctorReport by viewModel.deviceDoctorReport.collectAsStateWithLifecycle()
  val aiOrgPlan by viewModel.aiOrgPlan.collectAsStateWithLifecycle()
  val aiOrgInsights by viewModel.aiOrgInsights.collectAsStateWithLifecycle()
  val similarAppGroups by viewModel.similarAppGroups.collectAsStateWithLifecycle()
  val apkInspectionReport by viewModel.apkInspectionReport.collectAsStateWithLifecycle()
  val isInspectingApk by viewModel.isInspectingApk.collectAsStateWithLifecycle()
  val isBackingUpFolder by viewModel.isBackingUpFolder.collectAsStateWithLifecycle()
  val pendingApprovals by viewModel.pendingApprovals.collectAsStateWithLifecycle()
  val approvalHistory by viewModel.approvalHistory.collectAsStateWithLifecycle()
  val undoRecords by viewModel.undoRecords.collectAsStateWithLifecycle()
  val backupRecords by viewModel.backupRecords.collectAsStateWithLifecycle()

  // Command Center v4 StateFlows
  val orchestratorTasks by viewModel.orchestratorTasks.collectAsStateWithLifecycle()
  val currentlyDoingHe by viewModel.currentlyDoingHe.collectAsStateWithLifecycle()
  val memoryEntries by viewModel.memoryEntries.collectAsStateWithLifecycle()
  val memoryAutoSaveEnabled by viewModel.memoryAutoSaveEnabled.collectAsStateWithLifecycle()
  val learningRecords by viewModel.learningRecords.collectAsStateWithLifecycle()
  val learningInsights by viewModel.learningInsights.collectAsStateWithLifecycle()
  val reminderAlerts by viewModel.reminderAlerts.collectAsStateWithLifecycle()
  val networkStatus by viewModel.networkStatus.collectAsStateWithLifecycle()
  val pendingSyncQueue by viewModel.pendingSyncQueue.collectAsStateWithLifecycle()
  val toolStatuses by viewModel.toolStatuses.collectAsStateWithLifecycle()
  val openedDocument by viewModel.openedDocument.collectAsStateWithLifecycle()
  val isOpeningDocument by viewModel.isOpeningDocument.collectAsStateWithLifecycle()
  val isSummarizingDocument by viewModel.isSummarizingDocument.collectAsStateWithLifecycle()
  val isTtsPaused by viewModel.isTtsPaused.collectAsStateWithLifecycle()
  val ttsAvailableVoices by viewModel.ttsAvailableVoices.collectAsStateWithLifecycle()
  val ttsSpeechRate by viewModel.ttsSpeechRate.collectAsStateWithLifecycle()
  val ttsVoiceName by viewModel.ttsVoiceName.collectAsStateWithLifecycle()
  val noiseSuppressionEnabled by viewModel.noiseSuppressionEnabled.collectAsStateWithLifecycle()
  val floatingAssistantEnabled by viewModel.floatingAssistantEnabled.collectAsStateWithLifecycle()
  val floatingOffsetX by viewModel.floatingOffsetX.collectAsStateWithLifecycle()
  val floatingOffsetY by viewModel.floatingOffsetY.collectAsStateWithLifecycle()

  // Ultimate Master Upgrade (Aiko + Personal Life + Accounts Hub + Self Diagnostics)
  val lifeItems by viewModel.lifeItems.collectAsStateWithLifecycle()
  val managedAccounts by viewModel.managedAccounts.collectAsStateWithLifecycle()
  val accountConnectivityStatus by viewModel.accountConnectivityStatus.collectAsStateWithLifecycle()
  val selfDiagnosticsReport by viewModel.selfDiagnosticsReport.collectAsStateWithLifecycle()
  val isRunningSelfDiagnostics by viewModel.isRunningSelfDiagnostics.collectAsStateWithLifecycle()

  var showGlobalSearchDialog by rememberSaveable { mutableStateOf(false) }
  var globalSearchQuery by rememberSaveable { mutableStateOf("") }
  var showAllModulesSheet by rememberSaveable { mutableStateOf(false) }
  var showRemindersSheet by rememberSaveable { mutableStateOf(false) }

  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(bannerMessage) {
    val msg = bannerMessage
    if (msg != null) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearBannerMessage()
    }
  }

  val navigateToRoute: (String) -> Unit = { route ->
    if (currentRoute != route) {
      navController.navigate(route) {
        popUpTo(NexusDestination.DASHBOARD.route) { saveState = true }
        launchSingleTop = true
        restoreState = true
      }
    }
  }

  LaunchedEffect(navigateEvent) {
    val target = navigateEvent
    if (target != null) {
      navigateToRoute(target)
      viewModel.consumeNavigateEvent()
    }
  }

  LaunchedEffect(externalRouteRequest) {
    val extRoute = externalRouteRequest
    if (extRoute != null) {
      if (NexusDestination.entries.any { it.route == extRoute }) {
        navigateToRoute(extRoute)
      }
      onConsumeExternalRoute()
    }
  }

  val safFolderPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
      if (uri != null) {
        runCatching {
          context.contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
          )
        }
        viewModel.onSafFolderGranted(uri)
      }
    }

  val shortcuts =
    remember(telemetry.device.hasSamsungDeviceCare) {
      SystemControlHelper(context).buildShortcuts(telemetry.device.hasSamsungDeviceCare)
    }

  val currentDest =
    NexusDestination.entries.firstOrNull { it.route == currentRoute } ?: NexusDestination.DASHBOARD

  val compactNavDestinations =
    listOf(
      NexusDestination.DASHBOARD,
      NexusDestination.SMART_STORAGE,
      NexusDestination.APPROVAL_CENTER,
      NexusDestination.ASSISTANT
    )

  val shellGradientColors =
    if (darkThemeEnabled) {
      listOf(Color(0xFF050912), Color(0xFF081020), Color(0xFF04070E))
    } else {
      listOf(
        MaterialTheme.colorScheme.background,
        MaterialTheme.colorScheme.surfaceContainerLowest,
        MaterialTheme.colorScheme.surfaceContainerLow
      )
    }

  BoxWithConstraints(
    modifier =
      Modifier
        .fillMaxSize()
        .background(Brush.verticalGradient(colors = shellGradientColors))
  ) {
    val isTabletLayout = maxWidth >= 700.dp

    if (showGlobalSearchDialog) {
      val searchResults =
        remember(globalSearchQuery, appsState.allApps, securityReport, pendingApprovals) {
          viewModel.searchGlobal(globalSearchQuery)
        }
      AlertDialog(
        onDismissRequest = { showGlobalSearchDialog = false },
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(14.dp),
        title = {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              "חיפוש גלובלי ב-NEXUS AI",
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.primary
            )
            IconButton(onClick = { showGlobalSearchDialog = false }) {
              Icon(Icons.Rounded.Close, contentDescription = "סגור חיפוש")
            }
          }
        },
        text = {
          Column(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
              value = globalSearchQuery,
              onValueChange = { globalSearchQuery = it },
              singleLine = true,
              leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
              placeholder = { Text("חפש קובץ, אפליקציה, ממצא אבטחה או פעולה...") },
              shape = RoundedCornerShape(10.dp),
              colors =
                OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = MaterialTheme.colorScheme.primary,
                  unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                  focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                  unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                  focusedTextColor = MaterialTheme.colorScheme.onSurface,
                  unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                ),
              modifier = Modifier.fillMaxWidth().testTag("global_search_input")
            )
            Spacer(modifier = Modifier.height(10.dp))
            if (searchResults.isEmpty()) {
              Text(
                text =
                  if (globalSearchQuery.isBlank()) "הקלד מילת חיפוש כדי לחפש בקבצים, אפליקציות, אבטחה ואישורים."
                  else "לא נמצאו תוצאות עבור \"$globalSearchQuery\".",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            } else {
              LazyColumn(
                modifier = Modifier.fillMaxWidth().height(280.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                items(searchResults, key = { it.id }) { item ->
                  Surface(
                    modifier =
                      Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                          showGlobalSearchDialog = false
                          navigateToRoute(item.targetRoute)
                        },
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                  ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                      Text(
                        text = "${item.categoryLabel} • ${item.title}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface
                      )
                      Text(
                        text = item.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                  }
                }
              }
            }
          }
        },
        confirmButton = {
          TextButton(onClick = { showGlobalSearchDialog = false }) {
            Text("סגור")
          }
        }
      )
    }

    if (showAllModulesSheet) {
      val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
      ModalBottomSheet(
        onDismissRequest = { showAllModulesSheet = false },
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
          Text(
            text = "כל מודולי אייקו ו-COMMANDER (${NexusDestination.entries.size})",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.primary
          )
          Spacer(modifier = Modifier.height(10.dp))
          LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(NexusDestination.entries, key = { it.route }) { dest ->
              val isSelected = currentRoute == dest.route
              Surface(
                modifier =
                  Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable {
                      showAllModulesSheet = false
                      navigateToRoute(dest.route)
                    }
                    .testTag("sheet_nav_${dest.route}"),
                color =
                  if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                  else MaterialTheme.colorScheme.surface,
                border =
                  BorderStroke(
                    1.dp,
                    if (isSelected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.outlineVariant
                  )
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = dest.icon,
                      contentDescription = dest.labelHe,
                      tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                      text = dest.labelHe,
                      style = MaterialTheme.typography.titleMedium,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                  }
                  if (dest == NexusDestination.APPROVAL_CENTER && pendingApprovals.isNotEmpty()) {
                    Surface(
                      color = NexusAmber.copy(alpha = 0.2f),
                      shape = RoundedCornerShape(8.dp)
                    ) {
                      Text(
                        text = "${pendingApprovals.size} ממתינים",
                        style = MaterialTheme.typography.labelSmall,
                        color = NexusAmber,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    if (showRemindersSheet) {
      ReminderAndNotificationSheet(
        alerts = reminderAlerts,
        onDismissSheet = { showRemindersSheet = false },
        onCreateReminder = { title, message, delayMin, repeatH, cond ->
          viewModel.createReminder(title, message, delayMin, repeatH, cond)
        },
        onDismissAlert = { viewModel.dismissReminderAlert(it) },
        onCancelAlert = { viewModel.cancelReminderAlert(it) }
      )
    }

    Scaffold(
      containerColor = Color.Transparent,
      contentWindowInsets = WindowInsets.safeDrawing,
      snackbarHost = {
        SnackbarHost(hostState = snackbarHostState) { data ->
          Snackbar(
            snackbarData = data,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurface,
            shape = RoundedCornerShape(14.dp)
          )
        }
      },
      bottomBar = {
        if (!isTabletLayout) {
          Column(modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
            HorizontalDivider(thickness = 1.dp, color = MaterialTheme.colorScheme.outline)
            NavigationBar(
              containerColor = MaterialTheme.colorScheme.surface,
              tonalElevation = 0.dp,
              modifier = Modifier.navigationBarsPadding()
            ) {
              compactNavDestinations.forEach { dest ->
                val selected = currentRoute == dest.route
                NavigationBarItem(
                  selected = selected,
                  onClick = { navigateToRoute(dest.route) },
                  icon = {
                    if (dest == NexusDestination.APPROVAL_CENTER && pendingApprovals.isNotEmpty()) {
                      BadgedBox(badge = { Badge { Text("${pendingApprovals.size}") } }) {
                        Icon(dest.icon, contentDescription = dest.labelHe)
                      }
                    } else {
                      Icon(dest.icon, contentDescription = dest.labelHe)
                    }
                  },
                  label = { Text(dest.shortLabelHe, maxLines = 1) },
                  colors =
                    NavigationBarItemDefaults.colors(
                      selectedIconColor = MaterialTheme.colorScheme.primary,
                      selectedTextColor = MaterialTheme.colorScheme.primary,
                      indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                      unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                      unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                  modifier = Modifier.testTag("nav_${dest.route}")
                )
              }
              NavigationBarItem(
                selected = compactNavDestinations.none { it.route == currentRoute },
                onClick = { showAllModulesSheet = true },
                icon = { Icon(Icons.Rounded.Apps, contentDescription = "כל ${NexusDestination.entries.size} המודולים") },
                label = { Text("עוד", maxLines = 1) },
                colors =
                  NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                  ),
                modifier = Modifier.testTag("nav_all_modules")
              )
            }
          }
        }
      }
    ) { innerPadding ->
      Row(
        modifier =
          Modifier
            .fillMaxSize()
            .padding(innerPadding)
      ) {
        if (isTabletLayout) {
          NavigationRail(
            containerColor = MaterialTheme.colorScheme.surface,
            modifier =
              Modifier
                .fillMaxHeight()
                .width(92.dp)
          ) {
            Column(
              modifier = Modifier.fillMaxHeight().verticalScroll(rememberScrollState()).padding(vertical = 10.dp)
            ) {
              NexusDestination.entries.forEach { dest ->
                val selected = currentRoute == dest.route
                NavigationRailItem(
                  selected = selected,
                  onClick = { navigateToRoute(dest.route) },
                  icon = {
                    if (dest == NexusDestination.APPROVAL_CENTER && pendingApprovals.isNotEmpty()) {
                      BadgedBox(badge = { Badge { Text("${pendingApprovals.size}") } }) {
                        Icon(dest.icon, contentDescription = dest.labelHe)
                      }
                    } else {
                      Icon(dest.icon, contentDescription = dest.labelHe)
                    }
                  },
                  label = { Text(dest.shortLabelHe, maxLines = 1) },
                  colors =
                    NavigationRailItemDefaults.colors(
                      selectedIconColor = MaterialTheme.colorScheme.primary,
                      selectedTextColor = MaterialTheme.colorScheme.onSurface,
                      indicatorColor =
                        if (darkThemeEnabled) NexusElectricBlue.copy(alpha = 0.28f)
                        else MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                      unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                      unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                  modifier = Modifier.testTag("rail_${dest.route}")
                )
              }
            }
          }
          VerticalDivider(
            thickness = 1.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.72f),
            modifier = Modifier.fillMaxHeight()
          )
        }

        Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
          NexusCommandHeader(
            title = currentDest.labelHe,
            deviceLabel = "${telemetry.device.manufacturer} ${telemetry.device.model} • Android ${telemetry.device.androidRelease}",
            batteryPercent = telemetry.battery.levelPercent,
            showBackButton = !isTabletLayout && currentRoute != NexusDestination.DASHBOARD.route,
            performanceMode = performanceMode,
            isScanning = isRefreshing || isScanningFullDevice,
            pendingApprovalsCount = pendingApprovals.size,
            activeAlertsCount = reminderAlerts.count { it.status == "ACTIVE" || it.status == "TRIGGERED" },
            onNavigateBack = { navigateToRoute(NexusDestination.DASHBOARD.route) },
            onTogglePerformanceMode = { viewModel.togglePerformanceMode() },
            onRefreshTelemetry = { viewModel.refreshTelemetry(recordSnapshot = true) },
            onOpenGlobalSearch = { showGlobalSearchDialog = true },
            onToggleDarkTheme = { viewModel.toggleDarkTheme() },
            onOpenApprovals = { navigateToRoute(NexusDestination.APPROVAL_CENTER.route) },
            onOpenReminders = { showRemindersSheet = true }
          )

          centralError?.let { err ->
            Surface(
              color = MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.7f)),
              modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = err.messageHe,
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { viewModel.refreshTelemetry(recordSnapshot = false); viewModel.dismissCentralError() }) {
                  Text("נסה שוב", color = MaterialTheme.colorScheme.primary)
                }
                TextButton(onClick = { viewModel.dismissCentralError() }) {
                  Text("סגור", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }

          val motion = LocalMotionConfig.current
          val animDuration = motion.duration(210, 90)
          val exitDuration = motion.duration(150, 70)
          NavHost(
            navController = navController,
            startDestination = NexusDestination.DASHBOARD.route,
            enterTransition = {
              fadeIn(tween(animDuration, easing = FastOutSlowInEasing)) +
                slideInHorizontally(tween(animDuration, easing = FastOutSlowInEasing)) { it / 18 } +
                scaleIn(initialScale = 0.988f, animationSpec = tween(animDuration, easing = FastOutSlowInEasing))
            },
            exitTransition = {
              fadeOut(tween(exitDuration, easing = FastOutSlowInEasing)) +
                slideOutHorizontally(tween(exitDuration, easing = FastOutSlowInEasing)) { -it / 24 }
            },
            popEnterTransition = {
              fadeIn(tween(animDuration, easing = FastOutSlowInEasing)) +
                slideInHorizontally(tween(animDuration, easing = FastOutSlowInEasing)) { -it / 18 } +
                scaleIn(initialScale = 0.988f, animationSpec = tween(animDuration, easing = FastOutSlowInEasing))
            },
            popExitTransition = {
              fadeOut(tween(exitDuration, easing = FastOutSlowInEasing)) +
                slideOutHorizontally(tween(exitDuration, easing = FastOutSlowInEasing)) { it / 24 }
            },
            modifier = Modifier.weight(1f).fillMaxWidth()
          ) {
            composable(NexusDestination.DASHBOARD.route) {
              val openLife = remember(lifeItems) { lifeItems.filter { !it.isCompleted } }
              DashboardScreen(
                telemetry = telemetry,
                isRefreshing = isRefreshing,
                lastMaintenanceMillis = lastMaintenance,
                recentCleanHistory = cleanHistory,
                recentAuditLogs = auditLogs,
                onRefreshTelemetry = { viewModel.refreshTelemetry(recordSnapshot = true) },
                onNavigate = navigateToRoute,
                onQuickCleanLaunch = {
                  navigateToRoute(NexusDestination.DEEP_CLEAN.route)
                  viewModel.startDeepCleanScan()
                },
                onAssistantQuickCommand = { cmd ->
                  viewModel.sendAssistantCommand(cmd)
                  navigateToRoute(NexusDestination.ASSISTANT.route)
                },
                smartStorageReport = smartStorageReport,
                pendingApprovalsCount = pendingApprovals.size,
                isScanningFullDevice = isScanningFullDevice,
                lastFullScanMillis = lastFullScanMillis,
                onRunFullDeviceScan = { viewModel.runFullDeviceScan() },
                openLifeItemsCount = openLife.size,
                nextLifeTaskTitle = openLife.firstOrNull()?.title,
                telemetrySnapshots = telemetrySnapshots,
                assistantMood = assistantState.robotMood
              )
            }
            composable(NexusDestination.PERSONAL_LIFE.route) {
              PersonalLifeScreen(
                items = lifeItems,
                onAddItem = { title, details, kind, priority, cat, repeatH, project ->
                  viewModel.addLifeItem(title, details, kind, priority, cat, repeatH, project)
                },
                onToggleComplete = { viewModel.toggleLifeItemComplete(it) },
                onUpdateProgress = { item, pct -> viewModel.updateLifeItemProgress(item, pct) },
                onDeleteItem = { viewModel.deleteLifeItem(it) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.SMART_STORAGE.route) {
              SmartStorageScreen(
                report = smartStorageReport,
                telemetry = telemetry,
                safFolders = safFolders,
                isScanning = isScanningFullDevice,
                onRunFullScan = { viewModel.runFullDeviceScan() },
                onRequestAddSafFolder = { safFolderPicker.launch(null) },
                onRemoveSafFolder = { viewModel.removeSafFolder(it) },
                onStageProposal = { draft, goApprovals -> viewModel.stageProposalDraft(draft, goApprovals) },
                onOpenAiFileManager = { navigateToRoute(NexusDestination.AI_FILE_MANAGER.route) },
                onStageBatchCopyMove = { entries, destTree, destFolder, move ->
                  viewModel.stageBatchFileOperation(entries, destTree, destFolder, move)
                },
                onStageZipCreate = { entries, zipName, destTree ->
                  viewModel.stageZipCreate(entries, zipName, destTree)
                },
                onStageZipExtract = { zipEntry, destFolder, overwrite ->
                  viewModel.stageZipExtract(zipEntry, destFolder, overwrite)
                },
                onStageFolderTransfer = { folder, destTree, destFolder, move ->
                  viewModel.stageFolderTransfer(folder, destTree, destFolder, move)
                }
              )
            }
            composable(NexusDestination.DOWNLOADS_MANAGER.route) {
              DownloadsManagerScreen(
                report = smartStorageReport,
                safFolders = safFolders,
                isScanning = isScanningFullDevice,
                onRunFullScan = { viewModel.runFullDeviceScan() },
                onRequestAddSafFolder = { safFolderPicker.launch(null) },
                onQuickOrganizeDownloads = { viewModel.stageDownloadsOrganizeProposals(navigateToApprovals = true) },
                onStageProposal = { draft, goApprovals -> viewModel.stageProposalDraft(draft, goApprovals) },
                onStageBatchCopyMove = { entries, destTree, destFolder, move ->
                  viewModel.stageBatchFileOperation(entries, destTree, destFolder, move)
                },
                onStageZipCreate = { entries, zipName, destTree ->
                  viewModel.stageZipCreate(entries, zipName, destTree)
                },
                onStageZipExtract = { zipEntry, destFolder, overwrite ->
                  viewModel.stageZipExtract(zipEntry, destFolder, overwrite)
                },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.AI_FILE_MANAGER.route) {
              AiFileManagerScreen(
                report = smartStorageReport,
                orgPlan = aiOrgPlan,
                aiInsights = aiOrgInsights,
                isScanning = isScanningFullDevice,
                onRunFullScan = { viewModel.runFullDeviceScan() },
                onStageAllProposals = { viewModel.stageAllAiOrganizationProposals() },
                onStageSingleProposal = { draft, goApprovals -> viewModel.stageProposalDraft(draft, goApprovals) },
                onQuickDuplicateVideos = { viewModel.stageDuplicateVideoProposals(navigateToApprovals = true) },
                onQuickOrganizeDownloads = { viewModel.stageDownloadsOrganizeProposals(navigateToApprovals = true) },
                onQuickCleanupPlan = { viewModel.stageCleanupPlanProposals(navigateToApprovals = true) },
                onOpenApprovalCenter = { navigateToRoute(NexusDestination.APPROVAL_CENTER.route) }
              )
            }
            composable(NexusDestination.DEVICE_DOCTOR.route) {
              DeviceDoctorScreen(
                doctorReport = deviceDoctorReport,
                telemetry = telemetry,
                isScanning = isScanningFullDevice,
                onRunFullScan = { viewModel.runFullDeviceScan() },
                onNavigateRoute = navigateToRoute
              )
            }
            composable(NexusDestination.SELF_DIAGNOSTICS.route) {
              SelfDiagnosticsScreen(
                report = selfDiagnosticsReport,
                isRunningDiagnostics = isRunningSelfDiagnostics,
                onRunSelfDiagnostics = { viewModel.runSelfDiagnostics() },
                onNavigateRoute = navigateToRoute,
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.APPROVAL_CENTER.route) {
              ApprovalCenterScreen(
                pendingApprovals = pendingApprovals,
                approvalHistory = approvalHistory,
                undoRecords = undoRecords,
                backupRecords = backupRecords,
                auditLogs = auditLogs,
                safFolders = safFolders,
                isBackingUp = isBackingUpFolder,
                onApproveSingle = { viewModel.approveSingleProposal(it) },
                onApproveAllPending = { viewModel.approveAllPendingProposals() },
                onRejectSingle = { viewModel.rejectProposal(it) },
                onRejectAllPending = { viewModel.rejectAllPendingProposals() },
                onExecuteUndo = { viewModel.executeUndoRecord(it) },
                onCreateSafBackup = { src, dest -> viewModel.createSafBackup(src, dest) },
                onRestoreBackup = { rec, file -> viewModel.restoreBackupRecord(rec, file) },
                onParseManifest = { viewModel.parseBackupManifest(it) },
                onRequestAddSafFolder = { safFolderPicker.launch(null) }
              )
            }
            composable(NexusDestination.DEEP_CLEAN.route) {
              DeepCleanScreen(
                state = deepCleanState,
                telemetry = telemetry,
                safFolders = safFolders,
                onStartScan = { viewModel.startDeepCleanScan() },
                onToggleCandidate = { viewModel.toggleCleanCandidate(it) },
                onRequestCleanConfirmation = { viewModel.requestCleanConfirmation() },
                onConfirmClean = { viewModel.executeConfirmedClean() },
                onCancelConfirm = { viewModel.cancelCleanConfirmation() },
                onRequestAddSafFolder = { safFolderPicker.launch(null) },
                onRemoveSafFolder = { viewModel.removeSafFolder(it) },
                onOpenUsageAccessSettings = { viewModel.openSystemShortcut(SystemShortcutId.USAGE_ACCESS) },
                onOpenAndroidManageStorage = { viewModel.openSystemShortcut(SystemShortcutId.STORAGE) },
                onOpenAppDetails = { pkg, name -> viewModel.openAppSystemSettings(pkg, name) },
                onOpenSamsungDeviceCare = { viewModel.openSystemShortcut(SystemShortcutId.SAMSUNG_DEVICE_CARE) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.ASSISTANT.route) {
              AssistantScreen(
                assistantState = assistantState,
                transcriptionState = transcriptionState,
                liveVoiceState = liveVoiceState,
                visualDiagnosisState = visualDiagnosisState,
                messages = assistantMessages,
                automations = automations,
                ttsEnabled = ttsEnabled,
                cloudAiEnabled = cloudAiEnabled,
                onSendCommand = { viewModel.sendAssistantCommand(it) },
                onRetryAiWithFallback = { q, fallback -> viewModel.sendAssistantCommand(q, forceLocalFallback = fallback) },
                onDismissAiError = { viewModel.dismissAssistantAiError() },
                onToggleTts = { viewModel.toggleTtsEnabled() },
                onToggleCloudAi = { viewModel.toggleCloudAiEnabled() },
                onClearHistory = { viewModel.clearAssistantHistory() },
                onSetListening = { viewModel.setListeningState(it) },
                onConfirmPendingAction = { viewModel.confirmAssistantAction(it) },
                onDismissPendingAction = { viewModel.dismissAssistantAction() },
                onStartTranscribeRecord = { viewModel.startAudioTranscriptionRecording() },
                onStopAndTranscribe = { viewModel.stopAndTranscribeAudio() },
                onCancelTranscribe = { viewModel.cancelAudioTranscription() },
                onRetryTranscribe = { viewModel.retryLastTranscription() },
                onResetTranscribe = { viewModel.resetTranscriptionState() },
                onStartLiveVoice = { viewModel.startLiveVoiceConversation() },
                onStopLiveVoice = { viewModel.stopLiveVoiceConversation() },
                onSendLiveText = { viewModel.sendLiveTextMessage(it) },
                onAnalyzeImage = { uri, question -> viewModel.analyzeDiagnosticImageUri(uri, question) },
                onResetVisualDiagnosis = { viewModel.clearVisualDiagnosis() },
                onVoiceError = { msg -> viewModel.showBanner(msg) },
                onNotifyInfo = { msg -> viewModel.showBanner(msg) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) },
                orchestratorTasks = orchestratorTasks,
                currentlyDoingHe = currentlyDoingHe,
                onStartOrchestratorTask = { viewModel.startOrchestratorTask(it) },
                onPauseTask = { viewModel.pauseOrchestratorTask(it) },
                onResumeTask = { viewModel.resumeOrchestratorTask(it) },
                onCancelTask = { viewModel.cancelOrchestratorTask(it) },
                memoryEntries = memoryEntries,
                memoryAutoSaveEnabled = memoryAutoSaveEnabled,
                learningRecords = learningRecords,
                learningInsights = learningInsights,
                onToggleMemoryAutoSave = { viewModel.setMemoryAutoSaveEnabled(it) },
                onSaveMemory = { type, title, content, tag, persist ->
                  viewModel.saveMemoryEntry(type, title, content, tag, persist)
                },
                onUpdateMemory = { entry, title, content, type, persist ->
                  viewModel.updateMemoryEntry(entry, title, content, type, persist)
                },
                onToggleMemoryPersist = { viewModel.toggleMemoryPersist(it) },
                onDeleteMemory = { viewModel.deleteMemoryEntry(it) },
                onClearShortTermMemory = { viewModel.clearShortTermMemories() },
                onUndoLearning = { viewModel.undoLearningRecord(it) },
                onRateAssistantReply = { reply, pos -> viewModel.rateAssistantReply(reply, pos) },
                networkStatus = networkStatus,
                pendingSyncQueue = pendingSyncQueue,
                toolStatuses = toolStatuses,
                openedDocument = openedDocument,
                isOpeningDocument = isOpeningDocument,
                isSummarizingDocument = isSummarizingDocument,
                onRefreshToolHealth = { viewModel.refreshToolHealthCheck() },
                onOpenDocumentUri = { viewModel.openDocumentUri(it) },
                onPrevPdfPage = { viewModel.prevPdfPage() },
                onNextPdfPage = { viewModel.nextPdfPage() },
                onSearchDocument = { viewModel.searchOpenedDocument(it) },
                onSummarizeDocWithAi = { viewModel.summarizeOpenedDocumentWithAi() },
                onSaveDocumentUri = { uri, text -> viewModel.saveGeneratedDocumentUri(uri, text) },
                onCloseDocument = { viewModel.closeOpenedDocument() },
                ttsSpeechRate = ttsSpeechRate,
                ttsVoiceName = ttsVoiceName,
                ttsAvailableVoices = ttsAvailableVoices,
                isTtsPaused = isTtsPaused,
                noiseSuppressionEnabled = noiseSuppressionEnabled,
                floatingHudEnabled = floatingAssistantEnabled,
                onSetTtsRate = { viewModel.setTtsSpeechRate(it) },
                onSetTtsVoice = { viewModel.setTtsVoiceName(it) },
                onPauseOrResumeTts = { viewModel.pauseOrResumeTts() },
                onStopTts = { viewModel.stopTts() },
                onToggleNoiseSuppression = { viewModel.setNoiseSuppressionEnabled(it) },
                onToggleFloatingHud = { viewModel.setFloatingAssistantEnabled(it) },
                onRefreshTtsVoices = { viewModel.refreshTtsVoices() }
              )
            }
            composable(NexusDestination.ACCOUNTS_HUB.route) {
              AccountsHubScreen(
                accounts = managedAccounts,
                connectivityStatusMap = accountConnectivityStatus,
                onAddAccount = { serviceName, category, accountLabel, packageName, webUrl, reviewDays, notes ->
                  viewModel.addManagedAccount(serviceName, category, accountLabel, packageName, webUrl, reviewDays, notes)
                },
                onMarkReviewed = { viewModel.markAccountReviewed(it) },
                onOpenService = { viewModel.openManagedAccountService(it) },
                onCheckConnectivity = { viewModel.checkAccountConnectivity(it) },
                onDeleteAccount = { viewModel.deleteManagedAccount(it) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.SYSTEM_CONTROL.route) {
              SystemControlScreen(
                shortcuts = shortcuts,
                telemetry = telemetry,
                onOpenShortcut = { viewModel.openSystemShortcut(it) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.BATTERY.route) {
              BatteryScreen(
                telemetry = telemetry,
                snapshots = telemetrySnapshots,
                backgroundAlertsEnabled = backgroundAlertsEnabled,
                alertIntervalMinutes = alertIntervalMinutes,
                onToggleBackgroundAlerts = { viewModel.setBackgroundAlertsEnabled(it) },
                onSelectAlertInterval = { viewModel.setAlertIntervalMinutes(it) },
                onRunBackgroundCheckNow = { viewModel.triggerImmediateBackgroundCheck() },
                onOpenBatterySettings = { viewModel.openSystemShortcut(SystemShortcutId.BATTERY) },
                onRecordSnapshotNow = { viewModel.refreshTelemetry(recordSnapshot = true) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.APPS.route) {
              AppsScreen(
                state = appsState,
                hasUsageAccess = telemetry.hasUsageAccessPermission,
                onSearchChange = { viewModel.updateAppSearch(it) },
                onSortChange = { viewModel.updateAppSort(it) },
                onFilterChange = { viewModel.updateAppFilter(it) },
                onSelectApp = { viewModel.selectAppPackage(it) },
                onLaunchApp = { pkg, name -> viewModel.launchInstalledApp(pkg, name) },
                onOpenAppSettings = { pkg, name -> viewModel.openAppSystemSettings(pkg, name) },
                onOpenUsageAccess = { viewModel.openSystemShortcut(SystemShortcutId.USAGE_ACCESS) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) },
                similarAppGroups = similarAppGroups,
                onRequestUninstallProposal = { viewModel.requestAppUninstallProposal(it) }
              )
            }
            composable(NexusDestination.SECURITY.route) {
              SecurityScreen(
                report = securityReport,
                cloudAiEnabled = cloudAiEnabled,
                shareTelemetryWithAi = shareTelemetryWithAi,
                cloudHealthCheckState = cloudHealthCheckState,
                onToggleCloudAi = { viewModel.toggleCloudAiEnabled() },
                onToggleShareTelemetryWithAi = { viewModel.toggleShareTelemetryWithAi() },
                onRunCloudHealthCheck = { viewModel.runCloudHealthCheck() },
                onDeleteAllUserData = { viewModel.clearAllPersonalData() },
                onRefreshAudit = { viewModel.loadAppsAndSecurity() },
                onOpenPrivacySettings = { viewModel.openSystemShortcut(SystemShortcutId.PERMISSIONS) },
                onOpenAppPermissions = { pkg, name -> viewModel.openAppSystemSettings(pkg, name) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) },
                apkInspectionReport = apkInspectionReport,
                isInspectingApk = isInspectingApk,
                aiDiagnosticsReport = aiDiagnosticsReport,
                onInspectApkUri = { viewModel.inspectApkUri(it) },
                onRunComprehensiveAiDiagnostics = { viewModel.runComprehensiveAiDiagnostics() }
              )
            }
            composable(NexusDestination.AUTOMATION.route) {
              AutomationScreen(
                automations = automations,
                pendingConfirmation = pendingAutomation,
                onRequestRun = { viewModel.requestRunAutomation(it) },
                onConfirmRun = { viewModel.executeAutomation(it) },
                onDismissConfirm = { viewModel.dismissAutomationConfirmation() },
                onCreateAutomation = { name, phrase, steps, intervalHours ->
                  viewModel.createCustomAutomation(name, phrase, steps, intervalHours)
                },
                onUpdateSchedule = { automation, intervalHours ->
                  viewModel.updateAutomationSchedule(automation, intervalHours)
                },
                onDeleteCustom = { viewModel.deleteCustomAutomation(it) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) }
              )
            }
            composable(NexusDestination.REPORTS.route) {
              ReportsScreen(
                cleanHistory = cleanHistory,
                snapshots = telemetrySnapshots,
                auditLogs = auditLogs,
                onBuildReportText = { viewModel.buildExportReportText() },
                onExportJsonBackup = { viewModel.exportJsonBackup() },
                onRestoreBackupJson = { json -> viewModel.restoreBackupFromJson(json) },
                onNotifyResult = { msg -> viewModel.showBanner(msg) },
                onBack = { navigateToRoute(NexusDestination.DASHBOARD.route) },
                onRestoreBackupWithMode = { json, replace -> viewModel.restoreBackupFromJson(json, replace) }
              )
            }
          }
        }
      }
    }

    FloatingAssistantHud(
      enabled = floatingAssistantEnabled,
      savedOffsetX = floatingOffsetX,
      savedOffsetY = floatingOffsetY,
      activeTasks = orchestratorTasks,
      currentlyDoingHe = currentlyDoingHe,
      isSpeaking = assistantState.isSpeaking,
      isTtsPaused = isTtsPaused,
      onSaveOffset = { x, y -> viewModel.updateFloatingOffset(x, y) },
      onSendQuickCommand = { cmd ->
        viewModel.sendAssistantCommand(cmd)
        navigateToRoute(NexusDestination.ASSISTANT.route)
      },
      onOpenAssistantVoice = { navigateToRoute(NexusDestination.ASSISTANT.route) },
      onPauseOrResumeTts = { viewModel.pauseOrResumeTts() },
      onStopTts = { viewModel.stopTts() },
      onHideFloatingHud = { viewModel.setFloatingAssistantEnabled(false) },
      modifier = Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 76.dp)
    )
  }
}
