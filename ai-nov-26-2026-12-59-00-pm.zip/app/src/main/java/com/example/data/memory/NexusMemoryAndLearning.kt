package com.example.data.memory

import com.example.data.local.LearningRecordDao
import com.example.data.local.LearningRecordEntity
import com.example.data.local.MemoryEntryDao
import com.example.data.local.MemoryEntryEntity
import com.example.data.local.ToolUsageDao
import com.example.data.local.ToolUsageEntity
import kotlinx.coroutines.flow.Flow

enum class NexusMemoryType(val titleHe: String) {
  SHORT_TERM("זיכרון זמני (שיחה)"),
  LONG_TERM("זיכרון ארוך טווח"),
  PREFERENCE("העדפת משתמש"),
  PROJECT("פרויקט / משימה"),
  DECISION("החלטה קודמת"),
  CONTEXT("הקשר עבודה")
}

data class SecretCheckResult(
  val containsSensitiveData: Boolean,
  val reasonHe: String? = null,
  val sanitizedPreview: String
)

/**
 * Pure-Kotlin guardrail ensuring passwords, API keys, private tokens, PINs, and secrets
 * are NEVER stored in Long-Term Memory or backups.
 */
object NexusMemorySecretFilter {
  private val apiKeyRegex = Regex("(AIza[0-9A-Za-z\\-_]{18,}|sk-[0-9A-Za-z]{16,}|ghp_[0-9A-Za-z]{20,}|xox[baprs]-[0-9A-Za-z\\-]{10,})")
  private val bearerJwtRegex = Regex("(Bearer\\s+[A-Za-z0-9\\-_\\.]{16,}|eyJ[A-Za-z0-9_\\-]{10,}\\.[A-Za-z0-9_\\-]{10,})")
  private val privateKeyBlockRegex = Regex("-----BEGIN\\s+[A-Z\\s]*PRIVATE KEY-----")
  private val credentialAssignmentRegex =
    Regex("(?i)\\b(password|passwd|pwd|passcode|pin\\s*code|api[_\\s-]?key|secret[_\\s-]?key|client[_\\s-]?secret|access[_\\s-]?token)\\s*[:=]\\s*\\S+")
  private val hebrewCredentialRegex =
    Regex("(סיסמה|ססמה|סיסמא|קוד\\s*גישה|קוד\\s*אישי|מפתח\\s*API|טוקן\\s*סודי)\\s*(שלי\\s*)?[:=\\-]?\\s*\\S{3,}")

  fun inspect(title: String, content: String): SecretCheckResult {
    val combined = "$title\n$content"
    val reason =
      when {
        apiKeyRegex.containsMatchIn(combined) ->
          "זוהה מפתח API או מזהה גישה (כגון AIza/sk-/ghp_) — נשמר מחוץ לזיכרון לצמיתות מטעמי אבטחה."
        privateKeyBlockRegex.containsMatchIn(combined) ->
          "זוהה מפתח הצפנה פרטי (Private Key) — שמירה בזיכרון חסומה."
        bearerJwtRegex.containsMatchIn(combined) ->
          "זוהה טוקן הזדהות (JWT/Bearer) — שמירה בזיכרון חסומה."
        credentialAssignmentRegex.containsMatchIn(combined) || hebrewCredentialRegex.containsMatchIn(combined) ->
          "זוהתה סיסמה, קוד גישה או סוד אישי — NEXUS חוסם שמירת סיסמאות ומפתחות בזיכרון."
        else -> null
      }

    val sanitized =
      content
        .replace(apiKeyRegex, "[מפתח-API-מוגן]")
        .replace(bearerJwtRegex, "[טוקן-מוגן]")
        .replace(privateKeyBlockRegex, "[מפתח-פרטי-חוסם]")
        .replace(credentialAssignmentRegex, "$1=[סוד-חוסם]")
        .replace(hebrewCredentialRegex, "$1 [חוסם-מטעמי-אבטחה]")
        .trim()

    return SecretCheckResult(
      containsSensitiveData = reason != null,
      reasonHe = reason,
      sanitizedPreview = sanitized
    )
  }
}

object MemoryContextBuilder {
  fun buildPromptContext(
    memories: List<MemoryEntryEntity>,
    maxEntries: Int = 8,
    maxChars: Int = 1100
  ): String {
    val active =
      memories
        .filter { it.canPersist && it.memoryType != NexusMemoryType.SHORT_TERM.name }
        .sortedWith(
          compareByDescending<MemoryEntryEntity> { it.importanceScore }
            .thenByDescending { it.updatedAtMillis }
        )
        .take(maxEntries)

    if (active.isEmpty()) return ""

    val sb = StringBuilder()
    for (entry in active) {
      val check = NexusMemorySecretFilter.inspect(entry.title, entry.content)
      if (check.containsSensitiveData) continue
      val typeLabel = NexusMemoryType.entries.firstOrNull { it.name == entry.memoryType }?.titleHe ?: "זיכרון"
      val line = "- [$typeLabel] ${entry.title}: ${check.sanitizedPreview.take(150)}"
      if (sb.length + line.length + 2 > maxChars) break
      sb.appendLine(line)
    }
    return sb.toString().trim()
  }

  fun detectAutoMemoryCandidate(userMessage: String): Triple<NexusMemoryType, String, String>? {
    val trimmed = userMessage.trim()
    if (trimmed.length < 6 || trimmed.length > 420) return null
    val lower = trimmed.lowercase()

    val explicitSave =
      lower.startsWith("זכור ש") ||
        lower.startsWith("תזכור ש") ||
        lower.contains("זכור זאת") ||
        lower.startsWith("remember that")

    val preferenceSave =
      lower.contains("אני מעדיף") ||
        lower.contains("העדפה שלי") ||
        lower.contains("תמיד תעדיף") ||
        lower.contains("אל תשמור")

    val projectSave =
      lower.contains("אני עובד על פרויקט") ||
        lower.contains("הפרויקט שלי") ||
        lower.contains("המטרה שלי השבוע")

    val decisionSave =
      lower.contains("החלטנו ש") ||
        lower.contains("החלטתי ל")

    return when {
      explicitSave -> {
        val cleanContent = trimmed.removePrefix("זכור ש").removePrefix("תזכור ש").trim()
        if (cleanContent.isBlank()) null
        else Triple(NexusMemoryType.LONG_TERM, "זיכרון מפורש מהשיחה", cleanContent)
      }
      preferenceSave -> Triple(NexusMemoryType.PREFERENCE, "העדפת עבודה", trimmed)
      projectSave -> Triple(NexusMemoryType.PROJECT, "פרויקט פעיל", trimmed)
      decisionSave -> Triple(NexusMemoryType.DECISION, "החלטת משתמש", trimmed)
      else -> null
    }
  }
}

sealed interface MemorySaveResult {
  data class Saved(val id: Long, val entry: MemoryEntryEntity) : MemorySaveResult
  data class BlockedSecret(val reasonHe: String) : MemorySaveResult
  data class Invalid(val reasonHe: String) : MemorySaveResult
}

class NexusMemoryManager(private val dao: MemoryEntryDao) {

  fun observeAll(): Flow<List<MemoryEntryEntity>> = dao.observeAll()

  suspend fun saveMemory(
    type: NexusMemoryType,
    title: String,
    content: String,
    categoryTag: String = "כללי",
    canPersist: Boolean = true,
    importanceScore: Int = 60,
    nowMillis: Long = System.currentTimeMillis()
  ): MemorySaveResult {
    val cleanTitle = title.trim().take(80)
    val cleanContent = content.trim().take(800)
    if (cleanTitle.isBlank() || cleanContent.isBlank()) {
      return MemorySaveResult.Invalid("יש להזין כותרת ותוכן לזיכרון.")
    }
    val secretCheck = NexusMemorySecretFilter.inspect(cleanTitle, cleanContent)
    if (secretCheck.containsSensitiveData) {
      return MemorySaveResult.BlockedSecret(
        secretCheck.reasonHe ?: "שמירת מידע רגיש או סיסמה בזיכרון חסומה מטעמי אבטחה."
      )
    }

    val entry =
      MemoryEntryEntity(
        memoryType = type.name,
        title = cleanTitle,
        content = cleanContent,
        categoryTag = categoryTag.trim().ifBlank { "כללי" }.take(32),
        canPersist = canPersist && type != NexusMemoryType.SHORT_TERM,
        importanceScore = importanceScore.coerceIn(1, 100),
        createdAtMillis = nowMillis,
        updatedAtMillis = nowMillis,
        lastAccessedMillis = nowMillis
      )
    val id = dao.insert(entry)
    return MemorySaveResult.Saved(id = id, entry = entry.copy(id = id))
  }

  suspend fun updateMemory(
    existing: MemoryEntryEntity,
    newTitle: String,
    newContent: String,
    newType: NexusMemoryType,
    canPersist: Boolean,
    nowMillis: Long = System.currentTimeMillis()
  ): MemorySaveResult {
    val cleanTitle = newTitle.trim().take(80)
    val cleanContent = newContent.trim().take(800)
    if (cleanTitle.isBlank() || cleanContent.isBlank()) {
      return MemorySaveResult.Invalid("הכותרת והתוכן אינם יכולים להיות ריקים.")
    }
    val secretCheck = NexusMemorySecretFilter.inspect(cleanTitle, cleanContent)
    if (secretCheck.containsSensitiveData) {
      return MemorySaveResult.BlockedSecret(
        secretCheck.reasonHe ?: "לא ניתן לשמור סיסמאות, קודים או מפתחות API בזיכרון."
      )
    }
    val updated =
      existing.copy(
        title = cleanTitle,
        content = cleanContent,
        memoryType = newType.name,
        canPersist = canPersist,
        updatedAtMillis = nowMillis,
        lastAccessedMillis = nowMillis
      )
    dao.update(updated)
    return MemorySaveResult.Saved(id = updated.id, entry = updated)
  }

  suspend fun togglePersistAllowed(entry: MemoryEntryEntity) {
    dao.update(
      entry.copy(
        canPersist = !entry.canPersist,
        updatedAtMillis = System.currentTimeMillis()
      )
    )
  }

  suspend fun deleteMemory(id: Long) = dao.deleteById(id)

  suspend fun clearShortTerm() = dao.clearShortTerm()

  suspend fun buildContextForPrompt(maxEntries: Int = 8): String {
    val items = dao.getActivePersistableOnce(limit = maxEntries * 2)
    return MemoryContextBuilder.buildPromptContext(items, maxEntries = maxEntries)
  }

  suspend fun maybeExtractFromUserMessage(userMessage: String, autoSaveEnabled: Boolean): MemorySaveResult? {
    if (!autoSaveEnabled) return null
    val candidate = MemoryContextBuilder.detectAutoMemoryCandidate(userMessage) ?: return null
    val (type, title, content) = candidate
    return saveMemory(
      type = type,
      title = title,
      content = content,
      categoryTag = "אוטומטי-משיחה",
      canPersist = true,
      importanceScore = 70
    )
  }
}

data class ToolLearningSummary(
  val toolId: String,
  val toolNameHe: String,
  val totalRuns: Int,
  val successCount: Int,
  val failureCount: Int,
  val successRatePercent: Int,
  val avgLatencyMs: Long,
  val isFlaggedDegraded: Boolean,
  val lastErrorHe: String?
)

data class RecurringPatternSuggestion(
  val patternKey: String,
  val count: Int,
  val recommendationHe: String
)

data class LearningInsightsSnapshot(
  val totalFeedbackCount: Int,
  val positiveFeedbackCount: Int,
  val negativeFeedbackCount: Int,
  val toolSummaries: List<ToolLearningSummary>,
  val degradedTools: List<ToolLearningSummary>,
  val recurringSuggestions: List<RecurringPatternSuggestion>,
  val safetyBoundaryNoteHe: String =
    "גבול בטיחות קשיח: מנוע הלמידה מתעד מדדי הצלחה והעדפות בלבד — אינו משנה הרשאות, אבטחה או קוד מערכת."
)

/**
 * Pure-Kotlin analytics + persistent improvement tracker.
 */
object LearningAnalyticsCalculator {
  fun buildSnapshot(
    usageLogs: List<ToolUsageEntity>,
    learningRecords: List<LearningRecordEntity>
  ): LearningInsightsSnapshot {
    val activeRecords = learningRecords.filter { !it.undone }
    val groupedTools = usageLogs.groupBy { it.toolId }
    val summaries =
      groupedTools.entries.map { (toolId, runs) ->
        val total = runs.size
        val ok = runs.count { it.succeeded }
        val fail = total - ok
        val rate = if (total > 0) ((ok * 100f) / total).toInt() else 100
        val avgLat = if (total > 0) runs.map { it.latencyMs }.average().toLong() else 0L
        val lastErr = runs.firstOrNull { !it.succeeded && !it.errorHe.isNullOrBlank() }?.errorHe
        val isDegraded = total >= 3 && rate < 50
        ToolLearningSummary(
          toolId = toolId,
          toolNameHe = runs.firstOrNull()?.toolNameHe ?: toolId,
          totalRuns = total,
          successCount = ok,
          failureCount = fail,
          successRatePercent = rate,
          avgLatencyMs = avgLat,
          isFlaggedDegraded = isDegraded,
          lastErrorHe = lastErr
        )
      }.sortedByDescending { it.totalRuns }

    val recurring =
      activeRecords
        .filter { it.category == "RECURRING_TASK" }
        .groupBy { it.targetKey }
        .mapNotNull { (key, list) ->
          if (list.size >= 2) {
            RecurringPatternSuggestion(
              patternKey = key,
              count = list.size,
              recommendationHe = "זוהתה בקשה חוזרת (${list.size} פעמים): \"$key\" — מומלץ להפוך אותה לאוטומציה מתוזמנת."
            )
          } else null
        }

    return LearningInsightsSnapshot(
      totalFeedbackCount = activeRecords.count { it.userRating != 0 },
      positiveFeedbackCount = activeRecords.count { it.userRating > 0 },
      negativeFeedbackCount = activeRecords.count { it.userRating < 0 },
      toolSummaries = summaries,
      degradedTools = summaries.filter { it.isFlaggedDegraded },
      recurringSuggestions = recurring
    )
  }
}

class NexusLearningEngine(
  private val learningDao: LearningRecordDao,
  private val toolUsageDao: ToolUsageDao
) {
  fun observeRecords(): Flow<List<LearningRecordEntity>> = learningDao.observeRecords()

  fun observeToolUsage(): Flow<List<ToolUsageEntity>> = toolUsageDao.observeUsage()

  suspend fun recordToolRun(
    toolId: String,
    toolNameHe: String,
    succeeded: Boolean,
    latencyMs: Long,
    summaryHe: String,
    errorHe: String? = null
  ) {
    toolUsageDao.insert(
      ToolUsageEntity(
        toolId = toolId,
        toolNameHe = toolNameHe,
        succeeded = succeeded,
        latencyMs = latencyMs.coerceAtLeast(1L),
        summaryHe = summaryHe.take(220),
        errorHe = errorHe?.take(220),
        timestampMillis = System.currentTimeMillis()
      )
    )
  }

  suspend fun recordAssistantFeedback(
    querySummary: String,
    positive: Boolean,
    providerLabel: String
  ) {
    val safeTarget = NexusMemorySecretFilter.inspect("feedback", querySummary).sanitizedPreview.take(70)
    learningDao.insert(
      LearningRecordEntity(
        category = "ASSISTANT_FEEDBACK",
        targetKey = safeTarget.ifBlank { "assistant_reply" },
        summaryHe =
          if (positive) "משוב חיובי על תשובה ($providerLabel)"
          else "משוב לשיפור תשובה ($providerLabel) — יועדף הסבר ממוקד יותר להבא",
        succeeded = positive,
        userRating = if (positive) 1 else -1,
        reversiblePatchJson = "{\"provider\":\"$providerLabel\",\"rating\":${if (positive) 1 else -1}}",
        undone = false,
        createdAtMillis = System.currentTimeMillis()
      )
    )
  }

  suspend fun trackTaskGoalPattern(goal: String) {
    val cleanGoal = NexusMemorySecretFilter.inspect("goal", goal).sanitizedPreview.take(64)
    if (cleanGoal.length < 4) return
    learningDao.insert(
      LearningRecordEntity(
        category = "RECURRING_TASK",
        targetKey = cleanGoal,
        summaryHe = "תיעוד הרצת משימה: $cleanGoal",
        succeeded = true,
        userRating = 0,
        reversiblePatchJson = "{\"goal\":\"$cleanGoal\"}",
        undone = false,
        createdAtMillis = System.currentTimeMillis()
      )
    )
  }

  suspend fun undoLearningChange(id: Long): Boolean {
    val record = learningDao.getById(id) ?: return false
    if (record.undone) return false
    learningDao.markUndone(id)
    return true
  }

  suspend fun computeInsights(): LearningInsightsSnapshot {
    val usage = toolUsageDao.getRecentOnce()
    val records = learningDao.getRecentOnce()
    return LearningAnalyticsCalculator.buildSnapshot(usage, records)
  }
}
