package com.example.data.system

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.storage.StorageManager
import android.provider.Settings
import com.example.data.model.SystemShortcutId
import com.example.data.model.SystemShortcutItem

data class IntentLaunchOutcome(
  val succeeded: Boolean,
  val message: String,
  val failureReason: String? = null
)

class SystemControlHelper(private val context: Context) {

  fun buildShortcuts(hasSamsungDeviceCare: Boolean): List<SystemShortcutItem> {
    val items =
      mutableListOf(
        SystemShortcutItem(SystemShortcutId.WIFI, "Wi-Fi ואינטרנט", "פתיחת פאנל חיבוריות ורשת אלחוטית"),
        SystemShortcutItem(SystemShortcutId.BLUETOOTH, "Bluetooth", "ניהול התקנים ואביזרים אלחוטיים"),
        SystemShortcutItem(SystemShortcutId.DISPLAY, "הגדרות תצוגה", "רזולוציה, קצב ריענון ומצב כהה"),
        SystemShortcutItem(SystemShortcutId.BRIGHTNESS, "בהירות מסך", "פתיחת בקרת בהירות מערכת"),
        SystemShortcutItem(SystemShortcutId.SOUND, "צלילים ועוצמת שמע", "בקרת מדיה, צלצול והתראות"),
        SystemShortcutItem(SystemShortcutId.BATTERY, "סוללה וצריכת חשמל", "חיסכון בסוללה ואופטימיזציית יישומים"),
        SystemShortcutItem(SystemShortcutId.STORAGE, "אחסון ומנהל מקום", "ממשק האחסון הרשמי של Android 10"),
        SystemShortcutItem(SystemShortcutId.APPS, "ניהול אפליקציות", "הרשאות, מטמון והסרת יישומים"),
        SystemShortcutItem(SystemShortcutId.PERMISSIONS, "פרטיות והרשאות", "ניהול גישת מצלמה, מיקום ומיקרופון"),
        SystemShortcutItem(SystemShortcutId.NOTIFICATIONS, "התראות מערכת", "ניהול התראות לכל האפליקציות"),
        SystemShortcutItem(SystemShortcutId.ACCESSIBILITY, "נגישות", "כלי נגישות, טקסט וקול"),
        SystemShortcutItem(SystemShortcutId.SYSTEM_SETTINGS, "הגדרות מערכת כלליות", "פתיחת מסך ההגדרות המלא"),
        SystemShortcutItem(SystemShortcutId.USAGE_ACCESS, "הרשאת נתוני שימוש", "מאפשרת ל-NEXUS לקרוא גודל מטמון של אפליקציות")
      )

    if (hasSamsungDeviceCare) {
      items +=
        SystemShortcutItem(
          SystemShortcutId.SAMSUNG_DEVICE_CARE,
          "Samsung Device Care",
          "תחזוקה ייעודית מובנית בטאבלט Samsung"
        )
    }
    return items
  }

  fun openShortcut(id: SystemShortcutId): IntentLaunchOutcome {
    val candidates: List<Intent> =
      when (id) {
        SystemShortcutId.WIFI ->
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            listOf(
              Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY),
              Intent(Settings.ACTION_WIFI_SETTINGS)
            )
          } else {
            listOf(Intent(Settings.ACTION_WIFI_SETTINGS))
          }
        SystemShortcutId.BLUETOOTH -> listOf(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        SystemShortcutId.DISPLAY,
        SystemShortcutId.BRIGHTNESS ->
          listOf(Intent(Settings.ACTION_DISPLAY_SETTINGS), Intent(Settings.ACTION_SETTINGS))
        SystemShortcutId.SOUND ->
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            listOf(Intent(Settings.Panel.ACTION_VOLUME), Intent(Settings.ACTION_SOUND_SETTINGS))
          } else {
            listOf(Intent(Settings.ACTION_SOUND_SETTINGS))
          }
        SystemShortcutId.BATTERY ->
          listOf(
            Intent(Intent.ACTION_POWER_USAGE_SUMMARY),
            Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
          )
        SystemShortcutId.STORAGE ->
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            listOf(
              Intent(StorageManager.ACTION_MANAGE_STORAGE),
              Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
            )
          } else {
            listOf(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
          }
        SystemShortcutId.APPS -> listOf(Intent(Settings.ACTION_APPLICATION_SETTINGS))
        SystemShortcutId.PERMISSIONS ->
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            listOf(
              Intent(Settings.ACTION_PRIVACY_SETTINGS),
              Intent(Settings.ACTION_APPLICATION_SETTINGS)
            )
          } else {
            listOf(Intent(Settings.ACTION_APPLICATION_SETTINGS))
          }
        SystemShortcutId.NOTIFICATIONS ->
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            listOf(
              Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
              },
              Intent(Settings.ACTION_SETTINGS)
            )
          } else {
            listOf(Intent(Settings.ACTION_SETTINGS))
          }
        SystemShortcutId.ACCESSIBILITY -> listOf(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        SystemShortcutId.SYSTEM_SETTINGS -> listOf(Intent(Settings.ACTION_SETTINGS))
        SystemShortcutId.USAGE_ACCESS ->
          listOf(
            Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
              data = Uri.fromParts("package", context.packageName, null)
            },
            Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
          )
        SystemShortcutId.SAMSUNG_DEVICE_CARE -> {
          val pm = context.packageManager
          listOfNotNull(
            pm.getLaunchIntentForPackage("com.samsung.android.lool"),
            pm.getLaunchIntentForPackage("com.samsung.android.sm"),
            Intent(Settings.ACTION_SETTINGS)
          )
        }
      }

    for (intent in candidates) {
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      val launched = runCatching {
        context.startActivity(intent)
        true
      }.getOrDefault(false)
      if (launched) {
        return IntentLaunchOutcome(
          succeeded = true,
          message = "נפתח מסך המערכת המבוקש."
        )
      }
    }

    return IntentLaunchOutcome(
      succeeded = false,
      message = "מסך ההגדרות המבוקש אינו זמין בגרסת מערכת זו.",
      failureReason = "No activity resolved for shortcut $id"
    )
  }
}
