package com.example.data.system

import android.Manifest
import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.os.storage.StorageManager
import android.provider.Settings
import com.example.data.model.AppDiagnosticInfo
import java.io.File
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppIntelligenceProvider(
  private val context: Context,
  private val telemetryProvider: SystemTelemetryProvider
) {

  suspend fun loadApps(): List<AppDiagnosticInfo> =
    withContext(Dispatchers.IO) {
      val pm = context.packageManager
      val hasUsageAccess = telemetryProvider.hasUsageStatsPermission()
      val storageStats =
        if (hasUsageAccess && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          context.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        } else {
          null
        }
      val now = System.currentTimeMillis()
      val dormantThresholdMs = TimeUnit.DAYS.toMillis(30)
      val usageMap =
        if (hasUsageAccess) {
          runCatching {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            usm.queryAndAggregateUsageStats(now - TimeUnit.DAYS.toMillis(90), now)
          }.getOrDefault(emptyMap())
        } else {
          emptyMap()
        }

      val userHandle = Process.myUserHandle()

      val packagesMap = LinkedHashMap<String, ApplicationInfo>()
      val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
      pm.queryIntentActivities(launcherIntent, 0).forEach { resolveInfo ->
        val appInfo = resolveInfo.activityInfo?.applicationInfo
        if (appInfo != null) {
          packagesMap[appInfo.packageName] = appInfo
        }
      }

      // On Android 10 (API 29) and below, getInstalledApplications returns all packages as well
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
        @Suppress("DEPRECATION")
        pm.getInstalledApplications(PackageManager.GET_META_DATA).forEach { appInfo ->
          packagesMap.putIfAbsent(appInfo.packageName, appInfo)
        }
      }

      val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager

      packagesMap.values.map { appInfo ->
        val pkg = appInfo.packageName
        val label = runCatching { pm.getApplicationLabel(appInfo).toString() }.getOrDefault(pkg)
        val icon = runCatching { pm.getApplicationIcon(appInfo) }.getOrNull()
        val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

        val pkgInfo: PackageInfo? =
          runCatching {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
          }.getOrNull()

        val apkSize = runCatching { File(appInfo.sourceDir).length() }.getOrDefault(0L)
        var appData: Long? = null
        var cacheBytes: Long? = null
        var totalSize = apkSize

        if (storageStats != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          runCatching {
            val stats = storageStats.queryStatsForPackage(StorageManager.UUID_DEFAULT, pkg, userHandle)
            appData = stats.dataBytes
            cacheBytes = stats.cacheBytes
            totalSize = stats.appBytes + stats.dataBytes + stats.cacheBytes
          }
        }

        val usageStats = usageMap[pkg]
        val lastUsed: Long? =
          if (hasUsageAccess) usageStats?.lastTimeUsed?.takeIf { it > 0L } else null
        val fgTime: Long? =
          if (hasUsageAccess) usageStats?.totalTimeInForeground?.coerceAtLeast(0L) ?: 0L else null
        val isDormant =
          hasUsageAccess &&
            !isSystem &&
            pkg != context.packageName &&
            (lastUsed == null || (now - lastUsed) > dormantThresholdMs)

        val requested = pkgInfo?.requestedPermissions?.toList().orEmpty()
        val requestedFlags = pkgInfo?.requestedPermissionsFlags
        val grantedSensitive = mutableListOf<String>()

        requested.forEachIndexed { idx, perm ->
          val isGranted =
            requestedFlags != null &&
              idx < requestedFlags.size &&
              (requestedFlags[idx] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
          if (isGranted && isSensitivePermission(perm)) {
            grantedSensitive += perm
          }
        }

        val canDrawOverlays =
          if (Manifest.permission.SYSTEM_ALERT_WINDOW in requested) {
            runCatching {
              @Suppress("DEPRECATION")
              appOps.checkOpNoThrow(AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW, appInfo.uid, pkg) ==
                AppOpsManager.MODE_ALLOWED
            }.getOrDefault(false)
          } else false

        val canRequestInstalls =
          if (Manifest.permission.REQUEST_INSTALL_PACKAGES in requested) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
              runCatching {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                  "android:request_install_packages",
                  appInfo.uid,
                  pkg
                ) == AppOpsManager.MODE_ALLOWED
              }.getOrDefault(Manifest.permission.REQUEST_INSTALL_PACKAGES in grantedSensitive)
            } else {
              Manifest.permission.REQUEST_INSTALL_PACKAGES in grantedSensitive
            }
          } else false

        val isLaunchable = pm.getLaunchIntentForPackage(pkg) != null
        val isEnabled = appInfo.enabled

        AppDiagnosticInfo(
          packageName = pkg,
          appName = label,
          versionName = pkgInfo?.versionName ?: "—",
          isSystemApp = isSystem,
          apkSizeBytes = apkSize,
          appDataBytes = appData,
          cacheBytes = cacheBytes,
          totalSizeBytes = totalSize,
          firstInstallTime = pkgInfo?.firstInstallTime ?: 0L,
          lastUpdateTime = pkgInfo?.lastUpdateTime ?: 0L,
          requestedPermissions = requested,
          grantedSensitivePermissions = grantedSensitive,
          hasCameraPermission = Manifest.permission.CAMERA in grantedSensitive,
          hasMicPermission = Manifest.permission.RECORD_AUDIO in grantedSensitive,
          hasLocationPermission =
            Manifest.permission.ACCESS_FINE_LOCATION in grantedSensitive ||
              Manifest.permission.ACCESS_COARSE_LOCATION in grantedSensitive,
          hasBackgroundLocation =
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
              Manifest.permission.ACCESS_BACKGROUND_LOCATION in grantedSensitive,
          canDrawOverlays = canDrawOverlays,
          canRequestInstalls = canRequestInstalls,
          iconDrawable = icon,
          lastTimeUsedMillis = lastUsed,
          totalTimeInForegroundMillis = fgTime,
          isDormant = isDormant,
          isLaunchable = isLaunchable,
          isEnabled = isEnabled
        )
      }
    }

  private fun isSensitivePermission(perm: String): Boolean {
    return perm == Manifest.permission.CAMERA ||
      perm == Manifest.permission.RECORD_AUDIO ||
      perm == Manifest.permission.ACCESS_FINE_LOCATION ||
      perm == Manifest.permission.ACCESS_COARSE_LOCATION ||
      (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
        perm == Manifest.permission.ACCESS_BACKGROUND_LOCATION) ||
      perm == Manifest.permission.READ_CONTACTS ||
      perm == Manifest.permission.READ_CALL_LOG ||
      perm == Manifest.permission.READ_SMS ||
      perm == Manifest.permission.BODY_SENSORS ||
      perm == Manifest.permission.REQUEST_INSTALL_PACKAGES
  }

  fun launchApp(packageName: String): Boolean {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return runCatching {
      context.startActivity(intent)
      true
    }.getOrDefault(false)
  }

  fun openAppSettings(packageName: String): Boolean {
    val intent =
      Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
        data = android.net.Uri.fromParts("package", packageName, null)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
    return runCatching {
      context.startActivity(intent)
      true
    }.getOrDefault(false)
  }
}
