package com.example.data.system

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import com.example.data.local.TelemetrySnapshotEntity
import com.example.data.model.CategoryBreakdown
import com.example.data.model.DuplicateCopyItem
import com.example.data.model.DuplicateGroup
import com.example.data.model.FileCategory
import com.example.data.model.FolderStorageSummary
import com.example.data.model.MediaInspectionIssue
import com.example.data.model.ScannedFileEntry
import com.example.data.model.SmartStorageScanReport
import com.example.data.model.StorageForecastInfo
import com.example.data.model.StorageVolumeInfo
import com.example.data.model.StorageVolumeKind
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Pure classification & calculation helpers for Smart Storage, Duplicate Detection, and Forecast.
 * Kept unit-testable without requiring Android runtime dependencies.
 */
object StorageClassificationMath {
  private val IMAGE_EXTS = setOf("jpg", "jpeg", "png", "webp", "gif", "heic", "bmp")
  private val VIDEO_EXTS = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "m4v")
  private val AUDIO_EXTS = setOf("mp3", "wav", "m4a", "flac", "ogg", "aac", "opus")
  private val DOC_EXTS =
    setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "md")
  private val TEMP_EXTS = setOf("tmp", "temp", "log", "old", "chk", "dmp", "part", "crdownload")
  private val BACKUP_EXTS = setOf("bak", "backup", "zip", "tar", "gz", "7z", "rar")

  fun classifyFile(name: String, mimeType: String, relativePath: String): FileCategory {
    val ext = name.substringAfterLast('.', "").lowercase()
    val lowerName = name.lowercase()
    val lowerMime = mimeType.lowercase()
    val lowerPath = relativePath.lowercase()

    return when {
      ext == "apk" || lowerMime.contains("package-archive") -> FileCategory.APK_INSTALLERS
      ext in TEMP_EXTS || name.endsWith("~") || lowerName == "thumbs.db" ->
        FileCategory.TEMP_RESIDUAL
      ext in BACKUP_EXTS || lowerName.contains("backup") || lowerName.contains("גיבוי") ->
        FileCategory.BACKUPS
      ext in IMAGE_EXTS || lowerMime.startsWith("image/") -> FileCategory.IMAGES
      ext in VIDEO_EXTS || lowerMime.startsWith("video/") -> FileCategory.VIDEOS
      ext in AUDIO_EXTS || lowerMime.startsWith("audio/") -> FileCategory.AUDIO
      ext in DOC_EXTS || lowerMime.startsWith("text/") || lowerMime.contains("pdf") ->
        FileCategory.DOCUMENTS
      lowerPath.contains("download") || lowerPath.contains("הורדות") -> FileCategory.DOWNLOADS
      else -> FileCategory.OTHER
    }
  }

  fun isUnclearFilename(name: String): Boolean {
    val base = name.substringBeforeLast('.')
    if (base.length <= 2) return true
    val lower = base.lowercase()
    if (Regex("^\\d{4,}$").matches(base)) return true
    if (Regex("^(img|vid|pxl|dsc|doc|file|scan|screenshot)[_-]?\\d+.*").matches(lower)) return true
    if (Regex(".*\\(\\d+\\)$").matches(base)) return true
    if (lower.startsWith("download") || lower.startsWith("untitled") || lower.startsWith("new_file"))
      return true
    return false
  }

  fun pickRecommendedCopy(copies: List<ScannedFileEntry>): Pair<ScannedFileEntry, String> {
    val sorted =
      copies.sortedWith(
        compareBy<ScannedFileEntry>(
            { it.relativePath.lowercase().contains("download") },
            { it.isNameUnclear },
            { it.lastModifiedMillis },
            { it.relativePath.length }
          )
      )
    val best = sorted.first()
    val reason =
      when {
        !best.relativePath.lowercase().contains("download") ->
          "שמירה מומלצת: נמצא מחוץ לתיקיית ההורדות (${best.relativePath})"
        !best.isNameUnclear -> "שמירה מומלצת: שם קובץ ברור ומקורי יותר"
        else -> "שמירה מומלצת: העותק המוקדם/היציב ביותר"
      }
    return best to reason
  }

  fun computeStorageForecast(
    snapshots: List<TelemetrySnapshotEntity>,
    currentFreeBytes: Long
  ): StorageForecastInfo {
    if (snapshots.size < 2) {
      return StorageForecastInfo(
        hasEnoughHistory = false,
        dailyChangeBytes = 0L,
        estimatedDaysToFull = null,
        summaryHe = "נדרשות לפחות 2 מדידות לאורך זמן כדי לחשב מגמת אחסון אמיתית."
      )
    }
    val ordered = snapshots.sortedBy { it.timestampMillis }
    val oldest = ordered.first()
    val newest = ordered.last()
    val spanMillis = (newest.timestampMillis - oldest.timestampMillis).coerceAtLeast(0L)
    if (spanMillis < TimeUnit.MINUTES.toMillis(30)) {
      return StorageForecastInfo(
        hasEnoughHistory = false,
        dailyChangeBytes = 0L,
        estimatedDaysToFull = null,
        summaryHe = "טווח המדידות קצר מדי (פחות מ-30 דקות). התחזית תתעדכן בהמשך השימוש."
      )
    }
    val daysSpan = spanMillis.toDouble() / TimeUnit.DAYS.toMillis(1).toDouble()
    val freeDelta = oldest.storageFreeBytes - newest.storageFreeBytes // positive = storage filling up
    val dailyConsumption = (freeDelta / daysSpan).toLong()

    if (dailyConsumption <= 1024L * 1024L) {
      return StorageForecastInfo(
        hasEnoughHistory = true,
        dailyChangeBytes = dailyConsumption,
        estimatedDaysToFull = null,
        summaryHe = "קצב צריכת האחסון יציב או בירידה — לא צפוי מילוי קרוב של המכשיר."
      )
    }
    val daysLeft = (currentFreeBytes.toDouble() / dailyConsumption.toDouble()).roundToInt().coerceAtLeast(1)
    return StorageForecastInfo(
      hasEnoughHistory = true,
      dailyChangeBytes = dailyConsumption,
      estimatedDaysToFull = daysLeft,
      summaryHe = "במגמה הנוכחית (${formatBytes(dailyConsumption)} ליום), המקום הפנוי עלול להיגמר בעוד כ-$daysLeft ימים."
    )
  }
}

class SmartStorageEngine(private val context: Context) {

  companion object {
    const val LARGE_FILE_THRESHOLD_BYTES = 15L * 1024L * 1024L
    const val OLD_FILE_DAYS = 90L
    private const val MAX_FILES_PER_SCAN = 1500
    private const val MAX_MEDIA_INSPECT = 45
  }

  private data class InternalDirVisit(
    val treeUri: Uri,
    val docId: String,
    val folderName: String,
    val relativePath: String,
    val volumeKind: StorageVolumeKind
  )

  suspend fun scanSmartStorage(
    safTreeUris: Set<String>,
    telemetryHistory: List<TelemetrySnapshotEntity>,
    knownLargeIds: Set<String>
  ): SmartStorageScanReport =
    withContext(Dispatchers.IO) {
      val now = System.currentTimeMillis()
      val oldThresholdMillis = now - TimeUnit.DAYS.toMillis(OLD_FILE_DAYS)

      val internalStat = StatFs(Environment.getDataDirectory().path)
      val intTotal = internalStat.totalBytes.coerceAtLeast(1L)
      val intFree = internalStat.availableBytes.coerceIn(0L, intTotal)
      val intUsed = (intTotal - intFree).coerceAtLeast(0L)
      val intUsedPct = ((intUsed * 100.0) / intTotal).roundToInt().coerceIn(0, 100)

      val internalTrees = mutableListOf<String>()
      val sdTrees = mutableListOf<String>()
      safTreeUris.forEach { uriStr ->
        if (isSdCardTreeUri(uriStr)) sdTrees += uriStr else internalTrees += uriStr
      }

      val scannedFiles = mutableListOf<ScannedFileEntry>()
      val folders = mutableListOf<FolderStorageSummary>()
      val emptyFolders = mutableListOf<FolderStorageSummary>()
      var unreadableCount = 0

      // Scan all persisted SAF trees (Internal & SD)
      for (treeUriStr in safTreeUris) {
        val treeUri = runCatching { Uri.parse(treeUriStr) }.getOrNull() ?: continue
        val volumeKind =
          if (isSdCardTreeUri(treeUriStr)) StorageVolumeKind.SD_CARD else StorageVolumeKind.INTERNAL
        val rootDocId =
          runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull() ?: continue
        val rootLabel =
          rootDocId.substringAfterLast(':').ifBlank {
            if (volumeKind == StorageVolumeKind.SD_CARD) "שורש SD" else "תיקייה פנימית"
          }

        val queue =
          ArrayDeque<InternalDirVisit>().apply {
            add(InternalDirVisit(treeUri, rootDocId, rootLabel, rootLabel, volumeKind))
          }

        val projection =
          arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
          )

        while (queue.isNotEmpty() && scannedFiles.size < MAX_FILES_PER_SCAN) {
          val dir = queue.removeFirst()
          var childFiles = 0
          var childDirs = 0
          var dirBytes = 0L

          val childrenUri =
            DocumentsContract.buildChildDocumentsUriUsingTree(dir.treeUri, dir.docId)
          try {
            queryDocuments(childrenUri, projection)?.use { cursor ->
              val idIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
              val nameIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
              val mimeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
              val sizeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
              val modIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)

              while (cursor.moveToNext() && scannedFiles.size < MAX_FILES_PER_SCAN) {
                val docId = if (idIdx >= 0) cursor.getString(idIdx) else continue
                val name = if (nameIdx >= 0) cursor.getString(nameIdx) ?: "קובץ" else "קובץ"
                val mime = if (mimeIdx >= 0) cursor.getString(mimeIdx) ?: "" else ""
                val childRelPath = "${dir.relativePath}/$name"

                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                  childDirs++
                  queue.add(InternalDirVisit(dir.treeUri, docId, name, childRelPath, dir.volumeKind))
                } else {
                  val size =
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) cursor.getLong(sizeIdx).coerceAtLeast(0L)
                    else 0L
                  val mod =
                    if (modIdx >= 0 && !cursor.isNull(modIdx)) cursor.getLong(modIdx) else 0L
                  val docUri = DocumentsContract.buildDocumentUriUsingTree(dir.treeUri, docId)
                  val category = StorageClassificationMath.classifyFile(name, mime, childRelPath)
                  val isLarge = size >= LARGE_FILE_THRESHOLD_BYTES
                  val isOld = mod > 0L && mod < oldThresholdMillis
                  val entryId = docUri.toString()

                  scannedFiles +=
                    ScannedFileEntry(
                      uriString = entryId,
                      treeUriString = treeUriStr,
                      parentDocId = dir.docId,
                      docId = docId,
                      name = name,
                      relativePath = childRelPath,
                      mimeType = mime,
                      sizeBytes = size,
                      lastModifiedMillis = mod,
                      category = category,
                      volumeKind = dir.volumeKind,
                      isOldUnused = isOld,
                      isLargeFile = isLarge,
                      isNewlyDetectedLarge = isLarge && knownLargeIds.isNotEmpty() && entryId !in knownLargeIds,
                      isTempResidual = category == FileCategory.TEMP_RESIDUAL || size == 0L,
                      isInstallerApk = category == FileCategory.APK_INSTALLERS,
                      isBackupArchive = category == FileCategory.BACKUPS,
                      isNameUnclear = StorageClassificationMath.isUnclearFilename(name)
                    )
                  childFiles++
                  dirBytes += size
                }
              }
            }
          } catch (_: SecurityException) {
            unreadableCount++
          } catch (_: Exception) {
            unreadableCount++
          }

          val isDirEmpty = childFiles == 0 && childDirs == 0 && dir.docId != rootDocId
          val summary =
            FolderStorageSummary(
              treeUriString = treeUriStr,
              docId = dir.docId,
              folderName = dir.folderName,
              relativePath = dir.relativePath,
              volumeKind = dir.volumeKind,
              fileCount = childFiles,
              totalBytes = dirBytes,
              isEmpty = isDirEmpty
            )
          folders += summary
          if (isDirEmpty) {
            emptyFolders += summary
          }
        }
      }

      // Flag duplicate folder names across different paths
      val dupFolderNames =
        folders
          .groupBy { it.folderName.lowercase() }
          .filter { (name, list) -> name.length > 2 && list.size > 1 }
          .keys
      val foldersMarked =
        folders.map { folder ->
          if (folder.folderName.lowercase() in dupFolderNames) {
            folder.copy(isDuplicateFolderName = true)
          } else folder
        }

      // Real SHA-256 Duplicate Detector across all SAF files (4 KB .. 80 MB)
      val duplicateGroups = computeDuplicateGroups(scannedFiles)

      // Media Integrity Inspector (bounded for weak-tablet safety)
      val mediaIssues = inspectMediaSample(scannedFiles)

      // Category breakdown
      val totalScannedBytes = scannedFiles.sumOf { it.sizeBytes }.coerceAtLeast(1L)
      val categories =
        FileCategory.entries
          .map { cat ->
            val matching = scannedFiles.filter { it.category == cat }
            val sum = matching.sumOf { it.sizeBytes }
            CategoryBreakdown(
              category = cat,
              totalBytes = sum,
              fileCount = matching.size,
              percentOfScanned = ((sum * 100.0) / totalScannedBytes).roundToInt().coerceIn(0, 100)
            )
          }
          .filter { it.fileCount > 0 }
          .sortedByDescending { it.totalBytes }

      // Detect removable SD Card hardware volumes via StorageManager
      val volumes = buildVolumeList(intTotal, intFree, intUsed, intUsedPct, internalTrees, sdTrees, scannedFiles, unreadableCount)

      val forecast = StorageClassificationMath.computeStorageForecast(telemetryHistory, intFree)
      val newlyLarge = scannedFiles.filter { it.isNewlyDetectedLarge }
      val dupWaste = duplicateGroups.sumOf { it.reclaimableBytes }
      val tempWaste = scannedFiles.filter { it.isTempResidual }.sumOf { it.sizeBytes }

      SmartStorageScanReport(
        scannedAtMillis = now,
        volumes = volumes,
        files = scannedFiles,
        folders = foldersMarked.sortedByDescending { it.totalBytes },
        emptyFolders = emptyFolders,
        categories = categories,
        duplicateGroups = duplicateGroups,
        mediaIssues = mediaIssues,
        unreadableCount = unreadableCount,
        newlyLargeFiles = newlyLarge,
        forecast = forecast,
        totalScannedFilesBytes = scannedFiles.sumOf { it.sizeBytes },
        totalDuplicateWasteBytes = dupWaste,
        totalTempWasteBytes = tempWaste
      )
    }

  private fun buildVolumeList(
    intTotal: Long,
    intFree: Long,
    intUsed: Long,
    intUsedPct: Int,
    internalTrees: List<String>,
    sdTrees: List<String>,
    scannedFiles: List<ScannedFileEntry>,
    unreadableCount: Int
  ): List<StorageVolumeInfo> {
    val result = mutableListOf<StorageVolumeInfo>()
    val internalFileCount = scannedFiles.count { it.volumeKind == StorageVolumeKind.INTERNAL }
    result +=
      StorageVolumeInfo(
        id = "internal_primary",
        label = "אחסון פנימי",
        kind = StorageVolumeKind.INTERNAL,
        isMounted = true,
        totalBytes = intTotal,
        freeBytes = intFree,
        usedBytes = intUsed,
        usedPercent = intUsedPct,
        authorizedTreeUris = internalTrees,
        fileCountScanned = internalFileCount
      )

    val sm = context.getSystemService(Context.STORAGE_SERVICE) as StorageManager
    val sdVolumes = sm.storageVolumes.filter { it.isRemovable && !it.isPrimary }
    val sdFileCount = scannedFiles.count { it.volumeKind == StorageVolumeKind.SD_CARD }

    if (sdVolumes.isEmpty() && sdTrees.isEmpty()) {
      result +=
        StorageVolumeInfo(
          id = "sd_absent",
          label = "כרטיס SD חיצוני (לא זוהה)",
          kind = StorageVolumeKind.SD_CARD,
          isMounted = false,
          totalBytes = null,
          freeBytes = null,
          usedBytes = null,
          usedPercent = null,
          authorizedTreeUris = emptyList(),
          fileCountScanned = 0,
          sdHealthSummaryHe = "לא זוהה כרטיס זיכרון חיצוני מחובר במכשיר כרגע."
        )
    } else {
      sdVolumes.forEachIndexed { index, vol ->
        val mounted = vol.state == Environment.MEDIA_MOUNTED || vol.state == Environment.MEDIA_MOUNTED_READ_ONLY
        val desc = runCatching { vol.getDescription(context) }.getOrNull() ?: "כרטיס SD ${index + 1}"
        var totalB: Long? = null
        var freeB: Long? = null
        var usedB: Long? = null
        var usedPct: Int? = null

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
          vol.directory?.let { dir ->
            runCatching {
              val st = StatFs(dir.path)
              totalB = st.totalBytes
              freeB = st.availableBytes
              usedB = (st.totalBytes - st.availableBytes).coerceAtLeast(0L)
              usedPct = if (st.totalBytes > 0) ((usedB!! * 100.0) / st.totalBytes).roundToInt() else null
            }
          }
        }
        // Fallback for Android 10 (API 29): try externalMediaDirs / getExternalFilesDirs on removable volume if matched
        if (totalB == null && mounted) {
          context.getExternalFilesDirs(null).drop(1).firstOrNull()?.let { sdAppDir ->
            runCatching {
              val st = StatFs(sdAppDir.path)
              totalB = st.totalBytes
              freeB = st.availableBytes
              usedB = (st.totalBytes - st.availableBytes).coerceAtLeast(0L)
              usedPct = if (st.totalBytes > 0) ((usedB!! * 100.0) / st.totalBytes).roundToInt() else null
            }
          }
        }

        val healthNote =
          when {
            !mounted -> "הכרטיס מנותק או במצב קריאה בלבד (${vol.state})."
            vol.state == Environment.MEDIA_MOUNTED_READ_ONLY ->
              "התראה: הכרטיס במצב קריאה בלבד — בדוק נעילת כתיבה או תקינות כרטיס."
            sdTrees.isEmpty() ->
              "כרטיס SD זוהה! בחר תיקיית כרטיס SD דרך הרשאת SAF כדי לסרוק ולנהל קבצים."
            unreadableCount > 0 ->
              "נסרקו $sdFileCount קבצים, אך זוהו $unreadableCount תיקיות/קבצים שלא ניתן לקרוא."
            else ->
              "כרטיס SD מחובר ותקין. נסרקו $sdFileCount קבצים מתיקיות מאושרות."
          }

        result +=
          StorageVolumeInfo(
            id = "sd_${vol.uuid ?: index}",
            label = desc,
            kind = StorageVolumeKind.SD_CARD,
            isMounted = mounted,
            totalBytes = totalB,
            freeBytes = freeB,
            usedBytes = usedB,
            usedPercent = usedPct,
            authorizedTreeUris = sdTrees,
            fileCountScanned = sdFileCount,
            sdHealthSummaryHe = healthNote
          )
      }
      if (sdVolumes.isEmpty() && sdTrees.isNotEmpty()) {
        result +=
          StorageVolumeInfo(
            id = "sd_saf_only",
            label = "כרטיס SD (SAF)",
            kind = StorageVolumeKind.SD_CARD,
            isMounted = true,
            totalBytes = null,
            freeBytes = null,
            usedBytes = null,
            usedPercent = null,
            authorizedTreeUris = sdTrees,
            fileCountScanned = sdFileCount,
            sdHealthSummaryHe = "מחובר דרך הרשאת SAF. נסרקו $sdFileCount קבצים."
          )
      }
    }

    return result
  }

  private fun computeDuplicateGroups(files: List<ScannedFileEntry>): List<DuplicateGroup> {
    val sizeGroups =
      files
        .filter { it.sizeBytes in 4096L..(80L * 1024L * 1024L) }
        .groupBy { it.sizeBytes }
        .filterValues { it.size > 1 }

    val groups = mutableListOf<DuplicateGroup>()
    for ((_, sameSize) in sizeGroups) {
      val byHash = mutableMapOf<String, MutableList<ScannedFileEntry>>()
      for (entry in sameSize) {
        val hash = computeUriSha256(Uri.parse(entry.uriString)) ?: continue
        byHash.getOrPut(hash) { mutableListOf() }.add(entry.copy(sha256 = hash))
      }
      for ((hash, dupEntries) in byHash) {
        if (dupEntries.size > 1) {
          val (best, reason) = StorageClassificationMath.pickRecommendedCopy(dupEntries)
          val distinctNames = dupEntries.map { it.name.lowercase() }.distinct().size > 1
          val copyItems =
            dupEntries
              .sortedByDescending { it.uriString == best.uriString }
              .map { f ->
                val isKeep = f.uriString == best.uriString
                DuplicateCopyItem(
                  uriString = f.uriString,
                  treeUriString = f.treeUriString,
                  docId = f.docId,
                  parentDocId = f.parentDocId,
                  name = f.name,
                  relativePath = f.relativePath,
                  volumeKind = f.volumeKind,
                  sizeBytes = f.sizeBytes,
                  lastModifiedMillis = f.lastModifiedMillis,
                  recommendedKeep = isKeep,
                  keepReasonHe = if (isKeep) reason else "עותק זהה (SHA-256) — ניתן לבחור למחיקה באישור"
                )
              }
          groups +=
            DuplicateGroup(
              id = "dup_${hash.take(12)}",
              sha256 = hash,
              category = best.category,
              fileSizeBytes = best.sizeBytes,
              hasDifferentNames = distinctNames,
              copies = copyItems
            )
        }
      }
    }
    return groups.sortedByDescending { it.reclaimableBytes }
  }

  private fun inspectMediaSample(files: List<ScannedFileEntry>): List<MediaInspectionIssue> {
    val issues = mutableListOf<MediaInspectionIssue>()
    val candidates =
      files
        .filter { it.category == FileCategory.IMAGES || it.category == FileCategory.VIDEOS }
        .take(MAX_MEDIA_INSPECT)

    for (entry in candidates) {
      if (entry.sizeBytes == 0L) {
        issues +=
          MediaInspectionIssue(
            uriString = entry.uriString,
            name = entry.name,
            relativePath = entry.relativePath,
            isVideo = entry.category == FileCategory.VIDEOS,
            sizeBytes = 0L,
            reasonHe = "קובץ מדיה בגודל 0 בתים — ריק או פגום."
          )
        continue
      }
      val uri = Uri.parse(entry.uriString)
      if (entry.category == FileCategory.IMAGES) {
        val ok =
          runCatching {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
              BitmapFactory.decodeStream(stream, null, opts)
            }
            opts.outWidth > 0 && opts.outHeight > 0
          }.getOrDefault(false)
        if (!ok) {
          issues +=
            MediaInspectionIssue(
              uriString = entry.uriString,
              name = entry.name,
              relativePath = entry.relativePath,
              isVideo = false,
              sizeBytes = entry.sizeBytes,
              reasonHe = "לא ניתן לפענח את כותרות התמונה — ייתכן שהקובץ פגום או לא הורד במלואו."
            )
        }
      } else {
        val ok =
          runCatching {
            val mmr = MediaMetadataRetriever()
            try {
              mmr.setDataSource(context, uri)
              val duration = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
              !duration.isNullOrBlank()
            } finally {
              runCatching { mmr.release() }
            }
          }.getOrDefault(false)
        if (!ok) {
          issues +=
            MediaInspectionIssue(
              uriString = entry.uriString,
              name = entry.name,
              relativePath = entry.relativePath,
              isVideo = true,
              sizeBytes = entry.sizeBytes,
              reasonHe = "מטא-נתוני הווידאו אינם קריאים — ייתכן שהקובץ חלקי או לא נתמך."
            )
        }
      }
    }
    return issues
  }

  fun computeUriSha256(docUri: Uri): String? {
    return try {
      val digest = MessageDigest.getInstance("SHA-256")
      val buffer = ByteArray(16 * 1024)
      context.contentResolver.openInputStream(docUri)?.use { input ->
        var read = input.read(buffer)
        while (read != -1) {
          digest.update(buffer, 0, read)
          read = input.read(buffer)
        }
      } ?: return null
      digest.digest().joinToString("") { "%02x".format(it) }
    } catch (_: Exception) {
      null
    }
  }

  fun isSdCardTreeUri(uriString: String): Boolean {
    val docId =
      runCatching { DocumentsContract.getTreeDocumentId(Uri.parse(uriString)) }.getOrNull().orEmpty()
    val vol = docId.substringBefore(':', "")
    return vol.isNotBlank() && !vol.equals("primary", ignoreCase = true)
  }

  fun resolveMimeType(
    docUri: Uri,
    fileName: String,
    explicitMime: String? = null
  ): String {
    val cleanExplicit = explicitMime?.trim().orEmpty()
    if (cleanExplicit.isNotEmpty() &&
      !cleanExplicit.equals("application/octet-stream", ignoreCase = true) &&
      cleanExplicit != DocumentsContract.Document.MIME_TYPE_DIR
    ) {
      return cleanExplicit
    }

    val queriedMime =
      runCatching {
        queryDocuments(
          docUri,
          arrayOf(DocumentsContract.Document.COLUMN_MIME_TYPE)
        )?.use { cursor ->
          if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getString(0)?.trim() else null
        }
      }.getOrNull()
    if (!queriedMime.isNullOrBlank() &&
      !queriedMime.equals("application/octet-stream", ignoreCase = true) &&
      queriedMime != DocumentsContract.Document.MIME_TYPE_DIR
    ) {
      return queriedMime
    }

    val resolverType =
      runCatching { context.contentResolver.getType(docUri)?.trim() }.getOrNull()
    if (!resolverType.isNullOrBlank() &&
      !resolverType.equals("application/octet-stream", ignoreCase = true) &&
      resolverType != DocumentsContract.Document.MIME_TYPE_DIR
    ) {
      return resolverType
    }

    return guessMimeTypeByExtension(fileName)
  }

  fun guessMimeTypeByExtension(fileName: String): String {
    return when (fileName.substringAfterLast('.', "").lowercase(java.util.Locale.ROOT)) {
      "jpg", "jpeg" -> "image/jpeg"
      "png" -> "image/png"
      "webp" -> "image/webp"
      "gif" -> "image/gif"
      "heic" -> "image/heic"
      "bmp" -> "image/bmp"
      "mp4" -> "video/mp4"
      "mkv" -> "video/x-matroska"
      "avi" -> "video/x-msvideo"
      "mov" -> "video/quicktime"
      "webm" -> "video/webm"
      "3gp" -> "video/3gpp"
      "m4v" -> "video/x-m4v"
      "mp3" -> "audio/mpeg"
      "wav" -> "audio/wav"
      "m4a" -> "audio/mp4"
      "flac" -> "audio/flac"
      "ogg" -> "audio/ogg"
      "aac" -> "audio/aac"
      "opus" -> "audio/opus"
      "pdf" -> "application/pdf"
      "txt", "log", "md", "rtf" -> "text/plain"
      "csv" -> "text/csv"
      "json" -> "application/json"
      "xml" -> "application/xml"
      "html", "htm" -> "text/html"
      "doc" -> "application/msword"
      "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      "xls" -> "application/vnd.ms-excel"
      "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      "ppt" -> "application/vnd.ms-powerpoint"
      "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
      "zip" -> "application/zip"
      "apk" -> "application/vnd.android.package-archive"
      else -> "application/octet-stream"
    }
  }

  fun resolveParentDocId(
    treeUri: Uri,
    docUri: Uri,
    scannedFiles: List<ScannedFileEntry> = emptyList()
  ): String? {
    val targetDocId = runCatching { DocumentsContract.getDocumentId(docUri) }.getOrNull() ?: return null
    val treeStr = treeUri.toString()

    // 1. Check cached scan entries first (exact parentDocId captured during scan)
    scannedFiles.firstOrNull {
      it.uriString == docUri.toString() ||
        (it.treeUriString == treeStr && it.docId == targetDocId)
    }?.let { match ->
      if (match.parentDocId.isNotBlank() && isDirectChildOf(treeUri, match.parentDocId, targetDocId)) {
        return match.parentDocId
      }
    }

    // 2. Deterministic BFS inside the SAF tree to locate the exact parent folder containing targetDocId
    val rootDocId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull() ?: return null
    if (targetDocId == rootDocId) return rootDocId

    val queue = ArrayDeque<String>().apply { add(rootDocId) }
    val visited = HashSet<String>()
    val projection =
      arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_MIME_TYPE
      )

    while (queue.isNotEmpty() && visited.size < 2000) {
      val currentDirId = queue.removeFirst()
      if (!visited.add(currentDirId)) continue

      val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, currentDirId)
      runCatching {
        queryDocuments(childrenUri, projection)?.use { cursor ->
          val idIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
          val mimeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
          while (cursor.moveToNext()) {
            val childId = if (idIdx >= 0) cursor.getString(idIdx) else continue
            if (childId == targetDocId) {
              return currentDirId
            }
            val mime = if (mimeIdx >= 0) cursor.getString(mimeIdx) else ""
            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
              queue.add(childId)
            }
          }
        }
      }
    }

    // 3. Fallback ExternalStorageProvider docId path heuristic ("vol:a/b/c.jpg" -> "vol:a/b")
    val colonIdx = targetDocId.indexOf(':')
    if (colonIdx > 0) {
      val volPrefix = targetDocId.substring(0, colonIdx + 1)
      val rel = targetDocId.substring(colonIdx + 1)
      if (rel.contains('/')) {
        val candidateParent = volPrefix + rel.substringBeforeLast('/')
        if (isDirectChildOf(treeUri, candidateParent, targetDocId)) return candidateParent
      } else if (isDirectChildOf(treeUri, rootDocId, targetDocId)) {
        return rootDocId
      }
    }

    return null
  }

  fun resolveTreeUriForDocUri(
    docUri: Uri,
    authorizedTreeUris: Set<String>,
    fallbackTreeUri: Uri? = null
  ): Uri? {
    val embeddedTreeId = runCatching { DocumentsContract.getTreeDocumentId(docUri) }.getOrNull()
    val docAuth = docUri.authority
    if (!embeddedTreeId.isNullOrBlank()) {
      authorizedTreeUris
        .mapNotNull { runCatching { Uri.parse(it) }.getOrNull() }
        .firstOrNull { candidate ->
          candidate.authority == docAuth &&
            runCatching { DocumentsContract.getTreeDocumentId(candidate) }.getOrNull() == embeddedTreeId
        }?.let { return it }

      // Reconstruct canonical tree URI if embedded inside the document URI
      runCatching {
        DocumentsContract.buildTreeDocumentUri(docAuth ?: return@runCatching null, embeddedTreeId)
      }.getOrNull()?.let { return it }
    }

    val targetDocId = runCatching { DocumentsContract.getDocumentId(docUri) }.getOrNull()
    if (targetDocId != null) {
      for (treeStr in authorizedTreeUris) {
        val candidate = runCatching { Uri.parse(treeStr) }.getOrNull() ?: continue
        val rootId = runCatching { DocumentsContract.getTreeDocumentId(candidate) }.getOrNull() ?: continue
        val sameVol = targetDocId.substringBefore(':') == rootId.substringBefore(':')
        if (sameVol && resolveParentDocId(candidate, docUri) != null) {
          return candidate
        }
      }
    }
    return fallbackTreeUri
  }

  private fun isDirectChildOf(treeUri: Uri, parentDocId: String, childDocId: String): Boolean {
    val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
    return runCatching {
      queryDocuments(
        childrenUri,
        arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
      )?.use { cursor ->
        while (cursor.moveToNext()) {
          if (cursor.getString(0) == childDocId) return true
        }
        false
      } ?: false
    }.getOrDefault(false)
  }

  fun findChildByName(treeUri: Uri, parentDocId: String, targetName: String): Pair<String, Uri>? {
    val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
    val projection =
      arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME
      )
    return runCatching {
      queryDocuments(childrenUri, projection)?.use { cursor ->
        val idIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
        val nameIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        while (cursor.moveToNext()) {
          val id = if (idIdx >= 0) cursor.getString(idIdx) else continue
          val name = if (nameIdx >= 0) cursor.getString(nameIdx) else continue
          if (name.equals(targetName, ignoreCase = true)) {
            return id to DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
          }
        }
        null
      }
    }.getOrNull()
  }

  private fun queryDocuments(uri: Uri, projection: Array<String>): android.database.Cursor? {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      context.contentResolver.query(uri, projection, android.os.Bundle.EMPTY, null)
    } else {
      context.contentResolver.query(uri, projection, null, null, null)
    }
  }

  data class SafTransferResult(
    val uri: Uri?,
    val errorReasonHe: String? = null,
    val verifiedSha256: String? = null,
    val usedMimeType: String? = null
  )

  // ---- Controlled SAF Execution Primitives (Invoked ONLY from Approval Center / Undo Center) ----

  fun renameSafDocument(docUri: Uri, newName: String): Uri? {
    return runCatching {
      DocumentsContract.renameDocument(context.contentResolver, docUri, newName)
    }.getOrNull()
  }

  fun deleteSafDocument(docUri: Uri): Boolean {
    return runCatching {
      DocumentsContract.deleteDocument(context.contentResolver, docUri)
    }.getOrDefault(false)
  }

  fun ensureSubfolderPath(
    treeUri: Uri,
    rootParentDocId: String,
    folderPath: String
  ): Pair<String, Uri>? {
    val trimmed = folderPath.trim()
    if (trimmed.isEmpty() || trimmed == "." || trimmed == "/") {
      return rootParentDocId to DocumentsContract.buildDocumentUriUsingTree(treeUri, rootParentDocId)
    }
    val segments = trimmed.replace('\\', '/').split('/').filter { it.isNotBlank() && it != "." }
    if (segments.isEmpty()) {
      return rootParentDocId to DocumentsContract.buildDocumentUriUsingTree(treeUri, rootParentDocId)
    }
    if (segments.any { it == ".." }) return null
    var currentId = rootParentDocId
    var currentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootParentDocId)
    for (seg in segments) {
      val next = ensureSubfolder(treeUri, currentId, seg) ?: return null
      currentId = next.first
      currentUri = next.second
    }
    return currentId to currentUri
  }

  fun ensureSubfolder(treeUri: Uri, parentDocId: String, folderName: String): Pair<String, Uri>? {
    val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
    val projection =
      arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE
      )
    runCatching {
      queryDocuments(childrenUri, projection)?.use { cursor ->
        val idIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
        val nameIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        val mimeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
        while (cursor.moveToNext()) {
          val id = if (idIdx >= 0) cursor.getString(idIdx) else continue
          val name = if (nameIdx >= 0) cursor.getString(nameIdx) else continue
          val mime = if (mimeIdx >= 0) cursor.getString(mimeIdx) else ""
          if (mime == DocumentsContract.Document.MIME_TYPE_DIR && name.equals(folderName, ignoreCase = true)) {
            return id to DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
          }
        }
      }
    }
    val parentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, parentDocId)
    val created =
      runCatching {
        DocumentsContract.createDocument(
          context.contentResolver,
          parentUri,
          DocumentsContract.Document.MIME_TYPE_DIR,
          folderName
        )
      }.getOrNull() ?: return null
    val createdId = DocumentsContract.getDocumentId(created)
    return createdId to created
  }

  fun copySafDocumentVerified(
    sourceDocUri: Uri,
    destTreeUri: Uri,
    destParentDocId: String,
    targetName: String,
    mimeType: String,
    allowOverwrite: Boolean = false
  ): SafTransferResult {
    val effectiveMime = resolveMimeType(sourceDocUri, targetName, mimeType)
    val existing = findChildByName(destTreeUri, destParentDocId, targetName)
    if (existing != null) {
      if (!allowOverwrite) {
        return SafTransferResult(
          uri = null,
          errorReasonHe = "קובץ בשם '$targetName' כבר קיים בתיקיית היעד — ההעתקה בוטלה כדי למנוע דריסה ללא אישור.",
          usedMimeType = effectiveMime
        )
      }
      if (!deleteSafDocument(existing.second)) {
        return SafTransferResult(
          uri = null,
          errorReasonHe = "לא ניתן להחליף את הקובץ הקיים '$targetName' בתיקיית היעד.",
          usedMimeType = effectiveMime
        )
      }
    }

    val sourceHash = computeUriSha256(sourceDocUri)
      ?: return SafTransferResult(
        uri = null,
        errorReasonHe = "קריאת קובץ המקור או חישוב אימות SHA-256 נכשלו.",
        usedMimeType = effectiveMime
      )

    val destParentUri = DocumentsContract.buildDocumentUriUsingTree(destTreeUri, destParentDocId)
    val createdUri =
      runCatching {
        DocumentsContract.createDocument(context.contentResolver, destParentUri, effectiveMime, targetName)
      }.getOrNull()
        ?: return SafTransferResult(
          uri = null,
          errorReasonHe = "יצירת קובץ היעד '$targetName' נכשלה ב-SAF.",
          usedMimeType = effectiveMime
        )

    val copiedOk =
      runCatching {
        context.contentResolver.openInputStream(sourceDocUri)?.use { input ->
          context.contentResolver.openOutputStream(createdUri)?.use { output ->
            input.copyTo(output, 16 * 1024)
            output.flush()
          } ?: error("Output stream unavailable")
        } ?: error("Input stream unavailable")
        true
      }.getOrDefault(false)

    if (!copiedOk) {
      deleteSafDocument(createdUri)
      return SafTransferResult(
        uri = null,
        errorReasonHe = "כתיבת תוכן הקובץ ליעד נכשלה — קובץ היעד החלקי הוסר.",
        usedMimeType = effectiveMime
      )
    }

    val destHash = computeUriSha256(createdUri)
    if (destHash == null || destHash != sourceHash) {
      deleteSafDocument(createdUri)
      return SafTransferResult(
        uri = null,
        errorReasonHe = "אימות שלמות SHA-256 לאחר העתקה נכשל — הקובץ החלקי הוסר והמקור נשמר.",
        usedMimeType = effectiveMime
      )
    }

    return SafTransferResult(
      uri = createdUri,
      verifiedSha256 = destHash,
      usedMimeType = effectiveMime
    )
  }

  fun copySafDocumentToFolder(
    sourceDocUri: Uri,
    destTreeUri: Uri,
    destParentDocId: String,
    targetName: String,
    mimeType: String,
    allowOverwrite: Boolean = false
  ): Uri? {
    return copySafDocumentVerified(
      sourceDocUri = sourceDocUri,
      destTreeUri = destTreeUri,
      destParentDocId = destParentDocId,
      targetName = targetName,
      mimeType = mimeType,
      allowOverwrite = allowOverwrite
    ).uri
  }

  fun moveSafDocumentVerified(
    sourceDocUri: Uri,
    sourceParentDocId: String?,
    sourceTreeUri: Uri,
    destTreeUri: Uri,
    destParentDocId: String,
    targetName: String,
    mimeType: String,
    allowOverwrite: Boolean = false
  ): SafTransferResult {
    val effectiveMime = resolveMimeType(sourceDocUri, targetName, mimeType)

    if (sourceParentDocId != null && sourceTreeUri == destTreeUri && sourceParentDocId == destParentDocId) {
      return SafTransferResult(
        uri = null,
        errorReasonHe = "הקובץ '$targetName' כבר נמצא בתיקיית היעד המבוקשת.",
        usedMimeType = effectiveMime
      )
    }

    val existing = findChildByName(destTreeUri, destParentDocId, targetName)
    if (existing != null) {
      if (!allowOverwrite) {
        return SafTransferResult(
          uri = null,
          errorReasonHe = "קובץ בשם '$targetName' כבר קיים בתיקיית היעד — ההעברה בוטלה כדי למנוע דריסה ללא אישור.",
          usedMimeType = effectiveMime
        )
      }
      if (!deleteSafDocument(existing.second)) {
        return SafTransferResult(
          uri = null,
          errorReasonHe = "לא ניתן להחליף את הקובץ הקיים '$targetName' בתיקיית היעד.",
          usedMimeType = effectiveMime
        )
      }
    }

    val sourceHash = computeUriSha256(sourceDocUri)
      ?: return SafTransferResult(
        uri = null,
        errorReasonHe = "לא ניתן לקרוא את קובץ המקור לצורך אימות לפני העברה.",
        usedMimeType = effectiveMime
      )

    // Fast native move if same tree root and Android >= N with verified sourceParentDocId
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N &&
      sourceParentDocId != null &&
      sourceTreeUri == destTreeUri
    ) {
      val srcParentUri = DocumentsContract.buildDocumentUriUsingTree(sourceTreeUri, sourceParentDocId)
      val dstParentUri = DocumentsContract.buildDocumentUriUsingTree(destTreeUri, destParentDocId)
      val moved =
        runCatching {
          DocumentsContract.moveDocument(context.contentResolver, sourceDocUri, srcParentUri, dstParentUri)
        }.getOrNull()
      if (moved != null) {
        val movedHash = computeUriSha256(moved)
        if (movedHash == sourceHash) {
          return SafTransferResult(
            uri = moved,
            verifiedSha256 = movedHash,
            usedMimeType = effectiveMime
          )
        }
      }
    }

    // Verified cross-volume / SD / fallback copy + SHA-256 verification + delete source ONLY after verified copy
    val copyRes =
      copySafDocumentVerified(
        sourceDocUri = sourceDocUri,
        destTreeUri = destTreeUri,
        destParentDocId = destParentDocId,
        targetName = targetName,
        mimeType = effectiveMime,
        allowOverwrite = allowOverwrite
      )
    val copiedUri = copyRes.uri ?: return copyRes

    if (copyRes.verifiedSha256 != sourceHash) {
      deleteSafDocument(copiedUri)
      return SafTransferResult(
        uri = null,
        errorReasonHe = "אימות העתקה נכשל — קובץ המקור נשמר ללא שינוי.",
        usedMimeType = effectiveMime
      )
    }

    val deletedSource = deleteSafDocument(sourceDocUri)
    if (!deletedSource) {
      // Roll back copied target so move fails atomically rather than silently duplicating or leaving ambiguous state
      deleteSafDocument(copiedUri)
      return SafTransferResult(
        uri = null,
        errorReasonHe = "ההעתקה אומתה אך מחיקת קובץ המקור נחסמה בהרשאות SAF — השינוי בוטל והמקור נשמר.",
        usedMimeType = effectiveMime
      )
    }

    return SafTransferResult(
      uri = copiedUri,
      verifiedSha256 = copyRes.verifiedSha256,
      usedMimeType = effectiveMime
    )
  }

  fun moveSafDocumentToFolder(
    sourceDocUri: Uri,
    sourceParentDocId: String?,
    sourceTreeUri: Uri,
    destTreeUri: Uri,
    destParentDocId: String,
    targetName: String,
    mimeType: String,
    allowOverwrite: Boolean = false
  ): Uri? {
    return moveSafDocumentVerified(
      sourceDocUri = sourceDocUri,
      sourceParentDocId = sourceParentDocId,
      sourceTreeUri = sourceTreeUri,
      destTreeUri = destTreeUri,
      destParentDocId = destParentDocId,
      targetName = targetName,
      mimeType = mimeType,
      allowOverwrite = allowOverwrite
    ).uri
  }
}
