package com.example.data.ai

enum class AiProviderMode(
  val titleHe: String,
  val subtitleHe: String
) {
  FIREBASE_AI_LOGIC(
    titleHe = "Firebase AI Logic (ברירת מחדל מאובטחת)",
    subtitleHe = "מודלים חינמיים gemini-3.8-flash ו-gemini-3.5-flash-lite עם App Check וללא חשיפת מפתח."
  ),
  OPENAI_COMPATIBLE(
    titleHe = "שרת OpenAI-Compatible מותאם",
    subtitleHe = "חיבור ישיר לכתובת שרת מותאמת (ענן או שרת מקומי כגון Ollama/vLLM/OpenRouter) עם מפתח מוצפן מקומית."
  );

  companion object {
    fun fromString(raw: String?): AiProviderMode =
      entries.firstOrNull { it.name.equals(raw?.trim(), ignoreCase = true) } ?: FIREBASE_AI_LOGIC
  }
}

enum class AikoDomainMode(
  val titleHe: String,
  val shortLabelHe: String,
  val descriptionHe: String,
  val starterPrompts: List<String>,
  val systemInstructionAddendum: String
) {
  DEVICE(
    titleHe = "ניהול המכשיר",
    shortLabelHe = "מכשיר",
    descriptionHe = "אבחון טלמטריה, אחסון, ניקוי מטמון, כרטיס SD, סוללה, אפליקציות ואבטחה.",
    starterPrompts =
      listOf(
        "בדוק את מצב הטאבלט שלי עכשיו",
        "פתח את מנקה המטמון החכם",
        "תמצא לי קבצים גדולים או כפולים",
        "בדוק את הרשאות המצלמה והמיקרופון"
      ),
    systemInstructionAddendum =
      "תחום פעיל: ניהול המכשיר. התמקד במדדי המערכת, ניהול אחסון, ניקוי מטמון בטוח, אפליקציות, סוללה וביקורת הרשאות. ציין בבירור מגבלות Android 10."
  ),
  PERSONAL(
    titleHe = "ניהול אישי",
    shortLabelHe = "אישי",
    descriptionHe = "משימות יומיות, רשימות קניות/עבודה, תזכורות, תיעדוף וסדר יום אישי.",
    starterPrompts =
      listOf(
        "הוסף משימה אישית: לבדוק גיבוי שבועי",
        "עזור לי לארגן רשימת מטלות להיום",
        "אילו משימות פתוחות ממתינות לי?",
        "תזכיר לי מחר בבוקר לעשות סריקת אחסון"
      ),
    systemInstructionAddendum =
      "תחום פעיל: ניהול אישי. עזור למשתמש לנהל משימות, רשימות ותכנון זמן בעברית ברורה. הצע CREATE_PERSONAL_TASK כשמבקשים ליצור משימה או פריט רשימה."
  ),
  KNOWLEDGE(
    titleHe = "עוזר ידע",
    shortLabelHe = "ידע",
    descriptionHe = "שאלות ותשובות, סיכום מסמכים, ארגון מידע, כתיבה, השוואות ולמידה מודרכת.",
    starterPrompts =
      listOf(
        "הסבר לי בפשטות איך עובד מנגנון המטמון באנדרואיד",
        "עזור לי לנסח מייל רשמי ומדויק",
        "השווה יתרונות וחסרונות של גיבוי מקומי מול ענן",
        "ארגן את הנושאים שלי לסיכום מובנה"
      ),
    systemInstructionAddendum =
      "תחום פעיל: עוזר ידע. ענה בצורה מלמדת, מסודרת ובהירה על שאלות כלליות, למידה, סיכומים, ניסוח וכתיבה. אם מידע חסר — אמור זאת בכנות."
  ),
  PROJECTS(
    titleHe = "ניהול פרויקטים",
    shortLabelHe = "פרויקטים",
    descriptionHe = "תכנון אתרים, אפליקציות, רעיונות מוצר, מעקב התקדמות, תקלות ותוכניות עבודה.",
    starterPrompts =
      listOf(
        "תכנן אפיון ראשוני לאתר תדמית עסקי",
        "צור פרויקט חדש למעקב שדרוג מערכת",
        "פרק לי רעיון לאפליקציה לשלבי פיתוח ברורים",
        "עזור לי לזהות סיכונים ותקלות בפרויקט קיים"
      ),
    systemInstructionAddendum =
      "תחום פעיל: ניהול פרויקטים. סייע באפיון אתרים ואפליקציות, פירוק אבני דרך, מעקב תקלות ויוזמות. הצע CREATE_WORKSPACE_PROJECT כשרוצים לפתוח פרויקט חדש."
  ),
  AUTOMATIONS(
    titleHe = "אוטומציות",
    shortLabelHe = "אוטומציות",
    descriptionHe = "תרחישים רב-שלביים, תנאי סוללה/אחסון, תזמונים והשהיה או ביטול באמצע ריצה.",
    starterPrompts =
      listOf(
        "הפעל בדיקת בוקר מערכתית",
        "תזכיר לי כשסוללה יורדת מתחת ל-20%",
        "הכן תוכנית ניקוי וארגון במרכז האישורים",
        "איך ליצור אוטומציית תחזוקה קבועה?"
      ),
    systemInstructionAddendum =
      "תחום פעיל: אוטומציות. עזור לתכנן ולהפעיל תרחישי אוטומציה, סוכני ביצוע מדורגים והתראות מותנות, תוך הקפדה על אישור משתמש לפני כל פעולה משנה מצב."
  );

  companion object {
    fun fromString(raw: String?): AikoDomainMode =
      entries.firstOrNull { it.name.equals(raw?.trim(), ignoreCase = true) } ?: DEVICE
  }
}
