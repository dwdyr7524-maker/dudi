package com.example.data.documents

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import kotlin.math.min
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class NexusDocumentKind(val titleHe: String) {
  PDF("מסמך PDF"),
  MARKDOWN("Markdown (.md)"),
  JSON("JSON"),
  CSV("CSV / טבלה"),
  TEXT("טקסט רגיל"),
  UNSUPPORTED("פורמט בינארי לא-טקסטואלי")
}

data class DocumentSearchMatch(
  val lineNumber: Int,
  val snippet: String
)

data class OpenedDocumentState(
  val uriString: String,
  val fileName: String,
  val mimeType: String,
  val sizeBytes: Long,
  val kind: NexusDocumentKind,
  val textContent: String,
  val pdfPageCount: Int,
  val currentPdfPage: Int,
  val pdfPreviewBitmap: Bitmap?,
  val localSummaryHe: String,
  val aiSummaryHe: String? = null,
  val searchQuery: String = "",
  val searchMatches: List<DocumentSearchMatch> = emptyList(),
  val errorNoteHe: String? = null
)

/**
 * Pure-Kotlin helper for text document classification, searching, and extractive summarization.
 */
object DocumentTextAnalyzer {
  fun classifyKind(fileName: String, mimeType: String): NexusDocumentKind {
    val lowerName = fileName.lowercase()
    val lowerMime = mimeType.lowercase()
    return when {
      lowerMime.contains("pdf") || lowerName.endsWith(".pdf") -> NexusDocumentKind.PDF
      lowerName.endsWith(".md") || lowerName.endsWith(".markdown") -> NexusDocumentKind.MARKDOWN
      lowerMime.contains("json") || lowerName.endsWith(".json") -> NexusDocumentKind.JSON
      lowerMime.contains("csv") || lowerName.endsWith(".csv") -> NexusDocumentKind.CSV
      lowerMime.startsWith("text/") ||
        lowerName.endsWith(".txt") ||
        lowerName.endsWith(".log") ||
        lowerName.endsWith(".xml") ||
        lowerName.endsWith(".yaml") ||
        lowerName.endsWith(".yml") -> NexusDocumentKind.TEXT
      else -> NexusDocumentKind.UNSUPPORTED
    }
  }

  fun searchLines(text: String, query: String, maxMatches: Int = 25): List<DocumentSearchMatch> {
    val q = query.trim()
    if (q.isBlank() || text.isBlank()) return emptyList()
    return text.lineSequence().mapIndexedNotNull { idx, line ->
      if (line.contains(q, ignoreCase = true)) {
        DocumentSearchMatch(lineNumber = idx + 1, snippet = line.trim().take(160))
      } else null
    }.take(maxMatches).toList()
  }

  fun summarizeTextLocally(fileName: String, text: String, kind: NexusDocumentKind): String {
    val cleanLines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
    if (cleanLines.isEmpty()) return "הקובץ \"$fileName\" ריק."
    val wordCount = text.split(Regex("\\s+")).count { it.isNotBlank() }
    val preview = cleanLines.take(4).joinToString(" | ").take(260)
    return "${kind.titleHe} • ${cleanLines.size} שורות • כ-$wordCount מילים.\nפתיחת המסמך: $preview"
  }
}

class DocumentCommanderEngine(private val context: Context) {

  suspend fun openDocument(uri: Uri): Result<OpenedDocumentState> =
    withContext(Dispatchers.IO) {
      runCatching {
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        var name = uri.lastPathSegment ?: "document"
        var size = 0L

        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
          ?.use { cursor ->
            if (cursor.moveToFirst()) {
              val nIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
              val sIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
              if (nIdx >= 0) name = cursor.getString(nIdx) ?: name
              if (sIdx >= 0 && !cursor.isNull(sIdx)) size = cursor.getLong(sIdx)
            }
          }

        val kind = DocumentTextAnalyzer.classifyKind(name, mime)
        when (kind) {
          NexusDocumentKind.PDF -> openPdf(uri, name, mime, size)
          NexusDocumentKind.UNSUPPORTED ->
            OpenedDocumentState(
              uriString = uri.toString(),
              fileName = name,
              mimeType = mime,
              sizeBytes = size,
              kind = kind,
              textContent = "",
              pdfPageCount = 0,
              currentPdfPage = 0,
              pdfPreviewBitmap = null,
              localSummaryHe = "פורמט קובץ זה ($mime) אינו טקסט או PDF הניתן לקריאה ישירה.",
              errorNoteHe = "תומך בקריאת PDF, TXT, MD, JSON, CSV, LOG ו-XML."
            )
          else -> openUtf8Text(uri, name, mime, size, kind)
        }
      }
    }

  private fun openUtf8Text(
    uri: Uri,
    name: String,
    mime: String,
    size: Long,
    kind: NexusDocumentKind
  ): OpenedDocumentState {
    val maxReadBytes = 256 * 1024 // Cap at 256KB to stay snappy on Android 10 tablets
    val buf = ByteArrayOutputStream()
    var truncated = false
    context.contentResolver.openInputStream(uri)?.use { stream ->
      val chunk = ByteArray(8192)
      var total = 0
      while (true) {
        val n = stream.read(chunk)
        if (n <= 0) break
        if (total + n > maxReadBytes) {
          buf.write(chunk, 0, maxReadBytes - total)
          truncated = true
          break
        }
        buf.write(chunk, 0, n)
        total += n
      }
    } ?: error("לא ניתן לפתוח זרם קריאה למסמך.")

    val text = buf.toString(Charsets.UTF_8.name())
    val summary =
      DocumentTextAnalyzer.summarizeTextLocally(name, text, kind) +
        if (truncated) "\n(מוצגים 256KB הראשונים מתוך הקובץ לשמירה על ביצועים)" else ""

    return OpenedDocumentState(
      uriString = uri.toString(),
      fileName = name,
      mimeType = mime,
      sizeBytes = size,
      kind = kind,
      textContent = text,
      pdfPageCount = 0,
      currentPdfPage = 0,
      pdfPreviewBitmap = null,
      localSummaryHe = summary
    )
  }

  private fun openPdf(
    uri: Uri,
    name: String,
    mime: String,
    size: Long,
    pageIndex: Int = 0
  ): OpenedDocumentState {
    return try {
      val pfd =
        context.contentResolver.openFileDescriptor(uri, "r")
          ?: error("לא ניתן לפתוח את קובץ ה-PDF.")
      pfd.use { descriptor ->
        PdfRenderer(descriptor).use { renderer ->
          val pageCount = renderer.pageCount
          if (pageCount <= 0) {
            return OpenedDocumentState(
              uriString = uri.toString(),
              fileName = name,
              mimeType = mime,
              sizeBytes = size,
              kind = NexusDocumentKind.PDF,
              textContent = "",
              pdfPageCount = 0,
              currentPdfPage = 0,
              pdfPreviewBitmap = null,
              localSummaryHe = "קובץ ה-PDF ריק (0 עמודים)."
            )
          }
          val safeIdx = pageIndex.coerceIn(0, pageCount - 1)
          val bmp = renderPageSafe(renderer, safeIdx)
          OpenedDocumentState(
            uriString = uri.toString(),
            fileName = name,
            mimeType = mime,
            sizeBytes = size,
            kind = NexusDocumentKind.PDF,
            textContent = "",
            pdfPageCount = pageCount,
            currentPdfPage = safeIdx,
            pdfPreviewBitmap = bmp,
            localSummaryHe =
              "מסמך PDF אמיתי נטען בהצלחה ($pageCount עמודים). מוצג עמוד ${safeIdx + 1} מתוך $pageCount באמצעות מנוע PdfRenderer המובנה של Android."
          )
        }
      }
    } catch (sec: SecurityException) {
      OpenedDocumentState(
        uriString = uri.toString(),
        fileName = name,
        mimeType = mime,
        sizeBytes = size,
        kind = NexusDocumentKind.PDF,
        textContent = "",
        pdfPageCount = 0,
        currentPdfPage = 0,
        pdfPreviewBitmap = null,
        localSummaryHe = "קובץ ה-PDF מוגן בסיסמה ואינו ניתן לפתיחה ללא הסרת סיסמה.",
        errorNoteHe = sec.localizedMessage ?: "PDF מוגן בסיסמה"
      )
    }
  }

  suspend fun renderPdfPage(uri: Uri, pageIndex: Int): Result<Pair<Int, Bitmap>> =
    withContext(Dispatchers.IO) {
      runCatching {
        val pfd =
          context.contentResolver.openFileDescriptor(uri, "r")
            ?: error("לא ניתן לפתוח את קובץ ה-PDF.")
        pfd.use { descriptor ->
          PdfRenderer(descriptor).use { renderer ->
            val safeIdx = pageIndex.coerceIn(0, (renderer.pageCount - 1).coerceAtLeast(0))
            safeIdx to renderPageSafe(renderer, safeIdx)
          }
        }
      }
    }

  private fun renderPageSafe(renderer: PdfRenderer, pageIndex: Int): Bitmap {
    renderer.openPage(pageIndex).use { page ->
      val maxWidth = 1080f
      val scale = min(2.0f, maxWidth / page.width.coerceAtLeast(1))
      val w = (page.width * scale).toInt().coerceAtLeast(1)
      val h = (page.height * scale).toInt().coerceAtLeast(1)
      val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
      Canvas(bitmap).drawColor(Color.WHITE)
      page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
      return bitmap
    }
  }

  suspend fun writeDocumentToUri(uri: Uri, contentText: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        context.contentResolver.openOutputStream(uri)?.use { out ->
          out.write(contentText.toByteArray(Charsets.UTF_8))
          out.flush()
        } ?: error("לא ניתן לכתוב לנתיב שנבחר.")
      }
    }
}
