package com.example.data.ai

import com.example.data.local.AutomationEntity
import com.example.data.local.LifeItemEntity
import com.example.data.memory.NexusMemorySecretFilter
import com.example.data.model.AppDiagnosticInfo
import com.example.data.model.AssistantActionType
import com.example.data.model.AutomationStepType
import com.example.data.model.PendingAssistantAction
import com.example.data.model.SecurityAuditReport
import com.example.data.model.SystemTelemetry
import com.example.data.system.AssistantReply
import java.util.Locale

enum class LifeItemKind(val titleHe: String) {
  TASK("משימה"),
  REMINDER("תזכורת"),
  NOTE("פתק"),
  SHOPPING("קניות"),
  GOAL("מטרה"),
  JOURNAL("יומן")
}

enum class LifeItemPriority(val titleHe: String) {
  LOW("נמוכה"),
  NORMAL("רגילה"),
  HIGH("גבוהה"),
  URGENT("דחופה")
}

data class LifeItemDraft(
  val title: String,
  val details: String,
  val itemType: LifeItemKind,
  val priority: LifeItemPriority,
  val categoryTag: String,
  val repeatIntervalDays: Int = 0
)

data class NlAutomationProposal(
  val rawRuleText: String,
  val name: String,
  val voicePhrase: String,
  val steps: List<AutomationStepType>,
  val scheduleIntervalHours: Int,
  val triggerNoteHe: String,
  val isFeasible: Boolean,
  val explanationHe: String
)

sealed interface AikoLocalResult {
  data class AddLifeItem(
    val draft: LifeItemDraft,
    val reply: AssistantReply
  ) : AikoLocalResult

  data class CompleteLifeItem(
    val matchQuery: String,
    val reply: AssistantReply
  ) : AikoLocalResult

  data class ProposeAutomation(
    val proposal: NlAutomationProposal,
    val reply: AssistantReply
  ) : AikoLocalResult

  data class DirectReply(
    val reply: AssistantReply
  ) : AikoLocalResult

  data object DelegateToCloudOrSystem : AikoLocalResult
}

/**
 * Aiko (אייקו) — Natural Language Personal + Device Commander Brain.
 * Handles conversational Hebrew life-management, natural-language automations,
 * honest Android 10 feasibility checks, clarifying prompts, and safety guardrails.
 */
object AikoBrainEngine {

  private val heLocale = Locale.forLanguageTag("he-IL")

  fun interpret(
    rawInput: String,
    lifeItems: List<LifeItemEntity>,
    telemetry: SystemTelemetry?,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    customAutomations: List<AutomationEntity>
  ): AikoLocalResult {
    val trimmed = rawInput.trim()
    val q = trimmed.lowercase(heLocale)
    if (q.isBlank()) {
      return AikoLocalResult.DirectReply(
        AssistantReply(
          replyText = "היי, אני אייקו. במה תרצה שאתחיל היום — משימה אישית, ארגון קבצים או בדיקת הטאבלט?",
          actionTag = "AIKO_EMPTY"
        )
      )
    }

    // 1. Guardrail: refuse secret/password persistence immediately and honestly
    val secretReason = NexusMemorySecretFilter.inspect("", trimmed).reasonHe
    if (secretReason != null ||
      (q.contains("שמור") && (q.contains("סיסמה") || q.contains("קוד סודי") || q.contains("pin")))
    ) {
      return AikoLocalResult.DirectReply(
        AssistantReply(
          replyText =
            "מטעמי אבטחה, אייקו אינו שומר סיסמאות, קודי PIN או מפתחות גישה בטקסט. ניתן לשמור במרכז החשבונות רק שם שירות, קישור ומועד ביקורת תקופתית.",
          actionTag = "AIKO_GUARDRAIL_SECRET",
          pendingAction =
            PendingAssistantAction(
              actionType = AssistantActionType.OPEN_ACCOUNTS_HUB,
              title = "פתח מרכז חשבונות ושירותים",
              description = "ניהול שמות שירותים וקיצורי דרך מאובטחים ללא שמירת סיסמאות.",
              requiresConfirmation = false
            )
        )
      )
    }

    // 2. Guardrail: honest refusal of OS/Root-impossible actions on Android 10 SM-T545
    if (q.contains("root") ||
      q.contains("רוט") ||
      (q.contains("/data/data")) ||
      (q.contains("סמס") && q.contains("סיסמ")) ||
      (q.contains("בלי אישור") && (q.contains("מחק") || q.contains("הסר")))
    ) {
      return AikoLocalResult.DirectReply(
        AssistantReply(
          replyText =
            "בטאבלט Android 10 ללא Root לא ניתן לבצע גישה לקבצי מערכת פרטיים (/data/data) או למחוק/להסיר ללא אישור משתמש מפורש. החלופה הבטוחה היא שימוש ב-SAF, הגדרות המערכת ומרכז האישורים.",
          actionTag = "AIKO_HONEST_ANDROID10",
          pendingAction =
            PendingAssistantAction(
              actionType = AssistantActionType.OPEN_SELF_DIAGNOSTICS,
              title = "בדוק את מגבלות ההרשאות באבחון העצמי",
              description = "סקירה שקופה של מה זמין ומה חסום ב-Android 10.",
              requiresConfirmation = false
            )
        )
      )
    }

    // 3. Natural-language completion of an existing personal task
    if (q.startsWith("סיימתי") ||
      q.startsWith("בוצע") ||
      q.startsWith("השלמתי") ||
      (q.contains("סמן") && q.contains("בוצע"))
    ) {
      val target =
        trimmed
          .replace(Regex("^(סיימתי את|סיימתי|בוצע|השלמתי את|השלמתי|סמן את|סמן)\\s*"), "")
          .replace(Regex("\\s*(כבוצע|כמושלם)$"), "")
          .trim()
      if (target.isNotBlank()) {
        return AikoLocalResult.CompleteLifeItem(
          matchQuery = target,
          reply =
            AssistantReply(
              replyText = "בודק ומעדכן את המשימה התואמת ל-\"$target\" ברשימת החיים האישיים שלך.",
              actionTag = "AIKO_COMPLETE_LIFE_ITEM",
              plannedSteps = listOf("חיפוש משימה פתוחה", "סימון כהושלמה עם חותמת זמן")
            )
        )
      }
    }

    // 4. Natural-language query of personal tasks / shopping / goals / journal
    if ((q.contains("משימ") || q.contains("תזכור") || q.contains("קניות") || q.contains("מטר") || q.contains("יומן")) &&
      (q.contains("מה ") || q.contains("תראה") || q.contains("הצג") || q.contains("רשימת") || q.contains("להיום"))
    ) {
      val open = lifeItems.filter { !it.isCompleted }
      val summary =
        if (open.isEmpty()) {
          "אין כרגע משימות פתוחות במנהל החיים האישיים שלך."
        } else {
          open.take(6).joinToString("\n") { "• [${LifeItemKind.entries.firstOrNull { k -> k.name == it.kind }?.titleHe ?: "משימה"}] ${it.title}" }
        }
      return AikoLocalResult.DirectReply(
        AssistantReply(
          replyText = "הנה מצב המשימות והרשימות הפתוחות שלך (${open.size} פעילות):\n$summary",
          actionTag = "AIKO_LIST_LIFE",
          pendingAction =
            PendingAssistantAction(
              actionType = AssistantActionType.OPEN_PERSONAL_LIFE,
              title = "פתח מנהל חיים אישיים",
              description = "ניהול משימות, קניות, תזכורות, פתקים, מטרות ויומן.",
              requiresConfirmation = false
            )
        )
      )
    }

    // 5. Natural-language adding of Personal Life items (Task, Reminder, Note, Shopping, Goal, Journal)
    parseLifeItemDraft(trimmed)?.let { draft ->
      return AikoLocalResult.AddLifeItem(
        draft = draft,
        reply =
          AssistantReply(
            replyText =
              "שמרתי במנהל החיים האישיים כ-${draft.itemType.titleHe}: \"${draft.title}\" (קטגוריה: ${draft.categoryTag}, עדיפות: ${draft.priority.titleHe}).",
            actionTag = "AIKO_ADD_LIFE_${draft.itemType.name}",
            pendingAction =
              PendingAssistantAction(
                actionType = AssistantActionType.OPEN_PERSONAL_LIFE,
                title = "הצג במנהל החיים האישיים",
                description = "ערוך, סמן כבוצע או עדכן התקדמות.",
                requiresConfirmation = false
              ),
            plannedSteps =
              listOf(
                "סיווג הבקשה: ${draft.itemType.titleHe}",
                "שמירה מאובטחת במסד הנתונים המקומי (Room)"
              )
          )
      )
    }

    // 6. Natural-language Automation Rule ("כל פעם ש...", "כל ערב...", "כל בוקר...", "כל X שעות...")
    val isNlAutomation =
      q.startsWith("כל פעם") ||
        q.startsWith("כל ערב") ||
        q.startsWith("כל בוקר") ||
        q.startsWith("כל שבוע") ||
        q.startsWith("כל יום") ||
        q.startsWith("כל שעה") ||
        Regex("^כל\\s+\\d+\\s+שע").containsMatchIn(q) ||
        q.startsWith("תכנת לי אוטומציה") ||
        q.startsWith("צור אוטומציה") ||
        (q.contains("אוטומציה") && (q.contains("תזכור") || q.contains("תנקה") || q.contains("בדוק") || q.contains("סרוק") || q.contains("שעות") || q.contains("יומ")))

    if (isNlAutomation) {
      val proposal = parseNaturalAutomationRule(trimmed)
      val replyText =
        if (proposal.isFeasible) {
          "הבנתי את הכלל שלך! יצרתי ותזמנתי אוטומציה בשם \"${proposal.name}\" (${proposal.triggerNoteHe})."
        } else {
          proposal.explanationHe
        }
      return AikoLocalResult.ProposeAutomation(
        proposal = proposal,
        reply =
          AssistantReply(
            replyText = replyText,
            actionTag = "AIKO_NL_AUTOMATION",
            plannedSteps =
              if (proposal.isFeasible) proposal.steps.map { it.titleHe }
              else listOf("הסבר מגבלת Android 10", "הצעת שלבים חוקיים חלופיים")
          )
      )
    }

    // 7. Downloads & Recent Media / Photos / ZIP intents (skip when targeting a specific named file action handled by NexusAikoToolEngine)
    val looksLikeSpecificFileAction =
      (q.contains("העתק") || q.contains("תעתיק") || q.contains("העבר") || q.contains("תעביר") ||
        q.contains("מחק") || q.contains("תמחק") || q.contains("שנה שם") || q.contains("תשנה שם") ||
        q.contains("דחוס") || q.contains("תדחס")) &&
        (q.contains("קובץ") || q.contains("תמונה") || q.contains("מסמך") || q.contains("סרטון") || q.contains("."))

    if (!looksLikeSpecificFileAction &&
      q.contains("הורד") &&
      (q.contains("מצא") || q.contains("תמונ") || q.contains("שבוע") || q.contains("הצג") || q.contains("קובץ") || q.contains("קבצ"))
    ) {
      return AikoLocalResult.DirectReply(
        AssistantReply(
          replyText =
            "אפתח עבורך את מנהל ההורדות החכם כדי לסנן קבצים מתיקיית ההורדות (כולל תמונות, APK ומסמכים מהשבוע האחרון), למיין אותם, לדחוס ל-ZIP או לארגן לתיקיות.",
          actionTag = "AIKO_OPEN_DOWNLOADS",
          pendingAction =
            PendingAssistantAction(
              actionType = AssistantActionType.OPEN_DOWNLOADS_MANAGER,
              title = "פתח את מנהל ההורדות החכם",
              description = "סינון תמונות, מסמכים וקבצים שהורדו לאחרונה.",
              requiresConfirmation = false
            ),
          plannedSteps =
            listOf(
              "סינון תיקיות Downloads שנסרקו ב-SAF",
              "מיון לפי תאריך וקטגוריה",
              "פעולות דחיסה, העברה ומחיקה באישורך"
            )
        )
      )
    }

    // 8. ZIP / Archive intent (generic screen shortcut only when not naming a specific file)
    if (!looksLikeSpecificFileAction &&
      (q.contains("zip") || q.contains("דחוס") || q.contains("ארכיון") || q.contains("חלץ"))
    ) {
      return AikoLocalResult.DirectReply(
        AssistantReply(
          replyText =
            "במסך האחסון החכם ובמנהל ההורדות תוכל לסמן קבצים או תיקיות ולבצע דחיסה ל-ZIP או חילוץ מאובטח עם הגנת Zip-Slip, לאחר אישור במרכז האישורים.",
          actionTag = "AIKO_ZIP_TOOLS",
          pendingAction =
            PendingAssistantAction(
              actionType = AssistantActionType.NAVIGATE_SMART_STORAGE,
              title = "פתח אחסון חכם לדחיסה וחילוץ ZIP",
              description = "בחירת קבצים/תיקיות לפעולת ZIP בטוחה.",
              requiresConfirmation = false
            )
        )
      )
    }

    // 9. Self-diagnostics intent
    if (q.contains("אבחון עצמי") || q.contains("בדיקת מערכות") || q.contains("בדוק את עצמך") || q.contains("בדיקת ביצועים")) {
      return AikoLocalResult.DirectReply(
        AssistantReply(
          replyText =
            "מנוע האבחון העצמי של אייקו בודק את מסד הנתונים Room, נתיבי הניווט, הרשאות Android 10, תצורת AI, שירותי WorkManager ומבחן מהירות מעבד/זיכרון.",
          actionTag = "AIKO_SELF_DIAGNOSTICS",
          pendingAction =
            PendingAssistantAction(
              actionType = AssistantActionType.OPEN_SELF_DIAGNOSTICS,
              title = "פתח והרץ אבחון עצמי חכם",
              description = "בדיקת כל תתי-המערכות וה-Benchmark.",
              requiresConfirmation = false
            )
        )
      )
    }

    // 10. Accounts / Digital Services intent
    if (q.contains("חשבונ") || q.contains("שירותים דיגיטלי") || q.contains("מנויי") || q.contains("סקירת חשבון")) {
      return AikoLocalResult.DirectReply(
        AssistantReply(
          replyText =
            "במרכז החשבונות והשירותים תוכל לנהל שירותים ואפליקציות לפי קטגוריה, קישורים, ותזכורות ביקורת — ללא שמירת סיסמאות כלל.",
          actionTag = "AIKO_ACCOUNTS_HUB",
          pendingAction =
            PendingAssistantAction(
              actionType = AssistantActionType.OPEN_ACCOUNTS_HUB,
              title = "פתח מרכז חשבונות ושירותים",
              description = "תיעוד שירותים ובדיקות חיבוריות.",
              requiresConfirmation = false
            )
        )
      )
    }

    // 11. Ambiguous / clarification check
    if (q in setOf("עזור לי", "תעזור לי", "עזרה", "סדר", "תעשה סדר", "מה אתה יכול לעשות")) {
      return AikoLocalResult.DirectReply(
        AssistantReply(
          replyText =
            "היי, אני אייקו! כדי שאדייק עבורך, מה הכיוון המבוקש?\n" +
              "1. חיים אישיים: לדוגמה \"תזכור לי לקנות כבל USB-C\" או \"מה המשימות שלי להיום?\"\n" +
              "2. קבצים והורדות: לדוגמה \"תמצא את התמונה photo.jpg ותעתיק אותה לתיקיית התמונות\"\n" +
              "3. מכשיר ובריאות: לדוגמה \"בדוק את מצב הטאבלט\" או \"אבחון עצמי\"",
          actionTag = "AIKO_CLARIFY"
        )
      )
    }

    return AikoLocalResult.DelegateToCloudOrSystem
  }

  fun parseLifeItemDraft(rawInput: String): LifeItemDraft? {
    val trimmed = rawInput.trim()
    val q = trimmed.lowercase(heLocale)

    val kind =
      when {
        q.startsWith("רשימת קניות") || q.startsWith("לקנות") || q.startsWith("קניות:") || q.contains("להוסיף לקניות") ->
          LifeItemKind.SHOPPING
        q.startsWith("יומן:") || q.startsWith("כתוב ביומן") || q.startsWith("רשום ביומן") ->
          LifeItemKind.JOURNAL
        q.startsWith("מטרה חדשה") || q.startsWith("מטרה:") || q.startsWith("יעד:") ->
          LifeItemKind.GOAL
        q.startsWith("פתק:") || q.startsWith("רשום פתק") || q.startsWith("שמור פתק") ->
          LifeItemKind.NOTE
        q.startsWith("תזכור לי") || q.startsWith("תזכיר לי") || q.startsWith("תזכורת:") ->
          LifeItemKind.REMINDER
        q.startsWith("משימה:") || q.startsWith("הוסף משימה") || q.startsWith("צור משימה") || q.startsWith("צריך ל") ->
          LifeItemKind.TASK
        else -> null
      } ?: return null

    val strippedTitle =
      trimmed
        .replace(
          Regex(
            "^(רשימת קניות|להוסיף לקניות|קניות:|לקנות|כתוב ביומן|רשום ביומן|יומן:|מטרה חדשה|מטרה:|יעד:|רשום פתק|שמור פתק|פתק:|תזכור לי|תזכיר לי|תזכורת:|הוסף משימה|צור משימה|משימה:|צריך)\\s*[:\\-]?\\s*"
          ),
          ""
        )
        .trim()
        .ifBlank { trimmed }

    val priority =
      when {
        q.contains("דחוף") || q.contains("בהקדם") -> LifeItemPriority.URGENT
        q.contains("חשוב") -> LifeItemPriority.HIGH
        else -> LifeItemPriority.NORMAL
      }

    val categoryTag =
      when {
        kind == LifeItemKind.SHOPPING -> "קניות"
        kind == LifeItemKind.JOURNAL -> "יומן אישי"
        kind == LifeItemKind.GOAL -> "יעדים"
        q.contains("פרויקט") || q.contains("עבודה") || q.contains("אפליקצ") -> "עבודה ופרויקטים"
        q.contains("טאבלט") || q.contains("אחסון") || q.contains("גיבוי") -> "תחזוקת מכשיר"
        else -> "אישי"
      }

    val repeatDays =
      when {
        q.contains("כל יום") || q.contains("יומי") -> 1
        q.contains("כל שבוע") || q.contains("שבועי") -> 7
        q.contains("כל חודש") || q.contains("חודשי") -> 30
        else -> 0
      }

    return LifeItemDraft(
      title = strippedTitle.take(100),
      details = if (strippedTitle.length > 100) strippedTitle else "נוצר בשיחה טבעית מול אייקו",
      itemType = kind,
      priority = priority,
      categoryTag = categoryTag,
      repeatIntervalDays = repeatDays
    )
  }

  /**
   * Parses natural-language Hebrew automation rules into real feasible Android 10 Nexus steps.
   */
  fun parseNaturalAutomationRule(ruleText: String): NlAutomationProposal {
    val clean = ruleText.trim()
    val q = clean.lowercase(heLocale)

    if (q.contains("סיסמ") || q.contains("root") || q.contains("מחק אוטומטית") || q.contains("הסר אפליקציות לבד")) {
      return NlAutomationProposal(
        rawRuleText = clean,
        name = clean.take(40),
        voicePhrase = "בדיקת תחזוקה",
        steps = emptyList(),
        scheduleIntervalHours = 0,
        triggerNoteHe = "נחסם מטעמי בטיחות",
        isFeasible = false,
        explanationHe =
          "אייקו אינו מאפשר מחיקה שקטה אוטומטית של קבצים/אפליקציות או טיפול בסיסמאות. ניתן לבנות אוטומציה שבודקת ומכינה דוח או התראה לפני פעולה."
      )
    }

    val steps = mutableListOf<AutomationStepType>()
    if (q.contains("אחסון") || q.contains("קבצ") || q.contains("הורד") || q.contains("סרק") || q.contains("סריקה")) {
      steps += AutomationStepType.SYSTEM_SCAN
    }
    if (q.contains("סולל") || q.contains("חום") || q.contains("טמפרטור") || q.contains("טעינ")) {
      steps += AutomationStepType.BATTERY_CHECK
    }
    if (q.contains("אבטח") || q.contains("הרשא") || q.contains("פרטיות")) {
      steps += AutomationStepType.SECURITY_AUDIT
    }
    if (q.contains("מטמון") || q.contains("נקה") || q.contains("ניקוי")) {
      steps += AutomationStepType.CLEAR_NEXUS_CACHE
    }
    if (q.contains("דוח") || q.contains("בריאות") || q.contains("ערב") || q.contains("בוקר") || steps.isEmpty()) {
      steps += AutomationStepType.MAINTENANCE_REPORT
    }

    val numericHoursMatch = Regex("כל\\s+(\\d+)\\s*(שע|שעות|ש׳)").find(q)
    val numericHours = numericHoursMatch?.groupValues?.getOrNull(1)?.toIntOrNull()?.coerceIn(1, 720)
    val scheduleHours =
      when {
        q.contains("ידני") || q.contains("ללא תזמון") -> 0
        numericHours != null -> numericHours
        q.contains("כל שעה") -> 1
        q.contains("פעמיים ביום") -> 12
        q.contains("כל שבוע") || q.contains("שבועי") -> 168
        q.contains("כל ערב") || q.contains("כל בוקר") || q.contains("כל יום") || q.contains("יומי") -> 24
        else -> 24
      }

    val triggerNote =
      when {
        scheduleHours == 0 -> "הפעלה ידנית בלבד (ללא תזמון רקע)"
        q.contains("כל ערב") -> "תזמון מחזורי כל 24 שעות (ריצת תחזוקת ערב)"
        q.contains("כל בוקר") -> "תזמון מחזורי כל 24 שעות (בדיקת בוקר)"
        scheduleHours == 168 -> "תזמון שבועי (כל 168 שעות)"
        else -> "תזמון רקע מאושר כל $scheduleHours שעות דרך WorkManager"
      }

    val autoName =
      clean
        .replace(Regex("^(צור אוטומציה|תכנת לי אוטומציה|כל פעם ש|כל )\\s*"), "")
        .trim()
        .take(44)
        .ifBlank { "אוטומציית תחזוקה מותאמת" }

    return NlAutomationProposal(
      rawRuleText = clean,
      name = autoName,
      voicePhrase = autoName.take(24),
      steps = steps.distinct(),
      scheduleIntervalHours = scheduleHours,
      triggerNoteHe = triggerNote,
      isFeasible = true,
      explanationHe =
        if (scheduleHours > 0)
          "מופו ${steps.distinct().size} שלבים אמיתיים ומותרים ב-Android 10 עם תזמון WorkManager כל $scheduleHours שעות."
        else
          "מופו ${steps.distinct().size} שלבים אמיתיים להרצה ידנית לפי דרישה."
    )
  }
}
