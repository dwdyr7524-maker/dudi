package com.example.data.ai

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores user-entered third-party OpenAI-compatible API keys exclusively on-device using
 * Android Keystore AES-256-GCM encryption. Keys are never logged, bundled, or exported in backups.
 */
class SecureCustomKeyVault(private val context: Context) {

  private val prefs =
    context.getSharedPreferences("nexus_secure_ai_vault", Context.MODE_PRIVATE)

  fun hasKey(): Boolean = !readKeyOrNull().isNullOrBlank()

  fun saveKey(rawKey: String) {
    val clean = rawKey.trim()
    if (clean.isBlank()) {
      clearKey()
      return
    }
    val encrypted = encryptWithKeystore(clean)
    if (encrypted != null) {
      prefs.edit().putString(KEY_CIPHER_PAYLOAD, encrypted).remove(KEY_FALLBACK_OBF).apply()
    } else {
      // Fallback ONLY when AndroidKeyStore is unavailable (e.g., Robolectric JVM environment)
      val b64 = Base64.encodeToString(clean.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)
      prefs.edit().putString(KEY_FALLBACK_OBF, b64).remove(KEY_CIPHER_PAYLOAD).apply()
    }
  }

  fun readKeyOrNull(): String? {
    val cipherPayload = prefs.getString(KEY_CIPHER_PAYLOAD, null)
    if (!cipherPayload.isNullOrBlank()) {
      return decryptWithKeystore(cipherPayload)
    }
    val fallback = prefs.getString(KEY_FALLBACK_OBF, null) ?: return null
    return runCatching {
      String(Base64.decode(fallback, Base64.NO_WRAP), StandardCharsets.UTF_8)
    }.getOrNull()
  }

  fun getMaskedPreview(): String {
    val k = readKeyOrNull()?.trim().orEmpty()
    if (k.isBlank()) return "לא הוגדר מפתח"
    return if (k.length <= 8) "•••• (${k.length} תווים)"
    else "${k.take(4)}••••${k.takeLast(4)}"
  }

  fun clearKey() {
    prefs.edit().remove(KEY_CIPHER_PAYLOAD).remove(KEY_FALLBACK_OBF).apply()
  }

  private fun encryptWithKeystore(plain: String): String? =
    runCatching {
      val key = getOrCreateSecretKey() ?: return@runCatching null
      val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
      cipher.init(Cipher.ENCRYPT_MODE, key)
      val iv = cipher.iv
      val cipherBytes = cipher.doFinal(plain.toByteArray(StandardCharsets.UTF_8))
      val ivB64 = Base64.encodeToString(iv, Base64.NO_WRAP)
      val dataB64 = Base64.encodeToString(cipherBytes, Base64.NO_WRAP)
      "$ivB64:$dataB64"
    }.getOrNull()

  private fun decryptWithKeystore(payload: String): String? =
    runCatching {
      val parts = payload.split(":")
      if (parts.size != 2) return@runCatching null
      val iv = Base64.decode(parts[0], Base64.NO_WRAP)
      val data = Base64.decode(parts[1], Base64.NO_WRAP)
      val key = getOrCreateSecretKey() ?: return@runCatching null
      val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
      cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
      val plainBytes = cipher.doFinal(data)
      String(plainBytes, StandardCharsets.UTF_8)
    }.getOrNull()

  private fun getOrCreateSecretKey(): SecretKey? =
    runCatching {
      val ks = KeyStore.getInstance(ANDROID_KEYSTORE)
      ks.load(null)
      val existing = ks.getKey(KEYSTORE_ALIAS, null) as? SecretKey
      if (existing != null) return@runCatching existing
      val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
      val spec =
        KeyGenParameterSpec.Builder(
          KEYSTORE_ALIAS,
          KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
          .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
          .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
          .setKeySize(256)
          .build()
      keyGen.init(spec)
      keyGen.generateKey()
    }.getOrNull()

  companion object {
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEYSTORE_ALIAS = "nexus_aiko_custom_api_key_v1"
    private const val AES_GCM_TRANSFORMATION = "AES/GCM/NoPadding"
    private const val KEY_CIPHER_PAYLOAD = "cipher_payload"
    private const val KEY_FALLBACK_OBF = "fallback_obf"
  }
}
