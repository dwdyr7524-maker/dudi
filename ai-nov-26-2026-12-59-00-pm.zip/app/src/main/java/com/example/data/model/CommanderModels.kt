package com.example.data.model

enum class FileCategory(val titleHe: String) {
  IMAGES("תמונות"),
  VIDEOS("סרטונים"),
  DOCUMENTS("מסמכים"),
  DOWNLOADS("הורדות"),
  AUDIO("מוזיקה ואודיו"),
  APK_INSTALLERS("קבצי התקנה (APK)"),
  BACKUPS("גיבויים"),
  TEMP_RESIDUAL("קבצים זמניים"),
  OTHER("קבצים אחרים")
}

enum class FileSortMode(val titleHe: String) {
  SIZE_DESC("גודל (מהגדול)"),
  DATE_DESC("תאריך (חדש תחילה)"),
  NAME_ASC("שם (א-ת)"),
  TYPE("סוג קובץ")
}

enum class StorageVolumeKind(val titleHe: String) {
  INTERNAL("אחסון פנימי"),
  SD_CARD("כרטיס זיכרון (SD)"),
  NEXUS_PRIVATE("מטמון NEXUS")
}

data class StorageVolumeInfo(
  val id: String,
  val label: String,
  val kind: StorageVolumeKind,
  val isMounted: Boolean,
  val totalBytes: Long?,
  val freeBytes: Long?,
  val usedBytes: Long?,
  val usedPercent: Int?,
  val authorizedTreeUris: List<String>,
  val fileCountScanned: Int = 0,
  val sdHealthSummaryHe: String? = null
)

data class ScannedFileEntry(
  val uriString: String,
  val treeUriString: String,
  val parentDocId: String,
  val docId: String,
  val name: String,
  val relativePath: String,
  val mimeType: String,
  val sizeBytes: Long,
  val lastModifiedMillis: Long,
  val category: FileCategory,
  val volumeKind: StorageVolumeKind,
  val isOldUnused: Boolean,
  val isLargeFile: Boolean,
  val isNewlyDetectedLarge: Boolean = false,
  val isTempResidual: Boolean,
  val isInstallerApk: Boolean,
  val isBackupArchive: Boolean,
  val isNameUnclear: Boolean,
  val sha256: String? = null
)

data class FolderStorageSummary(
  val treeUriString: String,
  val docId: String,
  val folderName: String,
  val relativePath: String,
  val volumeKind: StorageVolumeKind,
  val fileCount: Int,
  val totalBytes: Long,
  val isEmpty: Boolean,
  val isDuplicateFolderName: Boolean = false
)

data class CategoryBreakdown(
  val category: FileCategory,
  val totalBytes: Long,
  val fileCount: Int,
  val percentOfScanned: Int
)

data class DuplicateCopyItem(
  val uriString: String,
  val treeUriString: String,
  val docId: String,
  val parentDocId: String,
  val name: String,
  val relativePath: String,
  val volumeKind: StorageVolumeKind,
  val sizeBytes: Long,
  val lastModifiedMillis: Long,
  val recommendedKeep: Boolean,
  val keepReasonHe: String?
)

data class DuplicateGroup(
  val id: String,
  val sha256: String,
  val category: FileCategory,
  val fileSizeBytes: Long,
  val hasDifferentNames: Boolean,
  val copies: List<DuplicateCopyItem>
) {
  val reclaimableBytes: Long
    get() = fileSizeBytes * (copies.size - 1).coerceAtLeast(0)
}

data class MediaInspectionIssue(
  val uriString: String,
  val name: String,
  val relativePath: String,
  val isVideo: Boolean,
  val sizeBytes: Long,
  val reasonHe: String
)

data class StorageForecastInfo(
  val hasEnoughHistory: Boolean,
  val dailyChangeBytes: Long,
  val estimatedDaysToFull: Int?,
  val summaryHe: String
)

data class SmartStorageScanReport(
  val scannedAtMillis: Long,
  val volumes: List<StorageVolumeInfo>,
  val files: List<ScannedFileEntry>,
  val folders: List<FolderStorageSummary>,
  val emptyFolders: List<FolderStorageSummary>,
  val categories: List<CategoryBreakdown>,
  val duplicateGroups: List<DuplicateGroup>,
  val mediaIssues: List<MediaInspectionIssue>,
  val unreadableCount: Int,
  val newlyLargeFiles: List<ScannedFileEntry>,
  val forecast: StorageForecastInfo,
  val totalScannedFilesBytes: Long,
  val totalDuplicateWasteBytes: Long,
  val totalTempWasteBytes: Long
) {
  val hasSdCard: Boolean
    get() = volumes.any { it.kind == StorageVolumeKind.SD_CARD && it.isMounted }
}

enum class ApprovalOperationType(val titleHe: String) {
  DELETE_SAF_DOCUMENT("מחיקת קובץ/תיקייה"),
  DELETE_NEXUS_CACHE("ניקוי מטמון פנימי של NEXUS"),
  RENAME_SAF_DOCUMENT("שינוי שם קובץ/תיקייה"),
  MOVE_SAF_DOCUMENT("העברת קובץ לתיקייה/SD"),
  COPY_SAF_DOCUMENT("העתקת קובץ לתיקייה/SD"),
  COPY_SAF_FOLDER("העתקת תיקייה שלמה"),
  MOVE_SAF_FOLDER("העברת תיקייה שלמה"),
  BATCH_COPY_SAF("העתקה מרובה של קבצים"),
  BATCH_MOVE_SAF("העברה מרובה של קבצים"),
  ZIP_CREATE("דחיסה לארכיון ZIP"),
  ZIP_EXTRACT("חילוץ ארכיון ZIP"),
  CREATE_SAF_FOLDER("יצירת תיקייה חדשה"),
  ORGANIZE_DOWNLOAD_FILE("ארגון קובץ מתיקיית ההורדות"),
  BACKUP_FOLDER_SNAPSHOT("יצירת גיבוי תיקייה"),
  RESTORE_BACKUP_FILE("שחזור קובץ מגיבוי"),
  OPEN_UNINSTALL_APP("פתיחת מסך הסרת אפליקציה רשמי"),
  OPEN_SYSTEM_SETTINGS("פתיחת הגדרות מערכת רשמיות")
}

enum class ApprovalRiskLevel(val titleHe: String) {
  LOW("סיכון נמוך"),
  MEDIUM("סיכון בינוני — דורש בדיקה"),
  HIGH("סיכון גבוה — עלול למחוק מידע")
}

enum class CleanerSafetyTier(val titleHe: String, val subtitleHe: String) {
  SAFE("1. ניקוי בטוח", "מטמון פנימי, קבצים זמניים ותיקיות ריקות מאומתות"),
  REVIEW_NEEDED("2. ניקוי הדורש בדיקה", "כפילויות SHA-256, קבצי APK ישנים וקבצים ישנים"),
  POTENTIAL_DATA_LOSS("3. עלול לגרום לאובדן מידע", "קבצים גדולים אישיים ומעבר לניקוי מטמון חיצוני בהגדרות Android")
}

data class HealthScoreBreakdownItem(
  val id: String,
  val title: String,
  val pointsDelta: Int,
  val reasonHe: String,
  val severity: HealthSeverity,
  val targetRoute: String? = null
)

data class DiagnosticCheckResult(
  val id: String,
  val categoryTitleHe: String,
  val statusTitleHe: String,
  val detailHe: String,
  val recommendationHe: String,
  val severity: HealthSeverity,
  val targetRoute: String? = null
)

data class MaintenanceTaskItem(
  val id: String,
  val titleHe: String,
  val reasonHe: String,
  val priorityHe: String,
  val actionLabelHe: String,
  val targetRoute: String
)

data class DeviceDoctorReport(
  val diagnosedAtMillis: Long,
  val totalScore: Int,
  val scoreFormulaSummaryHe: String,
  val scoreBreakdown: List<HealthScoreBreakdownItem>,
  val checks: List<DiagnosticCheckResult>,
  val recommendations: List<String>,
  val maintenancePlan: List<MaintenanceTaskItem>,
  val smartRecommendations: List<String>
)

data class SimilarAppGroup(
  val roleTitleHe: String,
  val apps: List<AppDiagnosticInfo>,
  val adviceHe: String
)

data class ApkInspectionReport(
  val fileName: String,
  val packageName: String?,
  val appLabel: String?,
  val versionName: String?,
  val sizeBytes: Long,
  val sha256: String,
  val requestedPermissions: List<String>,
  val highRiskPermissions: List<String>,
  val warningNotesHe: List<String>,
  val parsedSuccessfully: Boolean
)

data class AiOrganizationProposalDraft(
  val title: String,
  val reasonHe: String,
  val targetName: String,
  val targetLocation: String,
  val operationType: ApprovalOperationType,
  val riskLevel: ApprovalRiskLevel,
  val isReversible: Boolean,
  val expectedOutcomeHe: String,
  val sourceUriString: String? = null,
  val treeUriString: String? = null,
  val destTreeUriString: String? = null,
  val destFolderName: String? = null,
  val proposedNewName: String? = null,
  val packageName: String? = null,
  val bytesAffected: Long = 0L
)

data class AiOrganizationPlanReport(
  val generatedAtMillis: Long,
  val summaryHe: String,
  val suggestedFolders: List<String>,
  val proposals: List<AiOrganizationProposalDraft>,
  val providerName: String
)

data class GlobalSearchResultItem(
  val id: String,
  val title: String,
  val subtitle: String,
  val categoryLabel: String,
  val targetRoute: String
)

data class AppCacheEntry(
  val packageName: String,
  val appName: String,
  val isOwnApp: Boolean,
  val isSystemApp: Boolean,
  val cacheBytes: Long?,
  val dataBytes: Long?,
  val appBytes: Long?,
  val isDirectCleanSupported: Boolean,
  val guidanceHe: String
)

data class AppCacheScanResult(
  val scannedAtMillis: Long,
  val nexusOwnCacheBytes: Long,
  val externalIdentifiableCacheBytes: Long?,
  val totalIdentifiableCacheBytes: Long,
  val hasUsageAccessPermission: Boolean,
  val supportsSystemClearCacheDialog: Boolean,
  val freeStorageBeforeBytes: Long,
  val entries: List<AppCacheEntry>,
  val limitationNoticeHe: String
)

data class CacheCleanOutcome(
  val executedAtMillis: Long,
  val ownCacheClearedBytes: Long,
  val externalAppsGuidedCount: Int,
  val freeStorageBeforeBytes: Long,
  val freeStorageAfterBytes: Long,
  val identifiableExternalCacheDeltaBytes: Long,
  val summaryHe: String
)

