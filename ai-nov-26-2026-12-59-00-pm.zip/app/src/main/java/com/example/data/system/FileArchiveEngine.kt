package com.example.data.system

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.example.data.model.FileCategory
import com.example.data.model.ScannedFileEntry
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Pure security and path helpers for ZIP archives & Downloads filtering.
 * Safe to test in plain JVM unit tests without Android framework state.
 */
object ZipSecurityGuard {
  const val STREAM_BUFFER_BYTES = 32 * 1024 // 32 KB streaming buffer for SM-T545 RAM safety
  const val MAX_EXTRACTED_ENTRY_BYTES = 256L * 1024L * 1024L // 256 MB single-entry guard against Zip-Bomb
  const val MAX_EXTRACTED_ENTRIES = 2000

  /**
   * Sanitizes a ZIP entry name against Zip-Slip path traversal (`../`, `\`, leading `/`, control chars).
   * Returns normalized relative path segments joined by `/`, or `null` if unsafe or empty.
   */
  fun sanitizeEntryPath(rawEntryName: String): String? {
    val unified = rawEntryName.replace('\\', '/').trim()
    if (unified.isEmpty() || unified.startsWith("/") || unified.contains(':')) {
      return null
    }
    val segments = unified.split('/').filter { it.isNotEmpty() }
    if (segments.isEmpty()) return null
    for (seg in segments) {
      if (seg == "." || seg == ".." || seg.contains('\u0000')) {
        return null
      }
    }
    return segments.joinToString("/")
  }

  /**
   * Resolves a unique file name (e.g., `archive (2).zip`) when overwrite is disabled.
   */
  fun resolveUniqueName(desiredName: String, existingNamesLower: Set<String>): String {
    if (desiredName.lowercase(Locale.ROOT) !in existingNamesLower) return desiredName
    val dotIdx = desiredName.lastIndexOf('.')
    val base = if (dotIdx > 0) desiredName.substring(0, dotIdx) else desiredName
    val ext = if (dotIdx > 0) desiredName.substring(dotIdx) else ""
    var counter = 2
    while (counter <= 500) {
      val candidate = "$base ($counter)$ext"
      if (candidate.lowercase(Locale.ROOT) !in existingNamesLower) return candidate
      counter++
    }
    return "${base}_${System.currentTimeMillis()}$ext"
  }

  fun filterDownloads(files: List<ScannedFileEntry>): List<ScannedFileEntry> {
    return files.filter { entry ->
      val pathLower = entry.relativePath.lowercase(Locale.ROOT)
      entry.category == FileCategory.DOWNLOADS ||
        pathLower.contains("download") ||
        entry.relativePath.contains("הורדות")
    }
  }
}

data class ArchiveOperationResult(
  val succeeded: Boolean,
  val summaryHe: String,
  val filesProcessed: Int = 0,
  val totalBytesProcessed: Long = 0L,
  val createdRootUriString: String? = null,
  val createdUriStrings: List<String> = emptyList(),
  val skippedUnsafeEntries: Int = 0
)

/**
 * Memory-safe, Android 10 SAF-compliant engine for:
 * - Multi-file & recursive-folder ZIP compression (`<= 32KB` buffered streaming)
 * - ZIP extraction with Zip-Slip protection & overwrite control
 * - Recursive SAF folder copy & verified move
 */
class FileArchiveEngine(
  private val context: Context,
  private val smartStorageEngine: SmartStorageEngine
) {

  suspend fun createZipFromSafItems(
    targetTreeUri: Uri,
    parentDocId: String,
    zipFileName: String,
    sourceUris: List<Uri>,
    overwriteExisting: Boolean = false
  ): ArchiveOperationResult =
    withContext(Dispatchers.IO) {
      if (sourceUris.isEmpty()) {
        return@withContext ArchiveOperationResult(false, "לא נבחרו קבצים או תיקיות לדחיסה.")
      }
      val normalizedZipName =
        zipFileName.trim().ifBlank { "NexusArchive_${System.currentTimeMillis()}.zip" }.let {
          if (it.lowercase(Locale.ROOT).endsWith(".zip")) it else "$it.zip"
        }

      val existingMap = listChildDocsByName(targetTreeUri, parentDocId)
      val finalZipName: String
      val existingMatch = existingMap[normalizedZipName.lowercase(Locale.ROOT)]
      if (existingMatch != null && overwriteExisting) {
        smartStorageEngine.deleteSafDocument(existingMatch.second)
        finalZipName = normalizedZipName
      } else {
        finalZipName = ZipSecurityGuard.resolveUniqueName(normalizedZipName, existingMap.keys)
      }

      val parentUri = DocumentsContract.buildDocumentUriUsingTree(targetTreeUri, parentDocId)
      val outZipUri =
        runCatching {
          DocumentsContract.createDocument(context.contentResolver, parentUri, "application/zip", finalZipName)
        }.getOrNull()
          ?: return@withContext ArchiveOperationResult(false, "לא ניתן ליצור קובץ ZIP בתיקיית היעד.")

      var filesCount = 0
      var totalBytes = 0L
      val buffer = ByteArray(ZipSecurityGuard.STREAM_BUFFER_BYTES)

      val writeOk =
        runCatching {
          context.contentResolver.openOutputStream(outZipUri)?.use { rawOut ->
            ZipOutputStream(BufferedOutputStream(rawOut, ZipSecurityGuard.STREAM_BUFFER_BYTES)).use { zos ->
              val usedZipPaths = HashSet<String>()
              for (srcUri in sourceUris) {
                val meta = queryDocMeta(srcUri) ?: continue
                if (meta.isDirectory) {
                  val res = addSafDirectoryToZip(srcUri, meta.name, zos, buffer, usedZipPaths)
                  filesCount += res.first
                  totalBytes += res.second
                } else {
                  val entryPath = makeUniqueZipEntryPath(meta.name, usedZipPaths)
                  usedZipPaths += entryPath
                  context.contentResolver.openInputStream(srcUri)?.use { rawIn ->
                    zos.putNextEntry(ZipEntry(entryPath))
                    val copied = copyStreamBuffered(rawIn, zos, buffer)
                    zos.closeEntry()
                    filesCount++
                    totalBytes += copied
                  }
                }
              }
            }
          } ?: error("OutputStream null")
          true
        }.getOrDefault(false)

      if (!writeOk || filesCount == 0) {
        smartStorageEngine.deleteSafDocument(outZipUri)
        return@withContext ArchiveOperationResult(
          false,
          "יצירת ארכיון ה-ZIP נכשלה או שלא היו קבצים קריאים לדחיסה."
        )
      }

      ArchiveOperationResult(
        succeeded = true,
        summaryHe = "נוצר בהצלחה '$finalZipName' ($filesCount קבצים, ${formatBytes(totalBytes)}).",
        filesProcessed = filesCount,
        totalBytesProcessed = totalBytes,
        createdRootUriString = outZipUri.toString(),
        createdUriStrings = listOf(outZipUri.toString())
      )
    }

  suspend fun extractZipToSafFolder(
    zipUri: Uri,
    destTreeUri: Uri,
    destParentDocId: String,
    destFolderName: String,
    overwriteExisting: Boolean = false
  ): ArchiveOperationResult =
    withContext(Dispatchers.IO) {
      val cleanDestName = destFolderName.trim().ifBlank { "Extracted_${System.currentTimeMillis()}" }
      val destFolder =
        smartStorageEngine.ensureSubfolder(destTreeUri, destParentDocId, cleanDestName)
          ?: return@withContext ArchiveOperationResult(false, "לא ניתן ליצור תיקיית חילוץ '$cleanDestName'.")

      var filesExtracted = 0
      var totalBytes = 0L
      var skippedUnsafe = 0
      val createdUris = mutableListOf<String>()
      val buffer = ByteArray(ZipSecurityGuard.STREAM_BUFFER_BYTES)
      val folderCache = HashMap<String, Pair<String, Uri>>().apply { put("", destFolder) }

      val extractOk =
        runCatching {
          context.contentResolver.openInputStream(zipUri)?.use { rawIn ->
            ZipInputStream(BufferedInputStream(rawIn, ZipSecurityGuard.STREAM_BUFFER_BYTES)).use { zis ->
              var entry = zis.nextEntry
              while (entry != null && filesExtracted < ZipSecurityGuard.MAX_EXTRACTED_ENTRIES) {
                val safePath = ZipSecurityGuard.sanitizeEntryPath(entry.name)
                if (safePath == null) {
                  skippedUnsafe++
                  zis.closeEntry()
                  entry = zis.nextEntry
                  continue
                }

                if (entry.isDirectory) {
                  ensureNestedSafFolder(destTreeUri, safePath, folderCache)
                } else {
                  val parentRel = safePath.substringBeforeLast('/', "")
                  val fileName = safePath.substringAfterLast('/')
                  val parentPair = ensureNestedSafFolder(destTreeUri, parentRel, folderCache)
                  if (parentPair != null) {
                    val existing = listChildDocsByName(destTreeUri, parentPair.first)
                    val finalName =
                      existing[fileName.lowercase(Locale.ROOT)]?.let { existingPair ->
                        if (overwriteExisting) {
                          smartStorageEngine.deleteSafDocument(existingPair.second)
                          fileName
                        } else {
                          ZipSecurityGuard.resolveUniqueName(fileName, existing.keys)
                        }
                      } ?: fileName

                    val targetParentUri = DocumentsContract.buildDocumentUriUsingTree(destTreeUri, parentPair.first)
                    val outUri =
                      DocumentsContract.createDocument(
                        context.contentResolver,
                        targetParentUri,
                        guessMimeType(finalName),
                        finalName
                      )
                    if (outUri != null) {
                      var entryBytes = 0L
                      context.contentResolver.openOutputStream(outUri)?.use { rawOut ->
                        entryBytes =
                          copyStreamWithLimit(
                            input = zis,
                            output = rawOut,
                            buffer = buffer,
                            maxBytes = ZipSecurityGuard.MAX_EXTRACTED_ENTRY_BYTES
                          )
                      }
                      totalBytes += entryBytes
                      filesExtracted++
                      createdUris += outUri.toString()
                    }
                  }
                }
                zis.closeEntry()
                entry = zis.nextEntry
              }
            }
          } ?: error("Zip stream unavailable")
          true
        }.getOrDefault(false)

      if (!extractOk) {
        return@withContext ArchiveOperationResult(false, "חילוץ קובץ ה-ZIP נכשל — בדוק שהארכיון תקין וקריא.")
      }

      val unsafeNote =
        if (skippedUnsafe > 0) " (נדחו $skippedUnsafe נתיבים לא בטוחים מטעמי אבטחה)" else ""
      ArchiveOperationResult(
        succeeded = true,
        summaryHe =
          "חולצו $filesExtracted קבצים (${formatBytes(totalBytes)}) אל '$cleanDestName'$unsafeNote.",
        filesProcessed = filesExtracted,
        totalBytesProcessed = totalBytes,
        createdRootUriString = destFolder.second.toString(),
        createdUriStrings = createdUris,
        skippedUnsafeEntries = skippedUnsafe
      )
    }

  suspend fun copySafFolderRecursive(
    sourceFolderUri: Uri,
    sourceTreeUri: Uri,
    destTreeUri: Uri,
    destParentDocId: String,
    destFolderName: String
  ): ArchiveOperationResult =
    withContext(Dispatchers.IO) {
      val srcFolderDocId =
        runCatching { DocumentsContract.getDocumentId(sourceFolderUri) }.getOrNull()
          ?: return@withContext ArchiveOperationResult(false, "מזהה תיקיית מקור אינו תקין.")
      val targetSub =
        smartStorageEngine.ensureSubfolder(destTreeUri, destParentDocId, destFolderName)
          ?: return@withContext ArchiveOperationResult(false, "לא ניתן ליצור תיקיית יעד '$destFolderName'.")

      val stats = copyFolderContentsRecursive(sourceTreeUri, srcFolderDocId, destTreeUri, targetSub.first)
      ArchiveOperationResult(
        succeeded = stats.first > 0 || stats.second == 0,
        summaryHe =
          "הועתקה התיקייה '$destFolderName': ${stats.first} קבצים (${formatBytes(stats.third)}).",
        filesProcessed = stats.first,
        totalBytesProcessed = stats.third,
        createdRootUriString = targetSub.second.toString()
      )
    }

  suspend fun moveSafFolderRecursive(
    sourceFolderUri: Uri,
    sourceTreeUri: Uri,
    destTreeUri: Uri,
    destParentDocId: String,
    destFolderName: String
  ): ArchiveOperationResult =
    withContext(Dispatchers.IO) {
      val srcFolderDocId =
        runCatching { DocumentsContract.getDocumentId(sourceFolderUri) }.getOrNull()
          ?: return@withContext ArchiveOperationResult(false, "מזהה תיקיית מקור אינו תקין.")

      // 1. Copy recursively with byte verification before removing source
      val copyRes =
        copySafFolderRecursive(sourceFolderUri, sourceTreeUri, destTreeUri, destParentDocId, destFolderName)
      if (!copyRes.succeeded) {
        return@withContext ArchiveOperationResult(
          false,
          "העברת התיקייה נכשלה בשלב ההעתקה המאומתת — תיקיית המקור נשמרה בשלמותה."
        )
      }

      // 2. Verify count matches before deleting source
      val sourceFileCount = countFilesRecursive(sourceTreeUri, srcFolderDocId)
      if (sourceFileCount != copyRes.filesProcessed) {
        return@withContext ArchiveOperationResult(
          false,
          "אימות ההעתקה גילה אי-התאמה במספר הקבצים ($sourceFileCount מול ${copyRes.filesProcessed}); המקור לא נמחק."
        )
      }

      val deletedSrc = smartStorageEngine.deleteSafDocument(sourceFolderUri)
      if (!deletedSrc) {
        return@withContext ArchiveOperationResult(
          succeeded = true,
          summaryHe =
            "התיקייה '$destFolderName' הועתקה במלואה (${copyRes.filesProcessed} קבצים), אך הסרת תיקיית המקור נחסמה ב-SAF.",
          filesProcessed = copyRes.filesProcessed,
          totalBytesProcessed = copyRes.totalBytesProcessed,
          createdRootUriString = copyRes.createdRootUriString
        )
      }

      ArchiveOperationResult(
        succeeded = true,
        summaryHe =
          "הועברה בהצלחה התיקייה '$destFolderName' (${copyRes.filesProcessed} קבצים, ${formatBytes(copyRes.totalBytesProcessed)}).",
        filesProcessed = copyRes.filesProcessed,
        totalBytesProcessed = copyRes.totalBytesProcessed,
        createdRootUriString = copyRes.createdRootUriString
      )
    }

  // ---- Internal SAF & Stream Helpers ----

  private data class DocMeta(val docId: String, val name: String, val mimeType: String, val size: Long, val isDirectory: Boolean)

  private fun queryDocMeta(docUri: Uri): DocMeta? {
    val projection =
      arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_SIZE
      )
    return runCatching {
      context.contentResolver.query(docUri, projection, null, null, null)?.use { c ->
        if (!c.moveToFirst()) return null
        val idIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
        val nameIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        val mimeIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
        val sizeIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
        val id = if (idIdx >= 0) c.getString(idIdx) else DocumentsContract.getDocumentId(docUri)
        val name = if (nameIdx >= 0) c.getString(nameIdx) ?: "file" else "file"
        val mime = if (mimeIdx >= 0) c.getString(mimeIdx) ?: "" else ""
        val size = if (sizeIdx >= 0 && !c.isNull(sizeIdx)) c.getLong(sizeIdx) else 0L
        DocMeta(id, name, mime, size, mime == DocumentsContract.Document.MIME_TYPE_DIR)
      }
    }.getOrNull()
  }

  private fun listChildDocsByName(treeUri: Uri, parentDocId: String): Map<String, Pair<String, Uri>> {
    val map = LinkedHashMap<String, Pair<String, Uri>>()
    val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
    val projection =
      arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME
      )
    runCatching {
      context.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
        val idIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
        val nameIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        while (c.moveToNext()) {
          val id = if (idIdx >= 0) c.getString(idIdx) else continue
          val name = if (nameIdx >= 0) c.getString(nameIdx) else continue
          map[name.lowercase(Locale.ROOT)] = id to DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
        }
      }
    }
    return map
  }

  private fun addSafDirectoryToZip(
    dirUri: Uri,
    prefix: String,
    zos: ZipOutputStream,
    buffer: ByteArray,
    usedPaths: MutableSet<String>
  ): Pair<Int, Long> {
    val dirDocId = runCatching { DocumentsContract.getDocumentId(dirUri) }.getOrNull() ?: return 0 to 0L
    val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(dirUri, dirDocId)
    val projection =
      arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE
      )
    var count = 0
    var bytes = 0L
    runCatching {
      context.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
        val idIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
        val nameIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        val mimeIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
        while (c.moveToNext()) {
          val id = if (idIdx >= 0) c.getString(idIdx) else continue
          val name = if (nameIdx >= 0) c.getString(nameIdx) ?: "item" else "item"
          val mime = if (mimeIdx >= 0) c.getString(mimeIdx) ?: "" else ""
          val childUri = DocumentsContract.buildDocumentUriUsingTree(dirUri, id)
          val relPath = "$prefix/$name"
          if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
            val sub = addSafDirectoryToZip(childUri, relPath, zos, buffer, usedPaths)
            count += sub.first
            bytes += sub.second
          } else {
            val unique = makeUniqueZipEntryPath(relPath, usedPaths)
            usedPaths += unique
            context.contentResolver.openInputStream(childUri)?.use { rawIn ->
              zos.putNextEntry(ZipEntry(unique))
              val copied = copyStreamBuffered(rawIn, zos, buffer)
              zos.closeEntry()
              count++
              bytes += copied
            }
          }
        }
      }
    }
    return count to bytes
  }

  private fun makeUniqueZipEntryPath(path: String, usedPaths: Set<String>): String {
    if (path !in usedPaths) return path
    val dir = path.substringBeforeLast('/', "")
    val name = path.substringAfterLast('/')
    val dot = name.lastIndexOf('.')
    val base = if (dot > 0) name.substring(0, dot) else name
    val ext = if (dot > 0) name.substring(dot) else ""
    var i = 2
    while (i < 500) {
      val candidateName = "$base ($i)$ext"
      val full = if (dir.isEmpty()) candidateName else "$dir/$candidateName"
      if (full !in usedPaths) return full
      i++
    }
    return "${path}_${System.currentTimeMillis()}"
  }

  private fun ensureNestedSafFolder(
    treeUri: Uri,
    relFolderPath: String,
    cache: MutableMap<String, Pair<String, Uri>>
  ): Pair<String, Uri>? {
    if (relFolderPath.isEmpty()) return cache[""]
    cache[relFolderPath]?.let { return it }

    val segments = relFolderPath.split('/').filter { it.isNotEmpty() }
    var currentPath = ""
    var currentPair = cache[""] ?: return null
    for (seg in segments) {
      currentPath = if (currentPath.isEmpty()) seg else "$currentPath/$seg"
      val cached = cache[currentPath]
      if (cached != null) {
        currentPair = cached
      } else {
        val next = smartStorageEngine.ensureSubfolder(treeUri, currentPair.first, seg) ?: return null
        cache[currentPath] = next
        currentPair = next
      }
    }
    return currentPair
  }

  private fun copyFolderContentsRecursive(
    srcTreeUri: Uri,
    srcFolderDocId: String,
    dstTreeUri: Uri,
    dstFolderDocId: String
  ): Triple<Int, Int, Long> {
    var copiedFiles = 0
    var failedFiles = 0
    var totalBytes = 0L
    val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(srcTreeUri, srcFolderDocId)
    val projection =
      arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_SIZE
      )
    runCatching {
      context.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
        val idIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
        val nameIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        val mimeIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
        val sizeIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
        while (c.moveToNext()) {
          val id = if (idIdx >= 0) c.getString(idIdx) else continue
          val name = if (nameIdx >= 0) c.getString(nameIdx) ?: "item" else "item"
          val mime = if (mimeIdx >= 0) c.getString(mimeIdx) ?: "" else ""
          val size = if (sizeIdx >= 0 && !c.isNull(sizeIdx)) c.getLong(sizeIdx) else 0L
          if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
            val childDst = smartStorageEngine.ensureSubfolder(dstTreeUri, dstFolderDocId, name)
            if (childDst != null) {
              val sub = copyFolderContentsRecursive(srcTreeUri, id, dstTreeUri, childDst.first)
              copiedFiles += sub.first
              failedFiles += sub.second
              totalBytes += sub.third
            } else {
              failedFiles++
            }
          } else {
            val srcChildUri = DocumentsContract.buildDocumentUriUsingTree(srcTreeUri, id)
            val created =
              smartStorageEngine.copySafDocumentToFolder(
                sourceDocUri = srcChildUri,
                destTreeUri = dstTreeUri,
                destParentDocId = dstFolderDocId,
                targetName = name,
                mimeType = mime
              )
            if (created != null) {
              copiedFiles++
              totalBytes += size
            } else {
              failedFiles++
            }
          }
        }
      }
    }
    return Triple(copiedFiles, failedFiles, totalBytes)
  }

  private fun countFilesRecursive(treeUri: Uri, folderDocId: String): Int {
    var count = 0
    val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, folderDocId)
    val projection =
      arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_MIME_TYPE
      )
    runCatching {
      context.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
        val idIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
        val mimeIdx = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
        while (c.moveToNext()) {
          val id = if (idIdx >= 0) c.getString(idIdx) else continue
          val mime = if (mimeIdx >= 0) c.getString(mimeIdx) ?: "" else ""
          count +=
            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) countFilesRecursive(treeUri, id)
            else 1
        }
      }
    }
    return count
  }

  private fun copyStreamBuffered(input: InputStream, output: OutputStream, buffer: ByteArray): Long {
    var total = 0L
    var read = input.read(buffer)
    while (read != -1) {
      output.write(buffer, 0, read)
      total += read
      read = input.read(buffer)
    }
    return total
  }

  private fun copyStreamWithLimit(
    input: InputStream,
    output: OutputStream,
    buffer: ByteArray,
    maxBytes: Long
  ): Long {
    var total = 0L
    var read = input.read(buffer)
    while (read != -1) {
      total += read
      if (total > maxBytes) {
        error("Entry exceeds max safety limit")
      }
      output.write(buffer, 0, read)
      read = input.read(buffer)
    }
    return total
  }

  private fun guessMimeType(fileName: String): String {
    return when (fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
      "jpg", "jpeg" -> "image/jpeg"
      "png" -> "image/png"
      "webp" -> "image/webp"
      "mp4" -> "video/mp4"
      "mp3" -> "audio/mpeg"
      "pdf" -> "application/pdf"
      "txt", "md", "csv", "log" -> "text/plain"
      "json" -> "application/json"
      "zip" -> "application/zip"
      else -> "application/octet-stream"
    }
  }
}
