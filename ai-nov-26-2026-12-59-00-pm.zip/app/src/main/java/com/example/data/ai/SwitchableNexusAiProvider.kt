package com.example.data.ai

import android.graphics.Bitmap
import com.example.data.local.AutomationEntity
import com.example.data.local.PreferencesManager
import com.example.data.model.AppDiagnosticInfo
import com.example.data.model.SecurityAuditReport
import com.example.data.model.SystemTelemetry
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first

/**
 * Unified switchable AI provider orchestrating between built-in Firebase AI Logic (free tier + App Check)
 * and the optional user-configured OpenAI-compatible endpoint. Never auto-switches to paid tiers.
 */
class SwitchableNexusAiProvider(
  private val firebaseProvider: FirebaseNexusAiProvider,
  private val openAiProvider: OpenAiCompatibleAiProvider,
  private val prefs: PreferencesManager
) : NexusAiProvider {

  override val providerId: String
    get() = firebaseProvider.providerId

  override val liveVoiceState: StateFlow<LiveVoiceUiState>
    get() = firebaseProvider.liveVoiceState

  override suspend fun generateAssistantResponse(
    userInput: String,
    recentHistory: List<Pair<Boolean, String>>,
    telemetry: SystemTelemetry?,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    customAutomations: List<AutomationEntity>,
    allowDeviceContextSharing: Boolean,
    memoryContext: String,
    domainMode: AikoDomainMode,
    personalContext: String,
    userDisplayName: String
  ): Result<AiAgentReply> {
    val mode = AiProviderMode.fromString(prefs.aiProviderModeFlow.first())
    if (mode == AiProviderMode.OPENAI_COMPATIBLE) {
      val baseUrl = prefs.customAiBaseUrlFlow.first()
      val modelName = prefs.customAiModelFlow.first()
      return openAiProvider.generateAssistantResponse(
        rawBaseUrl = baseUrl,
        modelName = modelName,
        userInput = userInput,
        recentHistory = recentHistory,
        telemetry = telemetry,
        apps = apps,
        securityReport = securityReport,
        customAutomations = customAutomations,
        allowDeviceContextSharing = allowDeviceContextSharing,
        memoryContext = memoryContext,
        domainMode = domainMode,
        personalContext = personalContext,
        userDisplayName = userDisplayName
      )
    }

    return firebaseProvider.generateAssistantResponse(
      userInput = userInput,
      recentHistory = recentHistory,
      telemetry = telemetry,
      apps = apps,
      securityReport = securityReport,
      customAutomations = customAutomations,
      allowDeviceContextSharing = allowDeviceContextSharing,
      memoryContext = memoryContext,
      domainMode = domainMode,
      personalContext = personalContext,
      userDisplayName = userDisplayName
    )
  }

  override suspend fun summarizeDocumentText(
    fileName: String,
    textExcerpt: String
  ): Result<String> {
    val mode = AiProviderMode.fromString(prefs.aiProviderModeFlow.first())
    if (mode == AiProviderMode.OPENAI_COMPATIBLE) {
      val baseUrl = prefs.customAiBaseUrlFlow.first()
      val modelName = prefs.customAiModelFlow.first()
      return openAiProvider.summarizeText(baseUrl, modelName, fileName, textExcerpt)
    }
    return firebaseProvider.summarizeDocumentText(fileName, textExcerpt)
  }

  override suspend fun analyzeDiagnosticImage(
    bitmap: Bitmap,
    userQuestion: String,
    telemetry: SystemTelemetry?,
    allowDeviceContextSharing: Boolean
  ): Result<AiAgentReply> =
    firebaseProvider.analyzeDiagnosticImage(bitmap, userQuestion, telemetry, allowDeviceContextSharing)

  override suspend fun runCloudHealthCheck(): CloudHealthCheckState {
    val mode = AiProviderMode.fromString(prefs.aiProviderModeFlow.first())
    if (mode == AiProviderMode.OPENAI_COMPATIBLE) {
      val baseUrl = prefs.customAiBaseUrlFlow.first()
      val modelName = prefs.customAiModelFlow.first()
      return when (val res = openAiProvider.testConnection(baseUrl, modelName)) {
        is CustomConnectionTestState.Success ->
          CloudHealthCheckState.Healthy(
            latencyMs = res.latencyMs,
            modelChecked = "OpenAI-Compatible ($modelName)",
            summaryHe = res.messageHe,
            checkedAtMillis = System.currentTimeMillis()
          )
        is CustomConnectionTestState.Failure ->
          CloudHealthCheckState.Unhealthy(
            error = NexusAppError("custom_ai", res.messageHe),
            latencyMs = 0L,
            checkedAtMillis = System.currentTimeMillis()
          )
        else -> firebaseProvider.runCloudHealthCheck()
      }
    }
    return firebaseProvider.runCloudHealthCheck()
  }

  override suspend fun runComprehensiveAiDiagnostics(
    isNetworkConnected: Boolean,
    shareTelemetryWithAi: Boolean
  ): AiSystemDiagnosticsReport =
    firebaseProvider.runComprehensiveAiDiagnostics(isNetworkConnected, shareTelemetryWithAi)

  override suspend fun transcribeAudio(
    audioBytes: ByteArray,
    mimeType: String,
    languageHint: String
  ): Result<String> = firebaseProvider.transcribeAudio(audioBytes, mimeType, languageHint)

  override suspend fun startLiveVoiceConversation(
    telemetry: SystemTelemetry?,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    allowDeviceContextSharing: Boolean
  ): Result<Unit> =
    firebaseProvider.startLiveVoiceConversation(telemetry, apps, securityReport, allowDeviceContextSharing)

  override suspend fun sendTextToLiveSession(text: String): Result<Unit> =
    firebaseProvider.sendTextToLiveSession(text)

  override suspend fun stopLiveVoiceConversation() = firebaseProvider.stopLiveVoiceConversation()

  override suspend fun generateFileOrganizationInsights(
    folderNames: List<String>,
    categorySummary: String,
    duplicateCount: Int,
    sdMounted: Boolean,
    allowDeviceContextSharing: Boolean
  ): Result<String> =
    firebaseProvider.generateFileOrganizationInsights(
      folderNames,
      categorySummary,
      duplicateCount,
      sdMounted,
      allowDeviceContextSharing
    )

  suspend fun testCustomConnection(baseUrl: String, modelName: String): CustomConnectionTestState =
    openAiProvider.testConnection(baseUrl, modelName)

  fun shutdown() {
    firebaseProvider.shutdown()
  }
}
