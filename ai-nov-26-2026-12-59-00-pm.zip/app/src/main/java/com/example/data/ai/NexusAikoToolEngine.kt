package com.example.data.ai

import android.net.Uri
import android.provider.DocumentsContract
import com.example.data.model.AiOrganizationProposalDraft
import com.example.data.model.ApprovalOperationType
import com.example.data.model.ApprovalRiskLevel
import com.example.data.model.FileCategory
import com.example.data.model.FolderStorageSummary
import com.example.data.model.ScannedFileEntry
import com.example.data.model.SmartStorageScanReport
import com.example.data.model.StorageVolumeKind
import com.example.data.orchestrator.NexusToolDefinition
import com.example.data.orchestrator.NexusToolRegistry
import com.example.data.system.formatBytes
import java.util.Locale

enum class AikoRequestedOperation(val titleHe: String) {
  FIND_SCAN("חיפוש ואיתור קובץ"),
  COPY_FILE("העתקת קובץ"),
  MOVE_FILE("העברת קובץ"),
  DELETE_FILE("מחיקת קובץ"),
  RENAME_FILE("שינוי שם קובץ"),
  ZIP_FILE("דחיסת קובץ ל-ZIP"),
  CLEAN_STORAGE("ניקוי מטמון ושאריות")
}

data class AikoParsedToolParameters(
  val rawInput: String,
  val operation: AikoRequestedOperation,
  val toolId: String,
  val fileNameQuery: String? = null,
  val fileCategoryHint: FileCategory? = null,
  val extensionHint: String? = null,
  val sourceFolderHint: String? = null,
  val destFolderHint: String? = null,
  val newFileName: String? = null,
  val wantsOverwrite: Boolean = false
)

data class AikoResolvedFileActionPlan(
  val params: AikoParsedToolParameters,
  val selectedTool: NexusToolDefinition,
  val matchedFile: ScannedFileEntry? = null,
  val candidateFiles: List<ScannedFileEntry> = emptyList(),
  val destTreeUriString: String? = null,
  val destFolderRelativePath: String? = null,
  val destFolderDocId: String? = null,
  val destDisplayLabelHe: String? = null,
  val plannedStepsHe: List<String>,
  val proposalDraft: AiOrganizationProposalDraft? = null,
  val summaryReplyHe: String,
  val rejectionReasonHe: String? = null
) {
  val requiresConfirmation: Boolean
    get() = proposalDraft != null
}

/**
 * Structured Parameterized Tool Engine for Aiko (אייקו).
 * Extracts real file/folder/action parameters from free-form Hebrew requests,
 * validates against live SAF scan data, blocks unidentified/ambiguous targets,
 * and emits an explicit 8-step plan gated by user confirmation.
 */
object NexusAikoToolEngine {

  private val heLocale = Locale.forLanguageTag("he-IL")

  private val pronounStopWords =
    setOf(
      "אותו", "אותה", "אותם", "אותן", "את", "זה", "זו", "זאת", "הזה", "הזאת",
      "קובץ", "הקובץ", "תמונה", "התמונה", "קובץ התמונה", "מסמך", "המסמך",
      "סרטון", "הסרטון", "שיר", "השיר", "פריט", "הפריט", "בבקשה", "כאן", "שם"
    )

  private val imageAliases = listOf("תמונה", "תמונות", "התמונות", "pictures", "images", "dcim", "photos", "camera")
  private val downloadAliases = listOf("הורדה", "הורדות", "ההורדות", "download", "downloads")
  private val documentAliases = listOf("מסמך", "מסמכים", "המסמכים", "documents", "document", "docs")
  private val musicAliases = listOf("מוזיקה", "המוזיקה", "שירים", "שמע", "אודיו", "music", "audio")
  private val videoAliases = listOf("סרטון", "סרטונים", "הסרטונים", "וידאו", "הווידאו", "movies", "videos", "video")
  private val backupAliases = listOf("גיבוי", "גיבויים", "הגיבוי", "הגיבויים", "backup", "backups", "nexus_backup")

  fun parseFileToolParameters(rawInput: String): AikoParsedToolParameters? {
    val trimmed = rawInput.trim()
    if (trimmed.isBlank()) return null
    val q = trimmed.lowercase(heLocale)

    val hasCopyVerb = q.contains("העתק") || q.contains("תעתיק")
    val hasMoveVerb = q.contains("העבר") || q.contains("תעביר")
    val hasDeleteVerb = q.contains("מחק") || q.contains("תמחק")
    val hasRenameVerb = q.contains("שנה שם") || q.contains("תשנה שם") || q.contains("שנה את השם") || q.contains("החלף שם")
    val hasZipVerb = q.contains("דחוס") || q.contains("תדחס") || q.contains("כווץ") || q.contains("תכווץ")
    val hasCleanVerb = q.contains("נקה") || q.contains("תנקה")
    val hasFindVerb = q.contains("מצא") || q.contains("תמצא") || q.contains("חפש") || q.contains("תחפש") || q.contains("אתר")

    val hasFileOrStorageContext =
      q.contains("קובץ") ||
        q.contains("קבצ") ||
        q.contains("תמונה") ||
        q.contains("תמונות") ||
        q.contains("סרטון") ||
        q.contains("וידאו") ||
        q.contains("מסמך") ||
        q.contains("דוח") ||
        q.contains("שיר") ||
        q.contains("אודיו") ||
        q.contains("תיקיית") ||
        q.contains("תיקייה") ||
        q.contains("תיקיה") ||
        q.contains("כרטיס") ||
        q.contains("sd") ||
        q.contains("הורדות") ||
        q.contains("גיבוי") ||
        q.contains("מטמון") ||
        q.contains("זמניי") ||
        q.contains("zip") ||
        Regex("\\.[a-z0-9]{2,5}\\b").containsMatchIn(q)

    if (!hasFileOrStorageContext) return null

    val operation =
      when {
        hasCopyVerb -> AikoRequestedOperation.COPY_FILE
        hasMoveVerb -> AikoRequestedOperation.MOVE_FILE
        hasRenameVerb -> AikoRequestedOperation.RENAME_FILE
        hasZipVerb -> AikoRequestedOperation.ZIP_FILE
        hasDeleteVerb -> AikoRequestedOperation.DELETE_FILE
        hasCleanVerb && (q.contains("זמנ") || q.contains("מטמון") || q.contains("כפילו") || q.contains("מיותר") || q.contains("שארי")) ->
          AikoRequestedOperation.CLEAN_STORAGE
        hasFindVerb -> AikoRequestedOperation.FIND_SCAN
        else -> return null
      }

    // Extract destination & new name FIRST so folder nouns inside destination don't pollute file category/name
    var newFileName: String? = null
    var destFolderHint: String? = null
    var bodyWithoutDest = trimmed

    if (operation == AikoRequestedOperation.RENAME_FILE) {
      val renameRegex =
        Regex("\\s+(?:לשם|אל|ל-)\\s*[\"']?([A-Za-z0-9א-ת_.\\-()]+)[\"']?\\s*$", RegexOption.IGNORE_CASE)
      val m = renameRegex.find(trimmed)
      if (m != null) {
        newFileName = m.groupValues[1].trim()
        bodyWithoutDest = trimmed.substring(0, m.range.first).trim()
      }
    } else if (operation == AikoRequestedOperation.COPY_FILE || operation == AikoRequestedOperation.MOVE_FILE) {
      val sdDestRegex =
        Regex("\\s+(?:אל\\s+|ל-?)(?:כרטיס\\s+(?:ה-?)?sd|sd\\s*card|sd)(?:\\s+(?:בתיקיית|אל)\\s+[\"']?([^\"',\\n]+)[\"']?)?\\s*$", RegexOption.IGNORE_CASE)
      val sdMatch = sdDestRegex.find(trimmed)
      if (sdMatch != null) {
        val sub = sdMatch.groupValues.getOrNull(1)?.trim().orEmpty()
        destFolderHint = if (sub.isNotBlank()) "SD:$sub" else "כרטיס SD"
        bodyWithoutDest = trimmed.substring(0, sdMatch.range.first).trim()
      } else {
        val folderDestRegex =
          Regex(
            "\\s+(?:אל\\s+תיקיית|לתיקיית|אל\\s+תיקייה|לתיקייה|אל\\s+תיקיה|לתיקיה|אל\\s+|ל-)\\s*[\"']?([^\"',\\n]+?)[\"']?(?:\\s+(?:בבקשה|בלי\\s+לדרוס|ודרוס|החלף\\s+אם\\s+קיים))?\\s*$",
            RegexOption.IGNORE_CASE
          )
        val fMatch = folderDestRegex.find(trimmed)
        if (fMatch != null) {
          val candidateDest = fMatch.groupValues[1].trim()
          if (candidateDest.isNotBlank() && candidateDest.lowercase(heLocale) !in pronounStopWords) {
            destFolderHint = candidateDest
            bodyWithoutDest = trimmed.substring(0, fMatch.range.first).trim()
          }
        }
      }
    }

    // Extract source folder hint from remaining body
    var sourceFolderHint: String? = null
    var bodyWithoutSource = bodyWithoutDest
    val srcExplicitRegex =
      Regex(
        "(?:מתיקיית|מתוך\\s+תיקיית|מתוך)\\s+[\"']?([A-Za-z0-9א-ת_.\\-/ ]+?)[\"']?(?=\\s+(?:ו?תעתיק|ו?תעביר|ו?תמחק|ו?תשנה|$))",
        RegexOption.IGNORE_CASE
      )
    val srcMatch = srcExplicitRegex.find(bodyWithoutDest)
    if (srcMatch != null) {
      sourceFolderHint = srcMatch.groupValues[1].trim()
      bodyWithoutSource = bodyWithoutDest.removeRange(srcMatch.range).trim()
    } else {
      val srcShortRegex =
        Regex("\\b(?:מהורדות|מההורדות|מתיקיית הורדות|מתמונות|ממסמכים|מכרטיס\\s*sd)\\b", RegexOption.IGNORE_CASE)
      val shortMatch = srcShortRegex.find(bodyWithoutDest)
      if (shortMatch != null) {
        sourceFolderHint =
          when {
            shortMatch.value.contains("הורד") -> "הורדות"
            shortMatch.value.contains("תמונ") -> "תמונות"
            shortMatch.value.contains("מסמכ") -> "מסמכים"
            else -> "כרטיס SD"
          }
        bodyWithoutSource = bodyWithoutDest.removeRange(shortMatch.range).trim()
      }
    }

    // Infer file category hint ONLY from the subject/source clause (never from dest)
    val bodyLower = bodyWithoutSource.lowercase(heLocale)
    val fileCategoryHint =
      when {
        bodyLower.contains("תמונה") || bodyLower.contains("תמונת") || bodyLower.contains("צילום") -> FileCategory.IMAGES
        bodyLower.contains("סרטון") || bodyLower.contains("וידאו") -> FileCategory.VIDEOS
        bodyLower.contains("מסמך") || bodyLower.contains("דוח") || bodyLower.contains("pdf") -> FileCategory.DOCUMENTS
        bodyLower.contains("שיר") || bodyLower.contains("שמע") || bodyLower.contains("אודיו") || bodyLower.contains("הקלטה") ->
          FileCategory.AUDIO
        bodyLower.contains("apk") -> FileCategory.APK_INSTALLERS
        bodyLower.contains("גיבוי") -> FileCategory.BACKUPS
        else -> null
      }

    // Extract file name query
    val fileNameQuery = extractFileNameQuery(bodyWithoutSource)
    val extHint =
      fileNameQuery
        ?.substringAfterLast('.', "")
        ?.takeIf { it.length in 2..5 && fileNameQuery.contains('.') }
        ?.lowercase(Locale.ROOT)

    val wantsOverwrite =
      q.contains("דרוס") || q.contains("לדרוס") || q.contains("החלף אם קיים") || q.contains("החלף קיים")

    return AikoParsedToolParameters(
      rawInput = trimmed,
      operation = operation,
      toolId = "smart_storage",
      fileNameQuery = fileNameQuery,
      fileCategoryHint = fileCategoryHint,
      extensionHint = extHint,
      sourceFolderHint = sourceFolderHint,
      destFolderHint = destFolderHint,
      newFileName = newFileName,
      wantsOverwrite = wantsOverwrite
    )
  }

  private fun extractFileNameQuery(subjectClause: String): String? {
    // 1. Explicit quoted file token
    val quotedMatch = Regex("[\"']([^\"']+)[\"']").find(subjectClause)
    if (quotedMatch != null) {
      val token = quotedMatch.groupValues[1].trim()
      if (token.isNotBlank() && token.lowercase(heLocale) !in pronounStopWords) return token
    }

    // 2. Token with file extension (e.g., report.pdf, IMG_12.jpg, invoice_2025.pdf)
    val extMatch = Regex("([A-Za-z0-9א-ת_\\-()]+\\.[A-Za-z0-9]{2,5})").find(subjectClause)
    if (extMatch != null) {
      return extMatch.groupValues[1].trim()
    }

    // 3. Token positioned after descriptor noun ("קובץ התמונה X", "הקובץ X", "את הדוח X", "התמונה X")
    val afterDescriptor =
      Regex(
        "(?:קובץ\\s+ה?(?:תמונה|וידאו|סרטון|מסמך|דוח|שמע|אודיו)|את\\s+ה?(?:קובץ|תמונה|מסמך|דוח|סרטון|שיר)|הקובץ|התמונה|המסמך|הדוח|הסרטון)\\s+([A-Za-z0-9א-ת_.\\-()]+)(?=\\s+(?:ו?תעתיק|ו?העתק|ו?תעביר|ו?העבר|ו?תמחק|ו?מחק|ו?תשנה|ו?שנה|ו?תדחס|ו?דחוס|אותו|אותה|$)|\\s*$)",
        RegexOption.IGNORE_CASE
      ).find(subjectClause)
    if (afterDescriptor != null) {
      val tok = afterDescriptor.groupValues[1].trim()
      if (tok.isNotBlank() && tok.lowercase(heLocale) !in pronounStopWords) return tok
    }

    // 4. Fallback token right after leading action verb ("תמצא את X", "העתק X", "מחק את X")
    val afterVerb =
      Regex(
        "^(?:מצא|תמצא|חפש|תחפש|אתר|העתק|תעתיק|העבר|תעביר|מחק|תמחק|שנה\\s+(?:את\\s+)?(?:השם|שם)\\s+של|תשנה\\s+(?:את\\s+)?(?:השם|שם)\\s+של|דחוס|תדחס|תדחוס)(?:\\s+(?:ל-?zip|את\\s+הקובץ))?(?:\\s+את|\\s+של)?\\s+([A-Za-z0-9א-ת_.\\-()]+)",
        RegexOption.IGNORE_CASE
      ).find(subjectClause.trim())
    if (afterVerb != null) {
      val tok = afterVerb.groupValues[1].trim()
      if (tok.isNotBlank() && tok.lowercase(heLocale) !in pronounStopWords) return tok
    }

    return null
  }

  fun resolveFileToolPlan(
    params: AikoParsedToolParameters,
    safTreeUris: Set<String>,
    report: SmartStorageScanReport?
  ): AikoResolvedFileActionPlan {
    val selectedTool =
      NexusToolRegistry.catalog.firstOrNull { it.id == params.toolId }
        ?: NexusToolRegistry.catalog.first { it.id == "smart_storage" }

    val paramTrace =
      buildList {
        add("כלי נבחר: ${selectedTool.nameHe} (${selectedTool.id})")
        add("פעולה: ${params.operation.titleHe}")
        params.fileNameQuery?.let { add("קובץ מבוקש: \"$it\"") }
        params.fileCategoryHint?.let { add("סוג קובץ: ${it.titleHe}") }
        params.sourceFolderHint?.let { add("מקור: $it") }
        params.destFolderHint?.let { add("יעד: $it") }
        params.newFileName?.let { add("שם חדש: $it") }
      }

    // Step 1/2 check: CLEAN_STORAGE does not require single file resolution
    if (params.operation == AikoRequestedOperation.CLEAN_STORAGE) {
      val tempCount = report?.files?.count { it.isTempResidual } ?: 0
      val dupCount = report?.duplicateGroups?.size ?: 0
      val steps =
        listOf(
          "1. הבנת הבקשה: ניקוי שאריות זמניות ומטמון (${selectedTool.nameHe})",
          "2. זיהוי ממצאים: אותרו $tempCount קבצים זמניים ו-$dupCount קבוצות כפילויות בסריקה",
          "3. בחירת יעד בטוח: מטמון אפליקציה פנימי וניקוי עמוק מבוקר",
          "4. תוכנית פעולה: פתיחת סריקת ניקוי לבחירה ואישור מפורש",
          "5. ממתין לאישור המשתמש — שום קובץ אינו נמחק לפני אישור"
        )
      return AikoResolvedFileActionPlan(
        params = params,
        selectedTool = selectedTool,
        plannedStepsHe = steps,
        summaryReplyHe =
          "זיהיתי בקשה לניקוי שאריות ומטמון (${paramTrace.joinToString(" • ")}). " +
            "כדי למנוע מחיקה בטעות, תוכל לאשר למטה מעבר למסך הניקוי החכם או להפיק תוכנית פעולה לאישור."
      )
    }

    if (safTreeUris.isEmpty() || report == null) {
      val reason =
        "לא אושרו תיקיות אחסון (SAF) לסריקה עדיין. יש להעניק הרשאת תיקייה או כרטיס SD ב'אחסון חכם' לפני פעולה על קבצים."
      return AikoResolvedFileActionPlan(
        params = params,
        selectedTool = selectedTool,
        plannedStepsHe = listOf("1. הבנת הבקשה", "2. עצירה בטוחה: אין גישת SAF מאושרת לתיקיות"),
        summaryReplyHe = reason,
        rejectionReasonHe = reason
      )
    }

    // Strict guard: do not operate blindly when filename query wasn't identified for mutating ops
    if (params.fileNameQuery.isNullOrBlank()) {
      val reason =
        "לא הצלחתי לזהות שם קובץ מדויק בבקשה שלך. כדי שלא אפעל על קובץ שגוי, ציין שם קובץ ברור (למשל: \"העתק את sunset.jpg לתיקיית התמונות\")."
      return AikoResolvedFileActionPlan(
        params = params,
        selectedTool = selectedTool,
        plannedStepsHe = listOf("1. הבנת הבקשה", "2. עצירה בטוחה: שם קובץ לא זוהה בבקשה"),
        summaryReplyHe = reason,
        rejectionReasonHe = reason
      )
    }

    // Step 2: Filter real files from SAF scan
    var pool = report.files
    if (!params.sourceFolderHint.isNullOrBlank()) {
      val srcHint = params.sourceFolderHint.trim()
      pool = pool.filter { fileMatchesFolderHint(it, srcHint) }
    }
    if (params.fileCategoryHint != null) {
      pool = pool.filter { fileMatchesCategory(it, params.fileCategoryHint) }
    }

    val query = params.fileNameQuery.trim()
    val exactName = pool.filter { it.name.equals(query, ignoreCase = true) }
    val exactStem =
      if (exactName.isNotEmpty()) exactName
      else pool.filter { it.name.substringBeforeLast('.').equals(query, ignoreCase = true) }
    val containsMatches =
      if (exactStem.isNotEmpty()) exactStem
      else pool.filter { it.name.contains(query, ignoreCase = true) || it.relativePath.contains(query, ignoreCase = true) }

    if (containsMatches.isEmpty()) {
      val scopeNote =
        buildString {
          params.fileCategoryHint?.let { append("מסוג ${it.titleHe} ") }
          params.sourceFolderHint?.let { append("בתיקיית '$it' ") }
        }.trim()
      val reason =
        "לא נמצא קובץ בשם \"$query\" ${if (scopeNote.isNotEmpty()) "($scopeNote) " else ""}מתוך ${report.files.size} הקבצים שנסרקו ב-SAF. ודא שהתיקייה מאושרת או דייק את שם הקובץ."
      return AikoResolvedFileActionPlan(
        params = params,
        selectedTool = selectedTool,
        plannedStepsHe =
          listOf(
            "1. הבנת הבקשה: ${paramTrace.joinToString(" | ")}",
            "2. זיהוי קובץ: חיפוש \"$query\" מתוך ${report.files.size} קבצים — נמצאו 0 התאמות",
            "3. עצירה בטוחה: לא תבוצע פעולה על קובץ שלא אותר"
          ),
        summaryReplyHe = reason,
        rejectionReasonHe = reason
      )
    }

    if (containsMatches.size > 1 && params.operation != AikoRequestedOperation.FIND_SCAN) {
      val previewList =
        containsMatches.take(6).joinToString("\n") { f -> "• ${f.name} (${f.relativePath}, ${formatBytes(f.sizeBytes)})" }
      val reason =
        "נמצאו ${containsMatches.size} קבצים המתאימים ל-\"$query\" — כדי למנוע טעות, אייקו אינו פועל כשיש אי-ודאות. בחר שם מדויק:\n$previewList"
      return AikoResolvedFileActionPlan(
        params = params,
        selectedTool = selectedTool,
        candidateFiles = containsMatches.take(10),
        plannedStepsHe =
          listOf(
            "1. הבנת הבקשה: ${paramTrace.joinToString(" | ")}",
            "2. זיהוי קובץ: נמצאו ${containsMatches.size} קבצים דומים — נדרש מיקוד מהמשתמש",
            "3. עצירה בטוחה: נמנעה פעולה עקב עמימות"
          ),
        summaryReplyHe = reason,
        rejectionReasonHe = reason
      )
    }

    // FIND_SCAN succeeds with 1 or more matches (read-only)
    if (params.operation == AikoRequestedOperation.FIND_SCAN) {
      val listText =
        containsMatches.take(8).joinToString("\n") { f ->
          "• ${f.name} — ${f.relativePath} (${f.mimeType}, ${formatBytes(f.sizeBytes)})"
        }
      val steps =
        listOf(
          "1. הבנת הבקשה: חיפוש קובץ \"$query\"",
          "2. זיהוי קבצים ב-SAF: אותרו ${containsMatches.size} תוצאות מאומתות",
          "7. אימות תוצאה: הוצגו הנתיבים האמיתיים (${containsMatches.first().volumeKind.titleHe})",
          "8. דיווח למשתמש: הושלם ללא שינוי קבצים"
        )
      return AikoResolvedFileActionPlan(
        params = params,
        selectedTool = selectedTool,
        matchedFile = containsMatches.firstOrNull(),
        candidateFiles = containsMatches,
        plannedStepsHe = steps,
        summaryReplyHe = "נמצאו ${containsMatches.size} קבצים תואמים ל-\"$query\":\n$listText"
      )
    }

    val targetFile = containsMatches.first()

    // Step 3: Destination / parameter validation per mutating operation
    var resolvedDestTree: String? = targetFile.treeUriString
    var resolvedDestFolderRel: String? = null
    var resolvedDestDocId: String? = null
    var resolvedDestDisplay: String = targetFile.relativePath

    when (params.operation) {
      AikoRequestedOperation.COPY_FILE,
      AikoRequestedOperation.MOVE_FILE -> {
        val hint = params.destFolderHint?.trim()
        if (hint.isNullOrBlank()) {
          val reason = "לא צוינה תיקיית יעד ברורה עבור '${targetFile.name}'. ציין למשל \"לתיקיית התמונות\" או \"לכרטיס SD\"."
          return AikoResolvedFileActionPlan(
            params = params,
            selectedTool = selectedTool,
            matchedFile = targetFile,
            plannedStepsHe = listOf("1. הבנת הבקשה", "2. קובץ זוהה: ${targetFile.relativePath}", "3. עצירה: תיקיית יעד חסרה"),
            summaryReplyHe = reason,
            rejectionReasonHe = reason
          )
        }

        val resolvedDest = resolveDestinationFolder(hint, safTreeUris, report)
        if (resolvedDest == null) {
          val sdRequested = hint.contains("sd", ignoreCase = true) || hint.contains("כרטיס")
          val available = report.folders.take(6).joinToString(", ") { it.relativePath }
          val reason =
            if (sdRequested && !report.hasSdCard) {
              "כרטיס SD אינו מחובר או לא אושר בהרשאות SAF כרגע — לא ניתן להעביר או להעתיק אל '$hint'."
            } else {
              "תיקיית היעד המבוקשת ('$hint') לא נמצאה בתיקיות SAF שאושרו. תיקיות זמינות: ${available.ifBlank { "אין" }}."
            }
          return AikoResolvedFileActionPlan(
            params = params,
            selectedTool = selectedTool,
            matchedFile = targetFile,
            plannedStepsHe = listOf("1. הבנת הבקשה", "2. קובץ זוהה: ${targetFile.relativePath}", "3. עצירה: יעד '$hint' לא זמין ב-SAF"),
            summaryReplyHe = reason,
            rejectionReasonHe = reason
          )
        }

        resolvedDestTree = resolvedDest.treeUriString
        resolvedDestFolderRel = resolvedDest.relativePathForEnsure
        resolvedDestDocId = resolvedDest.folderDocId
        resolvedDestDisplay = resolvedDest.displayLabelHe

        // Same-folder protection
        if (resolvedDestTree == targetFile.treeUriString && resolvedDestDocId == targetFile.parentDocId) {
          val reason = "הקובץ '${targetFile.name}' כבר נמצא בתוך תיקיית היעד (${resolvedDest.displayLabelHe})."
          return AikoResolvedFileActionPlan(
            params = params,
            selectedTool = selectedTool,
            matchedFile = targetFile,
            plannedStepsHe = listOf("1. הבנת הבקשה", "2. קובץ זוהה: ${targetFile.relativePath}", "3. עצירה: המקור והיעד זהים"),
            summaryReplyHe = reason,
            rejectionReasonHe = reason
          )
        }

        // Non-overwrite guard (unless user explicitly requested overwrite)
        val duplicateTarget =
          report.files.firstOrNull {
            it.treeUriString == resolvedDestTree &&
              it.parentDocId == resolvedDestDocId &&
              it.name.equals(targetFile.name, ignoreCase = true)
          }
        if (duplicateTarget != null && !params.wantsOverwrite) {
          val reason =
            "בתיקיית היעד ($resolvedDestDisplay) כבר קיים קובץ בשם '${targetFile.name}'. " +
              "הפעולה נעצרה כדי למנוע דריסה ללא אישור מפורש."
          return AikoResolvedFileActionPlan(
            params = params,
            selectedTool = selectedTool,
            matchedFile = targetFile,
            plannedStepsHe = listOf("1. הבנת הבקשה", "2. קובץ זוהה: ${targetFile.relativePath}", "3. הגנת דריסה: קיים קובץ בשם זהה ביעד"),
            summaryReplyHe = reason,
            rejectionReasonHe = reason
          )
        }
      }

      AikoRequestedOperation.RENAME_FILE -> {
        val newName = params.newFileName?.trim()
        if (newName.isNullOrBlank() || newName == targetFile.name) {
          val reason = "לא צוין שם חדש תקין לשינוי שם הקובץ '${targetFile.name}'."
          return AikoResolvedFileActionPlan(
            params = params,
            selectedTool = selectedTool,
            matchedFile = targetFile,
            plannedStepsHe = listOf("1. הבנת הבקשה", "2. קובץ זוהה: ${targetFile.relativePath}", "3. עצירה: שם חדש חסר"),
            summaryReplyHe = reason,
            rejectionReasonHe = reason
          )
        }
        resolvedDestDisplay = "${targetFile.relativePath} ← $newName"
      }

      AikoRequestedOperation.ZIP_FILE -> {
        val zipName = "${targetFile.name.substringBeforeLast('.')}.zip"
        resolvedDestFolderRel = null
        resolvedDestDisplay = "${targetFile.volumeKind.titleHe}/$zipName"
      }

      AikoRequestedOperation.DELETE_FILE -> {
        resolvedDestDisplay = targetFile.relativePath
      }

      else -> Unit
    }

    // Build real ApprovalOperationType + AiOrganizationProposalDraft
    val draft =
      when (params.operation) {
        AikoRequestedOperation.COPY_FILE ->
          AiOrganizationProposalDraft(
            title = "אייקו: העתקת ${targetFile.name}",
            reasonHe = "בקשת משתמש להעתקת קובץ ${targetFile.category.titleHe} (${targetFile.mimeType}) עם אימות SHA-256.",
            targetName = targetFile.name,
            targetLocation = "${targetFile.relativePath} ← $resolvedDestDisplay",
            operationType = ApprovalOperationType.COPY_SAF_DOCUMENT,
            riskLevel = ApprovalRiskLevel.LOW,
            isReversible = true,
            expectedOutcomeHe = "ייווצר עותק מאומת SHA-256 של ${targetFile.name} בתוך $resolvedDestDisplay; המקור יישאר שמור.",
            sourceUriString = targetFile.uriString,
            treeUriString = targetFile.treeUriString,
            destTreeUriString = resolvedDestTree,
            destFolderName = resolvedDestFolderRel,
            proposedNewName = if (params.wantsOverwrite) "OVERWRITE" else null,
            bytesAffected = targetFile.sizeBytes
          )

        AikoRequestedOperation.MOVE_FILE ->
          AiOrganizationProposalDraft(
            title = "אייקו: העברת ${targetFile.name}",
            reasonHe = "בקשת משתמש להעברת קובץ (${targetFile.mimeType}); המקור יימחק רק לאחר אימות שלמות ההעתקה ביעד.",
            targetName = targetFile.name,
            targetLocation = "${targetFile.relativePath} ← $resolvedDestDisplay",
            operationType = ApprovalOperationType.MOVE_SAF_DOCUMENT,
            riskLevel = ApprovalRiskLevel.MEDIUM,
            isReversible = true,
            expectedOutcomeHe = "הקובץ יועבר אל $resolvedDestDisplay עם שמירת אפשרות ביטול (Undo) למיקום המקורי.",
            sourceUriString = targetFile.uriString,
            treeUriString = targetFile.treeUriString,
            destTreeUriString = resolvedDestTree,
            destFolderName = resolvedDestFolderRel,
            proposedNewName = if (params.wantsOverwrite) "OVERWRITE" else null,
            bytesAffected = targetFile.sizeBytes
          )

        AikoRequestedOperation.DELETE_FILE ->
          AiOrganizationProposalDraft(
            title = "אייקו: מחיקת ${targetFile.name}",
            reasonHe = "בקשת משתמש מפורשת למחיקת קובץ מ-${targetFile.relativePath}.",
            targetName = targetFile.name,
            targetLocation = targetFile.relativePath,
            operationType = ApprovalOperationType.DELETE_SAF_DOCUMENT,
            riskLevel = ApprovalRiskLevel.HIGH,
            isReversible = false,
            expectedOutcomeHe = "הקובץ ${targetFile.name} (${formatBytes(targetFile.sizeBytes)}) יימחק לצמיתות מהאחסון.",
            sourceUriString = targetFile.uriString,
            treeUriString = targetFile.treeUriString,
            bytesAffected = targetFile.sizeBytes
          )

        AikoRequestedOperation.RENAME_FILE ->
          AiOrganizationProposalDraft(
            title = "אייקו: שינוי שם ${targetFile.name}",
            reasonHe = "שינוי שם קובץ ב-SAF מ-'${targetFile.name}' אל '${params.newFileName}'.",
            targetName = targetFile.name,
            targetLocation = targetFile.relativePath,
            operationType = ApprovalOperationType.RENAME_SAF_DOCUMENT,
            riskLevel = ApprovalRiskLevel.LOW,
            isReversible = true,
            expectedOutcomeHe = "השם ישונה ל-'${params.newFileName}' (ניתן לביטול במרכז ה-Undo).",
            sourceUriString = targetFile.uriString,
            treeUriString = targetFile.treeUriString,
            proposedNewName = params.newFileName,
            bytesAffected = targetFile.sizeBytes
          )

        AikoRequestedOperation.ZIP_FILE -> {
          val zipName = "${targetFile.name.substringBeforeLast('.')}_${System.currentTimeMillis() / 1000L}.zip"
          AiOrganizationProposalDraft(
            title = "אייקו: דחיסת ${targetFile.name} ל-ZIP",
            reasonHe = "יצירת ארכיון ZIP מאומת מתוך ${targetFile.relativePath}.",
            targetName = zipName,
            targetLocation = targetFile.relativePath,
            operationType = ApprovalOperationType.ZIP_CREATE,
            riskLevel = ApprovalRiskLevel.LOW,
            isReversible = true,
            expectedOutcomeHe = "ייווצר ארכיון $zipName בשורש התיקייה המאושרת.",
            sourceUriString = targetFile.uriString,
            treeUriString = targetFile.treeUriString,
            destTreeUriString = targetFile.treeUriString,
            proposedNewName = zipName,
            bytesAffected = targetFile.sizeBytes
          )
        }

        AikoRequestedOperation.FIND_SCAN,
        AikoRequestedOperation.CLEAN_STORAGE -> null
      }

    // Build complete 8-step plan
    val steps8 =
      listOf(
        "1. הבנת הבקשה: ${params.operation.titleHe} — כלי: ${selectedTool.nameHe}",
        "2. זיהוי קובץ אמיתי: ${targetFile.name} (${targetFile.mimeType}, ${formatBytes(targetFile.sizeBytes)}, נתיב: ${targetFile.relativePath})",
        "3. זיהוי תיקיית יעד: $resolvedDestDisplay",
        "4. הצגת תוכנית פעולה: ${draft?.expectedOutcomeHe ?: "פעולת קובץ בטוחה"}",
        "5. בקשת אישור: ממתין לאישור מפורש שלך בכפתור הפעולה למטה לפני כל שינוי",
        "6. ביצוע אמיתי ב-SAF: ירוץ מיד לאחר אישורך (ללא דריסה, עם אימות שלמות)",
        "7. אימות תוצאה: בדיקת קיום הקובץ ביעד וסריקה מחדש של ה-SAF",
        "8. דיווח למשתמש: הצגת תוצאה מאומתת ותיעוד ביומן הבקרה ובמרכז ה-Undo"
      )

    val reply =
      buildString {
        appendLine("תוכנית פעולה מוכנה לאישורך (${selectedTool.nameHe}):")
        appendLine("• קובץ מקור מאומת: ${targetFile.name} (${targetFile.relativePath})")
        appendLine("• סוג MIME: ${targetFile.mimeType} • גודל: ${formatBytes(targetFile.sizeBytes)}")
        appendLine("• יעד: $resolvedDestDisplay")
        append("אף קובץ עדיין לא שונה. אשר למטה לביצוע הפעולה.")
      }

    return AikoResolvedFileActionPlan(
      params = params,
      selectedTool = selectedTool,
      matchedFile = targetFile,
      candidateFiles = listOf(targetFile),
      destTreeUriString = resolvedDestTree,
      destFolderRelativePath = resolvedDestFolderRel,
      destFolderDocId = resolvedDestDocId,
      destDisplayLabelHe = resolvedDestDisplay,
      plannedStepsHe = steps8,
      proposalDraft = draft,
      summaryReplyHe = reply
    )
  }

  private data class ResolvedSafDestination(
    val treeUriString: String,
    val folderDocId: String,
    val relativePathForEnsure: String,
    val displayLabelHe: String
  )

  private fun resolveDestinationFolder(
    destHint: String,
    safTreeUris: Set<String>,
    report: SmartStorageScanReport
  ): ResolvedSafDestination? {
    val cleanHint = destHint.trim().lowercase(heLocale)
    val isSdHint = cleanHint == "כרטיס sd" || cleanHint == "sd" || cleanHint == "sd card" || cleanHint.startsWith("sd:")

    if (isSdHint) {
      val sdVolume = report.volumes.firstOrNull { it.kind == StorageVolumeKind.SD_CARD && it.isMounted }
      val sdTreeStr = sdVolume?.authorizedTreeUris?.firstOrNull() ?: return null
      val sdRootDocId =
        runCatching { DocumentsContract.getTreeDocumentId(Uri.parse(sdTreeStr)) }.getOrNull() ?: return null
      if (cleanHint.startsWith("sd:")) {
        val subHint = destHint.substringAfter(':').trim()
        val matchingSub =
          report.folders.firstOrNull {
            it.treeUriString == sdTreeStr && folderMatchesHint(it, subHint)
          }
        if (matchingSub != null) {
          val rel = computeRelativeSubpath(sdTreeStr, matchingSub)
          return ResolvedSafDestination(sdTreeStr, matchingSub.docId, rel, "כרטיס SD/${matchingSub.relativePath}")
        }
        return null
      }
      return ResolvedSafDestination(sdTreeStr, sdRootDocId, ".", "כרטיס SD (שורש מאושר)")
    }

    // Match scanned SAF folders first (non-root subfolders preferred over root when matching specific name)
    val hintAliases = expandFolderAliases(cleanHint)
    val candidates =
      report.folders.filter { folder ->
        val nameLow = folder.folderName.lowercase(heLocale)
        val relLow = folder.relativePath.lowercase(heLocale)
        hintAliases.any { alias ->
          nameLow == alias ||
            nameLow.contains(alias) ||
            relLow == alias ||
            relLow.endsWith("/$alias")
        }
      }

    if (candidates.isNotEmpty()) {
      // Prefer exact folder name match, then internal volume (unless user asked for SD), then shallowest path
      val chosen =
        candidates.sortedWith(
          compareByDescending<FolderStorageSummary> { f -> hintAliases.any { it == f.folderName.lowercase(heLocale) } }
            .thenByDescending { it.volumeKind == StorageVolumeKind.INTERNAL }
            .thenBy { it.relativePath.count { ch -> ch == '/' } }
        ).first()
      val rel = computeRelativeSubpath(chosen.treeUriString, chosen)
      return ResolvedSafDestination(
        treeUriString = chosen.treeUriString,
        folderDocId = chosen.docId,
        relativePathForEnsure = rel,
        displayLabelHe = "${chosen.volumeKind.titleHe}: ${chosen.relativePath}"
      )
    }

    // Fallback: match authorized tree root label directly if user named the root folder
    for (treeStr in safTreeUris) {
      val rootDocId =
        runCatching { DocumentsContract.getTreeDocumentId(Uri.parse(treeStr)) }.getOrNull() ?: continue
      val rootLabel = rootDocId.substringAfterLast(':').lowercase(heLocale)
      if (hintAliases.any { alias -> rootLabel == alias || rootLabel.contains(alias) }) {
        return ResolvedSafDestination(
          treeUriString = treeStr,
          folderDocId = rootDocId,
          relativePathForEnsure = ".",
          displayLabelHe = rootDocId.substringAfterLast(':').ifBlank { "תיקיית השורש" }
        )
      }
    }

    return null
  }

  private fun computeRelativeSubpath(treeUriStr: String, folder: FolderStorageSummary): String {
    val rootDocId =
      runCatching { DocumentsContract.getTreeDocumentId(Uri.parse(treeUriStr)) }.getOrNull()
    if (rootDocId != null && folder.docId == rootDocId) return "."
    val rootLabel =
      rootDocId?.substringAfterLast(':')?.ifBlank { null }
    val rel = folder.relativePath
    return if (rootLabel != null && rel.startsWith("$rootLabel/", ignoreCase = true)) {
      rel.substring(rootLabel.length + 1).ifBlank { "." }
    } else if (rootLabel != null && rel.equals(rootLabel, ignoreCase = true)) {
      "."
    } else {
      rel
    }
  }

  private fun expandFolderAliases(cleanHint: String): Set<String> {
    val stripped =
      cleanHint
        .removePrefix("תיקיית ")
        .removePrefix("התיקייה ")
        .removePrefix("לתיקיית ")
        .trim()
    val result = linkedSetOf(cleanHint, stripped)
    val groups = listOf(imageAliases, downloadAliases, documentAliases, musicAliases, videoAliases, backupAliases)
    for (group in groups) {
      if (group.any { stripped == it || cleanHint == it || stripped.contains(it) }) {
        result.addAll(group)
      }
    }
    return result.filter { it.isNotBlank() }.toSet()
  }

  private fun folderMatchesHint(folder: FolderStorageSummary, hint: String): Boolean {
    val aliases = expandFolderAliases(hint.lowercase(heLocale))
    val n = folder.folderName.lowercase(heLocale)
    val r = folder.relativePath.lowercase(heLocale)
    return aliases.any { a -> n == a || n.contains(a) || r.endsWith("/$a") || r.contains(a) }
  }

  private fun fileMatchesFolderHint(file: ScannedFileEntry, hint: String): Boolean {
    val clean = hint.trim().lowercase(heLocale)
    if (clean.contains("sd") || clean.contains("כרטיס")) {
      return file.volumeKind == StorageVolumeKind.SD_CARD
    }
    val aliases = expandFolderAliases(clean)
    val relLow = file.relativePath.lowercase(heLocale)
    return aliases.any { a -> relLow.contains("/$a/") || relLow.startsWith("$a/") || relLow.contains(a) }
  }

  private fun fileMatchesCategory(file: ScannedFileEntry, cat: FileCategory): Boolean {
    if (file.category == cat) return true
    return when (cat) {
      FileCategory.IMAGES -> file.mimeType.startsWith("image/", ignoreCase = true)
      FileCategory.VIDEOS -> file.mimeType.startsWith("video/", ignoreCase = true)
      FileCategory.AUDIO -> file.mimeType.startsWith("audio/", ignoreCase = true)
      FileCategory.DOCUMENTS ->
        file.mimeType.startsWith("text/", ignoreCase = true) ||
          file.mimeType.contains("pdf", ignoreCase = true) ||
          file.mimeType.contains("document", ignoreCase = true)
      else -> false
    }
  }
}
