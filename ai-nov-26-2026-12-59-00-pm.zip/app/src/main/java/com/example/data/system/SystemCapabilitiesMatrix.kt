package com.example.data.system

import android.os.Build

enum class CapabilityAvailabilityStatus(val labelHe: String) {
  AVAILABLE_IMPLEMENTED("זמינה וממומשת"),
  REQUIRES_PERMISSION("דורשת הרשאה"),
  REQUIRES_EXTERNAL_CONNECTION("דורשת חיבור חיצוני"),
  NOT_POSSIBLE_ON_CURRENT_ANDROID("אינה אפשרית בגרסת Android הנוכחית")
}

data class SystemCapabilityItem(
  val id: String,
  val titleHe: String,
  val categoryHe: String,
  val status: CapabilityAvailabilityStatus,
  val detailHe: String,
  val actionRoute: String? = null
)

object SystemCapabilitiesMatrix {

  fun evaluateCapabilities(
    hasUsageStatsPermission: Boolean,
    hasSafFoldersAuthorized: Boolean,
    hasMicPermission: Boolean,
    hasCloudConnectionReady: Boolean,
    hasSamsungDeviceCare: Boolean,
    sdkInt: Int = Build.VERSION.SDK_INT
  ): List<SystemCapabilityItem> =
    listOf(
      SystemCapabilityItem(
        id = "own_cache_clean",
        titleHe = "ניקוי ישיר של מטמון NEXUS",
        categoryHe = "אחסון ומטמון",
        status = CapabilityAvailabilityStatus.AVAILABLE_IMPLEMENTED,
        detailHe = "מוחק מיידית קבצים זמניים ב-cacheDir, codeCacheDir ו-externalCacheDir עם מדידת שטח מדויקת.",
        actionRoute = "cache_cleaner"
      ),
      SystemCapabilityItem(
        id = "app_cache_inspection",
        titleHe = "זיהוי ומדידת מטמון של כל האפליקציות",
        categoryHe = "אחסון ומטמון",
        status =
          if (hasUsageStatsPermission) CapabilityAvailabilityStatus.AVAILABLE_IMPLEMENTED
          else CapabilityAvailabilityStatus.REQUIRES_PERMISSION,
        detailHe =
          if (hasUsageStatsPermission) "גישה ל-StorageStatsManager פעילה — נפח המטמון והנתונים של כל אפליקציה נמדד בזמן אמת."
          else "נדרשת הרשאת גישה לנתוני שימוש (PACKAGE_USAGE_STATS) בהגדרות Android.",
        actionRoute = "cache_cleaner"
      ),
      SystemCapabilityItem(
        id = "third_party_silent_cache_wipe",
        titleHe = "מחיקה שקטה של מטמון אפליקציות צד ג׳ ברקע",
        categoryHe = "אחסון ומטמון",
        status = CapabilityAvailabilityStatus.NOT_POSSIBLE_ON_CURRENT_ANDROID,
        detailHe = "מגבלת אבטחה של Android $sdkInt (ללא הרשאות Root/System): האפליקציה פותחת את מסך האפליקציה המדויק או דיאלוג המערכת לאישורך ומודדת הפרש נפח בחזרה.",
        actionRoute = "cache_cleaner"
      ),
      SystemCapabilityItem(
        id = "saf_files_and_sd",
        titleHe = "ניהול קבצים, תיקיות וכרטיס SD",
        categoryHe = "קבצים ואחסון",
        status =
          if (hasSafFoldersAuthorized) CapabilityAvailabilityStatus.AVAILABLE_IMPLEMENTED
          else CapabilityAvailabilityStatus.REQUIRES_PERMISSION,
        detailHe =
          if (hasSafFoldersAuthorized) "תיקיות מאושרות דרך SAF זמינות לניתוח כפילויות SHA-256, העברה, גיבוי וארגון."
          else "יש לבחור תיקייה או כרטיס SD דרך בורר התיקיות המאובטח (SAF) של Android.",
        actionRoute = "smart_storage"
      ),
      SystemCapabilityItem(
        id = "telemetry_and_doctor",
        titleHe = "טלמטריה חיה ורופא המכשיר (12 בדיקות)",
        categoryHe = "אבחון וחומרה",
        status = CapabilityAvailabilityStatus.AVAILABLE_IMPLEMENTED,
        detailHe = "קריאה ישירה מחיישני סוללה, זיכרון RAM, StatFs, רשת וביקורת הרשאות רגישות.",
        actionRoute = "device_doctor"
      ),
      SystemCapabilityItem(
        id = "samsung_device_care_bridge",
        titleHe = "חיבור ישיר ל-Samsung Device Care",
        categoryHe = "אופטימיזציה",
        status =
          if (hasSamsungDeviceCare) CapabilityAvailabilityStatus.AVAILABLE_IMPLEMENTED
          else CapabilityAvailabilityStatus.NOT_POSSIBLE_ON_CURRENT_ANDROID,
        detailHe =
          if (hasSamsungDeviceCare) "רכיב התחזוקה המובנה של Samsung Galaxy זוהה ומוכן להפעלה בלחיצה."
          else "אינו זמין במכשירים שאינם Samsung או בסביבת אמולטור.",
        actionRoute = "system_control"
      ),
      SystemCapabilityItem(
        id = "silent_wifi_toggle",
        titleHe = "כיבוי/הדלקה שקטה של Wi-Fi מתוך אפליקציה",
        categoryHe = "מערכת וקישוריות",
        status = CapabilityAvailabilityStatus.NOT_POSSIBLE_ON_CURRENT_ANDROID,
        detailHe = "ב-Android 10 (API 29) Google חסמה שינוי שקט של Wi-Fi; המערכת פותחת את פאנל הקישוריות הרשמי (Settings.Panel.ACTION_INTERNET_CONNECTIVITY).",
        actionRoute = "system_control"
      ),
      SystemCapabilityItem(
        id = "cloud_ai_reasoning",
        titleHe = "בינה מלאכותית בענן (Firebase AI Logic / שרת מותאם)",
        categoryHe = "אייקו ובינה מלאכותית",
        status =
          if (hasCloudConnectionReady) CapabilityAvailabilityStatus.AVAILABLE_IMPLEMENTED
          else CapabilityAvailabilityStatus.REQUIRES_EXTERNAL_CONNECTION,
        detailHe =
          if (hasCloudConnectionReady) "מחובר וזמין לשיחה חופשית, תכנון, סיכום מסמכים וניתוח תמונות (עם מנגנון פקודות מקומי בעת ניתוק)."
          else "כרגע אין חיבור רשת פעיל או שהספק ממתין לחיבור שרת חיצוני; המנוע המקומי פועל ללא אינטרנט.",
        actionRoute = "settings"
      ),
      SystemCapabilityItem(
        id = "voice_transcription_and_live",
        titleHe = "זיהוי קולי והקלטת פקודות (אייקו)",
        categoryHe = "אייקו וקול",
        status =
          if (hasMicPermission) CapabilityAvailabilityStatus.AVAILABLE_IMPLEMENTED
          else CapabilityAvailabilityStatus.REQUIRES_PERMISSION,
        detailHe =
          if (hasMicPermission) "הרשאת המיקרופון מאושרת — זמין להכתבה ולשיחה קולית."
          else "דורש אישור הרשאת מיקרופון (RECORD_AUDIO) בעת הפעלה ראשונה.",
        actionRoute = "assistant"
      ),
      SystemCapabilityItem(
        id = "personal_tasks_and_projects",
        titleHe = "ניהול משימות אישיות, רשימות ופרויקטים שמורים",
        categoryHe = "ניהול אישי",
        status = CapabilityAvailabilityStatus.AVAILABLE_IMPLEMENTED,
        detailHe = "שמירה רציפה במסד Room מקומי + ייצוא/שחזור בקבצי הגיבוי של NEXUS.",
        actionRoute = "tasks_projects"
      )
    )
}
