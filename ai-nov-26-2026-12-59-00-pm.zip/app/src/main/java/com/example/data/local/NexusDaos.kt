package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CleanHistoryDao {
  @Query("SELECT * FROM clean_history ORDER BY timestampMillis DESC LIMIT 50")
  fun observeHistory(): Flow<List<CleanHistoryEntity>>

  @Query("SELECT * FROM clean_history ORDER BY timestampMillis DESC LIMIT 50")
  suspend fun getHistoryOnce(): List<CleanHistoryEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(entry: CleanHistoryEntity)

  @Query("DELETE FROM clean_history")
  suspend fun clearAll()
}

@Dao
interface TelemetrySnapshotDao {
  @Query("SELECT * FROM telemetry_snapshots ORDER BY timestampMillis DESC LIMIT 40")
  fun observeRecentSnapshots(): Flow<List<TelemetrySnapshotEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(snapshot: TelemetrySnapshotEntity)

  @Query(
    "DELETE FROM telemetry_snapshots WHERE id NOT IN (SELECT id FROM telemetry_snapshots ORDER BY timestampMillis DESC LIMIT 120)"
  )
  suspend fun pruneOld()

  @Query("DELETE FROM telemetry_snapshots")
  suspend fun clearAll()
}

@Dao
interface AssistantMessageDao {
  @Query(
    "SELECT * FROM (SELECT * FROM assistant_messages ORDER BY timestampMillis DESC LIMIT 100) ORDER BY timestampMillis ASC"
  )
  fun observeMessages(): Flow<List<AssistantMessageEntity>>

  @Query(
    "SELECT * FROM (SELECT * FROM assistant_messages ORDER BY timestampMillis DESC LIMIT :limit) ORDER BY timestampMillis ASC"
  )
  suspend fun getRecentOnce(limit: Int = 10): List<AssistantMessageEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(message: AssistantMessageEntity)

  @Query("DELETE FROM assistant_messages")
  suspend fun clearAll()
}

@Dao
interface AutomationDao {
  @Query("SELECT * FROM automations ORDER BY isBuiltIn DESC, id ASC")
  fun observeAutomations(): Flow<List<AutomationEntity>>

  @Query("SELECT * FROM automations")
  suspend fun getAllOnce(): List<AutomationEntity>

  @Query("SELECT * FROM automations WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): AutomationEntity?

  @Query("SELECT * FROM automations WHERE scheduleIntervalHours > 0")
  suspend fun getScheduledOnce(): List<AutomationEntity>

  @Query("SELECT * FROM automations WHERE isBuiltIn = 0 ORDER BY id ASC")
  suspend fun getCustomOnce(): List<AutomationEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(automation: AutomationEntity): Long

  @Update
  suspend fun update(automation: AutomationEntity)

  @Query("UPDATE automations SET scheduleIntervalHours = :hours WHERE id = :id")
  suspend fun updateSchedule(id: Long, hours: Int)

  @Query("DELETE FROM automations WHERE id = :id AND isBuiltIn = 0")
  suspend fun deleteCustom(id: Long)

  @Query("DELETE FROM automations WHERE isBuiltIn = 0")
  suspend fun deleteAllCustom()
}

@Dao
interface ActionAuditDao {
  @Query("SELECT * FROM action_audit ORDER BY timestampMillis DESC LIMIT 80")
  fun observeAuditLogs(): Flow<List<ActionAuditEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(audit: ActionAuditEntity)

  @Query("DELETE FROM action_audit")
  suspend fun clearAll()
}

@Dao
interface ApprovalProposalDao {
  @Query("SELECT * FROM approval_proposals WHERE status = 'PENDING' ORDER BY createdAtMillis DESC LIMIT 120")
  fun observePending(): Flow<List<ApprovalProposalEntity>>

  @Query("SELECT * FROM approval_proposals WHERE status != 'PENDING' ORDER BY createdAtMillis DESC LIMIT 80")
  fun observeHistory(): Flow<List<ApprovalProposalEntity>>

  @Query("SELECT * FROM approval_proposals WHERE status = 'PENDING' ORDER BY createdAtMillis DESC")
  suspend fun getPendingOnce(): List<ApprovalProposalEntity>

  @Query("SELECT * FROM approval_proposals WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): ApprovalProposalEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(proposal: ApprovalProposalEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(proposals: List<ApprovalProposalEntity>): List<Long>

  @Query("UPDATE approval_proposals SET status = :status, resultMessageHe = :resultMessage WHERE id = :id")
  suspend fun updateStatus(id: Long, status: String, resultMessage: String?)

  @Query("DELETE FROM approval_proposals WHERE status = 'PENDING'")
  suspend fun clearPending()

  @Query("DELETE FROM approval_proposals")
  suspend fun clearAll()
}

@Dao
interface UndoRecordDao {
  @Query("SELECT * FROM undo_records ORDER BY createdAtMillis DESC LIMIT 60")
  fun observeUndoRecords(): Flow<List<UndoRecordEntity>>

  @Query("SELECT * FROM undo_records WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): UndoRecordEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(record: UndoRecordEntity): Long

  @Query("UPDATE undo_records SET undone = 1, noteHe = :note WHERE id = :id")
  suspend fun markUndone(id: Long, note: String)

  @Query("DELETE FROM undo_records")
  suspend fun clearAll()
}

@Dao
interface BackupRecordDao {
  @Query("SELECT * FROM backup_records ORDER BY createdAtMillis DESC LIMIT 40")
  fun observeBackups(): Flow<List<BackupRecordEntity>>

  @Query("SELECT * FROM backup_records WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): BackupRecordEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(record: BackupRecordEntity): Long

  @Query("DELETE FROM backup_records WHERE id = :id")
  suspend fun deleteById(id: Long)

  @Query("DELETE FROM backup_records")
  suspend fun clearAll()
}

@Dao
interface MemoryEntryDao {
  @Query("SELECT * FROM memory_entries ORDER BY updatedAtMillis DESC LIMIT 120")
  fun observeAll(): Flow<List<MemoryEntryEntity>>

  @Query("SELECT * FROM memory_entries WHERE canPersist = 1 ORDER BY importanceScore DESC, updatedAtMillis DESC LIMIT :limit")
  suspend fun getActivePersistableOnce(limit: Int = 40): List<MemoryEntryEntity>

  @Query("SELECT * FROM memory_entries ORDER BY updatedAtMillis DESC")
  suspend fun getAllOnce(): List<MemoryEntryEntity>

  @Query("SELECT * FROM memory_entries WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): MemoryEntryEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(entry: MemoryEntryEntity): Long

  @Update
  suspend fun update(entry: MemoryEntryEntity)

  @Query("DELETE FROM memory_entries WHERE id = :id")
  suspend fun deleteById(id: Long)

  @Query("DELETE FROM memory_entries WHERE memoryType = 'SHORT_TERM'")
  suspend fun clearShortTerm()

  @Query("DELETE FROM memory_entries")
  suspend fun clearAll()
}

@Dao
interface OrchestratorTaskDao {
  @Query("SELECT * FROM orchestrator_tasks ORDER BY updatedAtMillis DESC LIMIT 60")
  fun observeTasks(): Flow<List<OrchestratorTaskEntity>>

  @Query("SELECT * FROM orchestrator_tasks WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): OrchestratorTaskEntity?

  @Query("SELECT * FROM orchestrator_tasks WHERE status IN ('RUNNING', 'PENDING') ORDER BY createdAtMillis ASC")
  suspend fun getActiveOnce(): List<OrchestratorTaskEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(task: OrchestratorTaskEntity): Long

  @Update
  suspend fun update(task: OrchestratorTaskEntity)

  @Query("UPDATE orchestrator_tasks SET status = :status, errorMessage = :errorMessage, updatedAtMillis = :updatedAt WHERE id = :id")
  suspend fun updateStatus(id: Long, status: String, errorMessage: String?, updatedAt: Long)

  @Query("DELETE FROM orchestrator_tasks WHERE id = :id")
  suspend fun deleteById(id: Long)

  @Query("DELETE FROM orchestrator_tasks")
  suspend fun clearAll()
}

@Dao
interface LearningRecordDao {
  @Query("SELECT * FROM learning_records ORDER BY createdAtMillis DESC LIMIT 100")
  fun observeRecords(): Flow<List<LearningRecordEntity>>

  @Query("SELECT * FROM learning_records ORDER BY createdAtMillis DESC LIMIT 120")
  suspend fun getRecentOnce(): List<LearningRecordEntity>

  @Query("SELECT * FROM learning_records WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): LearningRecordEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(record: LearningRecordEntity): Long

  @Query("UPDATE learning_records SET undone = 1 WHERE id = :id")
  suspend fun markUndone(id: Long)

  @Query("DELETE FROM learning_records")
  suspend fun clearAll()
}

@Dao
interface ToolUsageDao {
  @Query("SELECT * FROM tool_usage ORDER BY timestampMillis DESC LIMIT 100")
  fun observeUsage(): Flow<List<ToolUsageEntity>>

  @Query("SELECT * FROM tool_usage ORDER BY timestampMillis DESC LIMIT 150")
  suspend fun getRecentOnce(): List<ToolUsageEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(usage: ToolUsageEntity): Long

  @Query("DELETE FROM tool_usage")
  suspend fun clearAll()
}

@Dao
interface ReminderAlertDao {
  @Query("SELECT * FROM reminder_alerts ORDER BY createdAtMillis DESC LIMIT 100")
  fun observeAlerts(): Flow<List<ReminderAlertEntity>>

  @Query("SELECT * FROM reminder_alerts WHERE status = 'ACTIVE' ORDER BY createdAtMillis DESC")
  suspend fun getActiveOnce(): List<ReminderAlertEntity>

  @Query("SELECT * FROM reminder_alerts WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): ReminderAlertEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(alert: ReminderAlertEntity): Long

  @Update
  suspend fun update(alert: ReminderAlertEntity)

  @Query("UPDATE reminder_alerts SET status = :status WHERE id = :id")
  suspend fun updateStatus(id: Long, status: String)

  @Query("DELETE FROM reminder_alerts WHERE id = :id")
  suspend fun deleteById(id: Long)

  @Query("DELETE FROM reminder_alerts")
  suspend fun clearAll()
}

@Dao
interface LifeItemDao {
  @Query("SELECT * FROM life_items ORDER BY isCompleted ASC, updatedAtMillis DESC LIMIT 200")
  fun observeAll(): Flow<List<LifeItemEntity>>

  @Query("SELECT * FROM life_items ORDER BY isCompleted ASC, updatedAtMillis DESC")
  suspend fun getAllOnce(): List<LifeItemEntity>

  @Query("SELECT * FROM life_items WHERE isCompleted = 0 ORDER BY updatedAtMillis DESC")
  suspend fun getOpenOnce(): List<LifeItemEntity>

  @Query("SELECT * FROM life_items WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): LifeItemEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(item: LifeItemEntity): Long

  @Update
  suspend fun update(item: LifeItemEntity)

  @Query("UPDATE life_items SET isCompleted = :completed, progressPercent = :progress, updatedAtMillis = :updatedAt WHERE id = :id")
  suspend fun setCompleted(id: Long, completed: Boolean, progress: Int, updatedAt: Long)

  @Query("DELETE FROM life_items WHERE id = :id")
  suspend fun deleteById(id: Long)

  @Query("DELETE FROM life_items")
  suspend fun clearAll()
}

@Dao
interface ManagedAccountDao {
  @Query("SELECT * FROM managed_accounts ORDER BY serviceName ASC")
  fun observeAll(): Flow<List<ManagedAccountEntity>>

  @Query("SELECT * FROM managed_accounts ORDER BY serviceName ASC")
  suspend fun getAllOnce(): List<ManagedAccountEntity>

  @Query("SELECT * FROM managed_accounts WHERE id = :id LIMIT 1")
  suspend fun getById(id: Long): ManagedAccountEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(account: ManagedAccountEntity): Long

  @Update
  suspend fun update(account: ManagedAccountEntity)

  @Query("UPDATE managed_accounts SET lastReviewedAtMillis = :millis WHERE id = :id")
  suspend fun markReviewed(id: Long, millis: Long)

  @Query("UPDATE managed_accounts SET lastCheckedAtMillis = :checkedAt, lastConnectivityStatusHe = :statusHe WHERE id = :id")
  suspend fun updateConnectivityStatus(id: Long, checkedAt: Long, statusHe: String)

  @Query("DELETE FROM managed_accounts WHERE id = :id")
  suspend fun deleteById(id: Long)

  @Query("DELETE FROM managed_accounts")
  suspend fun clearAll()
}


