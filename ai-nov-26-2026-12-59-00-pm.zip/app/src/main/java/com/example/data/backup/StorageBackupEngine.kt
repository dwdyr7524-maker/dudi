package com.example.data.backup

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.example.data.local.BackupRecordEntity
import com.example.data.system.SmartStorageEngine
import com.example.data.system.formatBytes
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class BackedUpFileEntry(
  val fileName: String,
  val mimeType: String,
  val sourceDocUri: String,
  val sourceParentDocId: String,
  val sourceTreeUri: String,
  val backupDocUri: String,
  val sizeBytes: Long,
  val sha256: String
)

class StorageBackupEngine(
  private val context: Context,
  private val storageEngine: SmartStorageEngine
) {

  companion object {
    private const val MAX_BACKUP_FILES = 150
  }

  suspend fun createFolderBackup(
    sourceTreeUriString: String,
    destTreeUriString: String
  ): Result<BackupRecordEntity> =
    withContext(Dispatchers.IO) {
      runCatching {
        val sourceTree = Uri.parse(sourceTreeUriString)
        val destTree = Uri.parse(destTreeUriString)
        val sourceRootId = DocumentsContract.getTreeDocumentId(sourceTree)
        val destRootId = DocumentsContract.getTreeDocumentId(destTree)

        val sourceLabel = sourceRootId.substringAfterLast(':').ifBlank { "תיקייה נבחרת" }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val backupFolderName = "NEXUS_Backup_${sourceLabel.replace('/', '_')}_$stamp"

        val (backupDirDocId, _) =
          storageEngine.ensureSubfolder(destTree, destRootId, backupFolderName)
            ?: error("לא ניתן ליצור תיקיית גיבוי ביעד שנבחר.")

        val manifestArray = JSONArray()
        var copiedCount = 0
        var verifiedCount = 0
        var totalBytes = 0L

        val projection =
          arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
          )

        val queue = ArrayDeque<String>().apply { add(sourceRootId) }
        while (queue.isNotEmpty() && copiedCount < MAX_BACKUP_FILES) {
          val parentId = queue.removeFirst()
          val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(sourceTree, parentId)
          context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
            val sizeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)

            while (cursor.moveToNext() && copiedCount < MAX_BACKUP_FILES) {
              val docId = if (idIdx >= 0) cursor.getString(idIdx) else continue
              val name = if (nameIdx >= 0) cursor.getString(nameIdx) ?: "file" else "file"
              val mime = if (mimeIdx >= 0) cursor.getString(mimeIdx) ?: "application/octet-stream" else "application/octet-stream"
              if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                queue.add(docId)
              } else {
                val size = if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) cursor.getLong(sizeIdx) else 0L
                val srcDocUri = DocumentsContract.buildDocumentUriUsingTree(sourceTree, docId)
                val srcHash = storageEngine.computeUriSha256(srcDocUri) ?: continue
                val copiedUri =
                  storageEngine.copySafDocumentToFolder(
                    sourceDocUri = srcDocUri,
                    destTreeUri = destTree,
                    destParentDocId = backupDirDocId,
                    targetName = name,
                    mimeType = mime
                  ) ?: continue
                val dstHash = storageEngine.computeUriSha256(copiedUri)
                if (dstHash == srcHash) {
                  verifiedCount++
                }
                copiedCount++
                totalBytes += size
                manifestArray.put(
                  JSONObject().apply {
                    put("fileName", name)
                    put("mimeType", mime)
                    put("sourceDocUri", srcDocUri.toString())
                    put("sourceParentDocId", parentId)
                    put("sourceTreeUri", sourceTreeUriString)
                    put("backupDocUri", copiedUri.toString())
                    put("sizeBytes", size)
                    put("sha256", srcHash)
                  }
                )
              }
            }
          }
        }

        val allOk = copiedCount > 0 && verifiedCount == copiedCount
        val summary =
          if (copiedCount == 0) {
            "לא נמצאו קבצים להעתקה בתיקיית המקור."
          } else {
            "גובו $copiedCount קבצים (${formatBytes(totalBytes)}). אומתו SHA-256: $verifiedCount מתוך $copiedCount."
          }

        BackupRecordEntity(
          createdAtMillis = System.currentTimeMillis(),
          sourceLabel = sourceLabel,
          sourceTreeUri = sourceTreeUriString,
          destTreeUri = destTreeUriString,
          destFolderDocId = backupDirDocId,
          destFolderName = backupFolderName,
          fileCount = copiedCount,
          totalBytes = totalBytes,
          verifiedOk = allOk,
          integritySummaryHe = summary,
          manifestJson = manifestArray.toString()
        )
      }
    }

  fun parseManifest(record: BackupRecordEntity): List<BackedUpFileEntry> {
    val result = mutableListOf<BackedUpFileEntry>()
    val arr = runCatching { JSONArray(record.manifestJson) }.getOrNull() ?: return emptyList()
    for (i in 0 until arr.length()) {
      val o = arr.optJSONObject(i) ?: continue
      result +=
        BackedUpFileEntry(
          fileName = o.optString("fileName"),
          mimeType = o.optString("mimeType", "application/octet-stream"),
          sourceDocUri = o.optString("sourceDocUri"),
          sourceParentDocId = o.optString("sourceParentDocId"),
          sourceTreeUri = o.optString("sourceTreeUri"),
          backupDocUri = o.optString("backupDocUri"),
          sizeBytes = o.optLong("sizeBytes"),
          sha256 = o.optString("sha256")
        )
    }
    return result
  }

  suspend fun restoreBackupEntries(entries: List<BackedUpFileEntry>): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        var restored = 0
        var verified = 0
        for (entry in entries) {
          val srcBackupUri = Uri.parse(entry.backupDocUri)
          val targetTree = Uri.parse(entry.sourceTreeUri)
          val copied =
            storageEngine.copySafDocumentToFolder(
              sourceDocUri = srcBackupUri,
              destTreeUri = targetTree,
              destParentDocId = entry.sourceParentDocId,
              targetName = "restored_${entry.fileName}",
              mimeType = entry.mimeType
            ) ?: continue
          restored++
          val hash = storageEngine.computeUriSha256(copied)
          if (hash == entry.sha256) verified++
        }
        require(restored > 0) { "השחזור נכשל — בדוק שתיקיית המקור והגיבוי עדיין זמינות בהרשאות SAF." }
        "שוחזרו $restored קבצים בהצלחה (אימות תקינות SHA-256: $verified/$restored)."
      }
    }
}
