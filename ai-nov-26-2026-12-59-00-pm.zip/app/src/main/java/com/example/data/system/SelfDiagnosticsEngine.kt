package com.example.data.system

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.work.WorkManager
import com.example.BuildConfig
import com.example.data.local.NexusDatabase
import com.example.data.model.HealthSeverity
import com.example.data.model.SystemTelemetry
import com.example.ui.navigation.NexusDestination
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class SelfDiagnosticCheckItem(
  val id: String,
  val titleHe: String,
  val statusHe: String,
  val detailHe: String,
  val severity: HealthSeverity,
  val durationMs: Long,
  val fixRoute: String? = null
)

data class SelfDiagnosticsReport(
  val checkedAtMillis: Long,
  val totalChecks: Int,
  val passedCount: Int,
  val warningCount: Int,
  val errorCount: Int,
  val overallScore: Int,
  val benchmarkDurationMs: Long,
  val cpuOpsLabelHe: String,
  val checks: List<SelfDiagnosticCheckItem>
)

/**
 * Interactive Self-Diagnostics & SM-T545 Lightweight Benchmark Suite.
 * Performs real runtime integrity checks across Room DB, Routes, Permissions, AI, WorkManager, and Heap/CPU.
 */
class SelfDiagnosticsEngine(
  private val context: Context,
  private val database: NexusDatabase
) {

  suspend fun runSuite(
    telemetry: SystemTelemetry,
    safTreeCount: Int,
    cloudAiEnabled: Boolean,
    shareTelemetryWithAi: Boolean
  ): SelfDiagnosticsReport =
    withContext(Dispatchers.IO) {
      val checks = mutableListOf<SelfDiagnosticCheckItem>()

      // 1. Room Database Read/Write Integrity & Latency
      val dbT0 = System.currentTimeMillis()
      val dbCheck =
        runCatching {
          val memCount = database.memoryEntryDao().getAllOnce().size
          val lifeOpen = database.lifeItemDao().getOpenOnce().size
          val accCount = database.managedAccountDao().getAllOnce().size
          val lat = (System.currentTimeMillis() - dbT0).coerceAtLeast(1L)
          SelfDiagnosticCheckItem(
            id = "diag_room_db",
            titleHe = "בדיקת מסד נתונים Room (גרסה 5)",
            statusHe = "תקין (${lat} מ״ש)",
            detailHe = "קריאה תקינה: $memCount רשומות זיכרון, $lifeOpen משימות פתוחות, $accCount שירותים.",
            severity = HealthSeverity.OPTIMAL,
            durationMs = lat,
            fixRoute = NexusDestination.PERSONAL_LIFE.route
          )
        }.getOrElse { err ->
          SelfDiagnosticCheckItem(
            id = "diag_room_db",
            titleHe = "בדיקת מסד נתונים Room",
            statusHe = "שגיאת מסד נתונים",
            detailHe = err.localizedMessage ?: "כשל בקריאת Room DAO.",
            severity = HealthSeverity.CRITICAL,
            durationMs = (System.currentTimeMillis() - dbT0).coerceAtLeast(1L)
          )
        }
      checks += dbCheck

      // 2. Navigation Routes Integrity
      val navT0 = System.currentTimeMillis()
      val routes = NexusDestination.entries.map { it.route }
      val uniqueRoutes = routes.toSet()
      val allHaveLabels = NexusDestination.entries.all { it.labelHe.isNotBlank() && it.shortLabelHe.isNotBlank() }
      val navOk = routes.size == uniqueRoutes.size && allHaveLabels
      checks +=
        SelfDiagnosticCheckItem(
          id = "diag_routes",
          titleHe = "שלמות מסכי וניווט המערכת (${routes.size} מודולים)",
          statusHe = if (navOk) "תקין (${uniqueRoutes.size} מסכים ייחודיים)" else "נמצאה התנגשות מסלול",
          detailHe = "כל כתובות ה-NavHost ותוויות ה-RTL מאומתות ללא כפילויות.",
          severity = if (navOk) HealthSeverity.OPTIMAL else HealthSeverity.CRITICAL,
          durationMs = (System.currentTimeMillis() - navT0).coerceAtLeast(1L),
          fixRoute = NexusDestination.DASHBOARD.route
        )

      // 3. Android 10 Permissions & SAF Capabilities
      val permT0 = System.currentTimeMillis()
      val hasMic =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
          PackageManager.PERMISSION_GRANTED
      val hasNotif =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
          ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        } else true
      val permNotice = mutableListOf<String>()
      if (!telemetry.hasUsageAccessPermission) permNotice += "חסרה גישת Usage Stats"
      if (safTreeCount == 0) permNotice += "לא נבחרה תיקיית SAF"
      if (!hasMic) permNotice += "מיקרופון יתבקש בהפעלת שיחה"
      if (!hasNotif) permNotice += "התראות כבויות"
      checks +=
        SelfDiagnosticCheckItem(
          id = "diag_perms_saf",
          titleHe = "הרשאות Android 10 וגישת תיקיות (SAF)",
          statusHe =
            if (safTreeCount > 0 && telemetry.hasUsageAccessPermission) "מלא ומאושר"
            else "נדרשת השלמת גישה",
          detailHe =
            if (permNotice.isEmpty()) "$safTreeCount תיקיות מאושרות, Usage Stats פעיל."
            else permNotice.joinToString(" • "),
          severity =
            if (safTreeCount == 0 && !telemetry.hasUsageAccessPermission) HealthSeverity.WARNING
            else if (permNotice.isNotEmpty()) HealthSeverity.NOTICE
            else HealthSeverity.OPTIMAL,
          durationMs = (System.currentTimeMillis() - permT0).coerceAtLeast(1L),
          fixRoute = NexusDestination.SECURITY.route
        )

      // 4. Firebase AI Logic & App Check Readiness
      val aiT0 = System.currentTimeMillis()
      val aiStatus =
        when {
          !cloudAiEnabled -> "מצב מקומי בלבד (ענן כבוי)"
          !telemetry.network.isConnected -> "אין רשת כרגע — עבר למנוע אייקו המקומי"
          else -> "מוכן (Firebase AI Logic + App Check)"
        }
      checks +=
        SelfDiagnosticCheckItem(
          id = "diag_ai_config",
          titleHe = "מוכנות אייקו ענן ו-App Check",
          statusHe = aiStatus,
          detailHe =
            (if (BuildConfig.DEBUG) "Debug AppCheck מוגדר" else "Release AppCheck") +
              " • שיתוף מדדים: ${if (shareTelemetryWithAi) "מופעל" else "מוגבל לפרטיות"}.",
          severity =
            if (cloudAiEnabled && telemetry.network.isConnected) HealthSeverity.OPTIMAL
            else HealthSeverity.NOTICE,
          durationMs = (System.currentTimeMillis() - aiT0).coerceAtLeast(1L),
          fixRoute = NexusDestination.ASSISTANT.route
        )

      // 5. WorkManager Background Scheduling State
      val wmT0 = System.currentTimeMillis()
      val wmStatus =
        runCatching {
          val wm = WorkManager.getInstance(context)
          val count = wm.getWorkInfosByTag("nexus_thermal_monitor").get().size
          true to "פעיל ($count משימת ניטור רשומה)"
        }.getOrElse {
          false to "WorkManager לא מאותחל בסביבה זו"
        }
      checks +=
        SelfDiagnosticCheckItem(
          id = "diag_workmanager",
          titleHe = "מנוע רקע (WorkManager)",
          statusHe = wmStatus.second,
          detailHe = "ניטור חום, תזכורות ואוטומציות מתוזמנות מנוהלים דרך תור Android חסכוני בסוללה.",
          severity = if (wmStatus.first) HealthSeverity.OPTIMAL else HealthSeverity.NOTICE,
          durationMs = (System.currentTimeMillis() - wmT0).coerceAtLeast(1L),
          fixRoute = NexusDestination.AUTOMATION.route
        )

      // 6. SM-T545 Heap & Lightweight CPU Micro-Benchmark
      val benchT0 = System.currentTimeMillis()
      var checksum = 0L
      for (i in 1..250_000) {
        checksum = (checksum * 31L + i) xor (i.toLong() shl 3)
      }
      val benchMs = (System.currentTimeMillis() - benchT0).coerceAtLeast(1L)
      val rt = Runtime.getRuntime()
      val usedHeapMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
      val maxHeapMb = rt.maxMemory() / (1024 * 1024)
      val heapPct = if (maxHeapMb > 0) ((usedHeapMb * 100) / maxHeapMb).toInt() else 0
      val cpuLabel =
        when {
          benchMs <= 25L && checksum != 0L -> "מהיר מאוד (${benchMs} מ״ש / 250K פעולות)"
          benchMs <= 80L -> "תקין לטאבלט (${benchMs} מ״ש / 250K פעולות)"
          else -> "עומס קל (${benchMs} מ״ש) — מומלץ מצב ביצועים"
        }
      checks +=
        SelfDiagnosticCheckItem(
          id = "diag_benchmark",
          titleHe = "מבחן מהירות מעבד וזיכרון אפליקציה (Heap)",
          statusHe = cpuLabel,
          detailHe = "Heap בשימוש: ${usedHeapMb}MB מתוך ${maxHeapMb}MB ($heapPct%). סריקת אחסון כבדה מופעלת ידנית בלבד.",
          severity = if (heapPct > 82 || benchMs > 110L) HealthSeverity.WARNING else HealthSeverity.OPTIMAL,
          durationMs = benchMs,
          fixRoute = NexusDestination.SYSTEM_CONTROL.route
        )

      val passed = checks.count { it.severity == HealthSeverity.OPTIMAL }
      val warnings = checks.count { it.severity == HealthSeverity.NOTICE || it.severity == HealthSeverity.WARNING }
      val errors = checks.count { it.severity == HealthSeverity.CRITICAL }
      val score = ((passed * 100.0 + warnings * 65.0) / checks.size.coerceAtLeast(1)).toInt().coerceIn(0, 100)

      SelfDiagnosticsReport(
        checkedAtMillis = System.currentTimeMillis(),
        totalChecks = checks.size,
        passedCount = passed,
        warningCount = warnings,
        errorCount = errors,
        overallScore = score,
        benchmarkDurationMs = benchMs,
        cpuOpsLabelHe = cpuLabel,
        checks = checks
      )
    }
}
