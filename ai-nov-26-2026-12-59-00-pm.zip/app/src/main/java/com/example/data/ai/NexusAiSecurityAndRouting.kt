package com.example.data.ai

import com.example.data.model.AssistantActionType
import com.example.data.model.PendingAssistantAction
import java.util.ArrayDeque

/**
 * Pure Kotlin AI routing, security guardrails, history sanitization, and rate-limiting layer.
 * Zero Android dependencies so every rule is deterministically unit-testable on the JVM.
 */
object NexusModelCatalog {
  const val MODEL_REASONING_PRIMARY = "gemini-3.8-flash"
  const val MODEL_FAST_LITE = "gemini-3.5-flash-lite"
  const val MODEL_TRANSCRIBE = "gemini-3.5-transcribe"
  const val MODEL_LIVE_VOICE = "gemini-3.8-live"

  // Paid-tier / Blaze-only models that MUST NEVER be auto-selected as fallback without explicit user consent.
  val BLOCKED_PAID_MODELS = setOf("gemini-4-argon", "gemini-nano-banana-2.1", "gemini-3-pro-image")

  val FREE_TEXT_REASONING_CHAIN = listOf(MODEL_REASONING_PRIMARY, MODEL_FAST_LITE)
  val FREE_AUDIO_TRANSCRIBE_CHAIN = listOf(MODEL_TRANSCRIBE, MODEL_REASONING_PRIMARY, MODEL_FAST_LITE)
}

enum class AiCapabilityKind {
  TEXT_REASONING,
  MULTIMODAL_VISION,
  AUDIO_TRANSCRIPTION,
  LIVE_VOICE_AUDIO,
  FILE_INSIGHTS
}

object ModelRoutingPolicy {
  fun fallbackChainFor(
    capability: AiCapabilityKind,
    allowPaidAutoFallback: Boolean = false
  ): List<String> {
    val raw =
      when (capability) {
        AiCapabilityKind.TEXT_REASONING,
        AiCapabilityKind.MULTIMODAL_VISION -> NexusModelCatalog.FREE_TEXT_REASONING_CHAIN
        AiCapabilityKind.AUDIO_TRANSCRIPTION -> NexusModelCatalog.FREE_AUDIO_TRANSCRIBE_CHAIN
        AiCapabilityKind.LIVE_VOICE_AUDIO -> listOf(NexusModelCatalog.MODEL_LIVE_VOICE)
        AiCapabilityKind.FILE_INSIGHTS ->
          listOf(NexusModelCatalog.MODEL_FAST_LITE, NexusModelCatalog.MODEL_REASONING_PRIMARY)
      }
    return if (allowPaidAutoFallback) raw else raw.filterNot { it in NexusModelCatalog.BLOCKED_PAID_MODELS }
  }

  fun isPaidModelBlocked(modelName: String): Boolean =
    modelName.trim().lowercase() in NexusModelCatalog.BLOCKED_PAID_MODELS

  fun isRetryableFallbackError(throwable: Throwable): Boolean {
    val msg = throwable.localizedMessage?.lowercase().orEmpty()
    return msg.contains("429") ||
      msg.contains("quota") ||
      msg.contains("resource_exhausted") ||
      msg.contains("timeout") ||
      msg.contains("unavailable") ||
      msg.contains("503") ||
      msg.contains("500") ||
      msg.contains("not found") ||
      msg.contains("model") ||
      msg.contains("empty") ||
      msg.contains("json")
  }
}

data class SanitizedInputResult(
  val sanitizedText: String,
  val injectionSuspected: Boolean,
  val matchedPattern: String? = null
)

data class OutputValidationResult(
  val text: String,
  val isValid: Boolean,
  val hallucinatedExecutionFlagged: Boolean = false,
  val invalidReason: String? = null
)

object NexusAiSecurityGuard {
  private val controlCharsRegex = Regex("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F\\u007F]")
  private val whitespaceRunRegex = Regex("[ \\t]{3,}")
  private val apiKeyLikeRegex = Regex("(AIza[0-9A-Za-z\\-_]{20,}|sk-[A-Za-z0-9\\-_]{16,})")

  private val injectionPatterns =
    listOf(
      Regex("(?i)ignore\\s+(all\\s+)?(previous|prior|above)\\s+instructions"),
      Regex("(?i)disregard\\s+(all\\s+)?(system|safety|previous)\\s+(rules|instructions)"),
      Regex("(?i)(reveal|print|leak|show)\\s+(the\\s+)?(system\\s+prompt|api\\s*key|secret)"),
      Regex("(?i)\\b(jailbreak|dan\\s+mode|developer\\s+mode|bypass\\s+confirmation)\\b"),
      Regex("(?i)</?(system|untrusted_user_input|device_context|instruction)[^>]*>"),
      Regex("התעלם\\s+מ(כל\\s+)?(ההוראות|הכללים|ההנחיות)"),
      Regex("עקוף\\s+(את\\s+)?(האישור|האבטחה|המגבלות)"),
      Regex("מחק\\s+(הכל|את\\s+כל\\s+הקבצים)\\s+(בלי|ללא)\\s+אישור"),
      Regex("הצג\\s+(את\\s+)?(מפתח\\s+ה-?API|הנחיות\\s+המערכת)")
    )

  private val fabricatedExecutionPatterns =
    listOf(
      Regex("מחקתי\\s+(בפועל|כבר|עבורך|את\\s+הקבצים|את\\s+כל)"),
      Regex("ניקיתי\\s+(בפועל|כבר|בהצלחה\\s+את)"),
      Regex("שיניתי\\s+(בפועל|כבר)\\s+את\\s+(הגדרות|שם\\s+הקובץ)"),
      Regex("העברתי\\s+(בפועל|כבר)\\s+את\\s+הקבצים"),
      Regex("ביצעתי\\s+(כבר\\s+)?מחיקה\\s+במכשיר")
    )

  private val mutatingOrExternalActions =
    setOf(
      AssistantActionType.REQUEST_START_CLEAN,
      AssistantActionType.OPEN_BATTERY_SETTINGS,
      AssistantActionType.OPEN_INTERNET_SETTINGS,
      AssistantActionType.OPEN_STORAGE_SETTINGS,
      AssistantActionType.RUN_AUTOMATION,
      AssistantActionType.STAGE_DUPLICATE_VIDEOS_PROPOSALS,
      AssistantActionType.STAGE_DOWNLOADS_ORGANIZE_PROPOSALS,
      AssistantActionType.STAGE_CLEANUP_PLAN_PROPOSALS,
      AssistantActionType.STAGE_AIKO_FILE_PROPOSAL
    )

  fun sanitizeUserInput(raw: String, maxChars: Int = 2000): SanitizedInputResult {
    val noControl = raw.replace(controlCharsRegex, " ").trim()
    val collapsed = noControl.replace(whitespaceRunRegex, " ").take(maxChars)
    val matched = injectionPatterns.firstOrNull { it.containsMatchIn(collapsed) }?.pattern
    val safeDelimited =
      collapsed
        .replace("<", "‹")
        .replace(">", "›")
        .replace(apiKeyLikeRegex, "[מפתח-מוגן]")
    return SanitizedInputResult(
      sanitizedText = safeDelimited,
      injectionSuspected = matched != null,
      matchedPattern = matched
    )
  }

  fun sanitizeContextLabel(raw: String, maxChars: Int = 64): String {
    return raw
      .replace(controlCharsRegex, " ")
      .replace("<", "")
      .replace(">", "")
      .replace("\n", " ")
      .replace("\r", " ")
      .replace(apiKeyLikeRegex, "[REDACTED]")
      .trim()
      .take(maxChars)
  }

  fun wrapPromptWithContext(
    contextSummary: String,
    userMessage: String,
    extraInstruction: String? = null
  ): String {
    val sb = StringBuilder()
    sb.appendLine("<device_context>")
    sb.appendLine(contextSummary.trim())
    sb.appendLine("</device_context>")
    sb.appendLine()
    sb.appendLine("<untrusted_user_input>")
    sb.appendLine(userMessage.trim())
    sb.appendLine("</untrusted_user_input>")
    if (!extraInstruction.isNullOrBlank()) {
      sb.appendLine()
      sb.appendLine(extraInstruction.trim())
    }
    return sb.toString().trim()
  }

  fun extractJsonObject(rawText: String): String {
    var s = rawText.trim()
    if (s.startsWith("```")) {
      s = s.removePrefix("```json").removePrefix("```JSON").removePrefix("```").trim()
      if (s.endsWith("```")) {
        s = s.removeSuffix("```").trim()
      }
    }
    val start = s.indexOf('{')
    val end = s.lastIndexOf('}')
    return if (start >= 0 && end > start) s.substring(start, end + 1) else s
  }

  fun enforceActionSafety(action: PendingAssistantAction?): PendingAssistantAction? {
    if (action == null) return null
    val mustConfirm = action.actionType in mutatingOrExternalActions
    return action.copy(
      title = sanitizeContextLabel(action.title, maxChars = 90),
      description = sanitizeContextLabel(action.description, maxChars = 220),
      requiresConfirmation = if (mustConfirm) true else action.requiresConfirmation
    )
  }

  fun sanitizeAndValidateOutput(
    rawReply: String,
    pendingAction: PendingAssistantAction?,
    maxChars: Int = 3500
  ): OutputValidationResult {
    val cleaned =
      rawReply
        .replace(controlCharsRegex, " ")
        .replace(apiKeyLikeRegex, "[REDACTED]")
        .trim()
        .take(maxChars)

    if (cleaned.isBlank()) {
      return OutputValidationResult(
        text = "",
        isValid = false,
        invalidReason = "Model returned an empty response."
      )
    }

    val meaningfulChars = cleaned.count { it.isLetterOrDigit() }
    if (meaningfulChars < 2) {
      return OutputValidationResult(
        text = "",
        isValid = false,
        invalidReason = "Model returned malformed or punctuation-only output."
      )
    }

    val hallucinated = fabricatedExecutionPatterns.any { it.containsMatchIn(cleaned) }
    val finalText =
      if (hallucinated) {
        val actionHint =
          pendingAction?.title?.let { "ניתן לאשר כעת את הפעולה '$it' בכפתור למטה." }
            ?: "אף פעולת מחיקה או שינוי לא הופעלה עדיין ללא לחיצה על אישור מפורש."
        "$cleaned\n\n⚠️ הבהרת מערכת NEXUS: $actionHint"
      } else {
        cleaned
      }

    return OutputValidationResult(
      text = finalText,
      isValid = true,
      hallucinatedExecutionFlagged = hallucinated
    )
  }
}

data class NormalizedHistoryTurn(
  val isUser: Boolean,
  val text: String
)

/**
 * Normalizes chat history for Firebase AI Logic `startChat(history)`:
 * - Drops empty turns and leading model greetings
 * - Merges consecutive same-role messages
 * - Ensures strictly alternating user -> model turns ending on a model turn
 */
object NexusAiHistorySanitizer {
  fun normalizeForStartChat(
    rawHistory: List<Pair<Boolean, String>>,
    maxTurns: Int = 8,
    maxTurnChars: Int = 800
  ): List<NormalizedHistoryTurn> {
    val cleaned =
      rawHistory
        .mapNotNull { (isUser, text) ->
          val t = text.replace("\u0000", "").trim().take(maxTurnChars)
          if (t.isBlank()) null else NormalizedHistoryTurn(isUser, t)
        }
        .dropWhile { !it.isUser }

    if (cleaned.isEmpty()) return emptyList()

    val merged = mutableListOf<NormalizedHistoryTurn>()
    for (turn in cleaned) {
      val prev = merged.lastOrNull()
      if (prev != null && prev.isUser == turn.isUser) {
        merged[merged.lastIndex] = prev.copy(text = "${prev.text}\n${turn.text}".take(maxTurnChars))
      } else {
        merged += turn
      }
    }

    // `startChat` history should end on a model reply so the subsequent `sendMessage` is the new user turn.
    if (merged.lastOrNull()?.isUser == true) {
      merged.removeAt(merged.lastIndex)
    }
    if (merged.size <= maxTurns) return merged

    val sliced = merged.takeLast(maxTurns).toMutableList()
    while (sliced.isNotEmpty() && !sliced.first().isUser) {
      sliced.removeAt(0)
    }
    if (sliced.lastOrNull()?.isUser == true) {
      sliced.removeAt(sliced.lastIndex)
    }
    return sliced
  }
}

sealed interface RateLimitDecision {
  data object Allowed : RateLimitDecision
  data class Blocked(val waitSeconds: Int, val reasonHe: String) : RateLimitDecision
}

/**
 * Sliding-window client rate limiter + quota backoff guard to prevent infinite retry loops or 429 storms.
 */
class NexusAiRateLimiter(
  private val maxRequestsPerWindow: Int = 12,
  private val windowMs: Long = 60_000L,
  private val minIntervalMs: Long = 800L,
  private val quotaCooldownMs: Long = 12_000L,
  private val clock: () -> Long = { System.currentTimeMillis() }
) {
  private val timestamps = ArrayDeque<Long>()
  private var lastRequestAt = 0L
  private var quotaBlockedUntil = 0L

  @Synchronized
  fun tryAcquire(isHealthCheck: Boolean = false): RateLimitDecision {
    val now = clock()
    if (!isHealthCheck && now < quotaBlockedUntil) {
      val waitSec = (((quotaBlockedUntil - now) + 999L) / 1000L).toInt().coerceAtLeast(1)
      return RateLimitDecision.Blocked(
        waitSeconds = waitSec,
        reasonHe = "שירות הענן בתקופת צינון קצרה עקב עומס (429). המתן $waitSec שניות או השתמש במצב מקומי."
      )
    }
    if (!isHealthCheck && lastRequestAt > 0L && (now - lastRequestAt) < minIntervalMs) {
      return RateLimitDecision.Blocked(
        waitSeconds = 1,
        reasonHe = "בקשה נשלחה מהר מדי. המתן רגע קצר בין הודעה להודעה."
      )
    }
    while (timestamps.isNotEmpty() && (now - timestamps.first) > windowMs) {
      timestamps.removeFirst()
    }
    if (!isHealthCheck && timestamps.size >= maxRequestsPerWindow) {
      val oldest = timestamps.first
      val waitSec = (((oldest + windowMs - now) + 999L) / 1000L).toInt().coerceAtLeast(1)
      return RateLimitDecision.Blocked(
        waitSeconds = waitSec,
        reasonHe = "הגעת למגבלת הקצב ($maxRequestsPerWindow בקשות בדקה). המתן $waitSec שניות."
      )
    }
    if (!isHealthCheck) {
      lastRequestAt = now
      timestamps.addLast(now)
    }
    return RateLimitDecision.Allowed
  }

  @Synchronized
  fun noteQuotaExceeded() {
    quotaBlockedUntil = clock() + quotaCooldownMs
  }

  @Synchronized
  fun currentWindowCount(): Int {
    val now = clock()
    while (timestamps.isNotEmpty() && (now - timestamps.first) > windowMs) {
      timestamps.removeFirst()
    }
    return timestamps.size
  }

  @Synchronized
  fun resetForTesting() {
    timestamps.clear()
    lastRequestAt = 0L
    quotaBlockedUntil = 0L
  }
}
