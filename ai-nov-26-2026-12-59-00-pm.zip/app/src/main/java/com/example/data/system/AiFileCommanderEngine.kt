package com.example.data.system

import com.example.data.local.ApprovalProposalEntity
import com.example.data.model.AiOrganizationPlanReport
import com.example.data.model.AiOrganizationProposalDraft
import com.example.data.model.ApprovalOperationType
import com.example.data.model.ApprovalRiskLevel
import com.example.data.model.FileCategory
import com.example.data.model.ScannedFileEntry
import com.example.data.model.SmartStorageScanReport
import com.example.data.model.StorageVolumeKind

/**
 * Generates file organization proposals & Approval Center drafts without EVER mutating storage directly.
 * All returned proposals always enter Room with status = "PENDING".
 */
object AiFileCommanderEngine {

  fun buildOrganizationPlan(
    report: SmartStorageScanReport,
    providerLabel: String = "NEXUS Folder Intelligence"
  ): AiOrganizationPlanReport {
    val drafts = mutableListOf<AiOrganizationProposalDraft>()
    val suggestedFolders = linkedSetOf<String>()

    val sdVolume = report.volumes.firstOrNull { it.kind == StorageVolumeKind.SD_CARD && it.isMounted }
    val sdTargetTree = sdVolume?.authorizedTreeUris?.firstOrNull()

    // 1. Download Organizer: sort files inside Downloads by topic/category
    val downloadFiles =
      report.files.filter {
        it.relativePath.lowercase().contains("download") || it.relativePath.lowercase().contains("הורדות")
      }
    downloadFiles.take(15).forEach { file ->
      val folderName =
        when (file.category) {
          FileCategory.DOCUMENTS -> "מסמכים מאורגנים"
          FileCategory.IMAGES -> "תמונות מהורדות"
          FileCategory.VIDEOS -> "סרטונים מהורדות"
          FileCategory.AUDIO -> "מוזיקה ושמע"
          FileCategory.APK_INSTALLERS -> "קובצי התקנה APK"
          FileCategory.BACKUPS -> "גיבויים ישנים"
          else -> "קבצים כלליים"
        }
      suggestedFolders += folderName
      drafts +=
        AiOrganizationProposalDraft(
          title = "מיון מהורדות: ${file.name}",
          reasonHe = "נמצא בתיקיית ההורדות (${file.category.titleHe}) ומתאים לתיקיית $folderName",
          targetName = file.name,
          targetLocation = file.relativePath,
          operationType = ApprovalOperationType.ORGANIZE_DOWNLOAD_FILE,
          riskLevel = ApprovalRiskLevel.LOW,
          isReversible = true,
          expectedOutcomeHe = "יועבר לתת-תיקייה '$folderName' באותו שורש תיקייה.",
          sourceUriString = file.uriString,
          treeUriString = file.treeUriString,
          destTreeUriString = file.treeUriString,
          destFolderName = folderName,
          bytesAffected = file.sizeBytes
        )
    }

    // 2. Rename unclear files
    report.files
      .filter { it.isNameUnclear && !it.isTempResidual }
      .take(10)
      .forEach { file ->
        val ext = file.name.substringAfterLast('.', "").let { if (it.isNotEmpty()) ".$it" else "" }
        val topicPrefix =
          when (file.category) {
            FileCategory.DOCUMENTS -> "מסמך"
            FileCategory.IMAGES -> "תמונה"
            FileCategory.VIDEOS -> "סרטון"
            FileCategory.AUDIO -> "הקלטה"
            else -> "קובץ"
          }
        val cleanNewName = "${topicPrefix}_${file.lastModifiedMillis.takeIf { it > 0 }?.let { it / 1000L } ?: "נשמר"}$ext"
        drafts +=
          AiOrganizationProposalDraft(
            title = "שינוי שם ברור יותר: ${file.name}",
            reasonHe = "שם הקובץ גנרי או מספרי ואינו מתאר את תוכנו.",
            targetName = file.name,
            targetLocation = file.relativePath,
            operationType = ApprovalOperationType.RENAME_SAF_DOCUMENT,
            riskLevel = ApprovalRiskLevel.LOW,
            isReversible = true,
            expectedOutcomeHe = "שינוי השם ל-$cleanNewName (ניתן לשחזור ממרכז הביטול).",
            sourceUriString = file.uriString,
            treeUriString = file.treeUriString,
            proposedNewName = cleanNewName,
            bytesAffected = file.sizeBytes
          )
      }

    // 3. Duplicate cleanup proposals (non-recommended copies ONLY)
    report.duplicateGroups.take(12).forEach { group ->
      group.copies
        .filter { !it.recommendedKeep }
        .forEach { copy ->
          drafts +=
            AiOrganizationProposalDraft(
              title = "מחיקת עותק כפול: ${copy.name}",
              reasonHe = "עותק זהה ב-100% (SHA-256 ${group.sha256.take(10)}). עותק מקורי מומלץ יישאר שמור.",
              targetName = copy.name,
              targetLocation = copy.relativePath,
              operationType = ApprovalOperationType.DELETE_SAF_DOCUMENT,
              riskLevel = ApprovalRiskLevel.HIGH,
              isReversible = false,
              expectedOutcomeHe = "פינוי ${formatBytes(copy.sizeBytes)} מהאחסון.",
              sourceUriString = copy.uriString,
              treeUriString = copy.treeUriString,
              bytesAffected = copy.sizeBytes
            )
        }
    }

    // 4. Empty folders cleanup
    report.emptyFolders.take(8).forEach { folder ->
      drafts +=
        AiOrganizationProposalDraft(
          title = "מחיקת תיקייה ריקה: ${folder.folderName}",
          reasonHe = "התיקייה אינה מכילה קבצים או תיקיות משנה.",
          targetName = folder.folderName,
          targetLocation = folder.relativePath,
          operationType = ApprovalOperationType.DELETE_SAF_DOCUMENT,
          riskLevel = ApprovalRiskLevel.LOW,
          isReversible = false,
          expectedOutcomeHe = "סדר וניקיון בעץ התיקיות ללא פגיעה בקבצים.",
          sourceUriString =
            android.provider.DocumentsContract.buildDocumentUriUsingTree(
              android.net.Uri.parse(folder.treeUriString),
              folder.docId
            ).toString(),
          treeUriString = folder.treeUriString,
          bytesAffected = 0L
        )
    }

    // 5. Large media transfer suggestion to SD Card (when internal + SD SAF authorized)
    if (sdTargetTree != null) {
      report.files
        .filter {
          it.volumeKind == StorageVolumeKind.INTERNAL &&
            it.isLargeFile &&
            (it.category == FileCategory.VIDEOS || it.category == FileCategory.BACKUPS)
        }
        .take(5)
        .forEach { file ->
          val destFolder = "NEXUS_SD_Archive"
          suggestedFolders += destFolder
          drafts +=
            AiOrganizationProposalDraft(
              title = "העברה לכרטיס SD: ${file.name}",
              reasonHe = "קובץ גדול (${formatBytes(file.sizeBytes)}) תופס מקום באחסון הפנימי וניתן להעברה לכרטיס ה-SD.",
              targetName = file.name,
              targetLocation = "${file.relativePath} ← כרטיס SD/$destFolder",
              operationType = ApprovalOperationType.MOVE_SAF_DOCUMENT,
              riskLevel = ApprovalRiskLevel.MEDIUM,
              isReversible = true,
              expectedOutcomeHe = "העתקה מאומתת SHA-256 ל-SD ולאחר מכן פינוי ${formatBytes(file.sizeBytes)} מהאחסון הפנימי.",
              sourceUriString = file.uriString,
              treeUriString = file.treeUriString,
              destTreeUriString = sdTargetTree,
              destFolderName = destFolder,
              bytesAffected = file.sizeBytes
            )
        }
    }

    // 6. Old APK / Old backups review
    report.files
      .filter { it.isInstallerApk || (it.isBackupArchive && it.isOldUnused) }
      .take(8)
      .forEach { file ->
        drafts +=
          AiOrganizationProposalDraft(
            title = if (file.isInstallerApk) "סקירת קובץ APK: ${file.name}" else "סקירת גיבוי ישן: ${file.name}",
            reasonHe =
              if (file.isInstallerApk) "קובץ התקנה APK שנותר בתיקיות לאחר התקנה."
              else "ארכיון גיבוי ישן שלא שונה מעל 90 יום.",
            targetName = file.name,
            targetLocation = file.relativePath,
            operationType = ApprovalOperationType.DELETE_SAF_DOCUMENT,
            riskLevel = ApprovalRiskLevel.MEDIUM,
            isReversible = false,
            expectedOutcomeHe = "פינוי ${formatBytes(file.sizeBytes)} לאחר אישורך.",
            sourceUriString = file.uriString,
            treeUriString = file.treeUriString,
            bytesAffected = file.sizeBytes
          )
      }

    val summary =
      if (drafts.isEmpty()) {
        "לא נמצאו קבצים המצריכים שינוי במבנה התיקיות הנוכחי. בחר תיקיות נוספות (כולל הורדות ו-SD) לניתוח מעמיק."
      } else {
        "נותחו ${report.files.size} קבצים ב-${report.folders.size} תיקיות והופקו ${drafts.size} הצעות פעולה. כל שינוי ממתין לאישור מפורש שלך במרכז האישורים."
      }

    return AiOrganizationPlanReport(
      generatedAtMillis = System.currentTimeMillis(),
      summaryHe = summary,
      suggestedFolders = suggestedFolders.toList(),
      proposals = drafts,
      providerName = providerLabel
    )
  }

  fun toPendingEntity(draft: AiOrganizationProposalDraft, now: Long = System.currentTimeMillis()): ApprovalProposalEntity {
    return ApprovalProposalEntity(
      createdAtMillis = now,
      title = draft.title,
      reasonHe = draft.reasonHe,
      targetName = draft.targetName,
      targetLocation = draft.targetLocation,
      operationType = draft.operationType.name,
      riskLevel = draft.riskLevel.name,
      isReversible = draft.isReversible,
      expectedOutcomeHe = draft.expectedOutcomeHe,
      sourceUriString = draft.sourceUriString,
      treeUriString = draft.treeUriString,
      destTreeUriString = draft.destTreeUriString,
      destFolderName = draft.destFolderName,
      proposedNewName = draft.proposedNewName,
      packageName = draft.packageName,
      bytesAffected = draft.bytesAffected,
      status = "PENDING",
      resultMessageHe = null
    )
  }

  fun draftsForDuplicateVideos(report: SmartStorageScanReport): List<AiOrganizationProposalDraft> {
    return report.duplicateGroups
      .filter { it.category == FileCategory.VIDEOS }
      .flatMap { group ->
        group.copies
          .filter { !it.recommendedKeep }
          .map { copy ->
            AiOrganizationProposalDraft(
              title = "מחיקת סרטון כפול: ${copy.name}",
              reasonHe = "זוהה סרטון זהה לחלוטין ב-SHA-256 (${group.sha256.take(10)}). עותק המקור נשמר.",
              targetName = copy.name,
              targetLocation = copy.relativePath,
              operationType = ApprovalOperationType.DELETE_SAF_DOCUMENT,
              riskLevel = ApprovalRiskLevel.HIGH,
              isReversible = false,
              expectedOutcomeHe = "פינוי ${formatBytes(copy.sizeBytes)} ממחיקת סרטון כפול.",
              sourceUriString = copy.uriString,
              treeUriString = copy.treeUriString,
              bytesAffected = copy.sizeBytes
            )
          }
      }
  }

  fun filterFiles(
    files: List<ScannedFileEntry>,
    query: String,
    category: FileCategory?
  ): List<ScannedFileEntry> {
    val q = query.trim().lowercase()
    return files.filter { file ->
      (category == null || file.category == category) &&
        (q.isEmpty() ||
          file.name.lowercase().contains(q) ||
          file.relativePath.lowercase().contains(q) ||
          file.category.titleHe.contains(q))
    }
  }
}
