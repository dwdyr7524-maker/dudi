package com.example.data.model

import android.graphics.drawable.Drawable

enum class HealthSeverity {
  OPTIMAL,
  NOTICE,
  WARNING,
  CRITICAL
}

data class HealthIssue(
  val id: String,
  val title: String,
  val detail: String,
  val severity: HealthSeverity,
  val actionLabel: String,
  val targetRoute: String
)

data class BatteryTelemetry(
  val levelPercent: Int,
  val isCharging: Boolean,
  val chargeSource: String,
  val temperatureC: Float,
  val voltageMv: Int,
  val healthLabel: String,
  val technology: String,
  val isPowerSaveMode: Boolean,
  val isAbnormal: Boolean,
  val alertMessage: String?
)

data class RamTelemetry(
  val totalBytes: Long,
  val availableBytes: Long,
  val usedBytes: Long,
  val usedPercent: Int,
  val isLowMemory: Boolean
)

data class StorageTelemetry(
  val totalBytes: Long,
  val freeBytes: Long,
  val usedBytes: Long,
  val usedPercent: Int,
  val allocatableBytes: Long
)

data class NetworkTelemetry(
  val isConnected: Boolean,
  val transportLabel: String,
  val isMetered: Boolean,
  val downstreamKbps: Int,
  val upstreamKbps: Int,
  val wifiRssiDbm: Int?,
  val wifiLinkSpeedMbps: Int?
)

data class DeviceIdentity(
  val manufacturer: String,
  val model: String,
  val androidRelease: String,
  val sdkInt: Int,
  val securityPatch: String,
  val uptimeMillis: Long,
  val isSamsungDevice: Boolean,
  val hasSamsungDeviceCare: Boolean,
  val isDeviceSecureLock: Boolean
)

data class SystemTelemetry(
  val battery: BatteryTelemetry,
  val ram: RamTelemetry,
  val storage: StorageTelemetry,
  val network: NetworkTelemetry,
  val device: DeviceIdentity,
  val healthScore: Int,
  val healthStatusLabel: String,
  val issues: List<HealthIssue>,
  val hasUsageAccessPermission: Boolean,
  val authorizedFolderCount: Int,
  val capturedAtMillis: Long
)

enum class CleanItemType {
  NEXUS_CACHE,
  TEMP_RESIDUAL,
  SAFE_DUPLICATE,
  LARGE_FILE,
  APP_CACHE_EXTERNAL,
  EMPTY_FOLDER,
  OLD_APK,
  OLD_BACKUP,
  OLD_UNUSED_FILE
}

data class CleanCandidateItem(
  val id: String,
  val name: String,
  val subtitle: String,
  val sizeBytes: Long,
  val type: CleanItemType,
  val uriString: String? = null,
  val filePath: String? = null,
  val packageName: String? = null,
  val isDirectDeletable: Boolean,
  val selectedByDefault: Boolean,
  val sha256Prefix: String? = null,
  val safetyTier: CleanerSafetyTier = CleanerSafetyTier.REVIEW_NEEDED,
  val treeUriString: String? = null
)

data class DeepCleanScanResult(
  val scannedAtMillis: Long,
  val nexusCacheBytes: Long,
  val tempFilesBytes: Long,
  val safeDuplicateBytes: Long,
  val largeFilesBytes: Long,
  val externalAppCacheBytes: Long?,
  val directReclaimableBytes: Long,
  val totalDetectedBytes: Long,
  val freeBeforeBytes: Long,
  val totalStorageBytes: Long,
  val candidates: List<CleanCandidateItem>,
  val folderSummaries: List<FolderScanSummary>,
  val hasUsageAccess: Boolean,
  val hasSafFolders: Boolean
)

data class FolderScanSummary(
  val treeUri: String,
  val displayName: String,
  val fileCount: Int,
  val totalBytes: Long
)

data class DeepCleanExecutionResult(
  val executedAtMillis: Long,
  val requestedItemsCount: Int,
  val deletedCount: Int,
  val failedCount: Int,
  val verifiedBytesFreed: Long,
  val freeBeforeBytes: Long,
  val freeAfterBytes: Long,
  val storageDeltaBytes: Long,
  val actionLogs: List<String>,
  val failureReasons: List<String>
)

enum class AppSortMode {
  SIZE_DESC,
  NAME_ASC,
  RECENT_UPDATED,
  LEAST_USED
}

enum class AppFilterMode {
  ALL,
  USER_APPS,
  SYSTEM_APPS,
  DORMANT
}

data class AppDiagnosticInfo(
  val packageName: String,
  val appName: String,
  val versionName: String,
  val isSystemApp: Boolean,
  val apkSizeBytes: Long,
  val appDataBytes: Long?,
  val cacheBytes: Long?,
  val totalSizeBytes: Long,
  val firstInstallTime: Long,
  val lastUpdateTime: Long,
  val requestedPermissions: List<String>,
  val grantedSensitivePermissions: List<String>,
  val hasCameraPermission: Boolean,
  val hasMicPermission: Boolean,
  val hasLocationPermission: Boolean,
  val hasBackgroundLocation: Boolean,
  val canDrawOverlays: Boolean,
  val canRequestInstalls: Boolean,
  val iconDrawable: Drawable? = null,
  val lastTimeUsedMillis: Long? = null,
  val totalTimeInForegroundMillis: Long? = null,
  val isDormant: Boolean = false,
  val isLaunchable: Boolean = true,
  val isEnabled: Boolean = true
)

data class SecurityFinding(
  val id: String,
  val title: String,
  val description: String,
  val severity: HealthSeverity,
  val packageName: String? = null,
  val appName: String? = null
)

data class SecurityAuditReport(
  val auditedAtMillis: Long,
  val totalAppsAudited: Int,
  val cameraAppsCount: Int,
  val micAppsCount: Int,
  val locationAppsCount: Int,
  val specialPermissionAppsCount: Int,
  val isDeviceSecureLock: Boolean,
  val securityPatch: String,
  val findings: List<SecurityFinding>,
  val sensitiveApps: List<AppDiagnosticInfo>
)

enum class AssistantActionType {
  NONE,
  RUN_SYSTEM_CHECK,
  NAVIGATE_DEEP_CLEAN,
  REQUEST_START_CLEAN,
  NAVIGATE_APPS_BY_SIZE,
  NAVIGATE_SECURITY,
  NAVIGATE_BATTERY,
  OPEN_BATTERY_SETTINGS,
  OPEN_INTERNET_SETTINGS,
  OPEN_STORAGE_SETTINGS,
  RUN_AUTOMATION,
  NAVIGATE_SMART_STORAGE,
  NAVIGATE_AI_FILE_MANAGER,
  NAVIGATE_DEVICE_DOCTOR,
  NAVIGATE_APPROVAL_CENTER,
  STAGE_DUPLICATE_VIDEOS_PROPOSALS,
  STAGE_DOWNLOADS_ORGANIZE_PROPOSALS,
  STAGE_CLEANUP_PLAN_PROPOSALS,
  CHECK_SD_CARD,
  OPEN_DOWNLOADS_MANAGER,
  OPEN_PERSONAL_LIFE,
  OPEN_ACCOUNTS_HUB,
  OPEN_SELF_DIAGNOSTICS,
  STAGE_AIKO_FILE_PROPOSAL
}

data class PendingAssistantAction(
  val actionType: AssistantActionType,
  val title: String,
  val description: String,
  val requiresConfirmation: Boolean,
  val automationId: Long? = null,
  val stagedProposalDraft: AiOrganizationProposalDraft? = null
)

enum class RobotMood {
  IDLE,
  LISTENING,
  THINKING,
  SPEAKING,
  ALERT,
  SUCCESS
}

enum class AutomationStepType(val titleHe: String, val requiresConfirm: Boolean) {
  SYSTEM_SCAN("סריקת מערכת ואחסון", false),
  MAINTENANCE_REPORT("הפקת דוח תחזוקה וציון בריאות", false),
  BATTERY_CHECK("בדיקת מצב סוללה וטמפרטורה", false),
  SECURITY_AUDIT("ביקורת הרשאות רגישות", false),
  OPEN_STORAGE_SETTINGS("פתיחת הגדרות אחסון מערכת", true),
  OPEN_BATTERY_SETTINGS("פתיחת הגדרות סוללה", true),
  OPEN_NETWORK_SETTINGS("פתיחת הגדרות רשת ואינטרנט", true),
  CLEAR_NEXUS_CACHE("ניקוי מטמון פנימי של NEXUS", true)
}

enum class SystemShortcutId {
  WIFI,
  BLUETOOTH,
  DISPLAY,
  BRIGHTNESS,
  SOUND,
  BATTERY,
  STORAGE,
  APPS,
  PERMISSIONS,
  NOTIFICATIONS,
  ACCESSIBILITY,
  SYSTEM_SETTINGS,
  SAMSUNG_DEVICE_CARE,
  USAGE_ACCESS
}

data class SystemShortcutItem(
  val id: SystemShortcutId,
  val title: String,
  val subtitle: String,
  val isSupported: Boolean = true
)
