package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.NavigateBefore
import androidx.compose.material.icons.automirrored.rounded.NavigateNext
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.documents.OpenedDocumentState
import com.example.data.local.LearningRecordEntity
import com.example.data.local.MemoryEntryEntity
import com.example.data.local.OrchestratorTaskEntity
import com.example.data.memory.LearningInsightsSnapshot
import com.example.data.memory.NexusMemorySecretFilter
import com.example.data.memory.NexusMemoryType
import com.example.data.orchestrator.NexusAgentRole
import com.example.data.orchestrator.NexusToolHealthState
import com.example.data.orchestrator.NexusToolStatus
import com.example.data.orchestrator.OrchestratorSerialization
import com.example.data.orchestrator.OrchestratorStepStatus
import com.example.data.orchestrator.OrchestratorTaskStatus
import com.example.data.system.NetworkStatusSnapshot
import com.example.data.system.OfflineCapabilityMatrix
import com.example.data.system.PendingSyncTask
import com.example.data.system.formatBytes
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusBorderSubtle
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian

@Composable
fun OrchestratorAgentsPanel(
  tasks: List<OrchestratorTaskEntity>,
  currentlyDoingHe: String?,
  onStartTask: (String) -> Unit,
  onPauseTask: (Long) -> Unit,
  onResumeTask: (Long) -> Unit,
  onCancelTask: (Long) -> Unit,
  modifier: Modifier = Modifier
) {
  var goalInput by rememberSaveable { mutableStateOf("") }
  val presets =
    listOf(
      "אבחון טאבלט מלא, הרשאות אבטחה והמלצת אחסון",
      "בדוק סוללה, SD וכפילויות ותכנן ניקוי",
      "תכנן קוד JSON לאוטומציית בוקר",
      "הפק דוח בריאות ומסמך סיכום מערכת"
    )

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    contentPadding = PaddingValues(bottom = 16.dp)
  ) {
    if (!currentlyDoingHe.isNullOrBlank()) {
      item {
        Surface(
          color = NexusNeonCyan.copy(alpha = 0.14f),
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.dp, NexusNeonCyan.copy(alpha = 0.7f)),
          modifier = Modifier.fillMaxWidth().testTag("orchestrator_live_banner")
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("מה העוזר עושה עכשיו:", style = MaterialTheme.typography.labelMedium, color = NexusNeonCyan)
            Text(currentlyDoingHe, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
            LinearProgressIndicator(
              modifier = Modifier.fillMaxWidth(),
              color = NexusNeonCyan
            )
          }
        }
      }
    }

    item {
      NexusHudCard(contentPadding = 12.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("מוח מרכזי ומערך 5 סוכנים מתמחים", style = MaterialTheme.typography.titleMedium, color = NexusNeonCyan)
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            NexusAgentRole.entries.forEach { role ->
              Surface(
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, NexusBorderSubtle),
                modifier = Modifier.width(168.dp)
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Text(role.titleHe, style = MaterialTheme.typography.labelLarge, color = NexusNeonCyan)
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(role.roleDescHe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }

          OutlinedTextField(
            value = goalInput,
            onValueChange = { goalInput = it },
            label = { Text("הזן משימה מורכבת לפירוק וביצוע...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("orchestrator_goal_input")
          )

          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            presets.forEach { preset ->
              FilterChip(
                selected = false,
                onClick = { goalInput = preset },
                label = { Text(preset, maxLines = 1) }
              )
            }
          }

          Button(
            onClick = {
              if (goalInput.isNotBlank()) {
                onStartTask(goalInput)
                goalInput = ""
              }
            },
            enabled = goalInput.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
            modifier = Modifier.fillMaxWidth().testTag("orchestrator_launch_btn")
          ) {
            Icon(Icons.Rounded.Psychology, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("פרק והפעל משימה במוח המרכזי")
          }
        }
      }
    }

    if (tasks.isEmpty()) {
      item {
        NexusHudCard(contentPadding = 14.dp) {
          Text(
            "תור המשימות ריק כרגע. בחר תבנית למעלה או הזן משימה מורכבת כדי לצפות בעבודת 5 הסוכנים בזמן אמת.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    } else {
      items(tasks, key = { it.id }) { task ->
        OrchestratorTaskCard(
          task = task,
          onPause = { onPauseTask(task.id) },
          onResume = { onResumeTask(task.id) },
          onCancel = { onCancelTask(task.id) }
        )
      }
    }
  }
}

@Composable
private fun OrchestratorTaskCard(
  task: OrchestratorTaskEntity,
  onPause: () -> Unit,
  onResume: () -> Unit,
  onCancel: () -> Unit
) {
  var expanded by rememberSaveable(task.id) { mutableStateOf(task.status == OrchestratorTaskStatus.RUNNING.name) }
  val statusEnum =
    OrchestratorTaskStatus.entries.firstOrNull { it.name == task.status } ?: OrchestratorTaskStatus.PENDING
  val accentColor =
    when (statusEnum) {
      OrchestratorTaskStatus.RUNNING -> NexusNeonCyan
      OrchestratorTaskStatus.COMPLETED -> NexusEmerald
      OrchestratorTaskStatus.PAUSED -> NexusAmber
      OrchestratorTaskStatus.FAILED -> NexusCrimson
      OrchestratorTaskStatus.CANCELLED,
      OrchestratorTaskStatus.PENDING -> MaterialTheme.colorScheme.onSurfaceVariant
    }
  val steps = remember(task.stepsJson) { OrchestratorSerialization.decodeSteps(task.stepsJson) }

  NexusHudCard(contentPadding = 12.dp, accentColor = accentColor) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(task.goal, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
          Text(
            text = "${statusEnum.titleHe} • ${task.progressPercent}% • ${task.currentStepLabel}",
            style = MaterialTheme.typography.bodySmall,
            color = accentColor
          )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          if (statusEnum == OrchestratorTaskStatus.RUNNING) {
            IconButton(onClick = onPause, modifier = Modifier.size(40.dp)) {
              Icon(Icons.Rounded.Pause, contentDescription = "השהה משימה", tint = NexusAmber)
            }
          } else if (statusEnum == OrchestratorTaskStatus.PAUSED || statusEnum == OrchestratorTaskStatus.FAILED) {
            IconButton(onClick = onResume, modifier = Modifier.size(40.dp)) {
              Icon(Icons.Rounded.PlayArrow, contentDescription = "המשך משימה", tint = NexusEmerald)
            }
          }
          if (statusEnum == OrchestratorTaskStatus.RUNNING ||
            statusEnum == OrchestratorTaskStatus.PAUSED ||
            statusEnum == OrchestratorTaskStatus.PENDING
          ) {
            IconButton(onClick = onCancel, modifier = Modifier.size(40.dp)) {
              Icon(Icons.Rounded.Cancel, contentDescription = "בטל משימה", tint = NexusCrimson)
            }
          }
        }
      }

      LinearProgressIndicator(
        progress = { (task.progressPercent / 100f).coerceIn(0f, 1f) },
        modifier = Modifier.fillMaxWidth(),
        color = accentColor
      )

      if (expanded) {
        steps.forEach { step ->
          val stLabel = step.status.titleHe
          val stepColor =
            when (step.status) {
              OrchestratorStepStatus.SUCCEEDED -> NexusEmerald
              OrchestratorStepStatus.RETRIED_LOCAL -> NexusAmber
              OrchestratorStepStatus.RUNNING -> NexusNeonCyan
              OrchestratorStepStatus.FAILED -> NexusCrimson
              else -> MaterialTheme.colorScheme.onSurfaceVariant
            }
          Surface(
            color = MaterialTheme.colorScheme.surfaceContainerLow,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, NexusBorderSubtle),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(8.dp)) {
              Text(
                text = "${step.index + 1}. [${step.agent.titleHe}] ${step.titleHe} — $stLabel",
                style = MaterialTheme.typography.labelMedium,
                color = stepColor
              )
              if (step.outputHe.isNotBlank()) {
                Text(
                  text = step.outputHe,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun MemoryAndLearningPanel(
  memories: List<MemoryEntryEntity>,
  memoryAutoSaveEnabled: Boolean,
  learningRecords: List<LearningRecordEntity>,
  learningInsights: LearningInsightsSnapshot,
  onToggleAutoSave: (Boolean) -> Unit,
  onSaveMemory: (NexusMemoryType, String, String, String, Boolean) -> Unit,
  onUpdateMemory: (MemoryEntryEntity, String, String, NexusMemoryType, Boolean) -> Unit,
  onTogglePersist: (MemoryEntryEntity) -> Unit,
  onDeleteMemory: (Long) -> Unit,
  onClearShortTerm: () -> Unit,
  onUndoLearning: (Long) -> Unit,
  modifier: Modifier = Modifier
) {
  var showAddDialog by remember { mutableStateOf(false) }
  var editingMemory by remember { mutableStateOf<MemoryEntryEntity?>(null) }
  var selectedTypeFilter by rememberSaveable { mutableStateOf<String>("ALL") }

  val filteredMemories =
    remember(memories, selectedTypeFilter) {
      if (selectedTypeFilter == "ALL") memories
      else memories.filter { it.memoryType == selectedTypeFilter }
    }

  if (showAddDialog || editingMemory != null) {
    val existing = editingMemory
    var title by remember(existing) { mutableStateOf(existing?.title ?: "") }
    var content by remember(existing) { mutableStateOf(existing?.content ?: "") }
    var selectedType by remember(existing) {
      mutableStateOf(
        NexusMemoryType.entries.firstOrNull { it.name == existing?.memoryType }
          ?: NexusMemoryType.PREFERENCE
      )
    }
    var canPersist by remember(existing) { mutableStateOf(existing?.canPersist ?: true) }
    val secretWarning = remember(title, content) { NexusMemorySecretFilter.inspect(title, content) }

    AlertDialog(
      onDismissRequest = { showAddDialog = false; editingMemory = null },
      title = { Text(if (existing == null) "הוספת זיכרון חכם" else "עריכת זיכרון") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            NexusMemoryType.entries.forEach { type ->
              FilterChip(
                selected = selectedType == type,
                onClick = { selectedType = type },
                label = { Text(type.titleHe) }
              )
            }
          }
          OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("כותרת") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = content,
            onValueChange = { content = it },
            label = { Text("תוכן (סיסמאות ומפתחות API נחסמים אוטומטית)") },
            minLines = 2,
            maxLines = 4,
            modifier = Modifier.fillMaxWidth()
          )
          if (secretWarning.containsSensitiveData) {
            Text(
              text = secretWarning.reasonHe ?: "תוכן רגיש חסום לשמירה.",
              style = MaterialTheme.typography.bodySmall,
              color = NexusCrimson
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("מותר לשמור ולהשתמש בהקשר AI", style = MaterialTheme.typography.bodySmall)
            Switch(checked = canPersist, onCheckedChange = { canPersist = it })
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (existing == null) {
              onSaveMemory(selectedType, title, content, selectedType.titleHe, canPersist)
            } else {
              onUpdateMemory(existing, title, content, selectedType, canPersist)
            }
            showAddDialog = false
            editingMemory = null
          },
          enabled = title.isNotBlank() && content.isNotBlank() && !secretWarning.containsSensitiveData
        ) {
          Text("שמור")
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddDialog = false; editingMemory = null }) {
          Text("ביטול")
        }
      }
    )
  }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    contentPadding = PaddingValues(bottom = 16.dp)
  ) {
    item {
      NexusHudCard(contentPadding = 12.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("זיכרון חכם לטווח ארוך וקצר", style = MaterialTheme.typography.titleMedium, color = NexusNeonCyan)
              Text(
                "שורד סגירה והפעלה מחדש • חוסם סיסמאות ומפתחות API",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Button(onClick = { showAddDialog = true }, modifier = Modifier.testTag("add_memory_btn")) {
              Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("הוסף")
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("שמירה אוטומטית של העדפות/פרויקטים מהצ'אט", style = MaterialTheme.typography.bodySmall)
            Switch(checked = memoryAutoSaveEnabled, onCheckedChange = onToggleAutoSave)
          }

          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            FilterChip(
              selected = selectedTypeFilter == "ALL",
              onClick = { selectedTypeFilter = "ALL" },
              label = { Text("הכול (${memories.size})") }
            )
            NexusMemoryType.entries.forEach { t ->
              FilterChip(
                selected = selectedTypeFilter == t.name,
                onClick = { selectedTypeFilter = t.name },
                label = { Text(t.titleHe) }
              )
            }
            OutlinedButton(onClick = onClearShortTerm) {
              Text("נקה זיכרון זמני")
            }
          }
        }
      }
    }

    items(filteredMemories, key = { it.id }) { mem ->
      val typeLabel = NexusMemoryType.entries.firstOrNull { it.name == mem.memoryType }?.titleHe ?: mem.memoryType
      NexusHudCard(contentPadding = 10.dp) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("[$typeLabel] ${mem.title}", style = MaterialTheme.typography.titleSmall, color = NexusNeonCyan)
              Text(mem.content, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
            }
            Row {
              IconButton(onClick = { editingMemory = mem }, modifier = Modifier.size(38.dp)) {
                Icon(Icons.Rounded.Edit, contentDescription = "ערוך זיכרון", tint = MaterialTheme.colorScheme.primary)
              }
              IconButton(onClick = { onDeleteMemory(mem.id) }, modifier = Modifier.size(38.dp)) {
                Icon(Icons.Rounded.Delete, contentDescription = "מחק זיכרון", tint = NexusCrimson)
              }
            }
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (mem.canPersist) "מוזרק להקשר ה-AI" else "שמור לעיון בלבד (מושהה מהקשר)",
              style = MaterialTheme.typography.labelSmall,
              color = if (mem.canPersist) NexusEmerald else NexusAmber
            )
            Switch(checked = mem.canPersist, onCheckedChange = { onTogglePersist(mem) })
          }
        }
      }
    }

    item {
      NexusHudCard(contentPadding = 12.dp, accentColor = NexusEmerald) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text("מנוע למידה ושיפור מתמיד (הפיך)", style = MaterialTheme.typography.titleMedium, color = NexusEmerald)
          Text(
            learningInsights.safetyBoundaryNoteHe,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = "משוב משתמש: ${learningInsights.positiveFeedbackCount} חיובי • ${learningInsights.negativeFeedbackCount} לשיפור",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface
          )
          learningInsights.degradedTools.forEach { badTool ->
            Text(
              text = "⚠️ כלי עם ירידה בדיוק: ${badTool.toolNameHe} (${badTool.successRatePercent}% הצלחה מתוך ${badTool.totalRuns} הרצות)",
              style = MaterialTheme.typography.bodySmall,
              color = NexusAmber
            )
          }
          learningInsights.recurringSuggestions.forEach { sug ->
            Text(
              text = "💡 ${sug.recommendationHe}",
              style = MaterialTheme.typography.bodySmall,
              color = NexusNeonCyan
            )
          }
          if (learningRecords.isNotEmpty()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text("שינויים ורשומות למידה אחרונות (ניתנות לביטול):", style = MaterialTheme.typography.labelMedium)
            learningRecords.take(8).forEach { rec ->
              Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = (if (rec.undone) "[בוטל] " else "") + rec.summaryHe,
                  style = MaterialTheme.typography.bodySmall,
                  color =
                    if (rec.undone) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.weight(1f)
                )
                if (!rec.undone) {
                  TextButton(onClick = { onUndoLearning(rec.id) }) {
                    Icon(Icons.AutoMirrored.Rounded.Undo, contentDescription = "בטל", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("בטל")
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun ToolsAndDocumentsPanel(
  networkStatus: NetworkStatusSnapshot,
  pendingSyncQueue: List<PendingSyncTask>,
  toolStatuses: List<NexusToolStatus>,
  openedDocument: OpenedDocumentState?,
  isOpeningDocument: Boolean,
  isSummarizingDocument: Boolean,
  onRefreshToolHealth: () -> Unit,
  onOpenDocumentUri: (Uri) -> Unit,
  onPrevPdfPage: () -> Unit,
  onNextPdfPage: () -> Unit,
  onSearchDocument: (String) -> Unit,
  onSummarizeDocWithAi: () -> Unit,
  onSaveDocumentUri: (Uri, String) -> Unit,
  onCloseDocument: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var docSearchQuery by remember(openedDocument?.uriString) {
    mutableStateOf(openedDocument?.searchQuery ?: "")
  }

  val openDocLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) {
        runCatching {
          context.contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION
          )
        }
        onOpenDocumentUri(uri)
      }
    }

  val createDocLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
      val doc = openedDocument
      if (uri != null && doc != null) {
        val textToSave =
          buildString {
            appendLine("=== ${doc.fileName} (${doc.kind.titleHe}) ===")
            appendLine(doc.aiSummaryHe ?: doc.localSummaryHe)
            if (doc.textContent.isNotBlank()) {
              appendLine()
              appendLine("--- תוכן ---")
              appendLine(doc.textContent.take(15_000))
            }
          }
        onSaveDocumentUri(uri, textToSave)
      }
    }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    contentPadding = PaddingValues(bottom = 16.dp)
  ) {
    // 1. Offline Mode & Controlled Sync Card
    item {
      val onlineColor = if (networkStatus.isOnline) NexusEmerald else NexusAmber
      NexusHudCard(contentPadding = 12.dp, accentColor = onlineColor) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(
              imageVector = if (networkStatus.isOnline) Icons.Rounded.Wifi else Icons.Rounded.CloudOff,
              contentDescription = null,
              tint = onlineColor
            )
            Text(
              text =
                if (networkStatus.isOnline) "מצב מקוון (${networkStatus.transportLabelHe})"
                else "מצב לא מקוון (Offline Safe Mode)",
              style = MaterialTheme.typography.titleMedium,
              color = onlineColor
            )
          }
          Text(
            text = "תור סנכרון מבוקר בחזרת רשת: ${pendingSyncQueue.size} משימות ממתינות",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          OfflineCapabilityMatrix.items.forEach { cap ->
            Text(
              text = "${if (cap.worksOffline) "✓ מקומי:" else "☁ ענן בלבד:"} ${cap.titleHe}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }
    }

    // 2. Document & PDF Commander
    item {
      NexusHudCard(contentPadding = 12.dp, accentColor = NexusElectricBlue) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("מרכז מסמכים ו-PDF (SAF + PdfRenderer)", style = MaterialTheme.typography.titleMedium, color = NexusNeonCyan)
              Text(
                "פתיחה בטוחה ללא הרשאת אחסון גורפת: PDF, TXT, MD, JSON, CSV",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Button(
              onClick = {
                openDocLauncher.launch(
                  arrayOf("application/pdf", "text/*", "application/json", "application/octet-stream")
                )
              },
              modifier = Modifier.testTag("open_document_btn")
            ) {
              Icon(Icons.Rounded.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("פתח קובץ")
            }
          }

          if (isOpeningDocument) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
          }

          openedDocument?.let { doc ->
            Surface(
              color = MaterialTheme.colorScheme.surfaceContainerHigh,
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.45f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(doc.fileName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(
                      "${doc.kind.titleHe} • ${formatBytes(doc.sizeBytes)}",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                  TextButton(onClick = onCloseDocument) { Text("סגור") }
                }

                Text(doc.aiSummaryHe ?: doc.localSummaryHe, style = MaterialTheme.typography.bodyMedium)

                if (doc.pdfPreviewBitmap != null) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    OutlinedButton(onClick = onPrevPdfPage, enabled = doc.currentPdfPage > 0) {
                      Icon(Icons.AutoMirrored.Rounded.NavigateBefore, contentDescription = "עמוד קודם")
                      Text("קודם")
                    }
                    Text("עמוד ${doc.currentPdfPage + 1} מתוך ${doc.pdfPageCount}", style = MaterialTheme.typography.labelLarge)
                    OutlinedButton(onClick = onNextPdfPage, enabled = doc.currentPdfPage < doc.pdfPageCount - 1) {
                      Text("הבא")
                      Icon(Icons.AutoMirrored.Rounded.NavigateNext, contentDescription = "עמוד הבא")
                    }
                  }
                  Image(
                    bitmap = doc.pdfPreviewBitmap.asImageBitmap(),
                    contentDescription = "תצוגת עמוד PDF",
                    contentScale = ContentScale.Fit,
                    modifier =
                      Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp, max = 360.dp)
                        .background(MaterialTheme.colorScheme.surface)
                  )
                }

                if (doc.textContent.isNotBlank()) {
                  OutlinedTextField(
                    value = docSearchQuery,
                    onValueChange = {
                      docSearchQuery = it
                      onSearchDocument(it)
                    },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    label = { Text("חיפוש מילים בתוך המסמך") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                  )

                  if (docSearchQuery.isNotBlank()) {
                    Text(
                      text = "תוצאות חיפוש (${doc.searchMatches.size}):",
                      style = MaterialTheme.typography.labelMedium,
                      color = NexusNeonCyan
                    )
                    doc.searchMatches.take(6).forEach { m ->
                      Text(
                        text = "שורה ${m.lineNumber}: ${m.snippet}",
                        style = MaterialTheme.typography.bodySmall
                      )
                    }
                  } else {
                    Text(
                      text = doc.textContent.take(550) + if (doc.textContent.length > 550) "\n..." else "",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  if (doc.textContent.isNotBlank()) {
                    Button(
                      onClick = onSummarizeDocWithAi,
                      enabled = !isSummarizingDocument
                    ) {
                      Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(if (isSummarizingDocument) "מסכם..." else "סכם ב-AI")
                    }
                  }
                  OutlinedButton(onClick = { createDocLauncher.launch("NEXUS_${doc.fileName}.txt") }) {
                    Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("שמור כמסמך")
                  }
                }
              }
            }
          }
        }
      }
    }

    // 3. Modular Tool Registry
    item {
      NexusHudCard(contentPadding = 12.dp) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Rounded.Build, contentDescription = null, tint = NexusNeonCyan)
            Text("מאגר כלים מודולריים ובריאות (${toolStatuses.size})", style = MaterialTheme.typography.titleMedium, color = NexusNeonCyan)
          }
          IconButton(onClick = onRefreshToolHealth) {
            Icon(Icons.Rounded.Refresh, contentDescription = "רענן תקינות כלים", tint = NexusNeonCyan)
          }
        }
      }
    }

    items(toolStatuses, key = { it.definition.id }) { tool ->
      val badgeColor =
        when (tool.healthState) {
          NexusToolHealthState.READY -> NexusEmerald
          NexusToolHealthState.PERMISSION_NEEDED,
          NexusToolHealthState.OFFLINE_LIMITED -> NexusAmber
          NexusToolHealthState.DEGRADED -> NexusCrimson
        }
      NexusHudCard(contentPadding = 10.dp, accentColor = badgeColor) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(tool.definition.nameHe, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
            Surface(
              color = badgeColor.copy(alpha = 0.16f),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = tool.healthState.titleHe,
                style = MaterialTheme.typography.labelSmall,
                color = badgeColor,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }
          Text(tool.definition.descriptionHe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text("הרשאה: ${tool.definition.requiredPermissionLabelHe}", style = MaterialTheme.typography.labelSmall, color = NexusNeonCyan)
          Text(
            text = "${tool.statusDetailHe} • ריצות: ${tool.totalRuns} (${tool.successRatePercent}% הצלחה)",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }
    }
  }
}
