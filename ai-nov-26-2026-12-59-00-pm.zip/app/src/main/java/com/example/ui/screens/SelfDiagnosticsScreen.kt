package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.FactCheck
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.HealthSeverity
import com.example.data.system.SelfDiagnosticCheckItem
import com.example.data.system.SelfDiagnosticsReport
import com.example.ui.components.NexusHudCard
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusEmerald
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SelfDiagnosticsScreen(
  report: SelfDiagnosticsReport?,
  isRunningDiagnostics: Boolean,
  onRunSelfDiagnostics: () -> Unit,
  onNavigateRoute: (String) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  val fmt = remember { SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()) }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      NexusHudCard(accentColor = MaterialTheme.colorScheme.primary) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "מרכז אבחון עצמי חכם ו-Benchmark",
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text =
                "בדיקת תקינות אמיתית למסד הנתונים Room, ניווט, הרשאות Android 10, AI Cloud, WorkManager ומהירות מעבד/Heap.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Icon(Icons.Rounded.FactCheck, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        }
        Spacer(modifier = Modifier.height(12.dp))
        Button(
          onClick = onRunSelfDiagnostics,
          enabled = !isRunningDiagnostics,
          modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("self_diag_run_btn")
        ) {
          if (isRunningDiagnostics) {
            CircularProgressIndicator(
              modifier = Modifier.width(18.dp).height(18.dp),
              strokeWidth = 2.dp,
              color = MaterialTheme.colorScheme.onPrimary
            )
          } else {
            Icon(Icons.Rounded.PlayArrow, contentDescription = null)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(if (isRunningDiagnostics) "מריץ בדיקות אמת..." else "הרץ אבחון עצמי מלא")
        }
      }
    }

    if (report == null) {
      item {
        NexusHudCard(accentColor = MaterialTheme.colorScheme.outline) {
          Text(
            text = "טרם הורץ אבחון עצמי בהפעלה זו",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "לחץ על \"הרץ אבחון עצמי מלא\" כדי לבדוק בזמן אמת את כל תתי-המערכות וה-Benchmark לטאבלט SM-T545.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    } else {
      val scoreColor =
        when {
          report.overallScore >= 85 -> NexusEmerald
          report.overallScore >= 60 -> NexusAmber
          else -> NexusCrimson
        }
      item {
        NexusHudCard(accentColor = scoreColor) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "ציון בריאות מערכת אייקו: ${report.overallScore}%",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = scoreColor
              )
              Text(
                text = "הורץ ב-${fmt.format(Date(report.checkedAtMillis))}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = scoreColor.copy(alpha = 0.14f)
            ) {
              Text(
                text = "${report.passedCount}/${report.totalChecks} תקינים",
                style = MaterialTheme.typography.labelMedium,
                color = scoreColor,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }
          Spacer(modifier = Modifier.height(8.dp))
          LinearProgressIndicator(
            progress = { report.overallScore / 100f },
            color = scoreColor,
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "תקינים: ${report.passedCount} • התראות/הערות: ${report.warningCount} • שגיאות: ${report.errorCount}",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }

      item {
        NexusHudCard(accentColor = MaterialTheme.colorScheme.secondary) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Speed, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "מדד ביצועי SM-T545 (CPU/Heap Benchmark)",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "${report.cpuOpsLabelHe} • זמן ריצה: ${report.benchmarkDurationMs} מ״ש",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }

      items(report.checks, key = { it.id }) { check ->
        SelfDiagCheckCard(
          check = check,
          onOpenFixRoute = { route -> onNavigateRoute(route) }
        )
      }
    }
  }
}

@Composable
private fun SelfDiagCheckCard(
  check: SelfDiagnosticCheckItem,
  onOpenFixRoute: (String) -> Unit
) {
  val (accent, icon) =
    when (check.severity) {
      HealthSeverity.OPTIMAL -> NexusEmerald to Icons.Rounded.CheckCircle
      HealthSeverity.NOTICE -> MaterialTheme.colorScheme.primary to Icons.Rounded.WarningAmber
      HealthSeverity.WARNING -> NexusAmber to Icons.Rounded.WarningAmber
      HealthSeverity.CRITICAL -> NexusCrimson to Icons.Rounded.ErrorOutline
    }

  NexusHudCard(accentColor = accent, contentPadding = 14.dp) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = icon, contentDescription = null, tint = accent)
        Spacer(modifier = Modifier.width(8.dp))
        Column {
          Text(
            text = check.titleHe,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = check.statusHe,
            style = MaterialTheme.typography.labelLarge,
            color = accent
          )
        }
      }
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
      ) {
        Text(
          text = "${check.durationMs} מ״ש",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
      }
    }
    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = check.detailHe,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    check.fixRoute?.let { route ->
      Spacer(modifier = Modifier.height(8.dp))
      OutlinedButton(
        onClick = { onOpenFixRoute(route) },
        modifier = Modifier.minimumInteractiveComponentSize().testTag("self_diag_fix_${check.id}")
      ) {
        Text("פתח / תקן")
      }
    }
  }
}
