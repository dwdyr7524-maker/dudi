package com.example.ui.screens

import android.graphics.drawable.Drawable
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Launch
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.example.data.model.AppDiagnosticInfo
import com.example.data.model.AppFilterMode
import com.example.data.model.AppSortMode
import com.example.data.model.SimilarAppGroup
import com.example.data.system.formatBytes
import com.example.ui.components.NexusDataWell
import com.example.ui.components.NexusEditorialSection
import com.example.ui.components.NexusHairlineDivider
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusShimmerBox
import com.example.ui.components.nexusInteractive
import com.example.ui.components.nexusStaggeredEntrance
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalMotionConfig
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusTurquoise
import com.example.ui.theme.NexusTurquoiseBright
import com.example.ui.viewmodel.AppsUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AppsScreen(
  state: AppsUiState,
  hasUsageAccess: Boolean,
  onSearchChange: (String) -> Unit,
  onSortChange: (AppSortMode) -> Unit,
  onFilterChange: (AppFilterMode) -> Unit,
  onSelectApp: (String) -> Unit,
  onLaunchApp: (String, String) -> Unit,
  onOpenAppSettings: (String, String) -> Unit,
  onOpenUsageAccess: () -> Unit,
  onBack: () -> Unit,
  similarAppGroups: List<SimilarAppGroup> = emptyList(),
  onRequestUninstallProposal: (AppDiagnosticInfo) -> Unit = {},
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  val motion = LocalMotionConfig.current
  val filteredApps =
    remember(state.allApps, state.searchQuery, state.sortMode, state.filterMode) {
      state.allApps
        .filter { app ->
          val matchesFilter =
            when (state.filterMode) {
              AppFilterMode.ALL -> true
              AppFilterMode.USER_APPS -> !app.isSystemApp
              AppFilterMode.SYSTEM_APPS -> app.isSystemApp
              AppFilterMode.DORMANT -> app.isDormant
            }
          val q = state.searchQuery.trim()
          val matchesQuery =
            q.isEmpty() ||
              app.appName.contains(q, ignoreCase = true) ||
              app.packageName.contains(q, ignoreCase = true)
          matchesFilter && matchesQuery
        }
        .let { list ->
          when (state.sortMode) {
            AppSortMode.SIZE_DESC -> list.sortedByDescending { it.totalSizeBytes }
            AppSortMode.NAME_ASC -> list.sortedBy { it.appName.lowercase() }
            AppSortMode.RECENT_UPDATED -> list.sortedByDescending { it.lastUpdateTime }
            AppSortMode.LEAST_USED ->
              list.sortedWith(
                compareBy<AppDiagnosticInfo> { it.isSystemApp }
                  .thenBy { it.lastTimeUsedMillis ?: 0L }
                  .thenByDescending { it.totalSizeBytes }
              )
          }
        }
    }

  val selectedApp =
    filteredApps.firstOrNull { it.packageName == state.selectedPackageName }
      ?: filteredApps.firstOrNull()

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isTabletWide = maxWidth >= 760.dp

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 14.dp)) {
      // Graphite Software Console Toolbar
      NexusHudCard(
        accentColor = NexusElectricBlue,
        contentPadding = 16.dp,
        modifier = Modifier.fillMaxWidth().nexusStaggeredEntrance(0, "apps_toolbar")
      ) {
        NexusEditorialSection(
          title = "קונסולת אפליקציות והרשאות",
          subtitle = "${filteredApps.size} אפליקציות מוצגות מתוך ${state.allApps.size} מותקנות",
          accentColor = NexusElectricBlue,
          trailing = {
            NexusDataWell(accentColor = MaterialTheme.colorScheme.primary, contentPadding = 8.dp) {
              Text(
                text = "${filteredApps.size}",
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
        ) {
          if (!hasUsageAccess) {
            Row(
              modifier =
                Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .background(NexusAmber.copy(alpha = 0.10f))
                  .border(1.dp, NexusAmber.copy(alpha = 0.42f), RoundedCornerShape(8.dp))
                  .clickable(onClick = onOpenUsageAccess)
                  .padding(horizontal = 12.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "מוצג נפח APK בסיסי — לחץ כאן לאישור הרשאת נתוני שימוש להצגת מטמון וזמן מסך מדויק.",
                style = MaterialTheme.typography.bodySmall,
                color = NexusAmber
              )
            }
            Spacer(modifier = Modifier.height(10.dp))
          }

          OutlinedTextField(
            value = state.searchQuery,
            onValueChange = onSearchChange,
            modifier = Modifier.fillMaxWidth().testTag("apps_search_field"),
            placeholder = { Text("חפש אפליקציה או שם חבילה...", color = MaterialTheme.colorScheme.onSurfaceVariant) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            colors =
              OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.78f),
                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
              )
          )

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            AppSortMode.entries.forEach { mode ->
              val label =
                when (mode) {
                  AppSortMode.SIZE_DESC -> "נפח אחסון"
                  AppSortMode.NAME_ASC -> "שם"
                  AppSortMode.RECENT_UPDATED -> "עודכנו לאחרונה"
                  AppSortMode.LEAST_USED -> "שימוש מועט"
                }
              FilterChip(
                selected = state.sortMode == mode,
                onClick = { onSortChange(mode) },
                label = { Text(label) },
                shape = RoundedCornerShape(8.dp),
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NexusElectricBlue.copy(alpha = 0.24f),
                    selectedLabelColor = MaterialTheme.colorScheme.primary
                  )
              )
            }
            AppFilterMode.entries.forEach { f ->
              val label =
                when (f) {
                  AppFilterMode.ALL -> "הכול"
                  AppFilterMode.USER_APPS -> "משתמש"
                  AppFilterMode.SYSTEM_APPS -> "מערכת"
                  AppFilterMode.DORMANT -> "רדומות 30+"
                }
              FilterChip(
                selected = state.filterMode == f,
                onClick = { onFilterChange(f) },
                label = { Text(label) },
                shape = RoundedCornerShape(8.dp),
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NexusTurquoise.copy(alpha = 0.22f),
                    selectedLabelColor = NexusTurquoiseBright
                  )
              )
            }
          }
        }
      }

      if (similarAppGroups.isNotEmpty()) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier =
            Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState())
              .padding(vertical = 2.dp),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Apps, contentDescription = null, tint = NexusAmber, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              "תפקידים חופפים (${similarAppGroups.size}):",
              style = MaterialTheme.typography.labelLarge,
              color = NexusAmber
            )
          }
          similarAppGroups.forEach { grp ->
            Surface(
              color = MaterialTheme.colorScheme.surface,
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.40f))
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Text("${grp.roleTitleHe}:", style = MaterialTheme.typography.labelMedium, color = NexusAmber)
                Text(
                  grp.apps.joinToString(", ") { it.appName },
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurface,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      if (state.isLoading) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          repeat(6) { NexusShimmerBox(height = 64.dp) }
        }
      } else if (isTabletWide) {
        Row(
          modifier = Modifier.fillMaxSize().nexusStaggeredEntrance(1, "apps_split"),
          horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          NexusHudCard(
            accentColor = MaterialTheme.colorScheme.outline,
            contentPadding = 8.dp,
            modifier = Modifier.weight(0.54f).fillMaxHeight()
          ) {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
              items(filteredApps, key = { it.packageName }) { app ->
                AppListRow(
                  app = app,
                  selected = selectedApp?.packageName == app.packageName,
                  onClick = { onSelectApp(app.packageName) },
                  onLaunchApp = onLaunchApp,
                  onOpenAppSettings = onOpenAppSettings,
                  onRequestUninstallProposal = onRequestUninstallProposal,
                  showInlineActions = false
                )
                NexusHairlineDivider()
              }
            }
          }

          NexusHudCard(
            accentColor = NexusTurquoise,
            contentPadding = 16.dp,
            modifier = Modifier.weight(0.46f).fillMaxHeight()
          ) {
            selectedApp?.let { detail ->
              AnimatedContent(
                targetState = detail,
                transitionSpec = {
                  fadeIn(tween(motion.duration(170, 70))) togetherWith fadeOut(tween(motion.duration(120, 60)))
                },
                label = "app_inspector_swap"
              ) { currentDetail ->
                AppDetailPane(
                  app = currentDetail,
                  hasUsageAccess = hasUsageAccess,
                  onLaunchApp = { onLaunchApp(currentDetail.packageName, currentDetail.appName) },
                  onOpenSettings = { onOpenAppSettings(currentDetail.packageName, currentDetail.appName) },
                  onRequestUninstall = { onRequestUninstallProposal(currentDetail) }
                )
              }
            }
          }
        }
      } else {
        NexusHudCard(
          accentColor = MaterialTheme.colorScheme.outline,
          contentPadding = 8.dp,
          modifier = Modifier.fillMaxSize()
        ) {
          LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(filteredApps, key = { it.packageName }) { app ->
              AppListRow(
                app = app,
                selected = selectedApp?.packageName == app.packageName,
                onClick = { onSelectApp(app.packageName) },
                onLaunchApp = onLaunchApp,
                onOpenAppSettings = onOpenAppSettings,
                onRequestUninstallProposal = onRequestUninstallProposal,
                showInlineActions = true
              )
              NexusHairlineDivider()
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AppListRow(
  app: AppDiagnosticInfo,
  selected: Boolean,
  onClick: () -> Unit,
  onLaunchApp: (String, String) -> Unit,
  onOpenAppSettings: (String, String) -> Unit,
  onRequestUninstallProposal: (AppDiagnosticInfo) -> Unit,
  showInlineActions: Boolean
) {
  val rowBg =
    if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.11f)
    else Color.Transparent

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(8.dp))
        .background(rowBg)
        .clickable(onClick = onClick)
        .padding(vertical = 12.dp, horizontal = 8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier =
          Modifier
            .width(3.dp)
            .fillMaxHeight()
            .background(
              if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
              RoundedCornerShape(2.dp)
            )
      )
      Spacer(modifier = Modifier.width(10.dp))
      AppDrawableIcon(drawable = app.iconDrawable, appName = app.appName, sizeDp = 42)
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = app.appName,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
          )
          if (app.isDormant) {
            Surface(
              color = NexusAmber.copy(alpha = 0.14f),
              shape = RoundedCornerShape(6.dp),
              border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.42f))
            ) {
              Text(
                text = "רדומה 30+",
                style = MaterialTheme.typography.labelSmall,
                color = NexusAmber,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
        }
        Text(
          text =
            (if (app.isSystemApp) "מערכת" else "משתמש") +
              " • ${app.grantedSensitivePermissions.size} הרשאות רגישות" +
              if (!app.isEnabled) " • מושבתת" else "",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = formatBytes(app.totalSizeBytes),
          style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.SemiBold),
          color = MaterialTheme.colorScheme.primary
        )
        app.cacheBytes?.let { cache ->
          Text(
            text = "מטמון ${formatBytes(cache)}",
            style = MaterialTheme.typography.labelSmall,
            color = NexusAmber
          )
        }
      }
    }

    if (showInlineActions && selected) {
      val canLaunch = app.isLaunchable && app.isEnabled
      Spacer(modifier = Modifier.height(10.dp))
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(start = 13.dp)) {
        Button(
          onClick = { onLaunchApp(app.packageName, app.appName) },
          enabled = canLaunch,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
          modifier = Modifier.weight(1f).height(48.dp)
        ) {
          Text(if (canLaunch) "פתח" else "ללא ממשק")
        }
        OutlinedButton(
          onClick = { onOpenAppSettings(app.packageName, app.appName) },
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.weight(1f).height(48.dp),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
          Text("פרטים", color = MaterialTheme.colorScheme.primary)
        }
        if (!app.isSystemApp) {
          OutlinedButton(
            onClick = { onRequestUninstallProposal(app) },
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f).height(48.dp),
            border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.55f))
          ) {
            Text("הסר", color = NexusCrimson)
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AppDetailPane(
  app: AppDiagnosticInfo,
  hasUsageAccess: Boolean,
  onLaunchApp: () -> Unit,
  onOpenSettings: () -> Unit,
  onRequestUninstall: () -> Unit
) {
  val fmt = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
  val lastUsedLabel =
    when {
      !hasUsageAccess -> "נדרשת הרשאת שימוש"
      app.lastTimeUsedMillis != null && app.lastTimeUsedMillis > 0L -> fmt.format(Date(app.lastTimeUsedMillis))
      else -> "לא זוהה (90 יום)"
    }
  val fgMinutes = ((app.totalTimeInForegroundMillis ?: 0L) / 60_000L)
  val fgLabel =
    when {
      !hasUsageAccess -> "נדרשת הרשאת שימוש"
      fgMinutes <= 0L -> "< דקה (90 יום)"
      fgMinutes < 60L -> "$fgMinutes דק׳ (90 יום)"
      else -> "${fgMinutes / 60L}ש׳ ${fgMinutes % 60L}ד׳"
    }

  Column(modifier = Modifier.fillMaxSize()) {
    // Tier 1: App Inspector Header
    Row(verticalAlignment = Alignment.CenterVertically) {
      AppDrawableIcon(drawable = app.iconDrawable, appName = app.appName, sizeDp = 52)
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(app.appName, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurface)
        Text(
          app.packageName,
          style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    }

    if (app.isDormant) {
      Spacer(modifier = Modifier.height(10.dp))
      Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(NexusAmber.copy(alpha = 0.11f))
            .border(1.dp, NexusAmber.copy(alpha = 0.42f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
      ) {
        Text(
          text = "אפליקציה רדומה (ללא שימוש 30+ יום) — מומלץ לבדוק הסרה או ניקוי בהגדרות.",
          style = MaterialTheme.typography.bodySmall,
          color = NexusAmber
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Tier 2: Recessed Tabular Telemetry Table
    NexusDataWell(contentPadding = 12.dp) {
      InspectorMetricRow("גרסה ועדכון", "${app.versionName} • ${if (app.lastUpdateTime > 0) fmt.format(Date(app.lastUpdateTime)) else "—"}")
      NexusHairlineDivider()
      InspectorMetricRow("שימוש אחרון / מסך", "$lastUsedLabel • $fgLabel", valueColor = if (app.isDormant) NexusAmber else MaterialTheme.colorScheme.onSurface)
      NexusHairlineDivider()
      InspectorMetricRow("נפח כולל / APK", "${formatBytes(app.totalSizeBytes)} (APK: ${formatBytes(app.apkSizeBytes)})", valueColor = MaterialTheme.colorScheme.primary)
      NexusHairlineDivider()
      InspectorMetricRow(
        "נתונים / מטמון",
        "${app.appDataBytes?.let { formatBytes(it) } ?: "—"} / ${app.cacheBytes?.let { formatBytes(it) } ?: "—"}",
        valueColor = if ((app.cacheBytes ?: 0L) > 0L) NexusAmber else MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    Spacer(modifier = Modifier.height(14.dp))
    Text(
      "הרשאות רגישות מאושרות (${app.grantedSensitivePermissions.size})",
      style = MaterialTheme.typography.titleSmall,
      color = MaterialTheme.colorScheme.onSurface
    )
    Spacer(modifier = Modifier.height(8.dp))

    if (app.grantedSensitivePermissions.isEmpty()) {
      Text("אין הרשאות רגישות מאושרות.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
      Spacer(modifier = Modifier.weight(1f))
    } else {
      LazyColumn(modifier = Modifier.weight(1f)) {
        item {
          FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            app.grantedSensitivePermissions.forEach { perm ->
              Surface(
                color = MaterialTheme.colorScheme.surfaceContainerLowest,
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
              ) {
                Text(
                  text = perm.substringAfterLast('.'),
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }
          }
        }
      }
    }

    val canLaunch = app.isLaunchable && app.isEnabled
    if (!canLaunch) {
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text =
          if (!app.isEnabled) "אפליקציה מושבתת בהגדרות — הפתיחה מנוטרלת."
          else "רכיב מערכת או שירות רקע ללא מסך הפעלה ישיר.",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    Spacer(modifier = Modifier.height(12.dp))
    // Tier 3: Clear Primary & Secondary Actions
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
      Button(
        onClick = onLaunchApp,
        enabled = canLaunch,
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
        modifier = Modifier.weight(1f).height(48.dp).nexusInteractive().testTag("app_detail_launch")
      ) {
        Icon(Icons.AutoMirrored.Rounded.Launch, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(if (canLaunch) "פתח" else "ללא פתיחה")
      }
      OutlinedButton(
        onClick = onOpenSettings,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.weight(1f).height(48.dp).nexusInteractive().testTag("app_detail_settings"),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f))
      ) {
        Icon(Icons.Rounded.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("הגדרות מערכת", color = MaterialTheme.colorScheme.primary)
      }
    }
    if (!app.isSystemApp) {
      Spacer(modifier = Modifier.height(8.dp))
      OutlinedButton(
        onClick = onRequestUninstall,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().height(48.dp).nexusInteractive().testTag("app_detail_uninstall"),
        border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.6f))
      ) {
        Icon(Icons.Rounded.DeleteForever, contentDescription = null, tint = NexusCrimson, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("הסר אפליקציה (שלח לאישור)", color = NexusCrimson)
      }
    }
  }
}

@Composable
private fun InspectorMetricRow(
  label: String,
  value: String,
  valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(
      text = value,
      style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
      color = valueColor,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )
  }
}

@Composable
private fun AppDrawableIcon(
  drawable: Drawable?,
  appName: String,
  sizeDp: Int = 42
) {
  val bitmap =
    remember(drawable) {
      drawable?.let {
        runCatching { it.toBitmap(width = 96, height = 96).asImageBitmap() }.getOrNull()
      }
    }
  if (bitmap != null) {
    Image(
      bitmap = bitmap,
      contentDescription = appName,
      modifier = Modifier.size(sizeDp.dp).clip(RoundedCornerShape(8.dp))
    )
  } else {
    Box(
      modifier =
        Modifier
          .size(sizeDp.dp)
          .clip(RoundedCornerShape(8.dp))
          .background(MaterialTheme.colorScheme.surfaceContainerHigh)
          .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
    )
  }
}
