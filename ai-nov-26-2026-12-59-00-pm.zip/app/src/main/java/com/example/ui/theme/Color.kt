package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ============================================================================
// NEXUS AI — COMMERCIAL DARK PREMIUM PALETTE
// Deep Blue-Black Canvas + Graphite Surfaces + Turquoise & Electric Blue Accents
// ============================================================================
val NexusElectricBlue = Color(0xFF2563EB)
val NexusElectricDeep = Color(0xFF1D4ED8)
val NexusDeepBlue = Color(0xFF172554)
val NexusDeepBlueGlow = Color(0xFF3B82F6)
val NexusTurquoise = Color(0xFF14B8A6)
val NexusTurquoiseBright = Color(0xFF2DD4BF)
val NexusNeonCyan = Color(0xFF06B6D4)
val NexusCyanBright = Color(0xFF22D3EE)
val NexusGlowSky = Color(0xFF38BDF8)
val NexusViolet = Color(0xFF8B5CF6)
val NexusVioletBright = Color(0xFFA78BFA)
val NexusEmerald = Color(0xFF10B981)
val NexusEmeraldBright = Color(0xFF34D399)
val NexusAmber = Color(0xFFF59E0B)
val NexusAmberBright = Color(0xFFFBBF24)
val NexusCrimson = Color(0xFFF43F5E)
val NexusRose = Color(0xFFF43F5E)
val NexusRoseBright = Color(0xFFFB7185)

// Dark Mode Canvas (Deep Blue-Black Canvas + Layered Graphite Cards)
val NexusObsidian = Color(0xFF050912)         // Primary deep blue-black canvas
val NexusTitaniumDark = Color(0xFF090F1D)     // Secondary blue-black depth
val NexusDataWellDark = Color(0xFF070B14)     // Recessed data-well surface inside cards
val NexusCharcoal = Color(0xFF101520)         // Graphite card base
val NexusTitaniumCard = Color(0xFF131926)     // Graphite secondary surface
val NexusTitaniumElevated = Color(0xFF171E2C) // Elevated graphite card
val NexusDarkSurfaceHighest = Color(0xFF1E2738) // Highest interactive graphite layer

val NexusTextPrimary = Color(0xFFF3F6FC)
val NexusTextSecondary = Color(0xFFBAC6D8)
val NexusTextMuted = Color(0xFF8392A8)

val NexusBorderSubtle = Color(0xFF212B3D)
val NexusBorderGraphite = Color(0xFF2A364B)
val NexusBorderGlow = Color(0xFF14B8A6)

// Light Mode Canvas (Preserved for optional theme toggle)
val NexusLightBackground = Color(0xFFF5F7FA)
val NexusLightSurface = Color(0xFFFFFFFF)
val NexusLightCard = Color(0xFFFFFFFF)
val NexusLightCardElevated = Color(0xFFEEF2F8)
val NexusLightCardHighest = Color(0xFFE4EBF5)
val NexusLightPrimary = Color(0xFF2563EB)
val NexusLightSecondary = Color(0xFF0D9488)
val NexusLightTertiary = Color(0xFF10B981)
val NexusLightTextPrimary = Color(0xFF172033)
val NexusLightTextSecondary = Color(0xFF64748B)
val NexusLightBorder = Color(0xFFE2E8F0)
val NexusLightCrimson = Color(0xFFE11D48)
val NexusLightAmber = Color(0xFFD97706)
