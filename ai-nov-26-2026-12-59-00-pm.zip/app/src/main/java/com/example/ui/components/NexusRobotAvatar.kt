package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.RobotMood
import com.example.ui.theme.LocalMotionConfig
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusRose
import com.example.ui.theme.NexusTitaniumElevated
import com.example.ui.theme.NexusViolet
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay

/**
 * Bespoke sculpted Aiko avatar: matte titanium-white armored helmet,
 * obsidian optical glass visor, expressive cyan eyes, chest core 'N',
 * subtle breathing, orbital thinking nodes, and reactive audio waveform.
 */
@Composable
fun NexusRobotAvatar(
  mood: RobotMood,
  modifier: Modifier = Modifier,
  size: Dp = 128.dp,
  isPlanning: Boolean = false,
  isExecuting: Boolean = false
) {
  val motion = LocalMotionConfig.current

  val (bobOffset, pulse, wavePhase, orbitPhase) =
    if (motion.allowAmbientMotion || (mood != RobotMood.IDLE && motion.allowMicroMotion)) {
      val inf = rememberInfiniteTransition(label = "aiko_bespoke")
      val bob by
        inf.animateFloat(
          initialValue = -2.8f,
          targetValue = 2.8f,
          animationSpec =
            infiniteRepeatable(
              animation = tween(if (motion.performanceMode) 2800 else 2100, easing = FastOutSlowInEasing),
              repeatMode = RepeatMode.Reverse
            ),
          label = "aiko_bob"
        )
      val p by
        inf.animateFloat(
          initialValue = 0.72f,
          targetValue = 1f,
          animationSpec =
            infiniteRepeatable(
              animation = tween(1600, easing = FastOutSlowInEasing),
              repeatMode = RepeatMode.Reverse
            ),
          label = "aiko_pulse"
        )
      val wave by
        inf.animateFloat(
          initialValue = 0f,
          targetValue = 6.283f,
          animationSpec = infiniteRepeatable(tween(780, easing = LinearEasing)),
          label = "aiko_wave"
        )
      val orbit by
        inf.animateFloat(
          initialValue = 0f,
          targetValue = 360f,
          animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)),
          label = "aiko_orbit"
        )
      listOf(bob, p, wave, orbit)
    } else {
      listOf(0f, 0.88f, 0f, 45f)
    }

  var isBlinking by remember { mutableStateOf(false) }
  LaunchedEffect(motion.allowAmbientMotion) {
    if (!motion.allowAmbientMotion) {
      isBlinking = false
      return@LaunchedEffect
    }
    while (true) {
      delay(3600)
      isBlinking = true
      delay(120)
      isBlinking = false
    }
  }

  val errorShake = remember { Animatable(0f) }
  LaunchedEffect(mood, motion.allowMicroMotion) {
    if (mood == RobotMood.ALERT && motion.allowMicroMotion) {
      listOf(-3.5f, 3.5f, -2f, 2f, 0f).forEach { target ->
        errorShake.animateTo(target, tween(50, easing = FastOutSlowInEasing))
      }
    } else {
      errorShake.snapTo(0f)
    }
  }

  val targetAccent =
    when {
      mood == RobotMood.ALERT -> NexusRose
      mood == RobotMood.SUCCESS -> NexusEmerald
      isPlanning || mood == RobotMood.THINKING -> NexusViolet
      mood == RobotMood.LISTENING -> NexusAmber
      isExecuting || mood == RobotMood.SPEAKING -> NexusElectricBlue
      else -> NexusNeonCyan
    }
  val accentColor by
    animateColorAsState(
      targetValue = targetAccent,
      animationSpec = tween(motion.duration(260, 90)),
      label = "aiko_accent_color"
    )

  Canvas(modifier = modifier.size(size)) {
    val w = this.size.width
    val h = this.size.height
    val cx = w / 2f + errorShake.value * (w / 128.dp.toPx())
    val floatY = if (!motion.allowAmbientMotion) 0f else bobOffset * (h / 128.dp.toPx())

    // Subtle atmospheric core halo behind helmet
    drawCircle(
      brush =
        Brush.radialGradient(
          colors =
            listOf(
              accentColor.copy(alpha = 0.20f * pulse),
              NexusElectricBlue.copy(alpha = 0.06f * pulse),
              Color.Transparent
            ),
          center = Offset(cx, h * 0.44f + floatY),
          radius = w * 0.46f
        )
    )

    // Thinking / Planning / Execution orbital track & nodes
    if ((mood == RobotMood.THINKING || isPlanning || isExecuting) && motion.allowMicroMotion) {
      val orbitR = w * 0.43f
      val centerOrbit = Offset(cx, h * 0.42f + floatY)
      drawArc(
        brush = Brush.sweepGradient(listOf(Color.Transparent, accentColor.copy(alpha = 0.85f), NexusNeonCyan)),
        startAngle = orbitPhase,
        sweepAngle = if (isExecuting) 210f else 125f,
        useCenter = false,
        topLeft = Offset(centerOrbit.x - orbitR, centerOrbit.y - orbitR),
        size = Size(orbitR * 2f, orbitR * 2f),
        style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round)
      )
      val nodeCount = if (isPlanning) 4 else if (motion.performanceMode) 3 else 5
      for (i in 0 until nodeCount) {
        val deg = orbitPhase + i * (360f / nodeCount)
        val rad = deg * (PI.toFloat() / 180f)
        val px = centerOrbit.x + cos(rad) * orbitR
        val py = centerOrbit.y + sin(rad) * (orbitR * 0.82f)
        drawCircle(
          color = if (i % 2 == 0) accentColor else NexusNeonCyan,
          radius = 2.6.dp.toPx(),
          center = Offset(px, py)
        )
      }
    }

    // Listening acoustic rings
    if (mood == RobotMood.LISTENING && motion.allowMicroMotion) {
      val headCenterY = h * 0.39f + floatY
      for (ring in 1..2) {
        val phaseShift = ((wavePhase / 6.283f) + ring * 0.45f) % 1f
        drawCircle(
          color = accentColor.copy(alpha = (1f - phaseShift) * 0.48f),
          radius = w * (0.31f + phaseShift * 0.15f),
          center = Offset(cx, headCenterY),
          style = Stroke(width = 1.8.dp.toPx())
        )
      }
    }

    // Success halo ring
    if (mood == RobotMood.SUCCESS) {
      drawCircle(
        color = NexusEmerald.copy(alpha = 0.48f * pulse),
        radius = w * 0.43f,
        center = Offset(cx, h * 0.44f + floatY),
        style = Stroke(width = 2.dp.toPx())
      )
    }

    // Precision base ring
    val pedY = h * 0.89f
    drawOval(
      color = accentColor.copy(alpha = 0.55f * pulse),
      topLeft = Offset(cx - w * 0.28f, pedY - h * 0.038f),
      size = Size(w * 0.56f, h * 0.076f),
      style = Stroke(width = 1.6.dp.toPx())
    )

    // Armored Chassis / Shoulders (Titanium-white outer shoulder plates + Navy core)
    val torsoTop = h * 0.62f + floatY
    val torsoW = w * 0.48f
    val torsoH = h * 0.21f
    drawRoundRect(
      brush =
        Brush.verticalGradient(
          colors = listOf(Color(0xFFF1F5F9), Color(0xFFCBD5E1))
        ),
      topLeft = Offset(cx - torsoW / 2f, torsoTop),
      size = Size(torsoW, torsoH),
      cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
    )
    // Inner Navy Armor Core
    val chestW = torsoW * 0.66f
    val chestH = torsoH * 0.78f
    val chestLeft = cx - chestW / 2f
    val chestTop = torsoTop + torsoH * 0.12f
    drawRoundRect(
      brush = Brush.verticalGradient(listOf(NexusTitaniumElevated, NexusCharcoal)),
      topLeft = Offset(chestLeft, chestTop),
      size = Size(chestW, chestH),
      cornerRadius = CornerRadius(w * 0.06f, w * 0.06f)
    )
    // Luminous 'N' emblem on chest
    val nW = chestW * 0.34f
    val nH = chestH * 0.52f
    val nLeft = cx - nW / 2f
    val nTop = chestTop + (chestH - nH) / 2f
    val chestN = Path().apply {
      moveTo(nLeft, nTop + nH)
      lineTo(nLeft, nTop)
      lineTo(nLeft + nW, nTop + nH)
      lineTo(nLeft + nW, nTop)
    }
    drawPath(
      path = chestN,
      color = accentColor.copy(alpha = 0.92f * pulse),
      style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    // Neck collar
    drawRoundRect(
      color = NexusCharcoal,
      topLeft = Offset(cx - w * 0.08f, h * 0.57f + floatY),
      size = Size(w * 0.16f, h * 0.065f),
      cornerRadius = CornerRadius(4f, 4f)
    )

    // Acoustic Ear Pods with cyan ring
    val headTop = h * 0.18f + floatY
    val headW = w * 0.56f
    val headH = h * 0.40f
    val headLeft = cx - headW / 2f

    drawRoundRect(
      color = NexusCharcoal,
      topLeft = Offset(headLeft - w * 0.055f, headTop + headH * 0.28f),
      size = Size(w * 0.07f, headH * 0.44f),
      cornerRadius = CornerRadius(8f, 8f)
    )
    drawRoundRect(
      color = accentColor.copy(alpha = 0.85f),
      topLeft = Offset(headLeft - w * 0.042f, headTop + headH * 0.36f),
      size = Size(w * 0.028f, headH * 0.28f),
      cornerRadius = CornerRadius(6f, 6f)
    )
    drawRoundRect(
      color = NexusCharcoal,
      topLeft = Offset(headLeft + headW - w * 0.015f, headTop + headH * 0.28f),
      size = Size(w * 0.07f, headH * 0.44f),
      cornerRadius = CornerRadius(8f, 8f)
    )
    drawRoundRect(
      color = accentColor.copy(alpha = 0.85f),
      topLeft = Offset(headLeft + headW + w * 0.014f, headTop + headH * 0.36f),
      size = Size(w * 0.028f, headH * 0.28f),
      cornerRadius = CornerRadius(6f, 6f)
    )

    // Matte Titanium-White Sculpted Helmet
    drawRoundRect(
      brush =
        Brush.linearGradient(
          colors = listOf(Color(0xFFFFFFFF), Color(0xFFE2E8F0), Color(0xFFCBD5E1)),
          start = Offset(headLeft, headTop),
          end = Offset(headLeft + headW, headTop + headH)
        ),
      topLeft = Offset(headLeft, headTop),
      size = Size(headW, headH),
      cornerRadius = CornerRadius(w * 0.19f, w * 0.19f)
    )
    drawRoundRect(
      color = accentColor.copy(alpha = 0.42f),
      topLeft = Offset(headLeft, headTop),
      size = Size(headW, headH),
      cornerRadius = CornerRadius(w * 0.19f, w * 0.19f),
      style = Stroke(width = 1.4.dp.toPx())
    )

    // Obsidian Optical Glass Visor (#0B1221)
    val visorPadX = headW * 0.10f
    val visorPadY = headH * 0.17f
    val visorW = headW - visorPadX * 2f
    val visorH = headH * 0.66f
    drawRoundRect(
      brush = Brush.verticalGradient(listOf(Color(0xFF070C18), Color(0xFF111C33))),
      topLeft = Offset(headLeft + visorPadX, headTop + visorPadY),
      size = Size(visorW, visorH),
      cornerRadius = CornerRadius(w * 0.13f, w * 0.13f)
    )

    // Optical Expressive Eyes inside Visor
    val eyeY = headTop + visorPadY + visorH * 0.43f
    val leftEyeX = cx - visorW * 0.23f
    val rightEyeX = cx + visorW * 0.23f
    val eyeW = visorW * 0.16f
    val eyeH = visorH * 0.20f

    if (isBlinking) {
      drawLine(
        color = accentColor,
        start = Offset(leftEyeX - eyeW / 2f, eyeY),
        end = Offset(leftEyeX + eyeW / 2f, eyeY),
        strokeWidth = 2.4.dp.toPx(),
        cap = StrokeCap.Round
      )
      drawLine(
        color = accentColor,
        start = Offset(rightEyeX - eyeW / 2f, eyeY),
        end = Offset(rightEyeX + eyeW / 2f, eyeY),
        strokeWidth = 2.4.dp.toPx(),
        cap = StrokeCap.Round
      )
    } else {
      drawRoundRect(
        color = accentColor,
        topLeft = Offset(leftEyeX - eyeW / 2f, eyeY - eyeH / 2f),
        size = Size(eyeW, eyeH),
        cornerRadius = CornerRadius(eyeH / 2f, eyeH / 2f)
      )
      drawRoundRect(
        color = accentColor,
        topLeft = Offset(rightEyeX - eyeW / 2f, eyeY - eyeH / 2f),
        size = Size(eyeW, eyeH),
        cornerRadius = CornerRadius(eyeH / 2f, eyeH / 2f)
      )
      drawCircle(
        color = Color.White.copy(alpha = 0.85f),
        radius = eyeH * 0.22f,
        center = Offset(leftEyeX - eyeW * 0.14f, eyeY - eyeH * 0.12f)
      )
      drawCircle(
        color = Color.White.copy(alpha = 0.85f),
        radius = eyeH * 0.22f,
        center = Offset(rightEyeX - eyeW * 0.14f, eyeY - eyeH * 0.12f)
      )
    }

    // Subtle Smile / Audio Waveform inside lower visor
    val mouthY = headTop + visorPadY + visorH * 0.78f
    if (mood == RobotMood.SPEAKING || mood == RobotMood.LISTENING || mood == RobotMood.THINKING || isPlanning || isExecuting) {
      val wavePath = Path()
      val mouthHalf = visorW * 0.26f
      val steps = 14
      for (i in 0..steps) {
        val t = i / steps.toFloat()
        val x = cx - mouthHalf + (mouthHalf * 2f * t)
        val amp = if (mood == RobotMood.SPEAKING || isExecuting) 3.4.dp.toPx() else 2.dp.toPx()
        val y = mouthY + sin(wavePhase + t * 8.5f) * amp
        if (i == 0) wavePath.moveTo(x, y) else wavePath.lineTo(x, y)
      }
      drawPath(
        path = wavePath,
        color = accentColor,
        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
      )
    } else {
      val smilePath = Path().apply {
        moveTo(cx - visorW * 0.13f, mouthY - 1.dp.toPx())
        quadraticTo(cx, mouthY + 2.8.dp.toPx(), cx + visorW * 0.13f, mouthY - 1.dp.toPx())
      }
      drawPath(
        path = smilePath,
        color = accentColor.copy(alpha = 0.85f),
        style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round)
      )
    }
  }
}
