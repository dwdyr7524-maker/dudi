package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import com.example.ui.navigation.NexusDestination

/**
 * Distinct, cohesive color identity for each NEXUS module family:
 * - Device Control: Electric Blue (#2563EB)
 * - AI Assistant: Violet (#8B5CF6)
 * - Security: Emerald (#10B981)
 * - Storage: Cyan (#06B6D4)
 * - Automation: Amber (#F59E0B)
 * - Applications: Deep Blue (#1E40AF / #3B82F6 in dark mode for crisp legibility)
 * - Diagnostics: Rose (#F43F5E)
 */
data class NexusModuleVisualStyle(
  val primary: Color,
  val secondary: Color,
  val familyLabelHe: String
)

fun NexusDestination.moduleStyle(isDark: Boolean): NexusModuleVisualStyle =
  when (this) {
    NexusDestination.DASHBOARD ->
      NexusModuleVisualStyle(
        primary = if (isDark) NexusCyanBright else NexusElectricBlue,
        secondary = NexusViolet,
        familyLabelHe = "COMMAND CENTER"
      )
    NexusDestination.SYSTEM_CONTROL,
    NexusDestination.BATTERY ->
      NexusModuleVisualStyle(
        primary = if (isDark) NexusDeepBlueGlow else NexusElectricBlue,
        secondary = NexusNeonCyan,
        familyLabelHe = "בקרת מכשיר"
      )
    NexusDestination.ASSISTANT,
    NexusDestination.PERSONAL_LIFE,
    NexusDestination.ACCOUNTS_HUB ->
      NexusModuleVisualStyle(
        primary = if (isDark) NexusVioletBright else NexusViolet,
        secondary = NexusNeonCyan,
        familyLabelHe = "עוזר AI"
      )
    NexusDestination.SECURITY,
    NexusDestination.APPROVAL_CENTER ->
      NexusModuleVisualStyle(
        primary = if (isDark) NexusEmeraldBright else NexusEmerald,
        secondary = NexusNeonCyan,
        familyLabelHe = "אבטחה ואישורים"
      )
    NexusDestination.SMART_STORAGE,
    NexusDestination.DOWNLOADS_MANAGER,
    NexusDestination.AI_FILE_MANAGER,
    NexusDestination.DEEP_CLEAN ->
      NexusModuleVisualStyle(
        primary = if (isDark) NexusCyanBright else NexusNeonCyan,
        secondary = NexusElectricBlue,
        familyLabelHe = "אחסון וקבצים"
      )
    NexusDestination.AUTOMATION ->
      NexusModuleVisualStyle(
        primary = if (isDark) NexusAmberBright else NexusAmber,
        secondary = NexusRose,
        familyLabelHe = "אוטומציה"
      )
    NexusDestination.APPS ->
      NexusModuleVisualStyle(
        primary = if (isDark) Color(0xFF60A5FA) else Color(0xFF1E40AF),
        secondary = NexusElectricBlue,
        familyLabelHe = "אפליקציות"
      )
    NexusDestination.DEVICE_DOCTOR,
    NexusDestination.SELF_DIAGNOSTICS,
    NexusDestination.REPORTS ->
      NexusModuleVisualStyle(
        primary = if (isDark) NexusRoseBright else NexusRose,
        secondary = NexusAmber,
        familyLabelHe = "אבחון ודוחות"
      )
  }
