package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ai.AiSystemDiagnosticsReport
import com.example.data.ai.CloudHealthCheckState
import com.example.data.ai.ModelDiagnosticStatus
import com.example.data.model.ApkInspectionReport
import com.example.data.model.HealthSeverity
import com.example.data.model.SecurityAuditReport
import com.example.data.system.formatBytes
import com.example.ui.components.NexusConfirmationDialog
import com.example.ui.components.NexusDataWell
import com.example.ui.components.NexusEditorialSection
import com.example.ui.components.NexusHairlineDivider
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusShimmerBox
import com.example.ui.components.NexusToggleSwitch
import com.example.ui.components.nexusInteractive
import com.example.ui.components.nexusStaggeredEntrance
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusDataWellDark
import com.example.ui.theme.NexusDeepBlueGlow
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTurquoise
import com.example.ui.theme.NexusTurquoiseBright

@Composable
fun SecurityScreen(
  report: SecurityAuditReport?,
  cloudAiEnabled: Boolean,
  shareTelemetryWithAi: Boolean,
  cloudHealthCheckState: CloudHealthCheckState,
  onToggleCloudAi: () -> Unit,
  onToggleShareTelemetryWithAi: () -> Unit,
  onRunCloudHealthCheck: () -> Unit,
  onDeleteAllUserData: () -> Unit,
  onRefreshAudit: () -> Unit,
  onOpenPrivacySettings: () -> Unit,
  onOpenAppPermissions: (String, String) -> Unit,
  onBack: () -> Unit,
  apkInspectionReport: ApkInspectionReport? = null,
  isInspectingApk: Boolean = false,
  aiDiagnosticsReport: AiSystemDiagnosticsReport? = null,
  onInspectApkUri: (Uri) -> Unit = {},
  onRunComprehensiveAiDiagnostics: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  var showDeleteDataDialog by remember { mutableStateOf(false) }

  val apkPickerLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) {
        onInspectApkUri(uri)
      }
    }

  if (showDeleteDataDialog) {
    NexusConfirmationDialog(
      title = "מחיקת כל הנתונים האישיים",
      message =
        "פעולה זו תמחק לצמיתות את היסטוריית הצ'אט, האוטומציות שיצרת, יומני הניקוי והגדרות המשתמש מתוך NEXUS. האם להמשיך?",
      confirmText = "מחק הכל",
      isDestructive = true,
      onConfirm = {
        showDeleteDataDialog = false
        onDeleteAllUserData()
      },
      onDismiss = { showDeleteDataDialog = false }
    )
  }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isWide = maxWidth >= 740.dp

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // 1. Cyber Defense Graphite Console Header + Honest Android 10 Scope Notice
      item {
        NexusHudCard(
          accentColor = NexusElectricBlue,
          modifier = Modifier.nexusStaggeredEntrance(0, "sec_hero")
        ) {
          NexusEditorialSection(
            title = "קונסולת אבטחה, פרטיות ו-APK",
            subtitle = "ביקורת הרשאות אמיתית, אימות חתימת SHA-256 ל-APK, ומדיניות אפס-סיסמאות — ללא סריקה מדומה.",
            accentColor = NexusElectricBlue,
            trailing = {
              Icon(Icons.Rounded.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
          ) {
            NexusDataWell(accentColor = MaterialTheme.colorScheme.outline) {
              Text(
                text = "מגבלות אבטחה ב-Android 10 (ללא Root): NEXUS פועל בגישת SAF סלקטיבית לתיקיות שבחרת, חוסם שמירת סיסמאות/טוקנים בזיכרון ובגיבויים, ומציג ממצאי הרשאות אמיתיים.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
              Button(
                onClick = onOpenPrivacySettings,
                colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
                modifier = Modifier.weight(1f).height(48.dp).nexusInteractive().testTag("security_open_privacy"),
                shape = RoundedCornerShape(10.dp)
              ) {
                Text("נהל הרשאות במערכת")
              }
              OutlinedButton(
                onClick = onRefreshAudit,
                modifier = Modifier.weight(1f).height(48.dp).nexusInteractive().testTag("security_refresh_audit"),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
                shape = RoundedCornerShape(10.dp)
              ) {
                Text("בצע ביקורת חוזרת", color = MaterialTheme.colorScheme.primary)
              }
            }
          }
        }
      }

      // 2. APK Inspector with Monospace SHA-256 Recessed Terminal Output
      item {
        NexusHudCard(
          accentColor = NexusAmber,
          modifier = Modifier.nexusStaggeredEntrance(1, "sec_apk")
        ) {
          NexusEditorialSection(
            title = "בודק חבילות התקנה (APK Inspector)",
            subtitle = "חישוב טביעת אצבע SHA-256 ובדיקת הרשאות מסוכנות לפני התקנה.",
            accentColor = NexusAmber,
            trailing = {
              OutlinedButton(
                onClick = { apkPickerLauncher.launch(arrayOf("application/vnd.android.package-archive", "*/*")) },
                enabled = !isInspectingApk,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.65f)),
                modifier = Modifier.height(48.dp).nexusInteractive().testTag("inspect_apk_button")
              ) {
                if (isInspectingApk) {
                  CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = NexusAmber)
                } else {
                  Icon(Icons.Rounded.Android, contentDescription = null, tint = NexusAmber, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("בחר APK", color = NexusAmber)
                }
              }
            }
          ) {
            AnimatedVisibility(visible = apkInspectionReport != null, enter = fadeIn() + expandVertically()) {
              apkInspectionReport?.let { apk ->
                val hasRisks = apk.highRiskPermissions.isNotEmpty()
                val statusAccent = if (hasRisks) NexusAmber else NexusTurquoiseBright
                NexusDataWell(accentColor = statusAccent) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = apk.fileName,
                      style = MaterialTheme.typography.titleSmall,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                      text = formatBytes(apk.sizeBytes),
                      style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                      color = MaterialTheme.colorScheme.primary
                    )
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "PKG: ${apk.packageName ?: "לא מזוהה"} | VER: ${apk.versionName ?: "—"}",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                  Spacer(modifier = Modifier.height(8.dp))
                  Box(
                    modifier =
                      Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(NexusDataWellDark)
                        .border(1.dp, statusAccent.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                  ) {
                    Text(
                      text = "SHA-256: ${apk.sha256}",
                      style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                      color = statusAccent
                    )
                  }
                  if (hasRisks) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                      text = "הרשאות רגישות: ${apk.highRiskPermissions.joinToString(", ")}",
                      style = MaterialTheme.typography.bodySmall,
                      color = NexusAmber
                    )
                  }
                  apk.warningNotesHe.forEach { w ->
                    Text("• $w", style = MaterialTheme.typography.bodySmall, color = NexusTextSecondary)
                  }
                }
              }
            }
          }
        }
      }

      // 3. Cloud Privacy Switches & Model Deep Audit
      item {
        NexusHudCard(
          accentColor = NexusTurquoise,
          modifier = Modifier.nexusStaggeredEntrance(2, "sec_ai")
        ) {
          NexusEditorialSection(
            title = "בקרת פרטיות, מודלי AI ואבחון עומק",
            accentColor = MaterialTheme.colorScheme.primary
          ) {
            Row(
              modifier =
                Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .clickable(onClick = onToggleCloudAi)
                  .padding(vertical = 10.dp, horizontal = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                Text("שירותי בינה מלאכותית בענן (Firebase AI)", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                Text(
                  "מאפשר עיבוד שפה טבעית, תמלול ושיחה קולית חיה. כיבוי יפעיל מנוע מקומי בלבד.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              NexusToggleSwitch(
                checked = cloudAiEnabled,
                onCheckedChange = { onToggleCloudAi() },
                accentColor = NexusElectricBlue
              )
            }

            NexusHairlineDivider()

            Row(
              modifier =
                Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .clickable(onClick = onToggleShareTelemetryWithAi)
                  .padding(vertical = 10.dp, horizontal = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                Text("שיתוף מדדי מכשיר בהקשר העוזר", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                Text(
                  "מצרף אחוז סוללה, אחסון ו-RAM לתשובות מדויקות; ללא שיתוף מידע אישי.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              NexusToggleSwitch(
                checked = shareTelemetryWithAi,
                onCheckedChange = { onToggleShareTelemetryWithAi() },
                accentColor = MaterialTheme.colorScheme.primary
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
              OutlinedButton(
                onClick = onRunCloudHealthCheck,
                enabled = cloudHealthCheckState !is CloudHealthCheckState.Checking,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).height(48.dp).nexusInteractive().testTag("security_cloud_health_check")
              ) {
                if (cloudHealthCheckState is CloudHealthCheckState.Checking) {
                  CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.primary)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("בודק...", color = MaterialTheme.colorScheme.primary)
                } else {
                  Icon(Icons.Rounded.CloudDone, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("בדיקת תקינות ענן", color = MaterialTheme.colorScheme.primary)
                }
              }

              Button(
                onClick = onRunComprehensiveAiDiagnostics,
                enabled = aiDiagnosticsReport?.isChecking != true,
                colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).height(48.dp).nexusInteractive().testTag("security_deep_ai_audit_button")
              ) {
                if (aiDiagnosticsReport?.isChecking == true) {
                  CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("מאבחן...", color = Color.White)
                } else {
                  Icon(Icons.Rounded.Psychology, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("בדיקת עומק למודלים", color = Color.White)
                }
              }
            }

            when (cloudHealthCheckState) {
              CloudHealthCheckState.Idle,
              CloudHealthCheckState.Checking -> Unit
              is CloudHealthCheckState.Healthy -> {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                  modifier =
                    Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(8.dp))
                      .background(NexusEmerald.copy(alpha = 0.11f))
                      .border(1.dp, NexusEmerald.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                      .padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = NexusEmerald)
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "חיבור תקין (${cloudHealthCheckState.modelChecked} • ${cloudHealthCheckState.latencyMs}ms)",
                      style = MaterialTheme.typography.titleSmall,
                      color = NexusEmerald
                    )
                    Text(cloudHealthCheckState.summaryHe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                  }
                }
              }
              is CloudHealthCheckState.Unhealthy -> {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                  modifier =
                    Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(8.dp))
                      .background(NexusCrimson.copy(alpha = 0.11f))
                      .border(1.dp, NexusCrimson.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                      .padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Rounded.ErrorOutline, contentDescription = null, tint = NexusCrimson)
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "בדיקת ענן נכשלה (${cloudHealthCheckState.latencyMs}ms)",
                      style = MaterialTheme.typography.titleSmall,
                      color = NexusCrimson
                    )
                    Text(cloudHealthCheckState.error.messageHe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                  }
                }
              }
            }

            if (aiDiagnosticsReport != null && !aiDiagnosticsReport.isChecking) {
              Spacer(modifier = Modifier.height(10.dp))
              NexusDataWell(accentColor = MaterialTheme.colorScheme.primary) {
                Text("דוח אבחון מודלים, API ואבטחת AI", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(4.dp))
                Text("• ${aiDiagnosticsReport.appCheckStatusHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                Text("• ${aiDiagnosticsReport.keySecuritySummaryHe}", style = MaterialTheme.typography.bodySmall, color = NexusEmerald)
                Text("• ${aiDiagnosticsReport.privacyGuardSummaryHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("• ${aiDiagnosticsReport.injectionProtectionSummaryHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("• ${aiDiagnosticsReport.fallbackPolicySummaryHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("• ${aiDiagnosticsReport.rateLimiterUsageSummaryHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                Spacer(modifier = Modifier.height(6.dp))
                aiDiagnosticsReport.models.forEach { m ->
                  val color =
                    when (m.status) {
                      ModelDiagnosticStatus.ACTIVE_HEALTHY -> NexusEmerald
                      ModelDiagnosticStatus.CONFIGURED_READY -> NexusTurquoiseBright
                      ModelDiagnosticStatus.FALLBACK_ONLY -> NexusDeepBlueGlow
                      ModelDiagnosticStatus.BLOCKED_PAID_TIER -> NexusAmber
                      ModelDiagnosticStatus.UNAVAILABLE -> NexusCrimson
                    }
                  NexusHairlineDivider()
                  Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text("${m.modelName} — ${m.status.titleHe}", style = MaterialTheme.typography.labelLarge, color = color)
                      Text("${m.roleHe}: ${m.detailHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (m.isPaidModel) {
                      Icon(Icons.Rounded.Block, contentDescription = "חסום", tint = NexusAmber, modifier = Modifier.size(18.dp))
                    } else if (m.latencyMs != null) {
                      Text(
                        "${m.latencyMs}ms",
                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = color
                      )
                    }
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
              onClick = { showDeleteDataDialog = true },
              border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.65f)),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth().height(48.dp).nexusInteractive().testTag("security_delete_all_data")
            ) {
              Icon(Icons.Rounded.DeleteForever, contentDescription = null, tint = NexusCrimson)
              Spacer(modifier = Modifier.width(6.dp))
              Text("מחק את כל הנתונים האישיים של NEXUS", color = NexusCrimson)
            }
          }
        }
      }

      if (report == null) {
        items(4) { NexusShimmerBox(height = 68.dp) }
      } else {
        // 4. Permission Telemetry Strip inside Graphite Surface
        item {
          NexusHudCard(
            accentColor = NexusTurquoise,
            contentPadding = 12.dp,
            modifier = Modifier.nexusStaggeredEntrance(3, "sec_stats")
          ) {
            if (isWide) {
              Row(
                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min).padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                PermStatColumn("מצלמה", report.cameraAppsCount, Icons.Rounded.CameraAlt, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                VerticalDivider(thickness = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.65f))
                PermStatColumn("מיקרופון", report.micAppsCount, Icons.Rounded.Mic, NexusDeepBlueGlow, Modifier.weight(1f))
                VerticalDivider(thickness = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.65f))
                PermStatColumn("מיקום", report.locationAppsCount, Icons.Rounded.LocationOn, NexusAmber, Modifier.weight(1f))
                VerticalDivider(thickness = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.65f))
                PermStatColumn("מיוחדות", report.specialPermissionAppsCount, Icons.Rounded.Shield, NexusCrimson, Modifier.weight(1f))
              }
            } else {
              Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                  PermStatColumn("מצלמה", report.cameraAppsCount, Icons.Rounded.CameraAlt, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                  VerticalDivider(thickness = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.65f))
                  PermStatColumn("מיקרופון", report.micAppsCount, Icons.Rounded.Mic, NexusDeepBlueGlow, Modifier.weight(1f))
                }
                NexusHairlineDivider(modifier = Modifier.padding(vertical = 8.dp))
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                  PermStatColumn("מיקום", report.locationAppsCount, Icons.Rounded.LocationOn, NexusAmber, Modifier.weight(1f))
                  VerticalDivider(thickness = 1.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.65f))
                  PermStatColumn("מיוחדות", report.specialPermissionAppsCount, Icons.Rounded.Shield, NexusCrimson, Modifier.weight(1f))
                }
              }
            }
          }
        }

        // 5. Findings Deck
        item {
          NexusEditorialSection(
            title = "ממצאים והתראות אבטחה (${report.findings.size})",
            accentColor = if (report.findings.any { it.severity == HealthSeverity.CRITICAL }) NexusCrimson else NexusAmber
          ) {}
        }

        items(report.findings, key = { it.id }) { finding ->
          val color =
            when (finding.severity) {
              HealthSeverity.CRITICAL -> NexusCrimson
              HealthSeverity.WARNING -> NexusAmber
              HealthSeverity.NOTICE -> NexusDeepBlueGlow
              HealthSeverity.OPTIMAL -> NexusTurquoiseBright
            }
          NexusHudCard(accentColor = color, contentPadding = 12.dp) {
            Row(
              modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(modifier = Modifier.width(3.dp).fillMaxHeight().background(color, RoundedCornerShape(2.dp)))
              Spacer(modifier = Modifier.width(10.dp))
              Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(finding.title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                Text(finding.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              if (finding.packageName != null) {
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedButton(
                  onClick = { onOpenAppPermissions(finding.packageName, finding.appName ?: finding.packageName) },
                  shape = RoundedCornerShape(8.dp),
                  border = BorderStroke(1.dp, color.copy(alpha = 0.55f)),
                  modifier = Modifier.height(48.dp)
                ) {
                  Text("ניהול", color = color)
                }
              }
            }
          }
        }

        // 6. Sensitive Apps Audit Table
        item {
          NexusEditorialSection(
            title = "אפליקציות עם הרשאות רגישות (${report.sensitiveApps.size})",
            accentColor = MaterialTheme.colorScheme.primary
          ) {}
        }

        items(report.sensitiveApps.take(25), key = { it.packageName }) { app ->
          val tags =
            buildList {
              if (app.hasCameraPermission) add("מצלמה")
              if (app.hasMicPermission) add("מיקרופון")
              if (app.hasLocationPermission) add("מיקום")
              if (app.hasBackgroundLocation) add("מיקום ברקע")
              if (app.canDrawOverlays) add("שכבת על")
              if (app.canRequestInstalls) add("התקנת חבילות")
            }
          NexusHudCard(accentColor = MaterialTheme.colorScheme.outline, contentPadding = 12.dp) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                Text(app.appName, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                Text(tags.joinToString(" • "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              OutlinedButton(
                onClick = { onOpenAppPermissions(app.packageName, app.appName) },
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                modifier = Modifier.height(48.dp)
              ) {
                Text("הרשאות", color = MaterialTheme.colorScheme.primary)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PermStatColumn(
  label: String,
  count: Int,
  icon: ImageVector,
  accent: Color,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier.padding(horizontal = 12.dp, vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.Center
  ) {
    Icon(icon, contentDescription = label, tint = accent, modifier = Modifier.size(20.dp))
    Spacer(modifier = Modifier.width(8.dp))
    Column {
      Text(
        text = "$count",
        style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}
