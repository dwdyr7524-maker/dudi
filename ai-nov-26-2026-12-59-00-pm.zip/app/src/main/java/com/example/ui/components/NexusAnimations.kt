package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalIsDarkTheme
import com.example.ui.theme.LocalMotionConfig
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.theme.NexusRose
import com.example.ui.theme.NexusViolet
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay

fun Modifier.nexusPressable(scaleDown: Float = 0.972f): Modifier = nexusInteractive(scaleDown = scaleDown)

fun Modifier.nexusInteractive(
  scaleDown: Float = 0.972f,
  hoverScale: Float = 1.008f
): Modifier = composed {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val isHovered by interactionSource.collectIsHoveredAsState()
  val motion = LocalMotionConfig.current

  val targetScale =
    when {
      !motion.allowMicroMotion -> 1f
      isPressed -> scaleDown
      isHovered -> hoverScale
      else -> 1f
    }

  val scale by
    animateFloatAsState(
      targetValue = targetScale,
      animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
      label = "interactive_scale"
    )

  this
    .hoverable(interactionSource = interactionSource)
    .graphicsLayer {
      scaleX = scale
      scaleY = scale
    }
}

fun Modifier.nexusStaggeredEntrance(
  index: Int,
  key: Any = Unit
): Modifier = composed {
  val motion = LocalMotionConfig.current
  var hasAnimated by rememberSaveable(key) { mutableStateOf(false) }
  val progress = remember { Animatable(if (!motion.allowMicroMotion || hasAnimated) 1f else 0f) }

  LaunchedEffect(key, motion.allowMicroMotion) {
    if (!motion.allowMicroMotion || hasAnimated) {
      progress.snapTo(1f)
      hasAnimated = true
      return@LaunchedEffect
    }
    val delayMs = (index.coerceIn(0, 6) * 32L)
    if (delayMs > 0L) delay(delayMs)
    progress.animateTo(
      targetValue = 1f,
      animationSpec = tween(durationMillis = motion.duration(240, 100), easing = FastOutSlowInEasing)
    )
    hasAnimated = true
  }

  val v = progress.value
  this.graphicsLayer {
    alpha = v
    translationY = (1f - v) * 14.dp.toPx()
  }
}

/**
 * Sleek spectral voice/AI waveform bar (inspired by Aiko vocal spectrum).
 * Gently pulses at rest when ambient motion is allowed, and reacts with lively harmonic amplitudes when active.
 */
@Composable
fun NexusVoiceWaveformBar(
  isActive: Boolean,
  modifier: Modifier = Modifier,
  accentColor: Color = NexusNeonCyan,
  secondaryColor: Color = NexusElectricBlue,
  barCount: Int = 27,
  height: Dp = 26.dp
) {
  val motion = LocalMotionConfig.current
  val shouldAnimate =
    (isActive && motion.allowMicroMotion) || motion.allowAmbientMotion

  val phase =
    if (shouldAnimate) {
      val inf = rememberInfiniteTransition(label = "aiko_spectrum")
      val p by
        inf.animateFloat(
          initialValue = 0f,
          targetValue = (2.0 * PI).toFloat(),
          animationSpec =
            infiniteRepeatable(
              animation = tween(if (isActive) 850 else 2200, easing = LinearEasing),
              repeatMode = RepeatMode.Restart
            ),
          label = "spectrum_phase"
        )
      p
    } else {
      0.8f
    }

  val energy by
    animateFloatAsState(
      targetValue = if (isActive) 1f else 0.34f,
      animationSpec = tween(motion.duration(240, 90)),
      label = "waveform_energy"
    )

  Canvas(modifier = modifier.height(height)) {
    val w = size.width
    val h = size.height
    val centerY = h / 2f
    val count = barCount.coerceAtLeast(7)
    val slot = w / count
    val barW = (slot * 0.44f).coerceIn(2.dp.toPx(), 4.dp.toPx())
    val mid = (count - 1) / 2f

    for (i in 0 until count) {
      val distNorm = 1f - (abs(i - mid) / (mid + 0.5f)).coerceIn(0f, 1f)
      val envelope = 0.22f + 0.78f * (distNorm * distNorm * 0.65f + distNorm * 0.35f)
      val wave = 0.5f + 0.5f * sin(phase + i * 0.68f)
      val amp = ((0.20f + wave * 0.80f * energy) * envelope).coerceIn(0.14f, 1f)
      val barH = (h * amp).coerceAtLeast(3.dp.toPx())
      val x = i * slot + (slot - barW) / 2f
      val mix = i / (count - 1f)
      val barColor =
        if (mix < 0.5f) secondaryColor.copy(alpha = 0.72f + 0.28f * distNorm)
        else accentColor.copy(alpha = 0.72f + 0.28f * distNorm)

      drawRoundRect(
        color = barColor,
        topLeft = Offset(x, centerY - barH / 2f),
        size = Size(barW, barH),
        cornerRadius = CornerRadius(barW / 2f, barW / 2f)
      )
    }
  }
}

@Composable
fun Nexus3DGyroLoader(
  modifier: Modifier = Modifier,
  size: Dp = 84.dp,
  active: Boolean = true,
  accentColor: Color = NexusNeonCyan
) {
  val motion = LocalMotionConfig.current
  val shouldSpin = active && motion.allowAmbientMotion

  val (rotY, rotX) =
    if (shouldSpin) {
      val inf = rememberInfiniteTransition(label = "gyro_3d")
      val ry by
        inf.animateFloat(
          initialValue = 0f,
          targetValue = 360f,
          animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
          label = "gyro_rotY"
        )
      val rx by
        inf.animateFloat(
          initialValue = 0f,
          targetValue = 360f,
          animationSpec = infiniteRepeatable(tween(3400, easing = LinearEasing)),
          label = "gyro_rotX"
        )
      ry to rx
    } else {
      32f to 18f
    }

  Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
    Canvas(
      modifier =
        Modifier.fillMaxSize().graphicsLayer {
          rotationY = rotY
          rotationX = rotX * 0.45f
          cameraDistance = 14f * density
        }
    ) {
      drawArc(
        brush = Brush.sweepGradient(listOf(Color.Transparent, accentColor, NexusElectricBlue, NexusViolet)),
        startAngle = 0f,
        sweepAngle = 250f,
        useCenter = false,
        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
      )
    }
    Canvas(
      modifier =
        Modifier.size(size * 0.72f).graphicsLayer {
          rotationY = -rotY * 1.2f
          rotationX = -rotX * 0.6f
          cameraDistance = 12f * density
        }
    ) {
      drawArc(
        brush = Brush.sweepGradient(listOf(Color.Transparent, NexusViolet, accentColor)),
        startAngle = 90f,
        sweepAngle = 210f,
        useCenter = false,
        style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
      )
    }
  }
}

@Composable
fun NexusScanBeamOverlay(
  isScanning: Boolean,
  modifier: Modifier = Modifier,
  beamColor: Color = NexusNeonCyan
) {
  val motion = LocalMotionConfig.current
  if (!isScanning || !motion.allowMicroMotion) return

  val inf = rememberInfiniteTransition(label = "scan_beam")
  val progress by
    inf.animateFloat(
      initialValue = 0f,
      targetValue = 1f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(if (motion.performanceMode) 1700 else 1200, easing = FastOutSlowInEasing),
          repeatMode = RepeatMode.Reverse
        ),
      label = "beam_y"
    )

  Canvas(modifier = modifier.fillMaxSize()) {
    val y = size.height * progress
    val bandHeight = 34.dp.toPx()
    drawRect(
      brush =
        Brush.verticalGradient(
          colors = listOf(Color.Transparent, beamColor.copy(alpha = 0.14f), Color.Transparent),
          startY = y - bandHeight,
          endY = y + bandHeight
        ),
      topLeft = Offset(0f, (y - bandHeight).coerceAtLeast(0f)),
      size = Size(size.width, bandHeight * 2f)
    )
    drawLine(
      brush =
        Brush.horizontalGradient(
          listOf(Color.Transparent, beamColor.copy(alpha = 0.85f), Color.Transparent)
        ),
      start = Offset(0f, y),
      end = Offset(size.width, y),
      strokeWidth = 1.6.dp.toPx()
    )
  }
}

@Composable
fun NexusDeviceScanVisualizer(
  isScanning: Boolean,
  statusLabel: String,
  accentColor: Color = NexusNeonCyan,
  modifier: Modifier = Modifier
) {
  if (!isScanning) return
  val motion = LocalMotionConfig.current
  val isDark = LocalIsDarkTheme.current

  val sweepAngle =
    if (motion.allowMicroMotion) {
      val inf = rememberInfiniteTransition(label = "radar_scan")
      val a by
        inf.animateFloat(
          initialValue = 0f,
          targetValue = 360f,
          animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
          label = "radar_angle"
        )
      a
    } else {
      45f
    }

  Surface(
    modifier = modifier.fillMaxWidth(),
    color = accentColor.copy(alpha = if (isDark) 0.12f else 0.08f),
    shape = RoundedCornerShape(10.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Canvas(modifier = Modifier.size(28.dp)) {
        drawCircle(
          color = accentColor.copy(alpha = 0.25f),
          style = Stroke(width = 2.dp.toPx())
        )
        drawArc(
          brush = Brush.sweepGradient(listOf(Color.Transparent, accentColor)),
          startAngle = sweepAngle,
          sweepAngle = 140f,
          useCenter = false,
          style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round)
        )
        drawCircle(color = accentColor, radius = 3.dp.toPx())
      }
      Text(
        text = statusLabel,
        style = MaterialTheme.typography.titleSmall,
        color = accentColor,
        modifier = Modifier.weight(1f)
      )
    }
  }
}

@Composable
fun NexusWaveProgressBar(
  progress: Float? = null,
  accentColor: Color = NexusNeonCyan,
  modifier: Modifier = Modifier,
  height: Dp = 6.dp
) {
  val motion = LocalMotionConfig.current
  val animatedProgress by
    animateFloatAsState(
      targetValue = (progress ?: 1f).coerceIn(0f, 1f),
      animationSpec = tween(motion.duration(400, 120), easing = FastOutSlowInEasing),
      label = "wave_progress"
    )

  val sweepPhase =
    if (motion.allowAmbientMotion) {
      val inf = rememberInfiniteTransition(label = "wave_sweep")
      val p by
        inf.animateFloat(
          initialValue = -0.35f,
          targetValue = 1.35f,
          animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
          label = "sweep_x"
        )
      p
    } else {
      0.5f
    }

  val trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
  Canvas(
    modifier =
      modifier
        .fillMaxWidth()
        .height(height)
        .clip(RoundedCornerShape(height))
  ) {
    drawRoundRect(
      color = trackColor,
      cornerRadius = CornerRadius(size.height / 2f, size.height / 2f)
    )
    if (progress == null) {
      val bandW = size.width * 0.38f
      val startX = (sweepPhase * size.width) - bandW / 2f
      drawRoundRect(
        brush =
          Brush.horizontalGradient(
            colors = listOf(Color.Transparent, accentColor, Color.Transparent),
            startX = startX,
            endX = startX + bandW
          ),
        topLeft = Offset(startX.coerceIn(0f, size.width), 0f),
        size = Size(bandW.coerceAtMost((size.width - startX).coerceAtLeast(0f)), size.height),
        cornerRadius = CornerRadius(size.height / 2f, size.height / 2f)
      )
    } else {
      val fillW = size.width * animatedProgress
      if (fillW > 0f) {
        drawRoundRect(
          color = accentColor,
          size = Size(fillW, size.height),
          cornerRadius = CornerRadius(size.height / 2f, size.height / 2f)
        )
      }
    }
  }
}

@Composable
fun NexusCleaningEnergyOverlay(
  isCleaning: Boolean,
  modifier: Modifier = Modifier
) {
  val motion = LocalMotionConfig.current
  if (!isCleaning || !motion.allowMicroMotion) return

  val inf = rememberInfiniteTransition(label = "clean_energy")
  val phase by
    inf.animateFloat(
      initialValue = 0f,
      targetValue = 1f,
      animationSpec = infiniteRepeatable(tween(if (motion.performanceMode) 1700 else 1100, easing = LinearEasing)),
      label = "energy_phase"
    )

  Canvas(modifier = modifier.fillMaxSize()) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val maxR = size.minDimension * 0.45f
    val particleCount = if (motion.performanceMode) 8 else 14

    drawCircle(
      color = NexusEmerald.copy(alpha = (1f - phase) * 0.50f),
      radius = maxR * phase,
      center = Offset(cx, cy),
      style = Stroke(width = 2.5.dp.toPx())
    )
    for (i in 0 until particleCount) {
      val angle = (i * (360f / particleCount) + phase * 180f) * (PI.toFloat() / 180f)
      val r = maxR * ((i % 4) / 4f + 0.25f) * (1f - phase * 0.4f)
      val x = cx + cos(angle) * r
      val y = cy + sin(angle) * r - phase * 20f
      drawCircle(
        color = if (i % 2 == 0) NexusNeonCyan else NexusEmerald,
        radius = if (i % 3 == 0) 3.2.dp.toPx() else 2.dp.toPx(),
        center = Offset(x, y)
      )
    }
  }
}

@Composable
fun NexusSuccessShockwave(
  visible: Boolean,
  modifier: Modifier = Modifier,
  size: Dp = 72.dp
) {
  if (!visible) return
  val motion = LocalMotionConfig.current
  val anim = remember { Animatable(if (motion.allowMicroMotion) 0f else 1f) }
  LaunchedEffect(visible, motion.allowMicroMotion) {
    if (!motion.allowMicroMotion) {
      anim.snapTo(1f)
      return@LaunchedEffect
    }
    anim.snapTo(0f)
    anim.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
  }
  val v = anim.value
  Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      drawCircle(
        color = NexusEmerald.copy(alpha = (1f - v) * 0.6f),
        radius = (this.size.minDimension / 2f) * (0.45f + 0.55f * v),
        style = Stroke(width = 2.5.dp.toPx())
      )
    }
    Box(
      modifier =
        Modifier
          .size(size * 0.68f)
          .graphicsLayer {
            scaleX = 0.7f + 0.3f * v
            scaleY = 0.7f + 0.3f * v
          }
          .clip(CircleShape)
          .background(NexusEmerald),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Rounded.Check,
        contentDescription = "בוצע בהצלחה",
        tint = NexusObsidian,
        modifier = Modifier.size(size * 0.4f)
      )
    }
  }
}

@Composable
fun NexusErrorPulseBadge(
  visible: Boolean,
  modifier: Modifier = Modifier,
  size: Dp = 56.dp
) {
  if (!visible) return
  val motion = LocalMotionConfig.current
  val shakeOffset = remember { Animatable(0f) }
  LaunchedEffect(visible, motion.allowMicroMotion) {
    if (!motion.allowMicroMotion) return@LaunchedEffect
    listOf(-5f, 5f, -3f, 3f, 0f).forEach { target ->
      shakeOffset.animateTo(target, tween(50, easing = FastOutSlowInEasing))
    }
  }
  Box(
    modifier =
      modifier
        .size(size)
        .offset(x = shakeOffset.value.dp)
        .clip(CircleShape)
        .background(NexusRose.copy(alpha = 0.14f))
        .border(1.4.dp, NexusRose.copy(alpha = 0.75f), CircleShape),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = Icons.Rounded.ErrorOutline,
      contentDescription = "שגיאה",
      tint = NexusRose,
      modifier = Modifier.size(size * 0.52f)
    )
  }
}

@Composable
fun NexusShimmerBox(
  modifier: Modifier = Modifier,
  height: Dp = 64.dp
) {
  val motion = LocalMotionConfig.current
  val baseSurface = MaterialTheme.colorScheme.surfaceContainerHigh
  val highlight = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)

  val offset =
    if (motion.allowAmbientMotion) {
      val inf = rememberInfiniteTransition(label = "hud_shimmer")
      val v by
        inf.animateFloat(
          initialValue = -0.3f,
          targetValue = 1.3f,
          animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing)),
          label = "shimmer_x"
        )
      v
    } else {
      0.5f
    }

  Box(
    modifier =
      modifier
        .fillMaxWidth()
        .height(height)
        .clip(RoundedCornerShape(10.dp))
        .background(
          Brush.horizontalGradient(
            colors = listOf(baseSurface, highlight, baseSurface),
            startX = (offset - 0.3f) * 900f,
            endX = (offset + 0.3f) * 900f
          )
        )
        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
  )
}

@Composable
fun NexusToggleSwitch(
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  modifier: Modifier = Modifier,
  accentColor: Color = NexusNeonCyan
) {
  val motion = LocalMotionConfig.current
  val trackColor by
    animateColorAsState(
      targetValue = if (checked) accentColor.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surfaceContainerHigh,
      animationSpec = tween(motion.duration(180, 80)),
      label = "switch_track"
    )
  val borderColor by
    animateColorAsState(
      targetValue = if (checked) accentColor else MaterialTheme.colorScheme.outline,
      animationSpec = tween(motion.duration(180, 80)),
      label = "switch_border"
    )
  val thumbOffset by
    animateDpAsState(
      targetValue = if (checked) 22.dp else 2.dp,
      animationSpec = spring(stiffness = Spring.StiffnessMedium),
      label = "switch_thumb"
    )

  Box(
    modifier =
      modifier
        .width(52.dp)
        .height(30.dp)
        .clip(RoundedCornerShape(15.dp))
        .background(trackColor)
        .border(1.4.dp, borderColor, RoundedCornerShape(15.dp))
        .clickable { onCheckedChange(!checked) }
        .padding(2.dp),
    contentAlignment = Alignment.CenterStart
  ) {
    Box(
      modifier =
        Modifier
          .offset(x = thumbOffset)
          .size(22.dp)
          .clip(CircleShape)
          .background(if (checked) accentColor else MaterialTheme.colorScheme.outline)
    )
  }
}
