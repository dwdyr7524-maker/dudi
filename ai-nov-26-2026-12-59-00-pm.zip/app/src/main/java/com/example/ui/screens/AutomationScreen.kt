package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoMode
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ai.AikoBrainEngine
import com.example.data.local.AutomationEntity
import com.example.data.model.AutomationStepType
import com.example.ui.components.NexusConfirmationDialog
import com.example.ui.components.NexusDataWell
import com.example.ui.components.NexusEditorialSection
import com.example.ui.components.NexusHudCard
import com.example.ui.components.nexusInteractive
import com.example.ui.components.nexusStaggeredEntrance
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusDeepBlueGlow
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusTurquoise
import com.example.ui.theme.NexusTurquoiseBright
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val scheduleOptions =
  listOf(
    0 to "ידני",
    6 to "כל 6 ש׳",
    12 to "כל 12 ש׳",
    24 to "פעם ביום",
    168 to "שבועי"
  )

private fun scheduleLabelHe(hours: Int): String =
  when (hours) {
    0 -> "ידני"
    6 -> "כל 6 שעות"
    12 -> "כל 12 שעות"
    24 -> "פעם ביום"
    168 -> "פעם בשבוע"
    else -> "כל $hours שעות"
  }

@Composable
fun AutomationScreen(
  automations: List<AutomationEntity>,
  pendingConfirmation: AutomationEntity?,
  onRequestRun: (AutomationEntity) -> Unit,
  onConfirmRun: (AutomationEntity) -> Unit,
  onDismissConfirm: () -> Unit,
  onCreateAutomation: (String, String, List<AutomationStepType>, Int) -> Unit,
  onUpdateSchedule: (AutomationEntity, Int) -> Unit,
  onDeleteCustom: (Long) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  var showCreatorDialog by remember { mutableStateOf(false) }

  if (pendingConfirmation != null) {
    NexusConfirmationDialog(
      title = "אישור הפעלת אוטומציה",
      message =
        "האוטומציה \"${pendingConfirmation.name}\" כוללת פעולה רגישה או מעבר למסכי מערכת:\n${pendingConfirmation.description}",
      confirmText = "אשר והפעל",
      onConfirm = { onConfirmRun(pendingConfirmation) },
      onDismiss = onDismissConfirm
    )
  }

  if (showCreatorDialog) {
    CreateAutomationDialog(
      onSave = { name, phrase, steps, intervalHours ->
        onCreateAutomation(name, phrase, steps, intervalHours)
        showCreatorDialog = false
      },
      onDismiss = { showCreatorDialog = false }
    )
  }

  val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())

  var nlRuleInput by remember { mutableStateOf("") }
  val parsedNlProposal =
    remember(nlRuleInput) {
      if (nlRuleInput.trim().length >= 4) AikoBrainEngine.parseNaturalAutomationRule(nlRuleInput)
      else null
    }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Pipeline Studio Header & Natural-Language Composer (Graphite Card)
    item {
      NexusHudCard(
        accentColor = NexusElectricBlue,
        modifier = Modifier.nexusStaggeredEntrance(0, "auto_studio")
      ) {
        NexusEditorialSection(
          title = "מנוע אוטומציות ורצפים",
          subtitle = "הגדרת רצפי פעולות בשפה טבעית, הפעלה מיידית או תזמון מחזורי ב-WorkManager.",
          accentColor = NexusElectricBlue,
          trailing = {
            Button(
              onClick = { showCreatorDialog = true },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
              modifier = Modifier.height(48.dp).nexusInteractive().testTag("create_automation_button")
            ) {
              Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("פקודה חדשה")
            }
          }
        ) {
          Text("בניית רצף בשפה טבעית (אייקו)", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = nlRuleInput,
            onValueChange = { nlRuleInput = it },
            placeholder = { Text("לדוגמה: כל ערב בדוק אחסון, סוללה והפק דוח", color = MaterialTheme.colorScheme.onSurfaceVariant) },
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            colors =
              OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
              ),
            modifier = Modifier.fillMaxWidth().testTag("nl_automation_input")
          )

          AnimatedVisibility(
            visible = parsedNlProposal != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
          ) {
            parsedNlProposal?.let { proposal ->
              Spacer(modifier = Modifier.height(10.dp))
              NexusDataWell(
                accentColor = if (proposal.isFeasible) NexusTurquoiseBright else NexusAmber
              ) {
                Text(
                  text = "תצוגת צינור (Pipeline): ${proposal.name}",
                  style = MaterialTheme.typography.titleSmall,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = proposal.explanationHe,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (proposal.isFeasible) {
                  Spacer(modifier = Modifier.height(8.dp))
                  PipelineChainRow(
                    steps = proposal.steps,
                    accentColor = NexusTurquoiseBright
                  )
                  Spacer(modifier = Modifier.height(10.dp))
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = proposal.triggerNoteHe,
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.primary
                    )
                    Button(
                      onClick = {
                        onCreateAutomation(
                          proposal.name,
                          proposal.voicePhrase,
                          proposal.steps,
                          proposal.scheduleIntervalHours
                        )
                        nlRuleInput = ""
                      },
                      shape = RoundedCornerShape(8.dp),
                      colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
                      modifier = Modifier.height(48.dp).nexusInteractive().testTag("nl_automation_confirm_btn")
                    ) {
                      Text("אשר ושמור אוטומציה")
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    item {
      NexusEditorialSection(
        title = "רצפים מוגדרים (${automations.size})",
        subtitle = "לחץ להפעלה או הגדר תזמון רקע קבוע",
        accentColor = NexusTurquoiseBright
      ) {}
    }

    // 2. Graphite Automation Workflow Cards
    items(automations, key = { it.id }) { item ->
      val hasUiSteps = item.stepsSerialized.contains("OPEN_")
      val parsedSteps =
        remember(item.stepsSerialized) {
          item.stepsSerialized
            .split(",")
            .mapNotNull { token -> AutomationStepType.entries.firstOrNull { it.name == token.trim() } }
        }
      val accent = if (item.isBuiltIn) NexusDeepBlueGlow else NexusTurquoiseBright

      NexusHudCard(
        accentColor = accent,
        modifier = Modifier.fillMaxWidth().animateContentSize()
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Box(
                modifier =
                  Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accent.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Rounded.AutoMode, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(item.name, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                Text(
                  text = "פקודה קולית: \"${item.voicePhrase}\"",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.primary
                )
              }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              if (!item.isBuiltIn) {
                IconButton(
                  onClick = { onDeleteCustom(item.id) },
                  modifier = Modifier.size(48.dp)
                ) {
                  Icon(Icons.Rounded.DeleteOutline, contentDescription = "מחק אוטומציה", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
              Button(
                onClick = { onRequestRun(item) },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
                modifier = Modifier.height(48.dp).nexusInteractive().testTag("run_automation_${item.id}")
              ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("הפעל")
              }
            }
          }

          Text(
            text = item.description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          if (parsedSteps.isNotEmpty()) {
            NexusDataWell(contentPadding = 10.dp) {
              PipelineChainRow(steps = parsedSteps, accentColor = accent)
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                Icons.Rounded.Schedule,
                contentDescription = null,
                tint = if (item.scheduleIntervalHours > 0) NexusTurquoiseBright else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "תזמון רקע: ${scheduleLabelHe(item.scheduleIntervalHours)}",
                style = MaterialTheme.typography.labelMedium,
                color = if (item.scheduleIntervalHours > 0) NexusTurquoiseBright else MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            item.lastRunMillis?.let { last ->
              Text(
                text = "ריצה אחרונה: ${fmt.format(Date(last))}",
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            scheduleOptions.forEach { (hours, label) ->
              FilterChip(
                selected = item.scheduleIntervalHours == hours,
                onClick = { onUpdateSchedule(item, hours) },
                label = { Text(label) },
                shape = RoundedCornerShape(8.dp),
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NexusTurquoise.copy(alpha = 0.22f),
                    selectedLabelColor = MaterialTheme.colorScheme.primary
                  ),
                modifier = Modifier.testTag("automation_schedule_${item.id}_$hours")
              )
            }
          }

          if (item.scheduleIntervalHours > 0 && hasUiSteps) {
            Text(
              text = "הערה: בהרצה מתוזמנת ברקע שלבי פתיחת מסכי הגדרות ידולגו אוטומטית.",
              style = MaterialTheme.typography.labelSmall,
              color = NexusAmber
            )
          }
        }
      }
    }
  }
}

@Composable
private fun PipelineChainRow(
  steps: List<AutomationStepType>,
  accentColor: Color
) {
  Row(
    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
    verticalAlignment = Alignment.CenterVertically
  ) {
    steps.forEachIndexed { idx, step ->
      Surface(
        color = accentColor.copy(alpha = 0.12f),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.38f))
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(accentColor))
          Text(
            text = "${idx + 1}. ${step.titleHe}",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }
      if (idx < steps.lastIndex) {
        Box(
          modifier =
            Modifier
              .width(16.dp)
              .height(1.5.dp)
              .background(accentColor.copy(alpha = 0.60f))
        )
      }
    }
  }
}

@Composable
private fun CreateAutomationDialog(
  onSave: (String, String, List<AutomationStepType>, Int) -> Unit,
  onDismiss: () -> Unit
) {
  var name by remember { mutableStateOf("") }
  var phrase by remember { mutableStateOf("") }
  var selectedScheduleHours by remember { mutableIntStateOf(0) }
  val selectedSteps = remember { mutableStateListOf(AutomationStepType.SYSTEM_SCAN) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
    shape = RoundedCornerShape(14.dp),
    title = {
      Text("יצירת רצף אוטומציה ופקודה אישית", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
    },
    text = {
      Column(
        modifier = Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("שם האוטומציה") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("automation_name_input"),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = MaterialTheme.colorScheme.primary,
              unfocusedBorderColor = MaterialTheme.colorScheme.outline,
              focusedTextColor = MaterialTheme.colorScheme.onSurface,
              unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
              focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
              unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest
            )
        )
        OutlinedTextField(
          value = phrase,
          onValueChange = { phrase = it },
          label = { Text("מילת הפעלה בעוזר החכם") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("automation_phrase_input"),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = MaterialTheme.colorScheme.primary,
              unfocusedBorderColor = MaterialTheme.colorScheme.outline,
              focusedTextColor = MaterialTheme.colorScheme.onSurface,
              unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
              focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
              unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest
            )
        )
        Text("תזמון אוטומטי ברקע:", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          scheduleOptions.forEach { (hours, label) ->
            FilterChip(
              selected = selectedScheduleHours == hours,
              onClick = { selectedScheduleHours = hours },
              label = { Text(label) },
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                  selectedLabelColor = MaterialTheme.colorScheme.primary
                )
            )
          }
        }
        Text("בחר פעולות ברצף:", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
        AutomationStepType.entries.forEach { step ->
          val checked = step in selectedSteps
          Row(
            modifier =
              Modifier
                .fillMaxWidth()
                .clickable {
                  if (checked) selectedSteps.remove(step) else selectedSteps.add(step)
                },
            verticalAlignment = Alignment.CenterVertically
          ) {
            Checkbox(
              checked = checked,
              onCheckedChange = {
                if (checked) selectedSteps.remove(step) else selectedSteps.add(step)
              },
              colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
            )
            Text(
              text = step.titleHe + if (step.requiresConfirm) " (דורש אישור)" else "",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onSave(name, phrase, selectedSteps.toList(), selectedScheduleHours) },
        enabled = name.isNotBlank() && selectedSteps.isNotEmpty(),
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
        modifier = Modifier.testTag("save_automation_button")
      ) {
        Text("שמור פקודה")
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
      ) {
        Text("ביטול", color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
  )
}
