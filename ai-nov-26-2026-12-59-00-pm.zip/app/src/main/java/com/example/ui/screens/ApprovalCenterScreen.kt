package com.example.ui.screens

import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.backup.BackedUpFileEntry
import com.example.data.local.ActionAuditEntity
import com.example.data.local.ApprovalProposalEntity
import com.example.data.local.BackupRecordEntity
import com.example.data.local.UndoRecordEntity
import com.example.data.model.ApprovalRiskLevel
import com.example.data.system.formatBytes
import com.example.ui.components.NexusHudCard
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusEmerald
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ApprovalCenterScreen(
  pendingApprovals: List<ApprovalProposalEntity>,
  approvalHistory: List<ApprovalProposalEntity>,
  undoRecords: List<UndoRecordEntity>,
  backupRecords: List<BackupRecordEntity>,
  auditLogs: List<ActionAuditEntity>,
  safFolders: Set<String>,
  isBackingUp: Boolean,
  onApproveSingle: (ApprovalProposalEntity) -> Unit,
  onApproveAllPending: () -> Unit,
  onRejectSingle: (ApprovalProposalEntity) -> Unit,
  onRejectAllPending: () -> Unit,
  onExecuteUndo: (UndoRecordEntity) -> Unit,
  onCreateSafBackup: (String, String) -> Unit,
  onRestoreBackup: (BackupRecordEntity, BackedUpFileEntry?) -> Unit,
  onParseManifest: (BackupRecordEntity) -> List<BackedUpFileEntry>,
  onRequestAddSafFolder: () -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  var detailProposal by remember { mutableStateOf<ApprovalProposalEntity?>(null) }
  var showBatchConfirmDialog by remember { mutableStateOf(false) }

  var backupSourceTree by remember(safFolders) { mutableStateOf(safFolders.firstOrNull()) }
  var backupDestTree by remember(safFolders) { mutableStateOf(safFolders.lastOrNull()) }
  var expandedBackupId by remember { mutableStateOf<Long?>(null) }

  LazyColumn(
    modifier = modifier.fillMaxSize().testTag("approval_center_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      NexusHudCard(accentColor = MaterialTheme.colorScheme.primary) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text("מרכז אישורים, גיבוי חכם וביטול (Undo)", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
            Text(
              "מערכת בטיחות אפס-הפתעות: AI אינו רשאי למחוק, לשנות או להעביר קובץ לפני אישור מפורש שלך.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
        Spacer(modifier = Modifier.height(10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          FilterChip(selected = selectedTab == 0, onClick = { selectedTab = 0 }, label = { Text("אישורים ממתינים (${pendingApprovals.size})") })
          FilterChip(selected = selectedTab == 1, onClick = { selectedTab = 1 }, label = { Text("גיבוי חכם ושחזור (${backupRecords.size})") })
          FilterChip(selected = selectedTab == 2, onClick = { selectedTab = 2 }, label = { Text("מרכז ביטול (${undoRecords.count { it.isUndoable && !it.undone }})") })
          FilterChip(selected = selectedTab == 3, onClick = { selectedTab = 3 }, label = { Text("יומן פעילות") })
        }
      }
    }

    if (selectedTab == 0) {
      if (pendingApprovals.isNotEmpty()) {
        item {
          NexusHudCard(accentColor = NexusAmber) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
              Text(
                "${pendingApprovals.size} פעולות ממתינות לאישורך",
                style = MaterialTheme.typography.titleMedium,
                color = NexusAmber
              )
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onRejectAllPending) { Text("דחה הכול") }
                Button(
                  onClick = { showBatchConfirmDialog = true },
                  modifier = Modifier.testTag("approve_all_batch_btn")
                ) {
                  Text("אשר רשימה (${pendingApprovals.size})")
                }
              }
            }
          }
        }
        items(pendingApprovals, key = { it.id }) { prop ->
          ApprovalProposalCard(
            proposal = prop,
            onApprove = { onApproveSingle(prop) },
            onReject = { onRejectSingle(prop) },
            onShowDetails = { detailProposal = prop }
          )
        }
      } else {
        item {
          NexusHudCard {
            Text(
              "אין כרגע פעולות ממתינות לאישור. הצעות ניקוי, ארגון, שינוי שמות או העברה ל-SD יופיעו כאן לבדיקתך.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else if (selectedTab == 1) {
      item {
        NexusHudCard(accentColor = NexusEmerald) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Backup, contentDescription = null, tint = NexusEmerald)
            Spacer(modifier = Modifier.width(8.dp))
            Text("גיבוי חכם מאומת SHA-256 (SAF / כרטיס SD)", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            "Android 10 חוסמת גישה ישירה לתיקיות פרטיות של אפליקציות אחרות (/data/data) ללא Root, ולכן מנגנון הגיבוי מעתיק ומאמת תיקיות קבצים ומדיה דרך SAF (כולל לכרטיס SD).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(10.dp))

          if (safFolders.isEmpty()) {
            Button(onClick = onRequestAddSafFolder) {
              Text("הוסף תיקיית מקור ויעד לגיבוי (SAF / SD)")
            }
          } else {
            Text("בחר תיקיית מקור:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              safFolders.forEach { uriStr ->
                val label = Uri.parse(uriStr).lastPathSegment?.substringAfterLast(':') ?: "תיקייה"
                FilterChip(selected = backupSourceTree == uriStr, onClick = { backupSourceTree = uriStr }, label = { Text(label) })
              }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text("בחר תיקיית יעד (מומלץ כרטיס SD):", style = MaterialTheme.typography.labelSmall, color = NexusEmerald)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              safFolders.forEach { uriStr ->
                val label = Uri.parse(uriStr).lastPathSegment?.substringAfterLast(':') ?: "תיקייה"
                FilterChip(selected = backupDestTree == uriStr, onClick = { backupDestTree = uriStr }, label = { Text(label) })
              }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(
                onClick = {
                  val s = backupSourceTree
                  val d = backupDestTree
                  if (s != null && d != null) onCreateSafBackup(s, d)
                },
                enabled = !isBackingUp && backupSourceTree != null && backupDestTree != null
              ) {
                if (isBackingUp) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                else Icon(Icons.Rounded.Backup, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (isBackingUp) "מגבה ומאמת..." else "בצע גיבוי מאומת כעת")
              }
              OutlinedButton(onClick = onRequestAddSafFolder) { Text("+ יעד נוסף / SD") }
            }
          }
        }
      }

      if (backupRecords.isEmpty()) {
        item {
          NexusHudCard {
            Text("עדיין לא נוצרו גיבויי תיקיות מקומיים.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      } else {
        items(backupRecords, key = { it.id }) { rec ->
          val dateStr = SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault()).format(Date(rec.createdAtMillis))
          val expanded = expandedBackupId == rec.id
          val entries = remember(rec, expanded) { if (expanded) onParseManifest(rec) else emptyList() }
          NexusHudCard(accentColor = if (rec.verifiedOk) NexusEmerald else NexusAmber) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
              Column(modifier = Modifier.weight(1f)) {
                Text("${rec.sourceLabel} ← ${rec.destFolderName}", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                Text("תאריך: $dateStr • ${rec.integritySummaryHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { expandedBackupId = if (expanded) null else rec.id }) {
                  Text(if (expanded) "סגור קבצים" else "קבצים (${rec.fileCount})")
                }
                Button(onClick = { onRestoreBackup(rec, null) }) {
                  Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("שחזר הכול")
                }
              }
            }
            if (expanded && entries.isNotEmpty()) {
              Spacer(modifier = Modifier.height(8.dp))
              entries.take(25).forEach { entry ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                  Text("${entry.fileName} (${formatBytes(entry.sizeBytes)})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                  OutlinedButton(onClick = { onRestoreBackup(rec, entry) }) { Text("שחזר קובץ") }
                }
              }
            }
          }
        }
      }
    } else if (selectedTab == 2) {
      if (undoRecords.isEmpty()) {
        item {
          NexusHudCard {
            Text("אין פעולות בהיסטוריית הביטול עדיין.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      } else {
        items(undoRecords, key = { it.id }) { rec ->
          NexusHudCard(accentColor = if (rec.isUndoable && !rec.undone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
              Column(modifier = Modifier.weight(1f)) {
                Text(rec.actionTitle, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                Text(rec.noteHe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              if (rec.isUndoable && !rec.undone) {
                Button(onClick = { onExecuteUndo(rec) }) {
                  Icon(Icons.Rounded.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("בטל פעולה")
                }
              } else {
                Text(if (rec.undone) "בוטל" else "לא הפיך", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }
      }
    } else {
      item {
        Text("היסטוריית החלטות ויומן פעילות המכשיר", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
      }
      items(approvalHistory.take(25), key = { "hist_${it.id}" }) { prop ->
        val ok = prop.status == "APPROVED_EXECUTED"
        NexusHudCard(accentColor = if (ok) NexusEmerald else if (prop.status == "FAILED") NexusCrimson else MaterialTheme.colorScheme.outline) {
          Text("${prop.title} [${prop.status}]", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
          Text(prop.resultMessageHe ?: prop.reasonHe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
      items(auditLogs.take(30), key = { "aud_${it.id}" }) { log ->
        val dateStr = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(log.timestampMillis))
        NexusHudCard {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.History, contentDescription = null, tint = if (log.succeeded) NexusEmerald else NexusCrimson, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text("[$dateStr] ${log.category} — ${log.actionTitle}", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
              Text(log.details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      }
    }
  }

  detailProposal?.let { prop ->
    AlertDialog(
      onDismissRequest = { detailProposal = null },
      title = { Text(prop.title) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text("• יעד: ${prop.targetName}")
          Text("• מיקום: ${prop.targetLocation}")
          Text("• סיבה: ${prop.reasonHe}")
          Text("• רמת סיכון: ${prop.riskLevel}")
          Text("• הפיכות: ${if (prop.isReversible) "פעולה הפיכה (תישמר במרכז הביטול)" else "בלתי הפיך"}")
          Text("• תוצאה צפויה: ${prop.expectedOutcomeHe}")
          if (prop.bytesAffected > 0) Text("• נפח מושפע: ${formatBytes(prop.bytesAffected)}")
        }
      },
      confirmButton = {
        Button(onClick = { onApproveSingle(prop); detailProposal = null }) { Text("אישור פעולה בודדת בלבד") }
      },
      dismissButton = {
        TextButton(onClick = { detailProposal = null }) { Text("סגור") }
      }
    )
  }

  if (showBatchConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showBatchConfirmDialog = false },
      title = { Text("אישור מרוכז של ${pendingApprovals.size} פעולות") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text("נא ודא לפני ביצוע — הפעולות הבאות יופעלו כעת:")
          pendingApprovals.take(10).forEach { p ->
            Text("• ${p.title} (${p.targetName})", style = MaterialTheme.typography.bodySmall)
          }
          if (pendingApprovals.size > 10) {
            Text("ועוד ${pendingApprovals.size - 10} פעולות...", style = MaterialTheme.typography.bodySmall)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = { showBatchConfirmDialog = false; onApproveAllPending() },
          colors = ButtonDefaults.buttonColors(containerColor = NexusEmerald, contentColor = MaterialTheme.colorScheme.onTertiary)
        ) {
          Text("אשר ובצע הכול")
        }
      },
      dismissButton = {
        TextButton(onClick = { showBatchConfirmDialog = false }) { Text("ביטול") }
      }
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ApprovalProposalCard(
  proposal: ApprovalProposalEntity,
  onApprove: () -> Unit,
  onReject: () -> Unit,
  onShowDetails: () -> Unit
) {
  val risk = ApprovalRiskLevel.entries.firstOrNull { it.name == proposal.riskLevel } ?: ApprovalRiskLevel.MEDIUM
  val riskColor =
    when (risk) {
      ApprovalRiskLevel.LOW -> NexusEmerald
      ApprovalRiskLevel.MEDIUM -> NexusAmber
      ApprovalRiskLevel.HIGH -> NexusCrimson
    }

  NexusHudCard(accentColor = riskColor) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
      Text(proposal.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
      Surface(color = riskColor.copy(alpha = 0.16f), shape = RoundedCornerShape(8.dp)) {
        Text(risk.titleHe, style = MaterialTheme.typography.labelSmall, color = riskColor, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
      }
    }
    Spacer(modifier = Modifier.height(6.dp))
    Text("למה: ${proposal.reasonHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text("קובץ/רכיב: ${proposal.targetName} | מיקום: ${proposal.targetLocation}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
    Text(
      "תוצאה צפויה: ${proposal.expectedOutcomeHe} • ${if (proposal.isReversible) "הפיך" else "בלתי הפיך"}",
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.primary
    )
    Spacer(modifier = Modifier.height(10.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
      Button(
        onClick = onApprove,
        colors = ButtonDefaults.buttonColors(containerColor = NexusEmerald, contentColor = MaterialTheme.colorScheme.onTertiary)
      ) {
        Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("אישור ביצוע")
      }
      OutlinedButton(onClick = onReject) {
        Icon(Icons.Rounded.Close, contentDescription = null, tint = NexusCrimson, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("דחייה", color = NexusCrimson)
      }
      OutlinedButton(onClick = onShowDetails) {
        Icon(Icons.Rounded.Info, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("פרטים / פעולה בודדת")
      }
    }
  }
}
