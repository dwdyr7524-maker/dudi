package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalIsDarkTheme
import com.example.ui.theme.LocalPerformanceMode
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusGlowSky
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTitaniumCard
import com.example.ui.theme.SpaceGroteskFontFamily
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay

@Composable
fun NexusLogoMark(
  modifier: Modifier = Modifier,
  size: Dp = 40.dp,
  animated: Boolean = true
) {
  val perfMode = LocalPerformanceMode.current
  val isDark = LocalIsDarkTheme.current
  val primaryCol = MaterialTheme.colorScheme.primary
  val secondaryCol = MaterialTheme.colorScheme.secondary
  val pulse =
    if (animated && !perfMode) {
      val inf = rememberInfiniteTransition(label = "logo_pulse")
      val v by
        inf.animateFloat(
          initialValue = 0.72f,
          targetValue = 1f,
          animationSpec =
            infiniteRepeatable(
              animation = tween(2000, easing = FastOutSlowInEasing),
              repeatMode = RepeatMode.Reverse
            ),
          label = "pulse_alpha"
        )
      v
    } else {
      0.88f
    }

  Canvas(modifier = modifier.size(size)) {
    val w = this.size.width
    val h = this.size.height
    val cx = w / 2f
    val cy = h / 2f

    val frame = Path().apply {
      moveTo(cx, h * 0.06f)
      lineTo(w * 0.90f, h * 0.26f)
      lineTo(w * 0.90f, h * 0.74f)
      lineTo(cx, h * 0.94f)
      lineTo(w * 0.10f, h * 0.74f)
      lineTo(w * 0.10f, h * 0.26f)
      close()
    }
    drawPath(
      path = frame,
      brush =
        Brush.linearGradient(
          colors =
            if (isDark) listOf(NexusTitaniumCard, NexusCharcoal)
            else listOf(Color(0xFF0F172A), Color(0xFF1E293B)),
          start = Offset(0f, 0f),
          end = Offset(w, h)
        )
    )
    drawPath(
      path = frame,
      brush =
        Brush.linearGradient(
          colors = listOf(NexusNeonCyan.copy(alpha = pulse), NexusElectricBlue.copy(alpha = 0.85f)),
          start = Offset(0f, 0f),
          end = Offset(w, h)
        ),
      style = Stroke(width = w * 0.045f, join = StrokeJoin.Round)
    )

    val nPath = Path().apply {
      moveTo(w * 0.29f, h * 0.72f)
      lineTo(w * 0.29f, h * 0.28f)
      lineTo(w * 0.41f, h * 0.28f)
      lineTo(w * 0.60f, h * 0.56f)
      lineTo(w * 0.60f, h * 0.28f)
      lineTo(w * 0.71f, h * 0.28f)
      lineTo(w * 0.71f, h * 0.72f)
      lineTo(w * 0.59f, h * 0.72f)
      lineTo(w * 0.40f, h * 0.44f)
      lineTo(w * 0.40f, h * 0.72f)
      close()
    }
    drawPath(
      path = nPath,
      brush =
        Brush.linearGradient(
          colors =
            if (isDark) listOf(NexusNeonCyan, NexusElectricBlue, NexusGlowSky)
            else listOf(NexusCyanBrightOrBlue(primaryCol), NexusNeonCyan),
          start = Offset(w * 0.2f, h * 0.2f),
          end = Offset(w * 0.8f, h * 0.8f)
        )
    )
    drawPath(
      path = nPath,
      color = Color.White.copy(alpha = 0.28f * pulse),
      style = Stroke(width = w * 0.018f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
  }
}

private fun NexusCyanBrightOrBlue(fallback: Color): Color =
  if (fallback == Color.Unspecified) NexusElectricBlue else NexusGlowSky

@Composable
fun NexusCommandHeader(
  title: String,
  deviceLabel: String,
  batteryPercent: Int,
  showBackButton: Boolean,
  performanceMode: Boolean,
  isScanning: Boolean,
  onNavigateBack: () -> Unit,
  onTogglePerformanceMode: () -> Unit,
  onRefreshTelemetry: () -> Unit,
  pendingApprovalsCount: Int = 0,
  activeAlertsCount: Int = 0,
  onOpenGlobalSearch: () -> Unit = {},
  onToggleDarkTheme: () -> Unit = {},
  onOpenApprovals: () -> Unit = {},
  onOpenReminders: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val isDark = LocalIsDarkTheme.current
  val primaryColor = MaterialTheme.colorScheme.primary
  val surfaceCard = MaterialTheme.colorScheme.surfaceContainerHigh
  val borderCol = MaterialTheme.colorScheme.outline
  val textMain = MaterialTheme.colorScheme.onSurface
  val textSub = MaterialTheme.colorScheme.onSurfaceVariant

  Column(
    modifier =
      modifier
        .fillMaxWidth()
        .background(
          if (isDark) NexusObsidian.copy(alpha = 0.72f)
          else MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)
        )
  ) {
    Row(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
        if (showBackButton) {
          IconButton(
            onClick = onNavigateBack,
            modifier =
              Modifier
                .size(48.dp)
                .nexusInteractive()
                .clip(RoundedCornerShape(10.dp))
                .background(surfaceCard)
                .border(1.dp, borderCol, RoundedCornerShape(10.dp))
                .testTag("header_back_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
              contentDescription = "חזור ללוח הפיקוד",
              tint = primaryColor
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
        }
        NexusLogoMark(size = 38.dp)
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
              text = "NEXUS AI",
              style =
                MaterialTheme.typography.titleMedium.copy(
                  fontFamily = SpaceGroteskFontFamily,
                  fontWeight = FontWeight.Bold
                ),
              color = textMain
            )
            Surface(
              color = primaryColor.copy(alpha = if (isDark) 0.14f else 0.10f),
              shape = RoundedCornerShape(6.dp),
              border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.34f))
            ) {
              Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = primaryColor,
                maxLines = 1,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }
          Text(
            text = if (showBackButton) deviceLabel else "השליטה החכמה במכשיר שלך • $deviceLabel",
            style = MaterialTheme.typography.bodySmall,
            color = textSub,
            maxLines = 1
          )
        }
      }

      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        if (pendingApprovalsCount > 0) {
          Surface(
            modifier =
              Modifier
                .height(48.dp)
                .nexusInteractive()
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onOpenApprovals)
                .testTag("header_approvals_badge"),
            color = NexusAmber.copy(alpha = 0.14f),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.55f))
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                Icons.Rounded.VerifiedUser,
                contentDescription = "אישורים ממתינים",
                tint = NexusAmber,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(5.dp))
              Text(
                text = "$pendingApprovalsCount לאישור",
                style = MaterialTheme.typography.labelSmall,
                color = textMain
              )
            }
          }
        }

        HeaderSquareButton(
          onClick = onOpenReminders,
          testTag = "notifications_bell_button"
        ) {
          if (activeAlertsCount > 0) {
            BadgedBox(badge = { Badge { Text("$activeAlertsCount") } }) {
              Icon(
                imageVector = Icons.Rounded.Notifications,
                contentDescription = "תזכורות והתראות מערכת",
                tint = primaryColor
              )
            }
          } else {
            Icon(
              imageVector = Icons.Rounded.Notifications,
              contentDescription = "תזכורות והתראות מערכת",
              tint = primaryColor
            )
          }
        }

        HeaderSquareButton(
          onClick = onOpenGlobalSearch,
          testTag = "global_search_button"
        ) {
          Icon(
            imageVector = Icons.Rounded.Search,
            contentDescription = "חיפוש גלובלי",
            tint = primaryColor
          )
        }

        HeaderSquareButton(
          onClick = onToggleDarkTheme,
          testTag = "theme_toggle_button"
        ) {
          Icon(
            imageVector = if (isDark) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
            contentDescription = if (isDark) "מעבר למצב בהיר" else "מעבר למצב כהה",
            tint = primaryColor
          )
        }

        Surface(
          modifier =
            Modifier
              .height(48.dp)
              .nexusInteractive()
              .clip(RoundedCornerShape(10.dp))
              .clickable(onClick = onTogglePerformanceMode)
              .testTag("performance_mode_chip"),
          color =
            if (performanceMode) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.16f)
            else surfaceCard,
          shape = RoundedCornerShape(10.dp),
          border =
            BorderStroke(
              1.dp,
              if (performanceMode) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.65f)
              else borderCol
            )
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Rounded.Bolt,
              contentDescription = "מצב ביצועים",
              tint = if (performanceMode) MaterialTheme.colorScheme.tertiary else primaryColor,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (performanceMode) "ביצועים" else "$batteryPercent%",
              style = MaterialTheme.typography.labelSmall,
              color = textMain
            )
          }
        }

        HeaderSquareButton(
          onClick = onRefreshTelemetry,
          testTag = "refresh_telemetry_button"
        ) {
          Icon(
            imageVector = Icons.Rounded.Refresh,
            contentDescription = "רענן נתוני מערכת",
            tint = if (isScanning) MaterialTheme.colorScheme.tertiary else primaryColor
          )
        }
      }
    }
    if (isScanning) {
      NexusWaveProgressBar(
        progress = null,
        accentColor = primaryColor,
        height = 2.dp
      )
    } else {
      HorizontalDivider(
        thickness = 1.dp,
        color = borderCol.copy(alpha = 0.72f)
      )
    }
  }
}

@Composable
private fun HeaderSquareButton(
  onClick: () -> Unit,
  testTag: String,
  content: @Composable () -> Unit
) {
  IconButton(
    onClick = onClick,
    modifier =
      Modifier
        .size(48.dp)
        .nexusInteractive()
        .clip(RoundedCornerShape(10.dp))
        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
        .testTag(testTag)
  ) {
    content()
  }
}

private data class LightParticle(
  val startAngle: Float,
  val startRadiusFactor: Float,
  val targetOffsetX: Float,
  val targetOffsetY: Float,
  val size: Float,
  val isCyan: Boolean
)

@Composable
fun NexusParticleSplash(
  onSplashFinished: () -> Unit,
  modifier: Modifier = Modifier
) {
  val perfMode = LocalPerformanceMode.current
  val progress = remember { Animatable(0f) }

  val particles = remember(perfMode) {
    val count = if (perfMode) 32 else 72
    List(count) { idx ->
      val angle = (idx * (360f / count)) * (PI.toFloat() / 180f)
      val radiusFactor = 0.42f + ((idx % 7) * 0.08f)
      val col = (idx % 6) / 5f - 0.5f
      val row = ((idx / 6) % 6) / 5f - 0.5f
      LightParticle(
        startAngle = angle,
        startRadiusFactor = radiusFactor,
        targetOffsetX = col * 0.22f,
        targetOffsetY = row * 0.22f,
        size = if (idx % 3 == 0) 4f else 2.5f,
        isCyan = idx % 2 == 0
      )
    }
  }

  LaunchedEffect(Unit) {
    progress.animateTo(
      targetValue = 1f,
      animationSpec = tween(durationMillis = if (perfMode) 800 else 1350, easing = FastOutSlowInEasing)
    )
    delay(220)
    onSplashFinished()
  }

  val p = progress.value

  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(
          Brush.radialGradient(
            colors = listOf(Color(0xFF0A172D), NexusObsidian),
            radius = 960f
          )
        )
        .clickable(onClick = onSplashFinished)
        .testTag("nexus_splash_screen"),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val cx = size.width / 2f
      val cy = size.height / 2f - 36f
      val maxDist = size.minDimension * 0.52f

      val converge = (1f - p).coerceIn(0f, 1f)
      particles.forEach { pt ->
        val currentR = maxDist * pt.startRadiusFactor * converge
        val swirl = pt.startAngle + (1f - converge) * 1.3f
        val x = cx + cos(swirl) * currentR + pt.targetOffsetX * size.minDimension * (1f - converge)
        val y = cy + sin(swirl) * currentR + pt.targetOffsetY * size.minDimension * (1f - converge)
        val color = if (pt.isCyan) NexusNeonCyan else NexusElectricBlue
        drawCircle(
          color = color.copy(alpha = (0.35f + 0.65f * p).coerceIn(0f, 1f)),
          radius = pt.size * (0.7f + 0.7f * (1f - converge)),
          center = Offset(x, y)
        )
      }

      if (p > 0.65f) {
        val burst = ((p - 0.65f) / 0.35f).coerceIn(0f, 1f)
        drawCircle(
          color = NexusNeonCyan.copy(alpha = (1f - burst) * 0.50f),
          radius = size.minDimension * 0.14f + burst * size.minDimension * 0.24f,
          center = Offset(cx, cy),
          style = Stroke(width = 2.5f)
        )
      }
    }

    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Box(contentAlignment = Alignment.Center) {
        Nexus3DGyroLoader(size = 148.dp, active = p < 0.98f)
        Box(
          modifier = Modifier.size((86 * p.coerceAtLeast(0.18f)).dp),
          contentAlignment = Alignment.Center
        ) {
          NexusLogoMark(size = 82.dp, animated = false)
        }
      }
      Spacer(modifier = Modifier.height(22.dp))
      Text(
        text = "NEXUS AI",
        style =
          MaterialTheme.typography.displayMedium.copy(
            fontFamily = SpaceGroteskFontFamily,
            fontWeight = FontWeight.Bold
          ),
        color = NexusTextPrimary.copy(alpha = p.coerceIn(0.25f, 1f))
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "השליטה החכמה במכשיר שלך",
        style = MaterialTheme.typography.titleMedium,
        color = NexusNeonCyan.copy(alpha = p.coerceIn(0.25f, 1f))
      )
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "מכין טלמטריית מערכת בזמן אמת...",
        style = MaterialTheme.typography.bodySmall,
        color = NexusTextSecondary.copy(alpha = p)
      )
    }
  }
}
