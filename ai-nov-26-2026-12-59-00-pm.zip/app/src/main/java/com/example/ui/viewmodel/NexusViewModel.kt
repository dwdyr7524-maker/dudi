package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.NexusApp
import com.example.data.ai.AiSystemDiagnosticsReport
import com.example.data.ai.AikoBrainEngine
import com.example.data.ai.AikoLocalResult
import com.example.data.ai.AikoRequestedOperation
import com.example.data.ai.CloudHealthCheckState
import com.example.data.ai.LifeItemKind
import com.example.data.ai.LifeItemPriority
import com.example.data.ai.LiveVoiceUiState
import com.example.data.ai.NexusAiErrorMapper
import com.example.data.ai.NexusAikoToolEngine
import com.example.data.ai.NexusAppError
import com.example.data.ai.TranscriptionUiState
import com.example.data.ai.VisualDiagnosisUiState
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import com.example.data.backup.BackedUpFileEntry
import com.example.data.documents.DocumentTextAnalyzer
import com.example.data.documents.OpenedDocumentState
import com.example.data.local.ActionAuditEntity
import com.example.data.local.ApprovalProposalEntity
import com.example.data.local.AssistantMessageEntity
import com.example.data.local.AutomationEntity
import com.example.data.local.BackupRecordEntity
import com.example.data.local.CleanHistoryEntity
import com.example.data.local.LearningRecordEntity
import com.example.data.local.LifeItemEntity
import com.example.data.local.ManagedAccountEntity
import com.example.data.local.MemoryEntryEntity
import com.example.data.local.OrchestratorTaskEntity
import com.example.data.local.ReminderAlertEntity
import com.example.data.local.TelemetrySnapshotEntity
import com.example.data.local.ToolUsageEntity
import com.example.data.local.UndoRecordEntity
import com.example.data.memory.LearningAnalyticsCalculator
import com.example.data.memory.LearningInsightsSnapshot
import com.example.data.memory.MemorySaveResult
import com.example.data.memory.NexusMemorySecretFilter
import com.example.data.memory.NexusMemoryType
import com.example.data.model.AiOrganizationPlanReport
import com.example.data.model.AiOrganizationProposalDraft
import com.example.data.model.ApkInspectionReport
import com.example.data.model.AppDiagnosticInfo
import com.example.data.model.AppFilterMode
import com.example.data.model.AppSortMode
import com.example.data.model.ApprovalOperationType
import com.example.data.model.ApprovalRiskLevel
import com.example.data.model.AssistantActionType
import com.example.data.model.AutomationStepType
import com.example.data.model.DeepCleanExecutionResult
import com.example.data.model.DeepCleanScanResult
import com.example.data.model.DeviceDoctorReport
import com.example.data.model.FolderStorageSummary
import com.example.data.model.GlobalSearchResultItem
import com.example.data.model.PendingAssistantAction
import com.example.data.model.RobotMood
import com.example.data.model.ScannedFileEntry
import com.example.data.model.SecurityAuditReport
import com.example.data.model.SimilarAppGroup
import com.example.data.model.SmartStorageScanReport
import com.example.data.model.SystemShortcutId
import com.example.data.model.SystemTelemetry
import com.example.data.orchestrator.NexusToolRegistry
import com.example.data.orchestrator.NexusToolStatus
import com.example.data.system.AiFileCommanderEngine
import com.example.data.system.NetworkStatusSnapshot
import com.example.data.system.NexusNotificationHelper
import com.example.data.system.PendingSyncTask
import com.example.data.system.SelfDiagnosticsReport
import com.example.data.system.VoiceOptionInfo
import com.example.data.system.formatBytes
import com.example.data.worker.NexusWorkScheduler
import com.example.ui.navigation.NexusDestination
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class DeepCleanPhase {
  IDLE,
  SCANNING,
  RESULTS_READY,
  AWAITING_CONFIRMATION,
  CLEANING,
  COMPLETED
}

data class DeepCleanUiState(
  val phase: DeepCleanPhase = DeepCleanPhase.IDLE,
  val scanResult: DeepCleanScanResult? = null,
  val selectedIds: Set<String> = emptySet(),
  val executionResult: DeepCleanExecutionResult? = null,
  val postCleanScanResult: DeepCleanScanResult? = null,
  val statusMessage: String? = null
)

data class AppsUiState(
  val isLoading: Boolean = true,
  val allApps: List<AppDiagnosticInfo> = emptyList(),
  val searchQuery: String = "",
  val sortMode: AppSortMode = AppSortMode.SIZE_DESC,
  val filterMode: AppFilterMode = AppFilterMode.ALL,
  val selectedPackageName: String? = null
)

data class AssistantUiState(
  val robotMood: RobotMood = RobotMood.IDLE,
  val isListening: Boolean = false,
  val isThinking: Boolean = false,
  val isSpeaking: Boolean = false,
  val pendingAction: PendingAssistantAction? = null,
  val lastPlannedSteps: List<String> = emptyList(),
  val lastProviderLabel: String? = null,
  val lastFailedInput: String? = null,
  val aiError: NexusAppError? = null
)

class NexusViewModel(application: Application) : AndroidViewModel(application) {
  private val app = application as NexusApp
  private val db = app.database
  private val prefs = app.preferencesManager
  private val commander = CommanderDelegate(app)

  val performanceMode: StateFlow<Boolean> =
    prefs.performanceModeFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

  val reduceMotionEnabled: StateFlow<Boolean> =
    prefs.reduceMotionFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

  val darkThemeEnabled: StateFlow<Boolean> =
    prefs.darkThemeEnabledFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  val lastFullScanMillis: StateFlow<Long?> =
    prefs.lastFullScanMillisFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val ttsEnabled: StateFlow<Boolean> =
    prefs.ttsEnabledFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  val ttsSpeechRate: StateFlow<Float> =
    prefs.ttsSpeechRateFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1.0f)

  val ttsPitch: StateFlow<Float> =
    prefs.ttsPitchFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1.0f)

  val ttsVoiceName: StateFlow<String?> =
    prefs.ttsVoiceNameFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val noiseSuppressionEnabled: StateFlow<Boolean> =
    prefs.noiseSuppressionEnabledFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  val memoryAutoSaveEnabled: StateFlow<Boolean> =
    prefs.memoryAutoSaveEnabledFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  val floatingAssistantEnabled: StateFlow<Boolean> =
    prefs.floatingAssistantEnabledFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  val floatingOffsetX: StateFlow<Float> =
    prefs.floatingOffsetXFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), -16f)

  val floatingOffsetY: StateFlow<Float> =
    prefs.floatingOffsetYFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), -96f)

  val cloudAiEnabled: StateFlow<Boolean> =
    prefs.cloudAiEnabledFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  val shareTelemetryWithAi: StateFlow<Boolean> =
    prefs.shareTelemetryWithAiFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  val backgroundAlertsEnabled: StateFlow<Boolean> =
    prefs.backgroundAlertsEnabledFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

  val alertIntervalMinutes: StateFlow<Long> =
    prefs.alertIntervalMinutesFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 30L)

  val safTreeUris: StateFlow<Set<String>> =
    prefs.safTreeUrisFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

  val lastMaintenanceMillis: StateFlow<Long?> =
    prefs.lastMaintenanceMillisFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val cleanHistory: StateFlow<List<CleanHistoryEntity>> =
    db.cleanHistoryDao().observeHistory().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val telemetrySnapshots: StateFlow<List<TelemetrySnapshotEntity>> =
    db.telemetrySnapshotDao().observeRecentSnapshots().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val assistantMessages: StateFlow<List<AssistantMessageEntity>> =
    db.assistantMessageDao().observeMessages().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val automations: StateFlow<List<AutomationEntity>> =
    db.automationDao().observeAutomations().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val actionAuditLogs: StateFlow<List<ActionAuditEntity>> =
    db.actionAuditDao().observeAuditLogs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val pendingApprovals: StateFlow<List<ApprovalProposalEntity>> =
    db.approvalProposalDao().observePending().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val approvalHistory: StateFlow<List<ApprovalProposalEntity>> =
    db.approvalProposalDao().observeHistory().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val undoRecords: StateFlow<List<UndoRecordEntity>> =
    db.undoRecordDao().observeUndoRecords().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val backupRecords: StateFlow<List<BackupRecordEntity>> =
    db.backupRecordDao().observeBackups().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Command Center: Memory, Learning, Orchestrator, Tool Registry, Reminders, Connectivity, Documents
  val memoryEntries: StateFlow<List<MemoryEntryEntity>> =
    app.memoryManager.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val orchestratorTasks: StateFlow<List<OrchestratorTaskEntity>> =
    app.orchestratorEngine.observeTasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val currentlyDoingHe: StateFlow<String?> = app.orchestratorEngine.currentlyDoingHe

  val learningRecords: StateFlow<List<LearningRecordEntity>> =
    app.learningEngine.observeRecords().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val toolUsageLogs: StateFlow<List<ToolUsageEntity>> =
    app.learningEngine.observeToolUsage().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val learningInsights: StateFlow<LearningInsightsSnapshot> =
    combine(toolUsageLogs, learningRecords) { usage, records ->
      LearningAnalyticsCalculator.buildSnapshot(usage, records)
    }.stateIn(
      viewModelScope,
      SharingStarted.WhileSubscribed(5000),
      LearningAnalyticsCalculator.buildSnapshot(emptyList(), emptyList())
    )

  val reminderAlerts: StateFlow<List<ReminderAlertEntity>> =
    db.reminderAlertDao().observeAlerts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val networkStatus: StateFlow<NetworkStatusSnapshot> = app.connectivityMonitor.status
  val pendingSyncQueue: StateFlow<List<PendingSyncTask>> = app.connectivityMonitor.pendingSyncQueue

  private val _isTtsPaused = MutableStateFlow(false)
  val isTtsPaused: StateFlow<Boolean> = _isTtsPaused.asStateFlow()

  private val _ttsAvailableVoices = MutableStateFlow<List<VoiceOptionInfo>>(emptyList())
  val ttsAvailableVoices: StateFlow<List<VoiceOptionInfo>> = _ttsAvailableVoices.asStateFlow()

  private val _openedDocument = MutableStateFlow<OpenedDocumentState?>(null)
  val openedDocument: StateFlow<OpenedDocumentState?> = _openedDocument.asStateFlow()

  private val _isOpeningDocument = MutableStateFlow(false)
  val isOpeningDocument: StateFlow<Boolean> = _isOpeningDocument.asStateFlow()

  private val _isSummarizingDocument = MutableStateFlow(false)
  val isSummarizingDocument: StateFlow<Boolean> = _isSummarizingDocument.asStateFlow()

  val lifeItems: StateFlow<List<LifeItemEntity>> =
    db.lifeItemDao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val managedAccounts: StateFlow<List<ManagedAccountEntity>> =
    db.managedAccountDao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _accountConnectivityStatus = MutableStateFlow<Map<Long, String>>(emptyMap())
  val accountConnectivityStatus: StateFlow<Map<Long, String>> = _accountConnectivityStatus.asStateFlow()

  val smartStorageReport: StateFlow<SmartStorageScanReport?> = commander.smartStorageReport
  val isScanningFullDevice: StateFlow<Boolean> = commander.isScanningFullDevice
  val deviceDoctorReport: StateFlow<DeviceDoctorReport?> = commander.deviceDoctorReport
  val aiOrgPlan: StateFlow<AiOrganizationPlanReport?> = commander.aiOrgPlan
  val aiOrgInsights: StateFlow<String?> = commander.aiOrgInsights
  val similarAppGroups: StateFlow<List<SimilarAppGroup>> = commander.similarAppGroups
  val apkInspectionReport: StateFlow<ApkInspectionReport?> = commander.apkInspectionReport
  val isInspectingApk: StateFlow<Boolean> = commander.isInspectingApk
  val isBackingUpFolder: StateFlow<Boolean> = commander.isBackingUp
  val selfDiagnosticsReport: StateFlow<SelfDiagnosticsReport?> = commander.selfDiagnosticsReport
  val isRunningSelfDiagnostics: StateFlow<Boolean> = commander.isRunningSelfDiagnostics

  val liveVoiceState: StateFlow<LiveVoiceUiState> = app.aiProvider.liveVoiceState

  private val _transcriptionState =
    MutableStateFlow<TranscriptionUiState>(TranscriptionUiState.Idle)
  val transcriptionState: StateFlow<TranscriptionUiState> = _transcriptionState.asStateFlow()

  private val _visualDiagnosisState =
    MutableStateFlow<VisualDiagnosisUiState>(VisualDiagnosisUiState.Idle)
  val visualDiagnosisState: StateFlow<VisualDiagnosisUiState> = _visualDiagnosisState.asStateFlow()

  private val _cloudHealthCheckState =
    MutableStateFlow<CloudHealthCheckState>(CloudHealthCheckState.Idle)
  val cloudHealthCheckState: StateFlow<CloudHealthCheckState> = _cloudHealthCheckState.asStateFlow()

  private val _aiDiagnosticsReport = MutableStateFlow<AiSystemDiagnosticsReport?>(null)
  val aiDiagnosticsReport: StateFlow<AiSystemDiagnosticsReport?> = _aiDiagnosticsReport.asStateFlow()

  private val isAssistantRequestInFlight = AtomicBoolean(false)
  private val isAudioTranscribeInFlight = AtomicBoolean(false)
  private var recordingObserverJob: Job? = null
  private var lastRecordedAudioForRetry: ByteArray? = null

  private val _telemetry =
    MutableStateFlow(app.telemetryProvider.captureTelemetry(authorizedFolderCount = 0))
  val telemetry: StateFlow<SystemTelemetry> = _telemetry.asStateFlow()

  val toolStatuses: StateFlow<List<NexusToolStatus>> =
    combine(_telemetry, safTreeUris, cloudAiEnabled, toolUsageLogs) { tel, folders, cloudOn, usage ->
      NexusToolRegistry.inspectTools(
        context = app,
        telemetry = tel,
        safFoldersCount = folders.size,
        cloudAiEnabled = cloudOn,
        usageLogs = usage
      )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _isRefreshingTelemetry = MutableStateFlow(false)
  val isRefreshingTelemetry: StateFlow<Boolean> = _isRefreshingTelemetry.asStateFlow()

  private val _deepCleanState = MutableStateFlow(DeepCleanUiState())
  val deepCleanState: StateFlow<DeepCleanUiState> = _deepCleanState.asStateFlow()

  private val _appsState = MutableStateFlow(AppsUiState())
  val appsState: StateFlow<AppsUiState> = _appsState.asStateFlow()

  private val _securityReport = MutableStateFlow<SecurityAuditReport?>(null)
  val securityReport: StateFlow<SecurityAuditReport?> = _securityReport.asStateFlow()

  private val _assistantState = MutableStateFlow(AssistantUiState())
  val assistantState: StateFlow<AssistantUiState> = _assistantState.asStateFlow()

  private val _pendingAutomationRun = MutableStateFlow<AutomationEntity?>(null)
  val pendingAutomationRun: StateFlow<AutomationEntity?> = _pendingAutomationRun.asStateFlow()

  private val _centralError = MutableStateFlow<NexusAppError?>(null)
  val centralError: StateFlow<NexusAppError?> = _centralError.asStateFlow()

  private val _uiBannerMessage = MutableStateFlow<String?>(null)
  val uiBannerMessage: StateFlow<String?> = _uiBannerMessage.asStateFlow()

  private val _navigateEvent = MutableStateFlow<String?>(null)
  val navigateEvent: StateFlow<String?> = _navigateEvent.asStateFlow()

  init {
    app.assistantEngine.setSpeakingListener { speaking ->
      _assistantState.update {
        it.copy(
          isSpeaking = speaking,
          robotMood =
            when {
              speaking -> RobotMood.SPEAKING
              it.isThinking -> RobotMood.THINKING
              it.isListening -> RobotMood.LISTENING
              else -> RobotMood.IDLE
            }
        )
      }
    }
    app.assistantEngine.setPausedListener { paused ->
      _isTtsPaused.value = paused
    }

    app.connectivityMonitor.setOnReconnectedListener {
      viewModelScope.launch {
        val now = System.currentTimeMillis()
        // Evaluate NETWORK_RECONNECTED conditional reminders
        val activeReminders = db.reminderAlertDao().getActiveOnce()
        activeReminders
          .filter { it.conditionKey == "NETWORK_RECONNECTED" }
          .forEach { rem ->
            db.reminderAlertDao().update(rem.copy(status = "TRIGGERED", lastTriggeredMillis = now))
            NexusNotificationHelper.postReminderNotification(
              context = app,
              notificationId = 7200 + (rem.id % 300).toInt(),
              title = "חיבור רשת חזר: ${rem.title}",
              body = rem.message.ifBlank { "חיבור האינטרנט חזר — ניתן להשלים משימות ענן." },
              targetRoute = rem.targetRoute
            )
          }

        val queued = app.connectivityMonitor.pendingSyncQueue.value
        if (queued.isNotEmpty() && cloudAiEnabled.value) {
          val count = queued.size
          app.connectivityMonitor.clearSyncQueue()
          _uiBannerMessage.value = "החיבור חזר — $count משימות סנכרון ממתינות מוכנות לעדכון."
        }
      }
    }

    viewModelScope.launch {
      refreshTelemetry(recordSnapshot = true)
      loadAppsAndSecurity()
      seedWelcomeChatIfNeeded()
      delay(400)
      _ttsAvailableVoices.value = app.assistantEngine.getAvailableVoices()
    }

    // Periodic live telemetry loop (every 12s)
    viewModelScope.launch {
      while (isActive) {
        delay(12_000)
        refreshTelemetry(recordSnapshot = false)
      }
    }
  }

  private suspend fun seedWelcomeChatIfNeeded() {
    val existing = db.assistantMessageDao().observeMessages().first()
    if (existing.isEmpty()) {
      db.assistantMessageDao().insert(
        AssistantMessageEntity(
          timestampMillis = System.currentTimeMillis(),
          isUser = false,
          text =
            "שלום! אני אייקו (Aiko) ב-NEXUS AI — העוזר האישי ומנהל המכשיר החכם שלך. תוכל לדבר איתי בעברית טבעית על משימות ותזכורות, הורדות וקבצי ZIP, אוטומציות, שירותים ואבחון מלא של הטאבלט."
        )
      )
    }
  }

  fun showBanner(message: String) {
    _uiBannerMessage.value = message
  }

  fun clearBannerMessage() {
    _uiBannerMessage.value = null
  }

  fun dismissCentralError() {
    _centralError.value = null
  }

  fun consumeNavigateEvent() {
    _navigateEvent.value = null
  }

  fun togglePerformanceMode() {
    viewModelScope.launch {
      val next = !performanceMode.value
      prefs.setPerformanceMode(next)
      _uiBannerMessage.value =
        if (next) "מצב ביצועים הופעל — אנימציות מופחתות לחיסכון בסוללה ובמעבד."
        else "מצב אנימציות מלא הופעל."
    }
  }

  fun toggleReduceMotion() {
    viewModelScope.launch {
      val next = !reduceMotionEnabled.value
      prefs.setReduceMotion(next)
      _uiBannerMessage.value =
        if (next) "הפחתת תנועה הופעלה — אפקטים כבדים כבויים לשמירה על נגישות ומהירות."
        else "מנוע האנימציות של NEXUS הופעל מחדש."
    }
  }

  fun toggleDarkTheme() {
    viewModelScope.launch {
      val next = !darkThemeEnabled.value
      prefs.setDarkThemeEnabled(next)
    }
  }

  fun toggleTtsEnabled() {
    viewModelScope.launch {
      val next = !ttsEnabled.value
      prefs.setTtsEnabled(next)
      if (!next) app.assistantEngine.stopSpeaking()
    }
  }

  fun toggleCloudAiEnabled() {
    viewModelScope.launch {
      val next = !cloudAiEnabled.value
      prefs.setCloudAiEnabled(next)
      _uiBannerMessage.value =
        if (next) "עוזר ענן חכם (Firebase AI Logic) הופעל."
        else "מצב מקומי בלבד הופעל — לא יישלחו בקשות לענן."
    }
  }

  fun toggleShareTelemetryWithAi() {
    viewModelScope.launch {
      val next = !shareTelemetryWithAi.value
      prefs.setShareTelemetryWithAi(next)
      _uiBannerMessage.value =
        if (next) "שיתוף מדדי מערכת בהקשר העוזר הופעל."
        else "מצב פרטיות מוגבר: מדדי המכשיר לא ישותפו עם שירותי הענן."
    }
  }

  fun setBackgroundAlertsEnabled(enabled: Boolean) {
    viewModelScope.launch {
      prefs.setBackgroundAlertsEnabled(enabled)
      val interval = prefs.alertIntervalMinutesFlow.first()
      NexusWorkScheduler.syncThermalMonitor(app, enabled, interval)
      logAudit(
        category = "ניטור רקע",
        title = if (enabled) "הפעלת התראות חום וסוללה" else "כיבוי התראות רקע",
        succeeded = true,
        details = if (enabled) "מרווח בדיקה: כל $interval דקות" else "ניטור WorkManager כובה"
      )
      _uiBannerMessage.value =
        if (enabled) "ניטור רקע פעיל (כל $interval דקות) להתראות חום, סוללה ואחסון."
        else "התראות הרקע כובו."
    }
  }

  fun setAlertIntervalMinutes(minutes: Long) {
    viewModelScope.launch {
      prefs.setAlertIntervalMinutes(minutes)
      val enabled = prefs.backgroundAlertsEnabledFlow.first()
      NexusWorkScheduler.syncThermalMonitor(app, enabled, minutes)
      _uiBannerMessage.value = "תדירות ניטור הרקע עודכנה לכל $minutes דקות."
    }
  }

  fun triggerImmediateBackgroundCheck() {
    NexusWorkScheduler.runImmediateMonitorCheck(app)
    _uiBannerMessage.value = "בדיקת רקע ועדכון וידג׳ט נשלחו לביצוע מיידי."
  }

  fun refreshTelemetry(recordSnapshot: Boolean = true) {
    viewModelScope.launch {
      _isRefreshingTelemetry.value = true
      runCatching {
        val folders = prefs.safTreeUrisFlow.first()
        val current = app.telemetryProvider.captureTelemetry(folders.size)
        _telemetry.value = current
        commander.updateDoctorAndSimilarApps(current, _appsState.value.allApps, _securityReport.value)
        if (recordSnapshot) {
          db.telemetrySnapshotDao().insert(
            TelemetrySnapshotEntity(
              timestampMillis = current.capturedAtMillis,
              batteryPercent = current.battery.levelPercent,
              batteryTempC = current.battery.temperatureC,
              batteryVoltageMv = current.battery.voltageMv,
              ramUsedPercent = current.ram.usedPercent,
              storageUsedPercent = current.storage.usedPercent,
              storageFreeBytes = current.storage.freeBytes,
              healthScore = current.healthScore
            )
          )
          db.telemetrySnapshotDao().pruneOld()
        }
      }.onFailure { err ->
        if (err is CancellationException) throw err
        _centralError.value =
          NexusAppError(
            source = "telemetry",
            messageHe = "שגיאה בקריאת נתוני המערכת: ${err.localizedMessage ?: "שגיאה לא ידועה"}",
            canRetry = true
          )
      }
      delay(250)
      _isRefreshingTelemetry.value = false
    }
  }

  fun loadAppsAndSecurity() {
    viewModelScope.launch {
      _appsState.update { it.copy(isLoading = true) }
      runCatching {
        val apps = app.appIntelligenceProvider.loadApps()
        val currentDevice = _telemetry.value.device
        val report = app.securityAuditor.buildAuditReport(apps, currentDevice)
        _appsState.update { state ->
          state.copy(
            isLoading = false,
            allApps = apps,
            selectedPackageName = state.selectedPackageName ?: apps.firstOrNull()?.packageName
          )
        }
        _securityReport.value = report
        commander.updateDoctorAndSimilarApps(_telemetry.value, apps, report)
      }.onFailure { err ->
        if (err is CancellationException) throw err
        _appsState.update { it.copy(isLoading = false) }
        _centralError.value =
          NexusAppError(
            source = "apps_security",
            messageHe = "טעינת האפליקציות וביקורת ההרשאות נכשלה: ${err.localizedMessage}",
            canRetry = true
          )
      }
    }
  }

  fun updateAppSearch(query: String) {
    _appsState.update { it.copy(searchQuery = query) }
  }

  fun updateAppSort(mode: AppSortMode) {
    _appsState.update { it.copy(sortMode = mode) }
  }

  fun updateAppFilter(mode: AppFilterMode) {
    _appsState.update { it.copy(filterMode = mode) }
  }

  fun selectAppPackage(packageName: String) {
    _appsState.update { it.copy(selectedPackageName = packageName) }
  }

  fun launchInstalledApp(packageName: String, appName: String) {
    val ok = app.appIntelligenceProvider.launchApp(packageName)
    logAudit(
      category = "אפליקציות",
      title = "פתיחת $appName",
      succeeded = ok,
      details = if (ok) "האפליקציה נפתחה" else "לא ניתן לפתוח אפליקציה זו",
      failureReason = if (ok) null else "לאפליקציה אין מסך הפעלה (Launcher Activity)"
    )
    if (!ok) {
      _uiBannerMessage.value = "לאפליקציה $appName אין ממשק פתיחה ישיר (רכיב מערכת)."
    }
  }

  fun openAppSystemSettings(packageName: String, appName: String) {
    val ok = app.appIntelligenceProvider.openAppSettings(packageName)
    logAudit(
      category = "אפליקציות",
      title = "פרטי האפליקציה: $appName",
      succeeded = ok,
      details = if (ok) "נפתח מסך הפרטים ב-Android" else "שגיאה בפתיחת מסך ההגדרות",
      failureReason = if (ok) null else "ActivityNotFoundException"
    )
  }

  fun onSafFolderGranted(uri: Uri) {
    viewModelScope.launch {
      prefs.addSafTreeUri(uri.toString())
      refreshTelemetry(recordSnapshot = false)
      logAudit(
        category = "ניקוי ואחסון",
        title = "הרשאת תיקייה (SAF)",
        succeeded = true,
        details = "אושרה גישה לתיקייה: ${uri.lastPathSegment ?: uri}"
      )
      startDeepCleanScan()
    }
  }

  fun removeSafFolder(uriString: String) {
    viewModelScope.launch {
      prefs.removeSafTreeUri(uriString)
      refreshTelemetry(recordSnapshot = false)
      startDeepCleanScan()
    }
  }

  // 8-Step Deep Clean Workflow
  fun startDeepCleanScan() {
    viewModelScope.launch {
      _deepCleanState.update {
        it.copy(
          phase = DeepCleanPhase.SCANNING,
          executionResult = null,
          postCleanScanResult = null,
          statusMessage = "סורק מטמון, תיקיות מאושרות וקבצים כפולים..."
        )
      }
      runCatching {
        val uris = prefs.safTreeUrisFlow.first()
        delay(550)
        val result = app.deepCleanEngine.scanSystem(uris)
        val defaultSelected =
          result.candidates
            .filter { it.isDirectDeletable && it.selectedByDefault }
            .map { it.id }
            .toSet()

        _deepCleanState.update {
          it.copy(
            phase = DeepCleanPhase.RESULTS_READY,
            scanResult = result,
            selectedIds = defaultSelected,
            statusMessage =
              "הסריקה הושלמה: זוהו ${formatBytes(result.directReclaimableBytes)} הניתנים לניקוי ישיר."
          )
        }
      }.onFailure { err ->
        if (err is CancellationException) throw err
        _deepCleanState.update {
          it.copy(phase = DeepCleanPhase.IDLE, statusMessage = "הסריקה הופסקה עקב שגיאה.")
        }
        _centralError.value =
          NexusAppError(
            source = "deep_clean",
            messageHe = "סריקת האחסון נכשלה: ${err.localizedMessage ?: "שגיאת מערכת"}",
            canRetry = true
          )
      }
    }
  }

  fun toggleCleanCandidate(id: String) {
    _deepCleanState.update { state ->
      val current = state.selectedIds
      val updated = if (id in current) current - id else current + id
      state.copy(selectedIds = updated)
    }
  }

  fun requestCleanConfirmation() {
    val state = _deepCleanState.value
    val selected = state.scanResult?.candidates?.filter { it.id in state.selectedIds }.orEmpty()
    if (selected.isEmpty()) {
      _uiBannerMessage.value = "לא נבחרו פריטים הניתנים לניקוי ישיר. סמן פריטים או פתח תיקייה לסריקה."
      return
    }
    _deepCleanState.update { it.copy(phase = DeepCleanPhase.AWAITING_CONFIRMATION) }
  }

  fun cancelCleanConfirmation() {
    _deepCleanState.update { it.copy(phase = DeepCleanPhase.RESULTS_READY) }
  }

  fun executeConfirmedClean() {
    viewModelScope.launch {
      val scan = _deepCleanState.value.scanResult ?: return@launch
      val selectedIds = _deepCleanState.value.selectedIds
      val selectedItems = scan.candidates.filter { it.id in selectedIds }

      _deepCleanState.update {
        it.copy(phase = DeepCleanPhase.CLEANING, statusMessage = "מבצע ניקוי אמיתי ובודק שחרור מקום...")
      }
      delay(550)

      runCatching {
        val execResult = app.deepCleanEngine.executeClean(selectedItems)
        val uris = prefs.safTreeUrisFlow.first()
        val postScan = app.deepCleanEngine.scanSystem(uris)

        val now = System.currentTimeMillis()
        prefs.updateLastMaintenanceMillis(now)

        db.cleanHistoryDao().insert(
          CleanHistoryEntity(
            timestampMillis = now,
            itemsDeleted = execResult.deletedCount,
            itemsFailed = execResult.failedCount,
            bytesFreed = execResult.storageDeltaBytes,
            freeBeforeBytes = execResult.freeBeforeBytes,
            freeAfterBytes = execResult.freeAfterBytes,
            summary =
              "נמחקו ${execResult.deletedCount} פריטים; שוחררו בפועל ${formatBytes(execResult.storageDeltaBytes)}",
            failureReason = execResult.failureReasons.firstOrNull()
          )
        )

        logAudit(
          category = "ניקוי מערכת",
          title = "הרצת CLEAN ALL",
          succeeded = execResult.deletedCount > 0 || execResult.failedCount == 0,
          details = "נמחקו ${execResult.deletedCount}, התפנו ${formatBytes(execResult.storageDeltaBytes)}",
          failureReason = execResult.failureReasons.firstOrNull()
        )

        _deepCleanState.update {
          it.copy(
            phase = DeepCleanPhase.COMPLETED,
            executionResult = execResult,
            postCleanScanResult = postScan,
            statusMessage = "הניקוי הושלם! התפנו בפועל ${formatBytes(execResult.storageDeltaBytes)}."
          )
        }
        refreshTelemetry(recordSnapshot = true)
      }.onFailure { err ->
        if (err is CancellationException) throw err
        _deepCleanState.update { it.copy(phase = DeepCleanPhase.RESULTS_READY) }
        _centralError.value =
          NexusAppError(
            source = "deep_clean",
            messageHe = "שגיאה במהלך הניקוי: ${err.localizedMessage ?: "לא ניתן להשלים"}",
            canRetry = true
          )
      }
    }
  }

  fun openSystemShortcut(id: SystemShortcutId) {
    val outcome = app.systemControlHelper.openShortcut(id)
    logAudit(
      category = "שליטת מערכת",
      title = "קיצור דרך: ${id.name}",
      succeeded = outcome.succeeded,
      details = outcome.message,
      failureReason = outcome.failureReason
    )
    if (!outcome.succeeded) {
      _uiBannerMessage.value = outcome.message
    }
  }

  // Smart Assistant (Cloud Gemini 3.8 Flash + Local Rule Engine Fallback)
  fun setListeningState(listening: Boolean) {
    _assistantState.update {
      it.copy(
        isListening = listening,
        robotMood = if (listening) RobotMood.LISTENING else RobotMood.IDLE
      )
    }
  }

  fun sendAssistantCommand(inputText: String, forceLocalFallback: Boolean = false) {
    val trimmed = inputText.trim()
    if (trimmed.isBlank()) return
    if (!isAssistantRequestInFlight.compareAndSet(false, true)) {
      _uiBannerMessage.value = "העוזר מעבד כרגע את הבקשה הקודמת..."
      return
    }

    viewModelScope.launch {
      try {
        _assistantState.update {
          it.copy(
            isThinking = true,
            robotMood = RobotMood.THINKING,
            aiError = null,
            lastFailedInput = null
          )
        }

        // Capture prior turns deterministically BEFORE inserting current user turn (prevents StateFlow race/duplication)
        val priorTurns =
          db.assistantMessageDao().getRecentOnce(limit = 10).map { it.isUser to it.text }

        if (!forceLocalFallback) {
          db.assistantMessageDao().insert(
            AssistantMessageEntity(
              timestampMillis = System.currentTimeMillis(),
              isUser = true,
              text = trimmed
            )
          )
          val memResult =
            app.memoryManager.maybeExtractFromUserMessage(
              userMessage = trimmed,
              autoSaveEnabled = memoryAutoSaveEnabled.value
            )
          if (memResult is MemorySaveResult.BlockedSecret) {
            _uiBannerMessage.value = memResult.reasonHe
          } else if (memResult is MemorySaveResult.Saved) {
            _uiBannerMessage.value = "נשמר בזיכרון ארוך טווח: ${memResult.entry.title}"
          }
        }

        val folders = prefs.safTreeUrisFlow.first()
        val freshTelemetry = app.telemetryProvider.captureTelemetry(folders.size)
        _telemetry.value = freshTelemetry
        val memoryContext = app.memoryManager.buildContextForPrompt(maxEntries = 8)

        // Check Aiko Natural-Language Personal Life / NL Automation / Guardrails first
        val aikoDecision =
          if (!forceLocalFallback) {
            AikoBrainEngine.interpret(
              rawInput = trimmed,
              lifeItems = lifeItems.value,
              telemetry = freshTelemetry,
              apps = _appsState.value.allApps,
              securityReport = _securityReport.value,
              customAutomations = automations.value
            )
          } else {
            AikoLocalResult.DelegateToCloudOrSystem
          }

        if (aikoDecision !is AikoLocalResult.DelegateToCloudOrSystem) {
          val reply =
            when (aikoDecision) {
              is AikoLocalResult.AddLifeItem -> {
                val d = aikoDecision.draft
                val now = System.currentTimeMillis()
                db.lifeItemDao().insert(
                  LifeItemEntity(
                    kind = d.itemType.name,
                    title = d.title,
                    details = d.details,
                    categoryTag = d.categoryTag,
                    priority = d.priority.name,
                    repeatIntervalHours = d.repeatIntervalDays * 24,
                    createdAtMillis = now,
                    updatedAtMillis = now
                  )
                )
                aikoDecision.reply
              }
              is AikoLocalResult.CompleteLifeItem -> {
                val q = aikoDecision.matchQuery.lowercase()
                val match =
                  lifeItems.value.firstOrNull { !it.isCompleted && it.title.lowercase().contains(q) }
                if (match != null) {
                  db.lifeItemDao().setCompleted(match.id, true, 100, System.currentTimeMillis())
                  aikoDecision.reply.copy(
                    replyText = "סימנתי כהושלמה: \"${match.title}\".",
                    pendingAction =
                      PendingAssistantAction(
                        actionType = AssistantActionType.OPEN_PERSONAL_LIFE,
                        title = "פתח מנהל חיים אישיים",
                        description = "צפייה ברשימה המעודכנת.",
                        requiresConfirmation = false
                      )
                  )
                } else {
                  aikoDecision.reply.copy(
                    replyText = "לא מצאתי משימה פתוחה התואמת ל-\"${aikoDecision.matchQuery}\". פתח את מנהל החיים האישיים לבדיקה.",
                    pendingAction =
                      PendingAssistantAction(
                        actionType = AssistantActionType.OPEN_PERSONAL_LIFE,
                        title = "פתח מנהל חיים אישיים",
                        description = "בדיקת כל המשימות והתזכורות.",
                        requiresConfirmation = false
                      )
                  )
                }
              }
              is AikoLocalResult.ProposeAutomation -> {
                if (aikoDecision.proposal.isFeasible) {
                  val p = aikoDecision.proposal
                  val cleanHours = p.scheduleIntervalHours.coerceAtLeast(0)
                  val autoEntity =
                    AutomationEntity(
                      name = p.name,
                      voicePhrase = p.voicePhrase,
                      description = p.steps.joinToString(" ← ") { it.titleHe } + " (${p.triggerNoteHe})",
                      stepsSerialized = p.steps.joinToString(",") { it.name },
                      isBuiltIn = false,
                      scheduleIntervalHours = cleanHours
                    )
                  val insertedId = db.automationDao().insert(autoEntity)
                  if (cleanHours > 0) {
                    val schedRes =
                      withContext(Dispatchers.IO) {
                        NexusWorkScheduler.syncScheduledAutomation(app, autoEntity.copy(id = insertedId))
                      }
                    logAudit(
                      category = "אוטומציות",
                      title = "תזמון AI: ${p.name}",
                      succeeded = schedRes.succeeded,
                      details =
                        if (schedRes.succeeded) "תוזמנה כל $cleanHours שעות (${schedRes.workName})"
                        else (schedRes.errorHe ?: "כשל בתזמון"),
                      failureReason = schedRes.errorHe
                    )
                    val note = schedRes.errorHe ?: schedRes.warningHe
                    if (note != null) {
                      _uiBannerMessage.value = note
                      aikoDecision.reply.copy(
                        replyText = "${aikoDecision.reply.replyText}\n\nשימו לב: $note"
                      )
                    } else {
                      aikoDecision.reply
                    }
                  } else {
                    aikoDecision.reply
                  }
                } else {
                  aikoDecision.reply
                }
              }
              is AikoLocalResult.DirectReply -> aikoDecision.reply
              AikoLocalResult.DelegateToCloudOrSystem -> error("unreachable")
            }

          val formatted =
            if (reply.plannedSteps.isNotEmpty()) {
              reply.replyText +
                "\n\nצעדים:\n" +
                reply.plannedSteps.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n")
            } else {
              reply.replyText
            }
          db.assistantMessageDao().insert(
            AssistantMessageEntity(
              timestampMillis = System.currentTimeMillis(),
              isUser = false,
              text = formatted,
              actionTag = reply.actionTag
            )
          )
          _assistantState.update {
            it.copy(
              isThinking = false,
              robotMood = if (reply.pendingAction != null) RobotMood.ALERT else RobotMood.SUCCESS,
              pendingAction = reply.pendingAction,
              lastPlannedSteps = reply.plannedSteps,
              lastProviderLabel = "אייקו • מוח שפה טבעית",
              aiError = null,
              lastFailedInput = null
            )
          }
          if (ttsEnabled.value) app.assistantEngine.speak(reply.replyText)
          return@launch
        }

        // Parameterized File / SAF Tool Engine for Aiko (Steps 1-5: parse, validate, plan, request confirmation)
        val parsedFileParams =
          if (!forceLocalFallback) NexusAikoToolEngine.parseFileToolParameters(trimmed) else null
        if (parsedFileParams != null) {
          val t0Tool = System.currentTimeMillis()
          val currentReport =
            if (smartStorageReport.value == null && folders.isNotEmpty()) {
              runCatching {
                commander.runFullDeviceScan(
                  telemetry = freshTelemetry,
                  apps = _appsState.value.allApps,
                  securityReport = _securityReport.value,
                  snapshots = telemetrySnapshots.value,
                  cloudAiEnabled = false,
                  shareTelemetryWithAi = false,
                  includeAiInsights = false
                )
              }.getOrNull()
            } else {
              smartStorageReport.value
            }
          val plan =
            NexusAikoToolEngine.resolveFileToolPlan(
              params = parsedFileParams,
              safTreeUris = folders,
              report = currentReport
            )
          val toolLatency = (System.currentTimeMillis() - t0Tool).coerceAtLeast(1L)
          val pendingAction =
            when {
              plan.proposalDraft != null ->
                PendingAssistantAction(
                  actionType = AssistantActionType.STAGE_AIKO_FILE_PROPOSAL,
                  title = plan.proposalDraft.title,
                  description = plan.proposalDraft.expectedOutcomeHe,
                  requiresConfirmation = true,
                  stagedProposalDraft = plan.proposalDraft
                )
              parsedFileParams.operation == AikoRequestedOperation.CLEAN_STORAGE ->
                PendingAssistantAction(
                  actionType = AssistantActionType.REQUEST_START_CLEAN,
                  title = "הפעל סריקת ניקוי חכמה",
                  description = "פתיחת סריקה ובחירה לפני ניקוי",
                  requiresConfirmation = true
                )
              parsedFileParams.operation == AikoRequestedOperation.FIND_SCAN && plan.rejectionReasonHe != null ->
                PendingAssistantAction(
                  actionType = AssistantActionType.NAVIGATE_SMART_STORAGE,
                  title = "פתח אחסון חכם להרשאת SAF",
                  description = "בחר תיקייה או כרטיס SD לסריקה.",
                  requiresConfirmation = false
                )
              else -> null
            }

          app.learningEngine.recordToolRun(
            toolId = plan.selectedTool.id,
            toolNameHe = plan.selectedTool.nameHe,
            succeeded = plan.rejectionReasonHe == null,
            latencyMs = toolLatency,
            summaryHe = trimmed.take(60),
            errorHe = plan.rejectionReasonHe
          )

          val formattedPlan =
            if (plan.plannedStepsHe.isNotEmpty()) {
              plan.summaryReplyHe + "\n\nצעדים:\n" + plan.plannedStepsHe.joinToString("\n")
            } else {
              plan.summaryReplyHe
            }
          db.assistantMessageDao().insert(
            AssistantMessageEntity(
              timestampMillis = System.currentTimeMillis(),
              isUser = false,
              text = formattedPlan,
              actionTag = "AIKO_TOOL_${parsedFileParams.operation.name}"
            )
          )
          _assistantState.update {
            it.copy(
              isThinking = false,
              robotMood =
                when {
                  plan.rejectionReasonHe != null || pendingAction != null -> RobotMood.ALERT
                  else -> RobotMood.SUCCESS
                },
              pendingAction = pendingAction,
              lastPlannedSteps = plan.plannedStepsHe,
              lastProviderLabel = "אייקו • מנוע כלים SAF",
              aiError = null,
              lastFailedInput = null
            )
          }
          if (ttsEnabled.value) app.assistantEngine.speak(plan.summaryReplyHe)
          return@launch
        }

        val useCloud =
          !forceLocalFallback && cloudAiEnabled.value && freshTelemetry.network.isConnected
        if (!forceLocalFallback && cloudAiEnabled.value && !freshTelemetry.network.isConnected) {
          app.connectivityMonitor.queueForControlledSync(
            id = "offline_query_${trimmed.hashCode()}",
            labelHe = "שאילתת ענן שממתינה לחיבור: ${trimmed.take(36)}"
          )
        }

        val t0 = System.currentTimeMillis()
        if (useCloud) {
          val result =
            app.aiProvider.generateAssistantResponse(
              userInput = trimmed,
              recentHistory = priorTurns,
              telemetry = freshTelemetry,
              apps = _appsState.value.allApps,
              securityReport = _securityReport.value,
              customAutomations = automations.value,
              allowDeviceContextSharing = shareTelemetryWithAi.value,
              memoryContext = memoryContext
            )
          val lat = (System.currentTimeMillis() - t0).coerceAtLeast(1L)

          result.fold(
            onSuccess = { aiReply ->
              app.learningEngine.recordToolRun(
                toolId = "cloud_gemini_ai",
                toolNameHe = "ספק ענן Firebase AI Logic",
                succeeded = true,
                latencyMs = lat,
                summaryHe = trimmed.take(60)
              )
              val formattedReply =
                if (aiReply.plannedSteps.isNotEmpty()) {
                  aiReply.replyText +
                    "\n\nתוכנית פעולה:\n" +
                    aiReply.plannedSteps.mapIndexed { i, step -> "${i + 1}. $step" }.joinToString("\n")
                } else {
                  aiReply.replyText
                }

              db.assistantMessageDao().insert(
                AssistantMessageEntity(
                  timestampMillis = System.currentTimeMillis(),
                  isUser = false,
                  text = formattedReply,
                  actionTag = aiReply.actionTag
                )
              )
              _assistantState.update {
                it.copy(
                  isThinking = false,
                  robotMood = if (aiReply.pendingAction != null) RobotMood.ALERT else RobotMood.IDLE,
                  pendingAction = aiReply.pendingAction,
                  lastPlannedSteps = aiReply.plannedSteps,
                  lastProviderLabel = aiReply.providerName,
                  aiError = null,
                  lastFailedInput = null
                )
              }
              if (ttsEnabled.value) {
                app.assistantEngine.speak(aiReply.replyText)
              }
            },
            onFailure = { err ->
              if (err is CancellationException) throw err
              val mapped = NexusAiErrorMapper.toHebrewError("gemini-3.8-flash", err)
              app.learningEngine.recordToolRun(
                toolId = "cloud_gemini_ai",
                toolNameHe = "ספק ענן Firebase AI Logic",
                succeeded = false,
                latencyMs = lat,
                summaryHe = trimmed.take(60),
                errorHe = mapped.messageHe
              )
              logAudit(
                category = "בינה מלאכותית",
                title = "שאילתת Gemini Assistant",
                succeeded = false,
                details = trimmed.take(60),
                failureReason = mapped.messageHe
              )
              _assistantState.update {
                it.copy(
                  isThinking = false,
                  robotMood = RobotMood.ALERT,
                  aiError = mapped,
                  lastFailedInput = trimmed
                )
              }
            }
          )
        } else {
          val reply =
            app.assistantEngine.processCommand(
              rawInput = trimmed,
              telemetry = freshTelemetry,
              apps = _appsState.value.allApps,
              securityReport = _securityReport.value,
              customAutomations = automations.value
            )
          val lat = (System.currentTimeMillis() - t0).coerceAtLeast(1L)
          app.learningEngine.recordToolRun(
            toolId = "task_orchestrator",
            toolNameHe = "מנוע פקודות ותזמור מקומי",
            succeeded = true,
            latencyMs = lat,
            summaryHe = trimmed.take(60)
          )
          val formattedReply =
            if (reply.plannedSteps.isNotEmpty()) {
              reply.replyText +
                "\n\nתוכנית פעולה מקומית:\n" +
                reply.plannedSteps.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n")
            } else {
              reply.replyText
            }
          db.assistantMessageDao().insert(
            AssistantMessageEntity(
              timestampMillis = System.currentTimeMillis(),
              isUser = false,
              text = formattedReply,
              actionTag = reply.actionTag
            )
          )
          _assistantState.update {
            it.copy(
              isThinking = false,
              robotMood = if (reply.pendingAction != null) RobotMood.ALERT else RobotMood.IDLE,
              pendingAction = reply.pendingAction,
              lastPlannedSteps = reply.plannedSteps,
              lastProviderLabel =
                if (!freshTelemetry.network.isConnected) "מנוע מקומי (Offline)"
                else "מנוע מקומי",
              aiError = null,
              lastFailedInput = null
            )
          }
          if (ttsEnabled.value) {
            app.assistantEngine.speak(reply.replyText)
          }
        }
      } finally {
        isAssistantRequestInFlight.set(false)
      }
    }
  }

  fun dismissAssistantAiError() {
    _assistantState.update { it.copy(aiError = null, lastFailedInput = null, robotMood = RobotMood.IDLE) }
  }

  // Audio Transcription using gemini-3.5-transcribe
  fun startAudioTranscriptionRecording() {
    app.assistantEngine.stopSpeaking()
    val startRes =
      app.audioRecorder.startRecording(
        noiseSuppressionEnabled = noiseSuppressionEnabled.value
      ) { autoWav ->
        viewModelScope.launch { processWavTranscription(autoWav) }
      }
    startRes.onFailure { err ->
      val mapped = NexusAiErrorMapper.toHebrewError("gemini-3.5-transcribe", err)
      _transcriptionState.value = TranscriptionUiState.Error(mapped)
      return
    }

    recordingObserverJob?.cancel()
    recordingObserverJob =
      viewModelScope.launch {
        combine(app.audioRecorder.elapsedSeconds, app.audioRecorder.amplitude) { sec, amp ->
            sec to amp
          }
          .collect { (sec, amp) ->
            if (app.audioRecorder.isRecording.value) {
              _transcriptionState.value = TranscriptionUiState.Recording(sec, amp)
            }
          }
      }
  }

  fun stopAndTranscribeAudio() {
    viewModelScope.launch {
      recordingObserverJob?.cancel()
      recordingObserverJob = null
      _transcriptionState.value = TranscriptionUiState.Processing
      val wavBytes = app.audioRecorder.stopAndBuildWav()
      if (wavBytes.size <= 44) {
        _transcriptionState.value =
          TranscriptionUiState.Error(
            NexusAppError(
              source = "gemini-3.5-transcribe",
              messageHe = "לא נקלט שמע במיקרופון. נסה להקליט שוב בקול ברור.",
              canRetry = true
            )
          )
        return@launch
      }
      lastRecordedAudioForRetry = wavBytes
      processWavTranscription(wavBytes)
    }
  }

  fun retryLastTranscription() {
    val wav = lastRecordedAudioForRetry ?: return
    viewModelScope.launch {
      _transcriptionState.value = TranscriptionUiState.Processing
      processWavTranscription(wav)
    }
  }

  private suspend fun processWavTranscription(wavBytes: ByteArray) {
    if (!isAudioTranscribeInFlight.compareAndSet(false, true)) return
    try {
      _transcriptionState.value = TranscriptionUiState.Processing
      val res = app.aiProvider.transcribeAudio(wavBytes, mimeType = "audio/wav", languageHint = "he-IL")
      res.fold(
        onSuccess = { text ->
          lastRecordedAudioForRetry = null
          _transcriptionState.value = TranscriptionUiState.Success(text = text)
          logAudit(
            category = "תמלול קולי",
            title = "תמלול באמצעות gemini-3.5-transcribe",
            succeeded = true,
            details = "תומלל (${text.length} תווים)"
          )
        },
        onFailure = { err ->
          if (err is CancellationException) throw err
          val mapped = NexusAiErrorMapper.toHebrewError("gemini-3.5-transcribe", err)
          _transcriptionState.value = TranscriptionUiState.Error(mapped)
          logAudit(
            category = "תמלול קולי",
            title = "תמלול באמצעות gemini-3.5-transcribe",
            succeeded = false,
            details = "כישלון תמלול",
            failureReason = mapped.messageHe
          )
        }
      )
    } finally {
      isAudioTranscribeInFlight.set(false)
    }
  }

  fun cancelAudioTranscription() {
    viewModelScope.launch {
      recordingObserverJob?.cancel()
      recordingObserverJob = null
      app.audioRecorder.cancelRecording()
      _transcriptionState.value = TranscriptionUiState.Idle
    }
  }

  fun resetTranscriptionState() {
    _transcriptionState.value = TranscriptionUiState.Idle
  }

  // Real-Time Voice Conversation using gemini-3.8-live
  fun startLiveVoiceConversation() {
    app.assistantEngine.stopSpeaking()
    viewModelScope.launch {
      val folders = prefs.safTreeUrisFlow.first()
      val freshTelemetry = app.telemetryProvider.captureTelemetry(folders.size)
      _telemetry.value = freshTelemetry

      val res =
        app.aiProvider.startLiveVoiceConversation(
          telemetry = freshTelemetry,
          apps = _appsState.value.allApps,
          securityReport = _securityReport.value,
          allowDeviceContextSharing = shareTelemetryWithAi.value
        )
      res.onFailure { err ->
        if (err is CancellationException) throw err
        val mapped = NexusAiErrorMapper.toHebrewError("gemini-3.8-live", err)
        logAudit(
          category = "שיחה קולית חיה",
          title = "חיבור ל-gemini-3.8-live",
          succeeded = false,
          details = "חיבור שיחה חיה נכשל",
          failureReason = mapped.messageHe
        )
      }
      res.onSuccess {
        logAudit(
          category = "שיחה קולית חיה",
          title = "הופעלה שיחה חיה ב-gemini-3.8-live",
          succeeded = true,
          details = "ערוץ אודיו דו-כיווני פתוח"
        )
      }
    }
  }

  fun stopLiveVoiceConversation() {
    viewModelScope.launch {
      app.aiProvider.stopLiveVoiceConversation()
    }
  }

  fun sendLiveTextMessage(text: String) {
    val clean = text.trim()
    if (clean.isBlank()) return
    viewModelScope.launch {
      app.aiProvider.sendTextToLiveSession(clean).onFailure { err ->
        if (err is CancellationException) throw err
        _uiBannerMessage.value = NexusAiErrorMapper.toHebrewError("gemini-3.8-live", err).messageHe
      }
    }
  }

  fun clearAssistantHistory() {
    viewModelScope.launch {
      db.assistantMessageDao().clearAll()
      seedWelcomeChatIfNeeded()
      _assistantState.update { it.copy(lastPlannedSteps = emptyList(), aiError = null) }
    }
  }

  // Multimodal Image / Screenshot Diagnostics using PickVisualMedia + gemini-3.8-flash
  fun analyzeDiagnosticImageUri(uri: Uri, userQuestion: String) {
    viewModelScope.launch {
      if (!cloudAiEnabled.value) {
        _visualDiagnosisState.value =
          VisualDiagnosisUiState.Error(
            NexusAppError(
              source = "gemini-3.8-flash-vision",
              messageHe = "מצב ענן AI כבוי כרגע. הפעל 'Gemini AI' כדי לנתח תמונות וצילומי מסך.",
              canRetry = false
            )
          )
        return@launch
      }
      _visualDiagnosisState.value = VisualDiagnosisUiState.Analyzing
      val bitmap = decodeDownsampledBitmap(uri)
      if (bitmap == null) {
        _visualDiagnosisState.value =
          VisualDiagnosisUiState.Error(
            NexusAppError(
              source = "image_decode",
              messageHe = "לא ניתן לקרוא את קובץ התמונה שנבחר. נסה תמונה או צילום מסך אחר.",
              canRetry = true
            )
          )
        return@launch
      }

      val folders = prefs.safTreeUrisFlow.first()
      val freshTelemetry = app.telemetryProvider.captureTelemetry(folders.size)
      _telemetry.value = freshTelemetry

      val result =
        try {
          app.aiProvider.analyzeDiagnosticImage(
            bitmap = bitmap,
            userQuestion = userQuestion,
            telemetry = freshTelemetry,
            allowDeviceContextSharing = shareTelemetryWithAi.value
          )
        } finally {
          if (!bitmap.isRecycled) {
            runCatching { bitmap.recycle() }
          }
        }

      result.fold(
        onSuccess = { reply ->
          _visualDiagnosisState.value =
            VisualDiagnosisUiState.Success(reply = reply, analyzedAtMillis = System.currentTimeMillis())
          logAudit(
            category = "אבחון תמונה AI",
            title = "ניתוח צילום מסך ב-gemini-3.8-flash",
            succeeded = true,
            details = reply.replyText.take(80)
          )
        },
        onFailure = { err ->
          if (err is CancellationException) throw err
          val mapped = NexusAiErrorMapper.toHebrewError("gemini-3.8-flash-vision", err)
          _visualDiagnosisState.value = VisualDiagnosisUiState.Error(mapped)
          logAudit(
            category = "אבחון תמונה AI",
            title = "ניתוח צילום מסך ב-gemini-3.8-flash",
            succeeded = false,
            details = "נכשל ניתוח תמונה",
            failureReason = mapped.messageHe
          )
        }
      )
    }
  }

  fun clearVisualDiagnosis() {
    _visualDiagnosisState.value = VisualDiagnosisUiState.Idle
  }

  private suspend fun decodeDownsampledBitmap(uri: Uri): Bitmap? =
    withContext(Dispatchers.IO) {
      runCatching {
        val optsBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        app.contentResolver.openInputStream(uri)?.use { stream ->
          BitmapFactory.decodeStream(stream, null, optsBounds)
        }
        val maxSide = maxOf(optsBounds.outWidth, optsBounds.outHeight)
        var sampleSize = 1
        while (maxSide / sampleSize > 1600) {
          sampleSize *= 2
        }
        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        app.contentResolver.openInputStream(uri)?.use { stream ->
          BitmapFactory.decodeStream(stream, null, decodeOpts)
        }
      }.getOrNull()
    }

  fun runCloudHealthCheck() {
    viewModelScope.launch {
      _cloudHealthCheckState.value = CloudHealthCheckState.Checking
      val result = app.aiProvider.runCloudHealthCheck()
      _cloudHealthCheckState.value = result
      when (result) {
        is CloudHealthCheckState.Healthy ->
          logAudit(
            category = "תקינות ענן AI",
            title = "בדיקת App Check ו-Gemini",
            succeeded = true,
            details = result.summaryHe
          )
        is CloudHealthCheckState.Unhealthy ->
          logAudit(
            category = "תקינות ענן AI",
            title = "בדיקת App Check ו-Gemini",
            succeeded = false,
            details = "בדיקת ענן נכשלה (${result.latencyMs} מ״ש)",
            failureReason = result.error.messageHe
          )
        else -> Unit
      }
    }
  }

  fun runComprehensiveAiDiagnostics() {
    viewModelScope.launch {
      _aiDiagnosticsReport.value =
        AiSystemDiagnosticsReport(
          checkedAtMillis = System.currentTimeMillis(),
          isChecking = true,
          appCheckStatusHe = "בודק אימות App Check והתקנת ספקים...",
          keySecuritySummaryHe = "סורק אבטחת מפתחות...",
          privacyGuardSummaryHe = "בודק הגדרות פרטיות...",
          injectionProtectionSummaryHe = "בודק שכבת הגנה...",
          fallbackPolicySummaryHe = "בודק שרשרת גיבוי חינמית...",
          rateLimiterUsageSummaryHe = "בודק מגבלות קצב..."
        )
      val folders = prefs.safTreeUrisFlow.first()
      val freshTelemetry = app.telemetryProvider.captureTelemetry(folders.size)
      _telemetry.value = freshTelemetry
      val report =
        app.aiProvider.runComprehensiveAiDiagnostics(
          isNetworkConnected = freshTelemetry.network.isConnected,
          shareTelemetryWithAi = shareTelemetryWithAi.value
        )
      _aiDiagnosticsReport.value = report
      logAudit(
        category = "אבחון מערכת AI",
        title = "בדיקת עומק למודלים ו-App Check",
        succeeded = true,
        details = "נבדקו ${report.models.size} מודלים ותצורות אבטחה"
      )
    }
  }

  fun dismissAssistantAction() {
    _assistantState.update { it.copy(pendingAction = null, robotMood = RobotMood.IDLE) }
  }

  fun confirmAssistantAction(action: PendingAssistantAction) {
    _assistantState.update { it.copy(pendingAction = null, robotMood = RobotMood.SUCCESS) }
    when (action.actionType) {
      AssistantActionType.RUN_SYSTEM_CHECK -> refreshTelemetry(recordSnapshot = true)
      AssistantActionType.NAVIGATE_DEEP_CLEAN -> _navigateEvent.value = "deep_clean"
      AssistantActionType.REQUEST_START_CLEAN -> {
        _navigateEvent.value = "deep_clean"
        startDeepCleanScan()
      }
      AssistantActionType.NAVIGATE_APPS_BY_SIZE -> {
        updateAppSort(AppSortMode.SIZE_DESC)
        _navigateEvent.value = "apps"
      }
      AssistantActionType.NAVIGATE_SECURITY -> _navigateEvent.value = "security"
      AssistantActionType.NAVIGATE_BATTERY -> _navigateEvent.value = "battery"
      AssistantActionType.OPEN_BATTERY_SETTINGS -> openSystemShortcut(SystemShortcutId.BATTERY)
      AssistantActionType.OPEN_INTERNET_SETTINGS -> openSystemShortcut(SystemShortcutId.WIFI)
      AssistantActionType.OPEN_STORAGE_SETTINGS -> openSystemShortcut(SystemShortcutId.STORAGE)
      AssistantActionType.RUN_AUTOMATION -> {
        val target = automations.value.firstOrNull { it.id == action.automationId }
        if (target != null) {
          executeAutomation(target)
        } else {
          _uiBannerMessage.value = "האוטומציה המבוקשת לא נמצאה. ניתן להריץ אותה ממסך האוטומציות."
        }
      }
      AssistantActionType.NAVIGATE_SMART_STORAGE,
      AssistantActionType.CHECK_SD_CARD -> {
        _navigateEvent.value = "smart_storage"
        runFullDeviceScan()
      }
      AssistantActionType.NAVIGATE_AI_FILE_MANAGER -> _navigateEvent.value = "ai_file_manager"
      AssistantActionType.NAVIGATE_DEVICE_DOCTOR -> _navigateEvent.value = "device_doctor"
      AssistantActionType.NAVIGATE_APPROVAL_CENTER -> _navigateEvent.value = "approval_center"
      AssistantActionType.STAGE_DUPLICATE_VIDEOS_PROPOSALS -> stageDuplicateVideoProposals(navigateToApprovals = true)
      AssistantActionType.STAGE_DOWNLOADS_ORGANIZE_PROPOSALS -> stageDownloadsOrganizeProposals(navigateToApprovals = true)
      AssistantActionType.STAGE_CLEANUP_PLAN_PROPOSALS -> stageCleanupPlanProposals(navigateToApprovals = true)
      AssistantActionType.OPEN_DOWNLOADS_MANAGER -> _navigateEvent.value = NexusDestination.DOWNLOADS_MANAGER.route
      AssistantActionType.OPEN_PERSONAL_LIFE -> _navigateEvent.value = NexusDestination.PERSONAL_LIFE.route
      AssistantActionType.OPEN_ACCOUNTS_HUB -> _navigateEvent.value = NexusDestination.ACCOUNTS_HUB.route
      AssistantActionType.OPEN_SELF_DIAGNOSTICS -> {
        _navigateEvent.value = NexusDestination.SELF_DIAGNOSTICS.route
        runSelfDiagnostics()
      }
      AssistantActionType.STAGE_AIKO_FILE_PROPOSAL -> {
        val draft = action.stagedProposalDraft ?: return
        _assistantState.update { it.copy(isThinking = true, robotMood = RobotMood.THINKING) }
        viewModelScope.launch {
          val insertedId = db.approvalProposalDao().insert(AiFileCommanderEngine.toPendingEntity(draft))
          val entity = db.approvalProposalDao().getById(insertedId)
          if (entity == null) {
            _assistantState.update { it.copy(isThinking = false, robotMood = RobotMood.ALERT) }
            _uiBannerMessage.value = "לא ניתן לטעון את הצעת הפעולה מהמסד."
            return@launch
          }
          val (ok, msg) = commander.approveAndExecuteProposal(entity)
          var verificationLine = ""
          if (ok) {
            refreshTelemetry(recordSnapshot = false)
            if (safTreeUris.value.isNotEmpty()) {
              val refreshed =
                runCatching {
                  commander.runFullDeviceScan(
                    telemetry = _telemetry.value,
                    apps = _appsState.value.allApps,
                    securityReport = _securityReport.value,
                    snapshots = telemetrySnapshots.value,
                    cloudAiEnabled = false,
                    shareTelemetryWithAi = false,
                    includeAiInsights = false
                  )
                }.getOrNull()
              if (refreshed != null) {
                val verifiedName =
                  when (draft.operationType) {
                    ApprovalOperationType.RENAME_SAF_DOCUMENT -> draft.proposedNewName ?: draft.targetName
                    else -> draft.targetName
                  }
                val existsInSaf =
                  refreshed.files.any { it.name.equals(verifiedName, ignoreCase = true) }
                verificationLine =
                  if (draft.operationType == ApprovalOperationType.DELETE_SAF_DOCUMENT) {
                    if (!existsInSaf) "\nאימות SAF: הקובץ '${draft.targetName}' הוסר מהתיקייה המאושרת."
                    else "\nאזהרת אימות: שם קובץ דומה עדיין קיים ב-SAF — בדוק במסך האחסון."
                  } else {
                    if (existsInSaf) "\nאימות SAF: הקובץ '$verifiedName' מאומת וזמין בסריקה המעודכנת."
                    else "\nאימות SAF: הפעולה הסתיימה, ייתכן שהקובץ ממוקם מחוץ לתיקיות שנסרקו."
                  }
              }
            }
          }
          val finalReply =
            if (ok) "הפעולה בוצעה בהצלחה: $msg$verificationLine"
            else "הפעולה לא הושלמה: $msg"
          db.assistantMessageDao().insert(
            AssistantMessageEntity(
              timestampMillis = System.currentTimeMillis(),
              isUser = false,
              text = finalReply,
              actionTag = if (ok) "AIKO_TOOL_VERIFIED_OK" else "AIKO_TOOL_FAILED"
            )
          )
          _uiBannerMessage.value = msg
          _assistantState.update {
            it.copy(
              isThinking = false,
              robotMood = if (ok) RobotMood.SUCCESS else RobotMood.ALERT
            )
          }
          if (ttsEnabled.value) app.assistantEngine.speak(finalReply)
        }
      }
      AssistantActionType.NONE -> Unit
    }
  }

  // ---- AI DEVICE COMMANDER ACTIONS ----

  fun runFullDeviceScan() {
    viewModelScope.launch {
      runCatching {
        val folders = prefs.safTreeUrisFlow.first()
        val freshTelemetry = app.telemetryProvider.captureTelemetry(folders.size)
        _telemetry.value = freshTelemetry
        val report =
          commander.runFullDeviceScan(
            telemetry = freshTelemetry,
            apps = _appsState.value.allApps,
            securityReport = _securityReport.value,
            snapshots = telemetrySnapshots.value,
            cloudAiEnabled = cloudAiEnabled.value,
            shareTelemetryWithAi = shareTelemetryWithAi.value
          )
        _uiBannerMessage.value =
          "הסריקה הושלמה: ${report.files.size} קבצים, ${report.duplicateGroups.size} כפילויות, ציון בריאות ${commander.deviceDoctorReport.value?.totalScore ?: freshTelemetry.healthScore}%."
      }.onFailure { err ->
        if (err is CancellationException) throw err
        _centralError.value =
          NexusAppError(
            source = "full_device_scan",
            messageHe = "סריקת המכשיר המלאה נכשלה: ${err.localizedMessage ?: "שגיאה"}",
            canRetry = true
          )
      }
    }
  }

  fun stageProposalDraft(draft: AiOrganizationProposalDraft, navigateToApprovals: Boolean = false) {
    viewModelScope.launch {
      val added = commander.stageDrafts(listOf(draft))
      _uiBannerMessage.value =
        if (added > 0) "הפעולה '${draft.title}' נוספה למרכז האישורים לבדיקתך."
        else "הצעה דומה כבר ממתינה במרכז האישורים."
      if (navigateToApprovals) _navigateEvent.value = "approval_center"
    }
  }

  fun stageAllAiOrganizationProposals() {
    val plan = aiOrgPlan.value ?: return
    viewModelScope.launch {
      val added = commander.stageDrafts(plan.proposals)
      _uiBannerMessage.value =
        if (added > 0) "הועברו $added הצעות למרכז האישורים. אף שינוי לא בוצע עדיין."
        else "כל ההצעות מהתוכנית כבר ממתינות לאישור."
      _navigateEvent.value = "approval_center"
    }
  }

  fun stageDuplicateVideoProposals(navigateToApprovals: Boolean = false) {
    viewModelScope.launch {
      val report =
        smartStorageReport.value
          ?: commander.runFullDeviceScan(
            _telemetry.value,
            _appsState.value.allApps,
            _securityReport.value,
            telemetrySnapshots.value,
            cloudAiEnabled.value,
            shareTelemetryWithAi.value
          )
      val drafts = AiFileCommanderEngine.draftsForDuplicateVideos(report)
      if (drafts.isEmpty()) {
        _uiBannerMessage.value =
          if (safTreeUris.value.isEmpty()) "בחר תחילה תיקיות או כרטיס SD בסריקת האחסון."
          else "לא נמצאו סרטונים כפולים בתיקיות שנסרקו."
      } else {
        val added = commander.stageDrafts(drafts)
        _uiBannerMessage.value = "אותרו והועברו $added הצעות של סרטונים כפולים למרכז האישורים."
        if (navigateToApprovals) _navigateEvent.value = "approval_center"
      }
    }
  }

  fun stageDownloadsOrganizeProposals(navigateToApprovals: Boolean = false) {
    viewModelScope.launch {
      val report =
        smartStorageReport.value
          ?: commander.runFullDeviceScan(
            _telemetry.value,
            _appsState.value.allApps,
            _securityReport.value,
            telemetrySnapshots.value,
            cloudAiEnabled.value,
            shareTelemetryWithAi.value
          )
      val plan = AiFileCommanderEngine.buildOrganizationPlan(report)
      val downloadDrafts =
        plan.proposals.filter {
          it.operationType == ApprovalOperationType.ORGANIZE_DOWNLOAD_FILE ||
            it.operationType == ApprovalOperationType.RENAME_SAF_DOCUMENT
        }
      val added = commander.stageDrafts(downloadDrafts)
      _uiBannerMessage.value =
        if (added > 0) "הוכנו $added הצעות ארגון להורדות ושמות קבצים במרכז האישורים."
        else "לא זוהו קבצים חדשים לסידור. ודא שהוספת את תיקיית ה-Downloads ב-SAF."
      if (navigateToApprovals) _navigateEvent.value = "approval_center"
    }
  }

  fun stageCleanupPlanProposals(navigateToApprovals: Boolean = false) {
    viewModelScope.launch {
      val report =
        smartStorageReport.value
          ?: commander.runFullDeviceScan(
            _telemetry.value,
            _appsState.value.allApps,
            _securityReport.value,
            telemetrySnapshots.value,
            cloudAiEnabled.value,
            shareTelemetryWithAi.value
          )
      val plan = AiFileCommanderEngine.buildOrganizationPlan(report)
      val added = commander.stageDrafts(plan.proposals)
      _uiBannerMessage.value =
        if (added > 0) "תוכנית ניקוי וארגון ($added פעולות) הועברה למרכז האישורים."
        else "התיקיות שנסרקו נקיות ומסודרות כרגע."
      if (navigateToApprovals) _navigateEvent.value = "approval_center"
    }
  }

  fun requestAppUninstallProposal(appInfo: AppDiagnosticInfo) {
    stageProposalDraft(
      AiOrganizationProposalDraft(
        title = "הסרת אפליקציה: ${appInfo.appName}",
        reasonHe =
          if (appInfo.isDormant) "אפליקציה ללא שימוש מעל 30 יום (${formatBytes(appInfo.totalSizeBytes)})."
          else "בקשת הסרה יזומה של ${appInfo.appName} (${formatBytes(appInfo.totalSizeBytes)}).",
        targetName = appInfo.appName,
        targetLocation = appInfo.packageName,
        operationType = ApprovalOperationType.OPEN_UNINSTALL_APP,
        riskLevel = ApprovalRiskLevel.HIGH,
        isReversible = false,
        expectedOutcomeHe = "תפתח את חלונית ההסרה הרשמית של Android לאישור סופי של המערכת.",
        packageName = appInfo.packageName,
        bytesAffected = appInfo.totalSizeBytes
      ),
      navigateToApprovals = true
    )
  }

  // ---- SAF BATCH OPERATIONS, FOLDER COPY/MOVE & ZIP ARCHIVE STAGING ----

  fun stageBatchFileOperation(
    entries: List<ScannedFileEntry>,
    destTreeUriString: String,
    destFolderName: String,
    moveInsteadOfCopy: Boolean
  ) {
    if (entries.isEmpty()) {
      _uiBannerMessage.value = "סמן תחילה קובץ אחד או יותר לביצוע."
      return
    }
    val totalBytes = entries.sumOf { it.sizeBytes }
    val first = entries.first()
    val opType = if (moveInsteadOfCopy) ApprovalOperationType.BATCH_MOVE_SAF else ApprovalOperationType.BATCH_COPY_SAF
    val verb = if (moveInsteadOfCopy) "העברה מרובה" else "העתקה מרובה"
    stageProposalDraft(
      AiOrganizationProposalDraft(
        title = "$verb: ${entries.size} קבצים אל '$destFolderName'",
        reasonHe = "נבחרו ${entries.size} קבצים (${formatBytes(totalBytes)}) להעברה/העתקה מרוכזת.",
        targetName = "${entries.size} קבצים",
        targetLocation = destFolderName,
        operationType = opType,
        riskLevel = if (moveInsteadOfCopy) ApprovalRiskLevel.MEDIUM else ApprovalRiskLevel.LOW,
        isReversible = !moveInsteadOfCopy,
        expectedOutcomeHe =
          if (moveInsteadOfCopy) "העתקה מאומתת ומחיקת מקור ל-${entries.size} קבצים אל '$destFolderName'."
          else "יצירת עותקים מאומתים של ${entries.size} קבצים בתוך '$destFolderName'.",
        sourceUriString = entries.joinToString("\n") { it.uriString },
        treeUriString = first.treeUriString,
        destTreeUriString = destTreeUriString,
        destFolderName = destFolderName,
        bytesAffected = totalBytes
      ),
      navigateToApprovals = true
    )
  }

  fun stageZipCreate(
    entries: List<ScannedFileEntry>,
    zipFileName: String,
    destTreeUriString: String? = null
  ) {
    if (entries.isEmpty()) {
      _uiBannerMessage.value = "סמן תחילה קבצים לדחיסה ל-ZIP."
      return
    }
    val targetTree = destTreeUriString ?: entries.first().treeUriString
    val cleanName = zipFileName.trim().ifBlank { "Nexus_${System.currentTimeMillis()}.zip" }
    val totalBytes = entries.sumOf { it.sizeBytes }
    stageProposalDraft(
      AiOrganizationProposalDraft(
        title = "דחיסה ל-ZIP: $cleanName (${entries.size} קבצים)",
        reasonHe = "דחיסה מזורזת מוגנת בזיכרון (32KB Buffer) עבור ${entries.size} קבצים (${formatBytes(totalBytes)}).",
        targetName = cleanName,
        targetLocation = cleanName,
        operationType = ApprovalOperationType.ZIP_CREATE,
        riskLevel = ApprovalRiskLevel.LOW,
        isReversible = true,
        expectedOutcomeHe = "ייווצר קובץ ארכיון ZIP חדש ללא מחיקת קובצי המקור.",
        sourceUriString = entries.joinToString("\n") { it.uriString },
        treeUriString = entries.first().treeUriString,
        destTreeUriString = targetTree,
        proposedNewName = cleanName,
        bytesAffected = totalBytes
      ),
      navigateToApprovals = true
    )
  }

  fun stageZipExtract(
    zipEntry: ScannedFileEntry,
    destFolderName: String,
    overwriteExisting: Boolean = false
  ) {
    val cleanFolder = destFolderName.trim().ifBlank { zipEntry.name.substringBeforeLast('.') + "_Extracted" }
    stageProposalDraft(
      AiOrganizationProposalDraft(
        title = "חילוץ ארכיון ZIP: ${zipEntry.name}",
        reasonHe = "חילוץ מאובטח עם הגנת Zip-Slip אל תיקייה '$cleanFolder'.",
        targetName = zipEntry.name,
        targetLocation = cleanFolder,
        operationType = ApprovalOperationType.ZIP_EXTRACT,
        riskLevel = if (overwriteExisting) ApprovalRiskLevel.HIGH else ApprovalRiskLevel.MEDIUM,
        isReversible = !overwriteExisting,
        expectedOutcomeHe =
          if (overwriteExisting) "יחולץ אל '$cleanFolder' עם דריסת קבצים בעלי שם זהה."
          else "יחולץ אל '$cleanFolder' תוך יצירת שמות ייחודיים ללא דריסה.",
        sourceUriString = zipEntry.uriString,
        treeUriString = zipEntry.treeUriString,
        destTreeUriString = zipEntry.treeUriString,
        destFolderName = cleanFolder,
        proposedNewName = if (overwriteExisting) "OVERWRITE" else "KEEP_BOTH",
        bytesAffected = zipEntry.sizeBytes
      ),
      navigateToApprovals = true
    )
  }

  fun stageFolderTransfer(
    folder: FolderStorageSummary,
    destTreeUriString: String,
    destFolderName: String,
    moveInsteadOfCopy: Boolean
  ) {
    val folderTreeUri = Uri.parse(folder.treeUriString)
    val folderDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(folderTreeUri, folder.docId)
    val verb = if (moveInsteadOfCopy) "העברת תיקייה" else "העתקת תיקייה"
    stageProposalDraft(
      AiOrganizationProposalDraft(
        title = "$verb: ${folder.folderName}",
        reasonHe = "מכילה ${folder.fileCount} קבצים ישירים (${formatBytes(folder.totalBytes)}).",
        targetName = folder.folderName,
        targetLocation = destFolderName,
        operationType =
          if (moveInsteadOfCopy) ApprovalOperationType.MOVE_SAF_FOLDER
          else ApprovalOperationType.COPY_SAF_FOLDER,
        riskLevel = if (moveInsteadOfCopy) ApprovalRiskLevel.HIGH else ApprovalRiskLevel.LOW,
        isReversible = !moveInsteadOfCopy,
        expectedOutcomeHe =
          if (moveInsteadOfCopy) "העתקה רקורסיבית מלאה, אימות ספירת קבצים, ומחיקת מקור רק לאחר הצלחה."
          else "שכפול רקורסיבי בטוח של התיקייה אל '$destFolderName'.",
        sourceUriString = folderDocUri.toString(),
        treeUriString = folder.treeUriString,
        destTreeUriString = destTreeUriString,
        destFolderName = destFolderName.ifBlank { folder.folderName },
        bytesAffected = folder.totalBytes
      ),
      navigateToApprovals = true
    )
  }

  fun approveSingleProposal(proposal: ApprovalProposalEntity) {
    viewModelScope.launch {
      val (ok, msg) = commander.approveAndExecuteProposal(proposal)
      _uiBannerMessage.value = msg
      if (ok) {
        refreshTelemetry(recordSnapshot = false)
        if (safTreeUris.value.isNotEmpty()) {
          commander.runFullDeviceScan(
            _telemetry.value,
            _appsState.value.allApps,
            _securityReport.value,
            telemetrySnapshots.value,
            cloudAiEnabled.value,
            shareTelemetryWithAi.value,
            includeAiInsights = false
          )
        }
      }
    }
  }

  fun approveAllPendingProposals() {
    viewModelScope.launch {
      val list = pendingApprovals.value
      var okCount = 0
      var failCount = 0
      list.forEach { prop ->
        val (ok, _) = commander.approveAndExecuteProposal(prop)
        if (ok) okCount++ else failCount++
      }
      _uiBannerMessage.value = "בוצעו באישור $okCount פעולות" + if (failCount > 0) " ($failCount נכשלו)." else "."
      refreshTelemetry(recordSnapshot = false)
    }
  }

  fun rejectProposal(proposal: ApprovalProposalEntity) {
    viewModelScope.launch {
      commander.rejectProposal(proposal)
      _uiBannerMessage.value = "הפעולה '${proposal.title}' נדחתה."
    }
  }

  fun rejectAllPendingProposals() {
    viewModelScope.launch {
      commander.rejectAllPending()
      _uiBannerMessage.value = "כל הפעולות הממתינות נדחו ונוקו."
    }
  }

  fun executeUndoRecord(record: UndoRecordEntity) {
    viewModelScope.launch {
      val (ok, msg) = commander.executeUndo(record)
      _uiBannerMessage.value = msg
      if (ok && safTreeUris.value.isNotEmpty()) {
        commander.runFullDeviceScan(
          _telemetry.value,
          _appsState.value.allApps,
          _securityReport.value,
          telemetrySnapshots.value,
          cloudAiEnabled.value,
          shareTelemetryWithAi.value,
          includeAiInsights = false
        )
      }
    }
  }

  fun createSafBackup(sourceTreeUri: String, destTreeUri: String) {
    viewModelScope.launch {
      val res = commander.createSafBackup(sourceTreeUri, destTreeUri)
      res.fold(
        onSuccess = { rec -> _uiBannerMessage.value = rec.integritySummaryHe },
        onFailure = { e -> _uiBannerMessage.value = "הגיבוי נכשל: ${e.localizedMessage}" }
      )
    }
  }

  fun restoreBackupRecord(record: BackupRecordEntity, singleFile: BackedUpFileEntry? = null) {
    viewModelScope.launch {
      val res = commander.restoreBackup(record, singleFile)
      res.fold(
        onSuccess = { msg -> _uiBannerMessage.value = msg },
        onFailure = { e -> _uiBannerMessage.value = "השחזור נכשל: ${e.localizedMessage}" }
      )
    }
  }

  fun parseBackupManifest(record: BackupRecordEntity): List<BackedUpFileEntry> =
    app.storageBackupEngine.parseManifest(record)

  fun inspectApkUri(uri: Uri) {
    viewModelScope.launch {
      commander.inspectApk(uri)
    }
  }

  fun searchGlobal(query: String): List<GlobalSearchResultItem> =
    commander.searchGlobal(
      query = query,
      apps = _appsState.value.allApps,
      securityReport = _securityReport.value,
      pendingApprovals = pendingApprovals.value
    )

  // Automations
  fun requestRunAutomation(automation: AutomationEntity) {
    val steps = parseSteps(automation.stepsSerialized)
    val hasSensitive = steps.any { it.requiresConfirm }
    if (hasSensitive) {
      _pendingAutomationRun.value = automation
    } else {
      executeAutomation(automation)
    }
  }

  fun dismissAutomationConfirmation() {
    _pendingAutomationRun.value = null
  }

  fun executeAutomation(automation: AutomationEntity) {
    _pendingAutomationRun.value = null
    viewModelScope.launch {
      val steps = parseSteps(automation.stepsSerialized)
      val summaries = mutableListOf<String>()

      for (step in steps) {
        when (step) {
          AutomationStepType.SYSTEM_SCAN -> {
            startDeepCleanScan()
            summaries += "סריקת אחסון הופעלה"
          }
          AutomationStepType.MAINTENANCE_REPORT -> {
            refreshTelemetry(recordSnapshot = true)
            summaries += "ציון בריאות: ${_telemetry.value.healthScore}%"
          }
          AutomationStepType.BATTERY_CHECK -> {
            val b = _telemetry.value.battery
            summaries += "סוללה: ${b.levelPercent}% (${b.temperatureC}°C)"
          }
          AutomationStepType.SECURITY_AUDIT -> {
            loadAppsAndSecurity()
            summaries += "ביקורת הרשאות עודכנה"
          }
          AutomationStepType.OPEN_STORAGE_SETTINGS -> {
            openSystemShortcut(SystemShortcutId.STORAGE)
            summaries += "נפתח מסך האחסון"
          }
          AutomationStepType.OPEN_BATTERY_SETTINGS -> {
            openSystemShortcut(SystemShortcutId.BATTERY)
            summaries += "נפתח מסך הסוללה"
          }
          AutomationStepType.OPEN_NETWORK_SETTINGS -> {
            openSystemShortcut(SystemShortcutId.WIFI)
            summaries += "נפתח פאנל רשת"
          }
          AutomationStepType.CLEAR_NEXUS_CACHE -> {
            val freed = app.deepCleanEngine.clearOwnCaches()
            summaries += "נוקה מטמון NEXUS (${formatBytes(freed)})"
          }
        }
      }

      db.automationDao().update(automation.copy(lastRunMillis = System.currentTimeMillis()))
      logAudit(
        category = "אוטומציות",
        title = automation.name,
        succeeded = true,
        details = summaries.joinToString(" • ")
      )
      _uiBannerMessage.value = "האוטומציה \"${automation.name}\" הושלמה: ${summaries.joinToString(" | ")}"
    }
  }

  fun createCustomAutomation(
    name: String,
    voicePhrase: String,
    steps: List<AutomationStepType>,
    scheduleIntervalHours: Int = 0
  ) {
    if (name.isBlank() || steps.isEmpty()) return
    viewModelScope.launch {
      val cleanHours = scheduleIntervalHours.coerceAtLeast(0)
      val entity =
        AutomationEntity(
          name = name.trim(),
          voicePhrase = voicePhrase.trim().ifBlank { name.trim() },
          description = steps.joinToString(" ← ") { it.titleHe },
          stepsSerialized = steps.joinToString(",") { it.name },
          isBuiltIn = false,
          scheduleIntervalHours = cleanHours
        )
      val insertedId = db.automationDao().insert(entity)
      if (cleanHours > 0) {
        val schedRes =
          withContext(Dispatchers.IO) {
            NexusWorkScheduler.syncScheduledAutomation(app, entity.copy(id = insertedId))
          }
        logAudit(
          category = "אוטומציות",
          title = "תזמון אוטומציה: $name",
          succeeded = schedRes.succeeded,
          details =
            if (schedRes.succeeded) "תוזמנה כל $cleanHours שעות (${schedRes.workName})"
            else (schedRes.errorHe ?: "כשל בתזמון"),
          failureReason = schedRes.errorHe
        )
        _uiBannerMessage.value =
          when {
            !schedRes.succeeded -> schedRes.errorHe ?: "שגיאה בתזמון WorkManager עבור \"$name\"."
            schedRes.warningHe != null -> "האוטומציה \"$name\" נשמרה ותרוץ כל $cleanHours שעות. שימו לב: ${schedRes.warningHe}"
            else -> "האוטומציה \"$name\" נשמרה ותרוץ אוטומטית כל $cleanHours שעות."
          }
      } else {
        _uiBannerMessage.value = "האוטומציה \"$name\" נשמרה בהצלחה ותזוהה גם בעוזר החכם."
      }
    }
  }

  fun updateAutomationSchedule(automation: AutomationEntity, scheduleIntervalHours: Int) {
    viewModelScope.launch {
      val cleanHours = scheduleIntervalHours.coerceAtLeast(0)
      db.automationDao().updateSchedule(automation.id, cleanHours)
      val schedRes =
        withContext(Dispatchers.IO) {
          NexusWorkScheduler.syncScheduledAutomation(app, automation.copy(scheduleIntervalHours = cleanHours))
        }
      logAudit(
        category = "אוטומציות",
        title = "עדכון תזמון: ${automation.name}",
        succeeded = schedRes.succeeded,
        details =
          when {
            !schedRes.succeeded -> schedRes.errorHe ?: "שגיאת תזמון"
            cleanHours > 0 -> "תוזמנה לכל $cleanHours שעות" + (schedRes.warningHe?.let { " • $it" } ?: "")
            else -> "הועברה להרצה ידנית בלבד"
          },
        failureReason = schedRes.errorHe
      )
      _uiBannerMessage.value =
        when {
          !schedRes.succeeded -> schedRes.errorHe ?: "עדכון התזמון נכשל ב-WorkManager."
          cleanHours > 0 && schedRes.warningHe != null ->
            "\"${automation.name}\" תוזמנה לכל $cleanHours שעות. אזהרה: ${schedRes.warningHe}"
          cleanHours > 0 -> "\"${automation.name}\" תוזמנה לביצוע אוטומטי כל $cleanHours שעות."
          else -> "\"${automation.name}\" הועברה למצב ידני."
        }
    }
  }

  fun deleteCustomAutomation(id: Long) {
    viewModelScope.launch {
      NexusWorkScheduler.cancelScheduledAutomation(app, id)
      db.automationDao().deleteCustom(id)
    }
  }

  // Backup, Restore & Privacy Data Wipe
  suspend fun exportJsonBackup(): String = app.backupManager.exportJsonBackup()

  fun restoreBackupFromJson(rawJson: String, replaceExisting: Boolean = false) {
    viewModelScope.launch {
      val result = app.backupManager.restoreFromJson(rawJson, replaceExisting = replaceExisting)
      result.fold(
        onSuccess = { summary ->
          val enabled = prefs.backgroundAlertsEnabledFlow.first()
          val interval = prefs.alertIntervalMinutesFlow.first()
          NexusWorkScheduler.syncThermalMonitor(app, enabled, interval)
          db.automationDao().getScheduledOnce().forEach {
            NexusWorkScheduler.syncScheduledAutomation(app, it)
          }
          logAudit(
            category = "גיבוי ושחזור",
            title = "שחזור נתוני NEXUS (${if (replaceExisting) "החלפה" else "מיזוג"})",
            succeeded = true,
            details =
              "שוחזרו ${summary.restoredAutomationsCount} אוטומציות, ${summary.restoredLifeItemsCount} משימות אישיות ו-${summary.restoredAccountsCount} שירותים"
          )
          _uiBannerMessage.value =
            "השחזור הושלם: ${summary.restoredAutomationsCount} אוטומציות, ${summary.restoredLifeItemsCount} משימות אישיות ו-${summary.restoredAccountsCount} שירותים."
        },
        onFailure = { err ->
          if (err is CancellationException) throw err
          _uiBannerMessage.value = "השחזור נכשל: ${err.localizedMessage ?: "קובץ לא תקין"}"
        }
      )
    }
  }

  fun clearAllPersonalData() {
    viewModelScope.launch {
      app.aiProvider.stopLiveVoiceConversation()
      app.assistantEngine.stopSpeaking()
      db.automationDao().getAllOnce().forEach {
        NexusWorkScheduler.cancelScheduledAutomation(app, it.id)
      }
      db.reminderAlertDao().getActiveOnce().forEach {
        NexusWorkScheduler.cancelReminder(app, it.id)
      }
      app.connectivityMonitor.clearSyncQueue()
      _openedDocument.value = null
      app.backupManager.clearAllUserData()
      app.reseedDefaultAutomations()
      seedWelcomeChatIfNeeded()
      _assistantState.value = AssistantUiState()
      _transcriptionState.value = TranscriptionUiState.Idle
      _visualDiagnosisState.value = VisualDiagnosisUiState.Idle
      _cloudHealthCheckState.value = CloudHealthCheckState.Idle
      _aiDiagnosticsReport.value = null
      _uiBannerMessage.value = "כל הנתונים האישיים, השיחות, הזיכרון והיומנים נמחקו בבטחה."
    }
  }

  // ---- CENTRAL AI ORCHESTRATOR (5 SPECIALIZED AGENTS) ----

  fun startOrchestratorTask(goal: String) {
    viewModelScope.launch {
      val res =
        app.orchestratorEngine.startNewTask(
          goal = goal,
          isOnline = networkStatus.value.isOnline,
          cloudAiEnabled = cloudAiEnabled.value,
          shareTelemetryWithAi = shareTelemetryWithAi.value
        )
      res.fold(
        onSuccess = { _uiBannerMessage.value = "המוח המרכזי פירק את המשימה והחל בתזמור 5 הסוכנים." },
        onFailure = { e -> _uiBannerMessage.value = e.localizedMessage ?: "לא ניתן להפעיל את המשימה." }
      )
    }
  }

  fun pauseOrchestratorTask(taskId: Long) {
    viewModelScope.launch {
      app.orchestratorEngine.pauseTask(taskId)
      _uiBannerMessage.value = "המשימה הושהתה."
    }
  }

  fun resumeOrchestratorTask(taskId: Long) {
    viewModelScope.launch {
      app.orchestratorEngine.resumeTask(taskId, cloudAiEnabled.value, shareTelemetryWithAi.value)
      _uiBannerMessage.value = "המשימה חודשה."
    }
  }

  fun cancelOrchestratorTask(taskId: Long) {
    viewModelScope.launch {
      app.orchestratorEngine.cancelTask(taskId)
      _uiBannerMessage.value = "המשימה בוטלה."
    }
  }

  // ---- LONG-TERM SMART MEMORY & CONTINUOUS LEARNING ----

  fun saveMemoryEntry(
    type: NexusMemoryType,
    title: String,
    content: String,
    categoryTag: String,
    canPersist: Boolean
  ) {
    viewModelScope.launch {
      when (
        val res =
          app.memoryManager.saveMemory(
            type = type,
            title = title,
            content = content,
            categoryTag = categoryTag,
            canPersist = canPersist
          )
      ) {
        is MemorySaveResult.Saved -> _uiBannerMessage.value = "הזיכרון '${res.entry.title}' נשמר בבטחה."
        is MemorySaveResult.BlockedSecret -> _uiBannerMessage.value = res.reasonHe
        is MemorySaveResult.Invalid -> _uiBannerMessage.value = res.reasonHe
      }
    }
  }

  fun updateMemoryEntry(
    existing: MemoryEntryEntity,
    newTitle: String,
    newContent: String,
    newType: NexusMemoryType,
    canPersist: Boolean
  ) {
    viewModelScope.launch {
      when (
        val res =
          app.memoryManager.updateMemory(
            existing = existing,
            newTitle = newTitle,
            newContent = newContent,
            newType = newType,
            canPersist = canPersist
          )
      ) {
        is MemorySaveResult.Saved -> _uiBannerMessage.value = "הזיכרון עודכן."
        is MemorySaveResult.BlockedSecret -> _uiBannerMessage.value = res.reasonHe
        is MemorySaveResult.Invalid -> _uiBannerMessage.value = res.reasonHe
      }
    }
  }

  fun toggleMemoryPersist(entry: MemoryEntryEntity) {
    viewModelScope.launch { app.memoryManager.togglePersistAllowed(entry) }
  }

  fun deleteMemoryEntry(id: Long) {
    viewModelScope.launch {
      app.memoryManager.deleteMemory(id)
      _uiBannerMessage.value = "הזיכרון נמחק לצמיתות."
    }
  }

  fun clearShortTermMemories() {
    viewModelScope.launch {
      app.memoryManager.clearShortTerm()
      _uiBannerMessage.value = "זיכרון זמני נוקה."
    }
  }

  fun setMemoryAutoSaveEnabled(enabled: Boolean) {
    viewModelScope.launch { prefs.setMemoryAutoSaveEnabled(enabled) }
  }

  fun rateAssistantReply(replyText: String, positive: Boolean) {
    viewModelScope.launch {
      app.learningEngine.recordAssistantFeedback(
        querySummary = replyText.take(60),
        positive = positive,
        providerLabel = _assistantState.value.lastProviderLabel ?: "NEXUS AI"
      )
      _uiBannerMessage.value =
        if (positive) "תודה! המשוב החיובי נשמר במנוע הלמידה."
        else "המשוב נשמר — המערכת תשפר דיוק בעתיד (הפיך)."
    }
  }

  fun undoLearningRecord(id: Long) {
    viewModelScope.launch {
      val ok = app.learningEngine.undoLearningChange(id)
      _uiBannerMessage.value =
        if (ok) "התאמת הלמידה בוטלה בהצלחה (Undo)." else "הרשומה כבר בוטלה קודם."
    }
  }

  // ---- DOCUMENT & PDF COMMANDER ----

  fun openDocumentUri(uri: Uri) {
    viewModelScope.launch {
      _isOpeningDocument.value = true
      val t0 = System.currentTimeMillis()
      val res = app.documentEngine.openDocument(uri)
      val lat = (System.currentTimeMillis() - t0).coerceAtLeast(1L)
      res.fold(
        onSuccess = { doc ->
          _openedDocument.value = doc
          app.learningEngine.recordToolRun(
            toolId = "document_pdf_reader",
            toolNameHe = "מנוע מסמכים ו-PDF",
            succeeded = doc.errorNoteHe == null,
            latencyMs = lat,
            summaryHe = "נפתח ${doc.fileName}",
            errorHe = doc.errorNoteHe
          )
          _uiBannerMessage.value = doc.errorNoteHe ?: "המסמך ${doc.fileName} נפתח בהצלחה."
        },
        onFailure = { e ->
          val msg = e.localizedMessage ?: "לא ניתן לפתוח את המסמך."
          app.learningEngine.recordToolRun(
            toolId = "document_pdf_reader",
            toolNameHe = "מנוע מסמכים ו-PDF",
            succeeded = false,
            latencyMs = lat,
            summaryHe = "פתיחת מסמך",
            errorHe = msg
          )
          _uiBannerMessage.value = msg
        }
      )
      _isOpeningDocument.value = false
    }
  }

  fun prevPdfPage() {
    val doc = _openedDocument.value ?: return
    if (doc.pdfPageCount <= 1 || doc.currentPdfPage <= 0) return
    loadPdfPageAt(doc.uriString, doc.currentPdfPage - 1)
  }

  fun nextPdfPage() {
    val doc = _openedDocument.value ?: return
    if (doc.pdfPageCount <= 1 || doc.currentPdfPage >= doc.pdfPageCount - 1) return
    loadPdfPageAt(doc.uriString, doc.currentPdfPage + 1)
  }

  private fun loadPdfPageAt(uriStr: String, targetIdx: Int) {
    viewModelScope.launch {
      val uri = Uri.parse(uriStr)
      app.documentEngine.renderPdfPage(uri, targetIdx).onSuccess { (safeIdx, bmp) ->
        _openedDocument.update { cur ->
          cur?.copy(currentPdfPage = safeIdx, pdfPreviewBitmap = bmp)
        }
      }
    }
  }

  fun searchOpenedDocument(query: String) {
    _openedDocument.update { doc ->
      doc?.copy(
        searchQuery = query,
        searchMatches = DocumentTextAnalyzer.searchLines(doc.textContent, query)
      )
    }
  }

  fun summarizeOpenedDocumentWithAi() {
    val doc = _openedDocument.value ?: return
    if (doc.textContent.isBlank()) {
      _uiBannerMessage.value = "סיכום ענן זמין למסמכי טקסט (TXT/MD/JSON/CSV); ב-PDF מוצגים עמודים סרוקים."
      return
    }
    if (!cloudAiEnabled.value || !networkStatus.value.isOnline) {
      app.connectivityMonitor.queueForControlledSync("doc_sum_${doc.fileName}", "סיכום AI למסמך ${doc.fileName}")
      _uiBannerMessage.value = "אין אינטרנט כרגע — הסיכום המקומי מוצג והמשימה נוספה לתור סנכרון."
      return
    }
    viewModelScope.launch {
      _isSummarizingDocument.value = true
      app.aiProvider.summarizeDocumentText(doc.fileName, doc.textContent).fold(
        onSuccess = { sum -> _openedDocument.update { it?.copy(aiSummaryHe = sum) } },
        onFailure = { e -> _uiBannerMessage.value = NexusAiErrorMapper.toHebrewError("doc_summary", e).messageHe }
      )
      _isSummarizingDocument.value = false
    }
  }

  fun saveGeneratedDocumentUri(uri: Uri, contentText: String) {
    viewModelScope.launch {
      app.documentEngine.writeDocumentToUri(uri, contentText).fold(
        onSuccess = { _uiBannerMessage.value = "המסמך נשמר בהצלחה ליעד שבחרת." },
        onFailure = { e -> _uiBannerMessage.value = "שמירת המסמך נכשלה: ${e.localizedMessage}" }
      )
    }
  }

  fun closeOpenedDocument() {
    _openedDocument.value = null
  }

  // ---- REMINDERS, NOTIFICATIONS, VOICE SETTINGS, TOOLS & FLOATING HUD ----

  fun createReminder(
    title: String,
    message: String,
    delayMinutes: Long,
    repeatIntervalHours: Int,
    conditionKey: String
  ) {
    val cleanTitle = title.trim().take(90)
    if (cleanTitle.isBlank()) return
    viewModelScope.launch {
      val now = System.currentTimeMillis()
      val isConditional = conditionKey != "NONE"
      val triggerMillis = if (!isConditional) now + delayMinutes.coerceAtLeast(1L) * 60_000L else null
      val id =
        db.reminderAlertDao().insert(
          ReminderAlertEntity(
            title = cleanTitle,
            message = message.trim().ifBlank { cleanTitle }.take(240),
            kind = if (isConditional) "CONDITIONAL_ALERT" else "REMINDER",
            triggerAtMillis = triggerMillis,
            repeatIntervalHours = repeatIntervalHours.coerceAtLeast(0),
            conditionKey = conditionKey,
            status = "ACTIVE",
            targetRoute = "assistant",
            createdAtMillis = now
          )
        )
      if (!isConditional) {
        NexusWorkScheduler.scheduleReminder(app, id, delayMinutes, repeatIntervalHours)
      }
      _uiBannerMessage.value =
        if (isConditional) "התראה מותנית \"$cleanTitle\" הופעלה."
        else "תזכורת \"$cleanTitle\" תוזמנה בעוד $delayMinutes דקות."
    }
  }

  fun dismissReminderAlert(id: Long) {
    viewModelScope.launch {
      NexusWorkScheduler.cancelReminder(app, id)
      db.reminderAlertDao().updateStatus(id, "DISMISSED")
    }
  }

  fun cancelReminderAlert(id: Long) {
    viewModelScope.launch {
      NexusWorkScheduler.cancelReminder(app, id)
      db.reminderAlertDao().deleteById(id)
    }
  }

  fun refreshTtsVoices() {
    _ttsAvailableVoices.value = app.assistantEngine.getAvailableVoices()
  }

  fun setTtsSpeechRate(rate: Float) {
    viewModelScope.launch {
      prefs.setTtsSpeechRate(rate)
      app.assistantEngine.setSpeechConfig(rate, ttsPitch.value, ttsVoiceName.value)
    }
  }

  fun setTtsVoiceName(voiceName: String?) {
    viewModelScope.launch {
      prefs.setTtsVoiceName(voiceName)
      app.assistantEngine.setSpeechConfig(ttsSpeechRate.value, ttsPitch.value, voiceName)
    }
  }

  fun pauseOrResumeTts() {
    if (_isTtsPaused.value) {
      app.assistantEngine.resumeSpeaking()
    } else if (_assistantState.value.isSpeaking) {
      app.assistantEngine.pauseSpeaking()
    }
  }

  fun stopTts() {
    app.assistantEngine.stopSpeaking()
  }

  fun setNoiseSuppressionEnabled(enabled: Boolean) {
    viewModelScope.launch { prefs.setNoiseSuppressionEnabled(enabled) }
  }

  fun setFloatingAssistantEnabled(enabled: Boolean) {
    viewModelScope.launch { prefs.setFloatingAssistantEnabled(enabled) }
  }

  fun updateFloatingOffset(offsetX: Float, offsetY: Float) {
    viewModelScope.launch { prefs.updateFloatingOffset(offsetX, offsetY) }
  }

  fun refreshToolHealthCheck() {
    refreshTelemetry(recordSnapshot = false)
    _uiBannerMessage.value = "תקינות כל ${NexusToolRegistry.catalog.size} הכלים נבדקה ואומתה."
  }

  // ---- PERSONAL LIFE MANAGER (TASKS, REMINDERS, NOTES, SHOPPING, GOALS, JOURNAL) ----

  fun addLifeItem(
    title: String,
    details: String,
    itemType: LifeItemKind,
    priority: LifeItemPriority,
    categoryTag: String,
    repeatIntervalHours: Int = 0,
    projectTag: String = ""
  ) {
    val cleanTitle = title.trim().take(120)
    if (cleanTitle.isBlank()) return
    val secretReason = NexusMemorySecretFilter.inspect(cleanTitle, details).reasonHe
    if (secretReason != null) {
      _uiBannerMessage.value = secretReason
      return
    }
    viewModelScope.launch {
      val now = System.currentTimeMillis()
      db.lifeItemDao().insert(
        LifeItemEntity(
          kind = itemType.name,
          title = cleanTitle,
          details = details.trim().take(600),
          categoryTag = categoryTag.trim().ifBlank { "כללי" },
          projectTag = projectTag.trim().take(40),
          priority = priority.name,
          repeatIntervalHours = repeatIntervalHours.coerceAtLeast(0),
          createdAtMillis = now,
          updatedAtMillis = now
        )
      )
      _uiBannerMessage.value = "נוסף אל ${itemType.titleHe}: $cleanTitle"
    }
  }

  fun toggleLifeItemComplete(item: LifeItemEntity) {
    viewModelScope.launch {
      val now = System.currentTimeMillis()
      val next = !item.isCompleted
      db.lifeItemDao().setCompleted(item.id, next, if (next) 100 else 0, now)
      if (next && item.repeatIntervalHours > 0) {
        val nextDue = now + item.repeatIntervalHours * 3_600_000L
        db.lifeItemDao().insert(
          item.copy(
            id = 0,
            isCompleted = false,
            progressPercent = 0,
            dueAtMillis = nextDue,
            createdAtMillis = now,
            updatedAtMillis = now
          )
        )
      }
    }
  }

  fun updateLifeItemProgress(item: LifeItemEntity, progressPercent: Int) {
    viewModelScope.launch {
      val pct = progressPercent.coerceIn(0, 100)
      db.lifeItemDao().update(
        item.copy(
          progressPercent = pct,
          isCompleted = pct >= 100,
          updatedAtMillis = System.currentTimeMillis()
        )
      )
    }
  }

  fun deleteLifeItem(id: Long) {
    viewModelScope.launch {
      db.lifeItemDao().deleteById(id)
    }
  }

  // ---- ACCOUNTS & DIGITAL SERVICES HUB (STRICTLY ZERO PASSWORDS/SECRETS) ----

  fun addManagedAccount(
    serviceName: String,
    category: String,
    accountLabel: String,
    packageName: String?,
    webUrl: String?,
    reviewIntervalDays: Int = 90,
    notes: String = ""
  ) {
    val cleanName = serviceName.trim().take(80)
    if (cleanName.isBlank()) return
    val secretReason = NexusMemorySecretFilter.inspect(cleanName, "$accountLabel $notes").reasonHe
    if (secretReason != null) {
      _uiBannerMessage.value = secretReason
      return
    }
    viewModelScope.launch {
      val now = System.currentTimeMillis()
      db.managedAccountDao().insert(
        ManagedAccountEntity(
          serviceName = cleanName,
          category = category.trim().ifBlank { "כלים" },
          accountLabel = accountLabel.trim().take(80),
          packageName = packageName?.trim()?.takeIf { it.isNotEmpty() },
          webUrl = webUrl?.trim()?.takeIf { it.startsWith("http://") || it.startsWith("https://") },
          lastReviewedAtMillis = now,
          reviewIntervalDays = reviewIntervalDays.coerceIn(7, 365),
          notes = notes.trim().take(240),
          createdAtMillis = now
        )
      )
      _uiBannerMessage.value = "השירות '$cleanName' נשמר במרכז השירותים (ללא סיסמאות)."
    }
  }

  fun markAccountReviewed(id: Long) {
    viewModelScope.launch {
      db.managedAccountDao().markReviewed(id, System.currentTimeMillis())
      _uiBannerMessage.value = "תאריך הביקורת עודכן להיום."
    }
  }

  fun openManagedAccountService(account: ManagedAccountEntity) {
    val pkg = account.packageName
    if (!pkg.isNullOrBlank()) {
      val launched = app.appIntelligenceProvider.launchApp(pkg)
      if (launched) return
    }
    val url = account.webUrl
    if (!url.isNullOrBlank()) {
      val opened =
        runCatching {
          app.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
          true
        }.getOrDefault(false)
      if (opened) return
    }
    _uiBannerMessage.value = "אין אפליקציה מותקנת או קישור תקין לפתיחת ${account.serviceName}."
  }

  fun checkAccountConnectivity(account: ManagedAccountEntity) {
    val urlStr = account.webUrl
    if (urlStr.isNullOrBlank()) {
      _accountConnectivityStatus.update { it + (account.id to "לא הוגדר קישור HTTP/HTTPS לבדיקה.") }
      return
    }
    viewModelScope.launch(Dispatchers.IO) {
      _accountConnectivityStatus.update { it + (account.id to "בודק זמינות DNS וחיבור...") }
      val msg =
        runCatching {
          val parsed = URL(urlStr)
          InetAddress.getByName(parsed.host)
          val conn = (parsed.openConnection() as HttpURLConnection).apply {
            requestMethod = "HEAD"
            connectTimeout = 5000
            readTimeout = 5000
            instanceFollowRedirects = true
          }
          try {
            val code = conn.responseCode
            "זמין (HTTP $code)"
          } finally {
            conn.disconnect()
          }
        }.getOrElse { err ->
          "לא נגיש (${err.javaClass.simpleName})"
        }
      _accountConnectivityStatus.update { it + (account.id to msg) }
      db.managedAccountDao().updateConnectivityStatus(account.id, System.currentTimeMillis(), msg)
    }
  }

  fun deleteManagedAccount(id: Long) {
    viewModelScope.launch {
      db.managedAccountDao().deleteById(id)
    }
  }

  // ---- SMART SELF-DIAGNOSTICS SUITE ----

  fun runSelfDiagnostics() {
    viewModelScope.launch {
      val folders = prefs.safTreeUrisFlow.first()
      val freshTelemetry = app.telemetryProvider.captureTelemetry(folders.size)
      _telemetry.value = freshTelemetry
      val report =
        commander.runSelfDiagnostics(
          telemetry = freshTelemetry,
          safTreeCount = folders.size,
          cloudAiEnabled = cloudAiEnabled.value,
          shareTelemetryWithAi = shareTelemetryWithAi.value
        )
      _uiBannerMessage.value =
        "אבחון עצמי הושלם: ${report.passedCount}/${report.totalChecks} תקינים (ציון ${report.overallScore}%)."
    }
  }

  fun buildExportReportText(): String {
    val t = _telemetry.value
    val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
    val sb = StringBuilder()
    sb.appendLine("===== NEXUS AI — דוח מערכת ותחזוקה =====")
    sb.appendLine("תאריך הפקה: ${fmt.format(Date())}")
    sb.appendLine("מכשיר: ${t.device.manufacturer} ${t.device.model} (Android ${t.device.androidRelease}, SDK ${t.device.sdkInt})")
    sb.appendLine("עדכון אבטחה: ${t.device.securityPatch}")
    sb.appendLine("ציון בריאות מערכת: ${t.healthScore}% — ${t.healthStatusLabel}")
    sb.appendLine()
    sb.appendLine("--- מדדים חיים ---")
    sb.appendLine("סוללה: ${t.battery.levelPercent}% | ${t.battery.chargeSource} | ${t.battery.temperatureC}°C | ${t.battery.healthLabel}")
    sb.appendLine("אחסון: פנוי ${formatBytes(t.storage.freeBytes)} מתוך ${formatBytes(t.storage.totalBytes)} (${t.storage.usedPercent}% בשימוש)")
    sb.appendLine("זיכרון RAM: זמין ${formatBytes(t.ram.availableBytes)} מתוך ${formatBytes(t.ram.totalBytes)} (${t.ram.usedPercent}% בשימוש)")
    sb.appendLine("רשת: ${t.network.transportLabel} | מחובר: ${if (t.network.isConnected) "כן" else "לא"}")
    sb.appendLine()
    sb.appendLine("--- היסטוריית ניקיונות (${cleanHistory.value.size}) ---")
    cleanHistory.value.take(10).forEach { item ->
      sb.appendLine("• [${fmt.format(Date(item.timestampMillis))}] ${item.summary}" + (item.failureReason?.let { " | הערה: $it" } ?: ""))
    }
    sb.appendLine()
    sb.appendLine("--- יומן פעולות ושגיאות (${actionAuditLogs.value.size}) ---")
    actionAuditLogs.value.take(20).forEach { log ->
      val status = if (log.succeeded) "הצליח" else "נכשל"
      sb.appendLine("• [${fmt.format(Date(log.timestampMillis))}] [$status] ${log.category} — ${log.actionTitle}: ${log.details}" + (log.failureReason?.let { " (סיבה: $it)" } ?: ""))
    }
    return sb.toString()
  }

  private fun parseSteps(serialized: String): List<AutomationStepType> {
    return serialized
      .split(",")
      .mapNotNull { token -> AutomationStepType.entries.firstOrNull { it.name == token.trim() } }
  }

  private fun logAudit(
    category: String,
    title: String,
    succeeded: Boolean,
    details: String,
    failureReason: String? = null
  ) {
    viewModelScope.launch {
      db.actionAuditDao().insert(
        ActionAuditEntity(
          timestampMillis = System.currentTimeMillis(),
          category = category,
          actionTitle = title,
          succeeded = succeeded,
          details = details,
          failureReason = failureReason
        )
      )
    }
  }

  override fun onCleared() {
    super.onCleared()
    recordingObserverJob?.cancel()
    app.audioRecorder.shutdown()
    app.aiProvider.shutdown()
    app.assistantEngine.shutdown()
    app.connectivityMonitor.shutdown()
  }
}
