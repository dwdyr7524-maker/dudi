package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.CleanCandidateItem
import com.example.data.model.CleanItemType
import com.example.data.model.CleanerSafetyTier
import com.example.data.model.SystemTelemetry
import com.example.data.system.formatBytes
import com.example.ui.components.Nexus3DGyroLoader
import com.example.ui.components.NexusCleaningEnergyOverlay
import com.example.ui.components.NexusConfirmationDialog
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusMetricArcGauge
import com.example.ui.components.NexusScanBeamOverlay
import com.example.ui.components.NexusShimmerBox
import com.example.ui.components.NexusSuccessShockwave
import com.example.ui.components.nexusPressable
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusBorderSubtle
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusGlowSky
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.viewmodel.DeepCleanPhase
import com.example.ui.viewmodel.DeepCleanUiState

@Composable
fun DeepCleanScreen(
  state: DeepCleanUiState,
  telemetry: SystemTelemetry,
  safFolders: Set<String>,
  onStartScan: () -> Unit,
  onToggleCandidate: (String) -> Unit,
  onRequestCleanConfirmation: () -> Unit,
  onConfirmClean: () -> Unit,
  onCancelConfirm: () -> Unit,
  onRequestAddSafFolder: () -> Unit,
  onRemoveSafFolder: (String) -> Unit,
  onOpenUsageAccessSettings: () -> Unit,
  onOpenAndroidManageStorage: () -> Unit,
  onOpenAppDetails: (String, String) -> Unit,
  onOpenSamsungDeviceCare: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  val scanResult = state.scanResult
  val selectedItems = scanResult?.candidates?.filter { it.id in state.selectedIds }.orEmpty()
  val selectedDirectBytes = selectedItems.filter { it.isDirectDeletable }.sumOf { it.sizeBytes }

  if (state.phase == DeepCleanPhase.AWAITING_CONFIRMATION) {
    NexusConfirmationDialog(
      title = "אישור ניקוי מערכת אמיתי",
      message =
        "המערכת תמחק ${selectedItems.size} פריטים מאושרים בנפח כולל של ${formatBytes(selectedDirectBytes)}.\nלא יימחק מידע אישי או קובצי מערכת חיוניים.",
      confirmText = "בצע ניקוי כעת",
      isDestructive = false,
      onConfirm = onConfirmClean,
      onDismiss = onCancelConfirm
    )
  }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isWide = maxWidth >= 740.dp

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Hero Scanner & CLEAN ALL Card
      item {
        NexusHudCard(accentColor = NexusNeonCyan) {
          Box(modifier = Modifier.fillMaxWidth()) {
            NexusScanBeamOverlay(isScanning = state.phase == DeepCleanPhase.SCANNING)
            NexusCleaningEnergyOverlay(isCleaning = state.phase == DeepCleanPhase.CLEANING)

            Column(modifier = Modifier.fillMaxWidth()) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "NEXUS DEEP CLEAN • 3 רמות בטיחות",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary
                  )
                  Text(
                    text = state.statusMessage ?: "סריקה חכמה, מדויקת ושקופה התואמת ל-Android 10",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }

                when (state.phase) {
                  DeepCleanPhase.SCANNING,
                  DeepCleanPhase.CLEANING -> Nexus3DGyroLoader(size = 70.dp)
                  DeepCleanPhase.COMPLETED -> NexusSuccessShockwave(visible = true, size = 70.dp)
                  else ->
                    NexusMetricArcGauge(
                      percent = telemetry.storage.usedPercent,
                      accentColor = if (telemetry.storage.usedPercent > 82) NexusAmber else NexusNeonCyan,
                      centerText = "${telemetry.storage.usedPercent}%",
                      size = 74.dp
                    )
                }
              }

              Spacer(modifier = Modifier.height(14.dp))

              val activeStep =
                when (state.phase) {
                  DeepCleanPhase.IDLE -> 0
                  DeepCleanPhase.SCANNING -> 1
                  DeepCleanPhase.RESULTS_READY -> 2
                  DeepCleanPhase.AWAITING_CONFIRMATION -> 3
                  DeepCleanPhase.CLEANING -> 4
                  DeepCleanPhase.COMPLETED -> 5
                }
              val steps = listOf("1. סריקה", "2. ממצאים", "3. אישור", "4. ניקוי", "5. סריקה חוזרת")
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                steps.forEachIndexed { idx, stepLabel ->
                  val stepNum = idx + 1
                  val isDone = activeStep > stepNum || activeStep == 5
                  val isCurrent = activeStep == stepNum
                  val stepColor =
                    when {
                      isDone -> NexusEmerald
                      isCurrent -> MaterialTheme.colorScheme.primary
                      else -> NexusBorderSubtle
                    }
                  Surface(
                    modifier = Modifier.weight(1f),
                    color = stepColor.copy(alpha = if (isCurrent || isDone) 0.16f else 0.08f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, stepColor.copy(alpha = if (isCurrent || isDone) 0.7f else 0.3f))
                  ) {
                    Text(
                      text = stepLabel,
                      style = MaterialTheme.typography.labelSmall,
                      color = if (isCurrent || isDone) stepColor else MaterialTheme.colorScheme.onSurfaceVariant,
                      maxLines = 1,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 5.dp)
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(14.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
              ) {
                Button(
                  onClick = {
                    if (state.phase == DeepCleanPhase.RESULTS_READY && selectedItems.isNotEmpty()) {
                      onRequestCleanConfirmation()
                    } else {
                      onStartScan()
                    }
                  },
                  enabled = state.phase != DeepCleanPhase.SCANNING && state.phase != DeepCleanPhase.CLEANING,
                  modifier =
                    Modifier
                      .weight(1f)
                      .height(54.dp)
                      .nexusPressable()
                      .testTag("deep_clean_main_cta"),
                  shape = RoundedCornerShape(16.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                  contentPadding = PaddingValues(0.dp)
                ) {
                  Box(
                    modifier =
                      Modifier
                        .fillMaxSize()
                        .background(
                          Brush.horizontalGradient(
                            if (state.phase == DeepCleanPhase.RESULTS_READY && selectedItems.isNotEmpty()) {
                              listOf(NexusEmerald, NexusNeonCyan)
                            } else {
                              listOf(NexusElectricBlue, NexusNeonCyan)
                            }
                          )
                        ),
                    contentAlignment = Alignment.Center
                  ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Icon(Icons.Rounded.CleaningServices, contentDescription = null, tint = NexusObsidian)
                      Spacer(modifier = Modifier.width(8.dp))
                      Text(
                        text =
                          when (state.phase) {
                            DeepCleanPhase.SCANNING -> "סורק אחסון..."
                            DeepCleanPhase.CLEANING -> "מבצע ניקוי אמיתי..."
                            DeepCleanPhase.RESULTS_READY ->
                              if (selectedItems.isNotEmpty())
                                "CLEAN ALL — נקה ${formatBytes(selectedDirectBytes)}"
                              else "סרוק מחדש"
                            else -> "CLEAN ALL — התחל סריקה וניקוי"
                          },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = NexusObsidian
                      )
                    }
                  }
                }

                if (state.phase == DeepCleanPhase.RESULTS_READY || state.phase == DeepCleanPhase.COMPLETED) {
                  OutlinedButton(
                    onClick = onStartScan,
                    modifier = Modifier.height(54.dp).testTag("deep_clean_rescan_button"),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f))
                  ) {
                    Text("סרוק שוב", color = MaterialTheme.colorScheme.primary)
                  }
                }
              }
            }
          }
        }
      }

      // Android 10 Official Capabilities & Permissions Panel
      item {
        if (isWide) {
          Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            PermissionsAndFoldersCard(
              telemetry = telemetry,
              safFolders = safFolders,
              onRequestAddSafFolder = onRequestAddSafFolder,
              onRemoveSafFolder = onRemoveSafFolder,
              onOpenUsageAccessSettings = onOpenUsageAccessSettings,
              onOpenAndroidManageStorage = onOpenAndroidManageStorage,
              onOpenSamsungDeviceCare = onOpenSamsungDeviceCare,
              modifier = Modifier.weight(1f)
            )
            ScanSummaryCard(state = state, telemetry = telemetry, modifier = Modifier.weight(1f))
          }
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            PermissionsAndFoldersCard(
              telemetry = telemetry,
              safFolders = safFolders,
              onRequestAddSafFolder = onRequestAddSafFolder,
              onRemoveSafFolder = onRemoveSafFolder,
              onOpenUsageAccessSettings = onOpenUsageAccessSettings,
              onOpenAndroidManageStorage = onOpenAndroidManageStorage,
              onOpenSamsungDeviceCare = onOpenSamsungDeviceCare
            )
            ScanSummaryCard(state = state, telemetry = telemetry)
          }
        }
      }

      if (state.phase == DeepCleanPhase.SCANNING) {
        items(3) {
          NexusShimmerBox(height = 72.dp)
        }
      }

      state.executionResult?.let { exec ->
        item {
          NexusHudCard(accentColor = NexusEmerald) {
            Text(
              text = "תוצאות ניקוי אמיתיות (לאחר סריקה חוזרת)",
              style = MaterialTheme.typography.titleLarge,
              color = NexusEmerald
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text =
                "• התפנו בפועל: ${formatBytes(exec.storageDeltaBytes)}\n" +
                  "• פריטים שנמחקו: ${exec.deletedCount} | נכשלו/חסומים: ${exec.failedCount}\n" +
                  "• מקום פנוי לפני: ${formatBytes(exec.freeBeforeBytes)} ← אחרי: ${formatBytes(exec.freeAfterBytes)}",
              style = MaterialTheme.typography.bodyLarge,
              color = MaterialTheme.colorScheme.onSurface
            )
            if (exec.failureReasons.isNotEmpty()) {
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "פירוט מגבלות מערכת:\n" + exec.failureReasons.take(4).joinToString("\n• ", prefix = "• "),
                style = MaterialTheme.typography.bodyMedium,
                color = NexusAmber
              )
            }
          }
        }
      }

      if (scanResult != null && state.phase != DeepCleanPhase.SCANNING) {
        if (scanResult.folderSummaries.isNotEmpty()) {
          item {
            Text(
              text = "ניתוח תיקיות מורשות (${scanResult.folderSummaries.size})",
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
          items(scanResult.folderSummaries, key = { it.treeUri }) { folder ->
            val isCrowded = folder.fileCount >= 80 || folder.totalBytes >= 500L * 1024L * 1024L
            NexusHudCard(
              isAlert = isCrowded,
              accentColor = if (isCrowded) NexusAmber else NexusNeonCyan,
              contentPadding = 12.dp
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = folder.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                  Text(
                    text = "${folder.fileCount} קבצים • נפח כולל: ${formatBytes(folder.totalBytes)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
                Surface(
                  color = (if (isCrowded) NexusAmber else NexusEmerald).copy(alpha = 0.16f),
                  shape = RoundedCornerShape(8.dp),
                  border = BorderStroke(1.dp, if (isCrowded) NexusAmber else NexusEmerald)
                ) {
                  Text(
                    text = if (isCrowded) "תיקייה עמוסה" else "מאוזנת",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isCrowded) NexusAmber else NexusEmerald,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }
              }
            }
          }
        }

        item {
          Text(
            text = "ממצאי הסריקה לפי רמות בטיחות (${scanResult.candidates.size})",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface
          )
        }

        if (scanResult.candidates.isEmpty()) {
          item {
            NexusHudCard {
              Text(
                text = "לא נמצאו קובצי זבל או מטמון לסריקה בתיקיות המורשות. ניתן לבחור תיקייה (כגון הורדות) כדי לאתר קבצים גדולים וכפילויות בטוחות.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        } else {
          CleanerSafetyTier.entries.forEach { tier ->
            val tierItems = scanResult.candidates.filter { it.safetyTier == tier }
            if (tierItems.isNotEmpty()) {
              val tierColor =
                when (tier) {
                  CleanerSafetyTier.SAFE -> NexusEmerald
                  CleanerSafetyTier.REVIEW_NEEDED -> NexusAmber
                  CleanerSafetyTier.POTENTIAL_DATA_LOSS -> com.example.ui.theme.NexusCrimson
                }
              val tierBytes = tierItems.sumOf { it.sizeBytes }
              item(key = "tier_header_${tier.name}") {
                Surface(
                  color = tierColor.copy(alpha = 0.12f),
                  shape = RoundedCornerShape(12.dp),
                  border = BorderStroke(1.dp, tierColor.copy(alpha = 0.55f)),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(tier.titleHe, style = MaterialTheme.typography.titleMedium, color = tierColor)
                      Text(tier.subtitleHe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                      text = "${tierItems.size} • ${formatBytes(tierBytes)}",
                      style = MaterialTheme.typography.labelLarge,
                      color = tierColor
                    )
                  }
                }
              }
              items(tierItems, key = { it.id }) { candidate ->
                CandidateRowCard(
                  item = candidate,
                  checked = candidate.id in state.selectedIds,
                  onToggle = { onToggleCandidate(candidate.id) },
                  onOpenAppDetails = onOpenAppDetails
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PermissionsAndFoldersCard(
  telemetry: SystemTelemetry,
  safFolders: Set<String>,
  onRequestAddSafFolder: () -> Unit,
  onRemoveSafFolder: (String) -> Unit,
  onOpenUsageAccessSettings: () -> Unit,
  onOpenAndroidManageStorage: () -> Unit,
  onOpenSamsungDeviceCare: () -> Unit,
  modifier: Modifier = Modifier
) {
  NexusHudCard(modifier = modifier) {
    Text(text = "סריקה חוקית ומאובטחת (Android 10)", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
    Spacer(modifier = Modifier.height(8.dp))
    Text(
      text = "ללא Root וללא מחיקת נתוני משתמש. אשר תיקייה (למשל הורדות או SD) לסריקת קבצים זמניים, גדולים וכפילויות SHA-256.",
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(modifier = Modifier.height(10.dp))

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
      Button(
        onClick = onRequestAddSafFolder,
        modifier = Modifier.weight(1f).testTag("add_saf_folder_button"),
        colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Rounded.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("בחר תיקייה לסריקה")
      }
      OutlinedButton(
        onClick = onOpenAndroidManageStorage,
        modifier = Modifier.weight(1f).testTag("android_manage_storage_button"),
        border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(12.dp)
      ) {
        Text("מנהל אחסון Android", color = MaterialTheme.colorScheme.primary)
      }
    }

    if (!telemetry.hasUsageAccessPermission) {
      Spacer(modifier = Modifier.height(10.dp))
      Surface(
        color = NexusAmber.copy(alpha = 0.12f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenUsageAccessSettings)
      ) {
        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = NexusAmber)
          Spacer(modifier = Modifier.width(8.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text("נדרשת הרשאת נתוני שימוש", style = MaterialTheme.typography.labelLarge, color = NexusAmber)
            Text("לחץ כדי למדוד מטמון אפליקציות דרך StorageStatsManager.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }

    if (telemetry.device.hasSamsungDeviceCare) {
      Spacer(modifier = Modifier.height(8.dp))
      OutlinedButton(
        onClick = onOpenSamsungDeviceCare,
        modifier = Modifier.fillMaxWidth().testTag("samsung_device_care_button"),
        border = BorderStroke(1.dp, NexusEmerald.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(12.dp)
      ) {
        Text("פתח תחזוקת Samsung Device Care", color = NexusEmerald)
      }
    }

    if (safFolders.isNotEmpty()) {
      Spacer(modifier = Modifier.height(8.dp))
      safFolders.forEach { uri ->
        val label = uri.substringAfterLast("%3A").ifBlank { uri.takeLast(28) }
        Row(
          modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("• תיקייה מורשית: $label", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
          Icon(
            Icons.Rounded.DeleteOutline,
            contentDescription = "הסר תיקייה",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp).clickable { onRemoveSafFolder(uri) }
          )
        }
      }
    }
  }
}

@Composable
private fun ScanSummaryCard(
  state: DeepCleanUiState,
  telemetry: SystemTelemetry,
  modifier: Modifier = Modifier
) {
  val scan = state.scanResult
  NexusHudCard(modifier = modifier) {
    Text(text = "מדדי אחסון ותוצאות", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
    Spacer(modifier = Modifier.height(10.dp))
    StatRow("פנוי כרגע במכשיר", formatBytes(telemetry.storage.freeBytes), MaterialTheme.colorScheme.primary)
    StatRow("מטמון פנימי של NEXUS", scan?.let { formatBytes(it.nexusCacheBytes) } ?: "ממתין לסריקה", NexusEmerald)
    StatRow("קבצים זמניים / שיוריים", scan?.let { formatBytes(it.tempFilesBytes) } ?: "—", NexusGlowSky)
    StatRow("כפילויות מאומתות (SHA-256)", scan?.let { formatBytes(it.safeDuplicateBytes) } ?: "—", NexusAmber)
    StatRow("קבצים גדולים (>=15MB)", scan?.let { formatBytes(it.largeFilesBytes) } ?: "—", MaterialTheme.colorScheme.onSurface)
    StatRow(
      "מטמון אפליקציות חיצוניות",
      scan?.externalAppCacheBytes?.let { formatBytes(it) } ?: "דורש הרשאת נתוני שימוש",
      MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}

@Composable
private fun StatRow(label: String, value: String, valueColor: Color) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(text = value, style = MaterialTheme.typography.labelLarge, color = valueColor)
  }
}

@Composable
private fun CandidateRowCard(
  item: CleanCandidateItem,
  checked: Boolean,
  onToggle: () -> Unit,
  onOpenAppDetails: (String, String) -> Unit
) {
  val typeBadgeHe =
    when (item.type) {
      CleanItemType.NEXUS_CACHE -> "מטמון NEXUS"
      CleanItemType.TEMP_RESIDUAL -> "קובץ זמני"
      CleanItemType.SAFE_DUPLICATE -> "כפילות SHA-256"
      CleanItemType.LARGE_FILE -> "קובץ גדול"
      CleanItemType.APP_CACHE_EXTERNAL -> "מטמון אפליקציה"
      CleanItemType.EMPTY_FOLDER -> "תיקייה ריקה"
      CleanItemType.OLD_APK -> "APK ישן"
      CleanItemType.OLD_BACKUP -> "גיבוי ישן"
      CleanItemType.OLD_UNUSED_FILE -> "קובץ ישן"
    }
  val accentColor =
    when (item.safetyTier) {
      CleanerSafetyTier.SAFE -> NexusEmerald
      CleanerSafetyTier.REVIEW_NEEDED -> NexusAmber
      CleanerSafetyTier.POTENTIAL_DATA_LOSS -> com.example.ui.theme.NexusCrimson
    }

  NexusHudCard(
    selected = checked,
    accentColor = accentColor,
    contentPadding = 12.dp
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (item.isDirectDeletable) {
        Checkbox(
          checked = checked,
          onCheckedChange = { onToggle() },
          colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary, uncheckedColor = NexusBorderSubtle)
        )
      } else {
        Icon(
          Icons.Rounded.Info,
          contentDescription = null,
          tint = NexusAmber,
          modifier = Modifier.padding(10.dp)
        )
      }
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(text = item.name, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f, fill = false))
          Surface(color = accentColor.copy(alpha = 0.14f), shape = RoundedCornerShape(6.dp)) {
            Text(typeBadgeHe, style = MaterialTheme.typography.labelSmall, color = accentColor, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
          }
        }
        Text(text = item.subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
      Spacer(modifier = Modifier.width(8.dp))
      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = formatBytes(item.sizeBytes),
          style = MaterialTheme.typography.labelLarge,
          color = if (item.isDirectDeletable) MaterialTheme.colorScheme.primary else NexusAmber
        )
        if (!item.isDirectDeletable && item.packageName != null) {
          Spacer(modifier = Modifier.height(4.dp))
          OutlinedButton(
            onClick = { onOpenAppDetails(item.packageName, item.name) },
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
            border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.6f))
          ) {
            Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null, tint = NexusAmber, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("נקה בהגדרות", style = MaterialTheme.typography.labelSmall, color = NexusAmber)
          }
        }
      }
    }
  }
}
