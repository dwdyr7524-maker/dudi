package com.example.ui.components

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.ImageSearch
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.example.data.ai.LiveVoiceUiState
import com.example.data.ai.TranscriptionUiState
import com.example.data.ai.VisualDiagnosisUiState
import com.example.data.model.PendingAssistantAction
import com.example.data.model.RobotMood
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.example.ui.theme.LocalPerformanceMode
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusBorderSubtle
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTitaniumCard
import com.example.ui.theme.NexusTitaniumElevated

@Composable
fun AudioTranscriptionPanel(
  state: TranscriptionUiState,
  onStartRecord: () -> Unit,
  onStopAndTranscribe: () -> Unit,
  onCancelRecord: () -> Unit,
  onRetry: () -> Unit,
  onUseInChat: (String) -> Unit,
  onCopySuccess: () -> Unit,
  onReset: () -> Unit,
  modifier: Modifier = Modifier
) {
  @Suppress("DEPRECATION")
  val clipboard = LocalClipboardManager.current

  NexusHudCard(modifier = modifier, accentColor = NexusNeonCyan) {
    Column(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "תמלול הקלטה קולית (Gemini 3.5 Transcribe)",
            style = MaterialTheme.typography.titleLarge,
            color = NexusNeonCyan
          )
          Text(
            text = "הקלט שמע ישירות מהמיקרופון לתמלול מדויק בעברית ובאנגלית.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = NexusNeonCyan)
      }

      when (state) {
        is TranscriptionUiState.Idle -> {
          Box(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentAlignment = Alignment.Center
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
              Button(
                onClick = onStartRecord,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
                contentPadding = PaddingValues(horizontal = 28.dp, vertical = 18.dp),
                modifier = Modifier.testTag("transcribe_record_button")
              ) {
                Icon(Icons.Rounded.Mic, contentDescription = "התחל הקלטה לתמלול")
                Spacer(modifier = Modifier.width(8.dp))
                Text("התחל הקלטה לתמלול", style = MaterialTheme.typography.titleMedium)
              }
              Text(
                text = "מקסימום 120 שניות להקלטה • ניתן לעצור בכל רגע",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }

        is TranscriptionUiState.Recording -> {
          Box(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentAlignment = Alignment.Center
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
              AudioWaveformBars(amplitude = state.amplitude)
              Text(
                text = "מקליט שמע... ${state.elapsedSeconds} שניות",
                style = MaterialTheme.typography.titleLarge,
                color = NexusNeonCyan
              )
              Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                  onClick = onStopAndTranscribe,
                  colors = ButtonDefaults.buttonColors(containerColor = NexusEmerald),
                  shape = RoundedCornerShape(14.dp),
                  modifier = Modifier.testTag("transcribe_stop_button")
                ) {
                  Icon(Icons.Rounded.Stop, contentDescription = null, tint = NexusObsidian)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("עצור ותמלל", color = NexusObsidian)
                }
                OutlinedButton(
                  onClick = onCancelRecord,
                  border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.6f)),
                  shape = RoundedCornerShape(14.dp)
                ) {
                  Icon(Icons.Rounded.Close, contentDescription = null, tint = NexusCrimson)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("בטל", color = NexusCrimson)
                }
              }
            }
          }
        }

        is TranscriptionUiState.Processing -> {
          Box(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentAlignment = Alignment.Center
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              CircularProgressIndicator(color = NexusNeonCyan)
              Text(
                text = "מתמלל את ההקלטה באמצעות gemini-3.5-transcribe...",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }

        is TranscriptionUiState.Success -> {
          Surface(
            color = MaterialTheme.colorScheme.surfaceContainerHighest,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, NexusEmerald.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth().weight(1f)
          ) {
            Column(
              modifier = Modifier.fillMaxSize().padding(14.dp),
              verticalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text(
                  text = "תוצאת התמלול (${state.modelUsed})",
                  style = MaterialTheme.typography.labelSmall,
                  color = NexusEmerald
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = state.text,
                  style = MaterialTheme.typography.bodyLarge,
                  color = MaterialTheme.colorScheme.onSurface
                )
              }

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Button(
                  onClick = { onUseInChat(state.text) },
                  colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("שלח לעוזר")
                }
                OutlinedButton(
                  onClick = {
                    clipboard.setText(AnnotatedString(state.text))
                    onCopySuccess()
                  },
                  border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f))
                ) {
                  Icon(Icons.Rounded.ContentCopy, contentDescription = "העתק", tint = NexusNeonCyan)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("העתק", color = NexusNeonCyan)
                }
                OutlinedButton(onClick = onReset) {
                  Text("חדש", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }
        }

        is TranscriptionUiState.Error -> {
          Surface(
            color = NexusCrimson.copy(alpha = 0.14f),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.7f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Text(
                text = "שגיאה בתמלול הקולי",
                style = MaterialTheme.typography.titleMedium,
                color = NexusCrimson
              )
              Text(
                text = state.error.messageHe,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
              )
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (state.error.canRetry) {
                  Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue)
                  ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("נסה שוב")
                  }
                }
                OutlinedButton(onClick = onStartRecord) {
                  Text("הקלט מחדש", color = NexusNeonCyan)
                }
                OutlinedButton(onClick = onReset) {
                  Text("סגור", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun LiveVoiceConversationPanel(
  state: LiveVoiceUiState,
  onStartLive: () -> Unit,
  onStopLive: () -> Unit,
  onSendLiveText: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var quickText by remember { mutableStateOf("") }

  NexusHudCard(modifier = modifier, accentColor = NexusElectricBlue) {
    Column(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "שיחה קולית חיה בזמן אמת (Gemini 3.8 Live)",
            style = MaterialTheme.typography.titleLarge,
            color = NexusNeonCyan
          )
          Text(
            text = "דיבור טבעי דו-כיווני עם האזנה רציפה, הפרעות בזמן אמת וכתוביות חיות.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      when (state) {
        is LiveVoiceUiState.Idle -> {
          Box(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentAlignment = Alignment.Center
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
              NexusRobotAvatar(mood = RobotMood.IDLE, size = 128.dp)
              Button(
                onClick = onStartLive,
                colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
                shape = RoundedCornerShape(18.dp),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 14.dp),
                modifier = Modifier.testTag("live_voice_toggle_button")
              ) {
                Icon(Icons.Rounded.Mic, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("התחל שיחה קולית חיה", style = MaterialTheme.typography.titleMedium)
              }
              Text(
                text = "ללא צורך בהקשה חוזרת • ניתן לעצור ולדבר בכל רגע",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }

        is LiveVoiceUiState.Connecting -> {
          Box(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentAlignment = Alignment.Center
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              CircularProgressIndicator(color = NexusNeonCyan)
              Text(
                text = "פותח ערוץ אודיו מוצפן מול gemini-3.8-live...",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
              )
              OutlinedButton(onClick = onStopLive) {
                Text("בטל חיבור", color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }

        is LiveVoiceUiState.Active -> {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              NexusRobotAvatar(
                mood = if (state.isSpeaking) RobotMood.SPEAKING else RobotMood.LISTENING,
                size = 64.dp
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = if (state.isSpeaking) "NEXUS מדבר..." else "מאזין לקולך בזמן אמת...",
                  style = MaterialTheme.typography.titleMedium,
                  color = if (state.isSpeaking) NexusNeonCyan else NexusEmerald
                )
                Text(
                  text = "ערוץ Live פעיל • ניתן להתפרץ בדיבור בכל רגע",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
            Button(
              onClick = onStopLive,
              colors = ButtonDefaults.buttonColors(containerColor = NexusCrimson),
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier.testTag("live_voice_stop_button")
            ) {
              Icon(Icons.Rounded.CallEnd, contentDescription = "סיים שיחה")
              Spacer(modifier = Modifier.width(6.dp))
              Text("סיים")
            }
          }

          LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            items(state.turns, key = { it.id }) { turn ->
              Surface(
                color =
                  if (turn.isUser) NexusElectricBlue.copy(alpha = 0.22f)
                  else MaterialTheme.colorScheme.surfaceContainerHighest,
                shape = RoundedCornerShape(14.dp),
                border =
                  BorderStroke(
                    1.dp,
                    if (turn.isUser) NexusElectricBlue.copy(alpha = 0.6f)
                    else NexusBorderGlow.copy(alpha = 0.35f)
                  ),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Text(
                    text = if (turn.isUser) "אתה" else "NEXUS AI",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (turn.isUser) NexusNeonCyan else NexusEmerald
                  )
                  Text(
                    text = turn.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }
            }

            if (state.userPartialTranscript.isNotBlank()) {
              item(key = "user_partial") {
                Text(
                  text = "אתה (חי): ${state.userPartialTranscript}",
                  style = MaterialTheme.typography.bodyMedium,
                  color = NexusNeonCyan,
                  modifier = Modifier.padding(horizontal = 4.dp)
                )
              }
            }
            if (state.modelPartialTranscript.isNotBlank()) {
              item(key = "model_partial") {
                Text(
                  text = "NEXUS (חי): ${state.modelPartialTranscript}",
                  style = MaterialTheme.typography.bodyMedium,
                  color = NexusAmber,
                  modifier = Modifier.padding(horizontal = 4.dp)
                )
              }
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = quickText,
              onValueChange = { quickText = it },
              modifier = Modifier.weight(1f),
              placeholder = { Text("שלח טקסט לתוך השיחה החיה...", color = MaterialTheme.colorScheme.onSurfaceVariant) },
              singleLine = true,
              shape = RoundedCornerShape(14.dp),
              colors =
                OutlinedTextFieldDefaults.colors(
                  focusedBorderColor = NexusNeonCyan,
                  unfocusedBorderColor = NexusBorderSubtle,
                  focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                  unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                  focusedTextColor = MaterialTheme.colorScheme.onSurface,
                  unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                )
            )
            IconButton(
              onClick = {
                onSendLiveText(quickText)
                quickText = ""
              },
              modifier =
                Modifier.size(48.dp).clip(CircleShape).background(NexusElectricBlue)
            ) {
              Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "שלח", tint = MaterialTheme.colorScheme.onSurface)
            }
          }
        }

        is LiveVoiceUiState.Error -> {
          Surface(
            color = NexusCrimson.copy(alpha = 0.14f),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.7f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Text("השיחה הקולית החיה נותקה או נכשלה", style = MaterialTheme.typography.titleMedium, color = NexusCrimson)
              Text(state.error.messageHe, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                  onClick = onStartLive,
                  colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue)
                ) {
                  Icon(Icons.Rounded.Refresh, contentDescription = null)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("התחבר מחדש")
                }
                OutlinedButton(onClick = onStopLive) {
                  Text("סגור", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AudioWaveformBars(amplitude: Float) {
  val perfMode = LocalPerformanceMode.current
  val barCount = 12
  val smoothAmp by animateFloatAsState(targetValue = amplitude.coerceIn(0.08f, 1f), label = "amp")
  val phaseShift =
    if (!perfMode) {
      val inf = rememberInfiniteTransition(label = "wave")
      val v by
        inf.animateFloat(
          initialValue = 0f,
          targetValue = 1f,
          animationSpec =
            infiniteRepeatable(
              animation = tween(700, easing = FastOutSlowInEasing),
              repeatMode = RepeatMode.Reverse
            ),
          label = "wave_shift"
        )
      v
    } else {
      0.5f
    }

  Row(
    horizontalArrangement = Arrangement.spacedBy(6.dp),
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier.height(68.dp)
  ) {
    repeat(barCount) { index ->
      val factor = 0.45f + 0.55f * kotlin.math.abs(kotlin.math.sin((index + phaseShift * 3.14f).toDouble())).toFloat()
      val h = (14f + 50f * smoothAmp * factor).dp
      Box(
        modifier =
          Modifier
            .width(7.dp)
            .height(h)
            .clip(RoundedCornerShape(4.dp))
            .background(if (index % 2 == 0) NexusNeonCyan else NexusElectricBlue)
      )
    }
  }
}

@Composable
fun VisualDiagnosticsPanel(
  state: VisualDiagnosisUiState,
  cloudAiEnabled: Boolean,
  onAnalyzeImage: (Uri, String) -> Unit,
  onConfirmAction: (PendingAssistantAction) -> Unit,
  onReset: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var selectedUri by remember { mutableStateOf<Uri?>(null) }
  var previewBitmap by remember { mutableStateOf<ImageBitmap?>(null) }
  var questionText by remember { mutableStateOf("") }

  LaunchedEffect(selectedUri) {
    val uri = selectedUri
    previewBitmap =
      if (uri == null) {
        null
      } else {
        withContext(Dispatchers.IO) {
          runCatching {
            val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
            context.contentResolver.openInputStream(uri)?.use { stream ->
              BitmapFactory.decodeStream(stream, null, opts)?.asImageBitmap()
            }
          }.getOrNull()
        }
      }
  }

  val photoPickerLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
      if (uri != null) {
        selectedUri = uri
        onReset()
      }
    }

  val presetPrompts =
    listOf(
      "נתח צילום מסך של תקלה",
      "המלץ מה לפנות מהאחסון לפי התמונה",
      "בדוק נתוני סוללה או צריכה בתמונה",
      "הסבר התראת מערכת או הרשאה שבתמונה"
    )

  NexusHudCard(modifier = modifier, accentColor = NexusNeonCyan) {
    Column(
      modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding(),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "אבחון צילומי מסך ותמונות (Gemini 3.8 Vision)",
            style = MaterialTheme.typography.titleLarge,
            color = NexusNeonCyan
          )
          Text(
            text = "בחר צילום מסך או תמונה דרך בורר המערכת המאובטח (ללא הרשאות גלריה רחבות).",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        Icon(Icons.Rounded.ImageSearch, contentDescription = null, tint = NexusNeonCyan)
      }

      if (!cloudAiEnabled) {
        Surface(
          color = NexusAmber.copy(alpha = 0.14f),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.55f))
        ) {
          Text(
            text = "מצב ענן AI כבוי כעת. הפעל 'Gemini AI' בסרגל העליון כדי לבצע ניתוח תמונות.",
            style = MaterialTheme.typography.bodyMedium,
            color = NexusAmber,
            modifier = Modifier.padding(10.dp)
          )
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        Button(
          onClick = {
            photoPickerLauncher.launch(
              PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
          },
          colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f).testTag("visual_pick_image_button")
        ) {
          Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null)
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (selectedUri == null) "בחר צילום מסך / תמונה" else "החלף תמונה")
        }
        if (selectedUri != null) {
          OutlinedButton(
            onClick = {
              selectedUri = null
              previewBitmap = null
              onReset()
            },
            border = BorderStroke(1.dp, NexusBorderSubtle),
            shape = RoundedCornerShape(14.dp)
          ) {
            Text("נקה", color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }

      previewBitmap?.let { bmp ->
        Surface(
          color = MaterialTheme.colorScheme.surfaceContainerLow,
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.45f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Image(
            bitmap = bmp,
            contentDescription = "תצוגה מקדימה של צילום מסך לאבחון",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxWidth().height(180.dp).padding(6.dp)
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        presetPrompts.forEach { preset ->
          Surface(
            color = MaterialTheme.colorScheme.surfaceContainerLow,
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, NexusBorderSubtle),
            modifier = Modifier.clip(RoundedCornerShape(18.dp)).clickable { questionText = preset }
          ) {
            Text(
              text = preset,
              style = MaterialTheme.typography.labelSmall,
              color = NexusNeonCyan,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
            )
          }
        }
      }

      OutlinedTextField(
        value = questionText,
        onValueChange = { questionText = it },
        modifier = Modifier.fillMaxWidth().testTag("visual_question_input"),
        label = { Text("מה לבדוק בתמונה? (אופציונלי)") },
        placeholder = { Text("לדוגמה: מה השגיאה בתמונה ואיך לפתור אותה?", color = MaterialTheme.colorScheme.onSurfaceVariant) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors =
          OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NexusNeonCyan,
            unfocusedBorderColor = NexusBorderSubtle,
            focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
            focusedTextColor = MaterialTheme.colorScheme.onSurface,
            unfocusedTextColor = MaterialTheme.colorScheme.onSurface
          )
      )

      Button(
        onClick = { selectedUri?.let { onAnalyzeImage(it, questionText) } },
        enabled = selectedUri != null && state !is VisualDiagnosisUiState.Analyzing && cloudAiEnabled,
        colors = ButtonDefaults.buttonColors(containerColor = NexusNeonCyan),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("visual_analyze_button")
      ) {
        Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = NexusObsidian)
        Spacer(modifier = Modifier.width(8.dp))
        Text("נתח תמונה עם Gemini 3.8 Flash", color = NexusObsidian)
      }

      when (state) {
        is VisualDiagnosisUiState.Idle -> Unit
        is VisualDiagnosisUiState.Analyzing -> {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(vertical = 8.dp)
          ) {
            CircularProgressIndicator(color = NexusNeonCyan, modifier = Modifier.size(24.dp))
            Text("מנתח את התמונה ומכין תוכנית פעולה...", color = MaterialTheme.colorScheme.onSurface)
          }
        }
        is VisualDiagnosisUiState.Success -> {
          Surface(
            color = MaterialTheme.colorScheme.surfaceContainerHighest,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, NexusEmerald.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text(
                text = "תוצאות אבחון (${state.reply.providerName})",
                style = MaterialTheme.typography.labelSmall,
                color = NexusEmerald
              )
              Text(
                text = state.reply.replyText,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
              )
              if (state.reply.plannedSteps.isNotEmpty()) {
                Text("שלבים מומלצים:", style = MaterialTheme.typography.titleMedium, color = NexusNeonCyan)
                state.reply.plannedSteps.forEachIndexed { idx, step ->
                  Text("${idx + 1}. $step", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
              state.reply.pendingAction?.let { action ->
                Button(
                  onClick = { onConfirmAction(action) },
                  colors = ButtonDefaults.buttonColors(containerColor = NexusEmerald),
                  shape = RoundedCornerShape(12.dp)
                ) {
                  Text(action.title, color = NexusObsidian)
                }
              }
            }
          }
        }
        is VisualDiagnosisUiState.Error -> {
          Surface(
            color = NexusCrimson.copy(alpha = 0.14f),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.7f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text("שגיאה באבחון התמונה", style = MaterialTheme.typography.titleMedium, color = NexusCrimson)
              Text(state.error.messageHe, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
              if (state.error.canRetry && selectedUri != null) {
                Button(
                  onClick = { selectedUri?.let { onAnalyzeImage(it, questionText) } },
                  colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue)
                ) {
                  Icon(Icons.Rounded.Refresh, contentDescription = null)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("נסה שוב")
                }
              }
            }
          }
        }
      }
    }
  }
}
