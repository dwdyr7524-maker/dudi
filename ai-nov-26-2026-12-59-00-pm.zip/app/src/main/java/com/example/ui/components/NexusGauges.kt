package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalIsDarkTheme
import com.example.ui.theme.LocalMotionConfig
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusRose
import com.example.ui.theme.NexusTurquoiseBright
import com.example.ui.theme.SpaceGroteskFontFamily
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun NexusSystemHealthRing(
  score: Int,
  statusLabel: String,
  isScanning: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  ringSize: Dp = 204.dp
) {
  val motion = LocalMotionConfig.current
  val isDark = LocalIsDarkTheme.current
  val trackColor = MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.50f else 0.70f)

  val animatedScore by animateIntAsState(
    targetValue = score,
    animationSpec = tween(motion.duration(520, 140), easing = FastOutSlowInEasing),
    label = "health_score_int"
  )
  val animatedSweep by animateFloatAsState(
    targetValue = (score.coerceIn(0, 100) / 100f) * 280f,
    animationSpec = tween(motion.duration(650, 160), easing = FastOutSlowInEasing),
    label = "health_sweep"
  )

  val orbitAngle =
    if (isScanning && motion.allowMicroMotion) {
      val inf = rememberInfiniteTransition(label = "ring_scan")
      val o by
        inf.animateFloat(
          initialValue = 0f,
          targetValue = 360f,
          animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
          label = "scan_orbit"
        )
      o
    } else {
      0f
    }

  val targetRingColor =
    when {
      score >= 85 -> NexusTurquoiseBright
      score >= 70 -> NexusNeonCyan
      score >= 55 -> NexusAmber
      else -> NexusRose
    }
  val primaryRingColor by animateColorAsState(
    targetValue = targetRingColor,
    animationSpec = tween(motion.duration(300, 100)),
    label = "ring_status_color"
  )

  Box(
    modifier =
      modifier
        .size(ringSize)
        .clip(CircleShape)
        .clickable(onClick = onClick)
        .testTag("system_health_ring"),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
      val w = size.width
      val h = size.height
      val cx = w / 2f
      val cy = h / 2f
      val outerR = size.minDimension / 2f

      val tickCount = 36
      for (i in 0 until tickCount) {
        val deg = i * (360f / tickCount)
        val rad = deg * (PI.toFloat() / 180f)
        val inner = outerR * if (i % 3 == 0) 0.89f else 0.93f
        val outer = outerR * 0.97f
        drawLine(
          color =
            if (i % 3 == 0) primaryRingColor.copy(alpha = 0.58f)
            else trackColor.copy(alpha = 0.48f),
          start = Offset(cx + cos(rad) * inner, cy + sin(rad) * inner),
          end = Offset(cx + cos(rad) * outer, cy + sin(rad) * outer),
          strokeWidth = if (i % 3 == 0) 1.6.dp.toPx() else 0.9.dp.toPx()
        )
      }

      val arcInset = outerR * 0.19f
      val arcSize = Size(w - arcInset * 2f, h - arcInset * 2f)
      drawArc(
        color = trackColor,
        startAngle = 130f,
        sweepAngle = 280f,
        useCenter = false,
        topLeft = Offset(arcInset, arcInset),
        size = arcSize,
        style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
      )

      drawArc(
        brush =
          Brush.sweepGradient(
            colors = listOf(NexusElectricBlue, primaryRingColor, NexusElectricBlue)
          ),
        startAngle = 130f,
        sweepAngle = animatedSweep,
        useCenter = false,
        topLeft = Offset(arcInset, arcInset),
        size = arcSize,
        style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
      )

      if (isScanning && motion.allowMicroMotion) {
        val innerInset = outerR * 0.31f
        drawArc(
          brush = Brush.sweepGradient(listOf(Color.Transparent, primaryRingColor.copy(alpha = 0.85f))),
          startAngle = orbitAngle,
          sweepAngle = 110f,
          useCenter = false,
          topLeft = Offset(innerInset, innerInset),
          size = Size(w - innerInset * 2f, h - innerInset * 2f),
          style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
      }
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = if (isScanning) "סורק מערכת..." else "מדד בריאות",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Text(
        text = "$animatedScore%",
        style =
          MaterialTheme.typography.displayMedium.copy(
            fontFamily = SpaceGroteskFontFamily,
            fontWeight = FontWeight.Bold
          ),
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = statusLabel,
        style = MaterialTheme.typography.labelMedium,
        color = primaryRingColor
      )
    }
  }
}

@Composable
fun NexusMetricArcGauge(
  percent: Int,
  accentColor: Color,
  centerText: String,
  modifier: Modifier = Modifier,
  size: Dp = 68.dp,
  centerTextColor: Color = MaterialTheme.colorScheme.onSurface,
  trackColorOverride: Color? = null
) {
  val motion = LocalMotionConfig.current
  val trackColor = trackColorOverride ?: MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
  val animatedSweep by animateFloatAsState(
    targetValue = (percent.coerceIn(0, 100) / 100f) * 360f,
    animationSpec = tween(motion.duration(520, 140), easing = FastOutSlowInEasing),
    label = "mini_gauge"
  )

  Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.fillMaxSize().padding(4.dp)) {
      drawArc(
        color = trackColor,
        startAngle = -90f,
        sweepAngle = 360f,
        useCenter = false,
        style = Stroke(width = 5.5.dp.toPx(), cap = StrokeCap.Round)
      )
      drawArc(
        brush = Brush.sweepGradient(listOf(accentColor.copy(alpha = 0.65f), accentColor)),
        startAngle = -90f,
        sweepAngle = animatedSweep,
        useCenter = false,
        style = Stroke(width = 5.5.dp.toPx(), cap = StrokeCap.Round)
      )
    }
    Text(
      text = centerText,
      style =
        MaterialTheme.typography.labelMedium.copy(
          fontFamily = JetBrainsMonoFontFamily,
          fontWeight = FontWeight.Bold
        ),
      color = centerTextColor
    )
  }
}

@Composable
fun NexusLiveTrendChart(
  values: List<Float>,
  labels: List<String>,
  lineColor: Color,
  unitSuffix: String,
  modifier: Modifier = Modifier,
  chartHeight: Dp = 148.dp,
  labelColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
  showColumnBars: Boolean = true
) {
  val motion = LocalMotionConfig.current
  val safeValues = if (values.size >= 2) values else listOf(values.firstOrNull() ?: 0f, values.firstOrNull() ?: 0f)
  val minVal = (safeValues.minOrNull() ?: 0f) - 2f
  val maxVal = ((safeValues.maxOrNull() ?: 100f) + 2f).coerceAtLeast(minVal + 5f)
  val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)

  val reveal = remember { Animatable(if (motion.allowMicroMotion) 0f else 1f) }
  LaunchedEffect(safeValues, motion.allowMicroMotion) {
    if (!motion.allowMicroMotion) {
      reveal.snapTo(1f)
      return@LaunchedEffect
    }
    reveal.snapTo(0f)
    reveal.animateTo(1f, tween(motion.duration(540, 150), easing = FastOutSlowInEasing))
  }
  val revealFrac = reveal.value

  Column(modifier = modifier.fillMaxWidth()) {
    Canvas(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(chartHeight)
          .padding(vertical = 8.dp, horizontal = 6.dp)
    ) {
      val w = size.width
      val h = size.height
      val stepX = w / (safeValues.size - 1).coerceAtLeast(1)

      for (g in 0..3) {
        val gy = h * (g / 3f)
        drawLine(
          color = gridColor,
          start = Offset(0f, gy),
          end = Offset(w, gy),
          strokeWidth = 0.8.dp.toPx()
        )
      }

      val points =
        safeValues.mapIndexed { idx, v ->
          val norm = ((v - minVal) / (maxVal - minVal)).coerceIn(0f, 1f)
          Offset(x = idx * stepX, y = h - (norm * h))
        }

      if (showColumnBars && points.size >= 2) {
        val barW = (stepX * 0.42f).coerceIn(3.dp.toPx(), 10.dp.toPx())
        points.forEachIndexed { idx, pt ->
          val barH = ((h - pt.y) * revealFrac).coerceAtLeast(2.dp.toPx())
          drawRoundRect(
            brush =
              Brush.verticalGradient(
                colors =
                  listOf(
                    lineColor.copy(alpha = if (idx == points.lastIndex) 0.45f else 0.22f),
                    lineColor.copy(alpha = 0.03f)
                  ),
                startY = h - barH,
                endY = h
              ),
            topLeft = Offset((pt.x - barW / 2f).coerceIn(0f, w - barW), h - barH),
            size = Size(barW, barH),
            cornerRadius = CornerRadius(barW / 3f, barW / 3f)
          )
        }
      }

      val linePath = Path().apply {
        points.forEachIndexed { idx, pt ->
          if (idx == 0) {
            moveTo(pt.x, pt.y)
          } else {
            val prev = points[idx - 1]
            val ctrlX = (prev.x + pt.x) / 2f
            cubicTo(ctrlX, prev.y, ctrlX, pt.y, pt.x, pt.y)
          }
        }
      }

      val revealedPath =
        if (revealFrac >= 0.995f) {
          linePath
        } else {
          val pm = PathMeasure()
          pm.setPath(linePath, false)
          Path().also { out -> pm.getSegment(0f, pm.length * revealFrac, out, true) }
        }

      val fillPath = Path().apply {
        addPath(linePath)
        lineTo(points.last().x, h)
        lineTo(points.first().x, h)
        close()
      }

      drawPath(
        path = fillPath,
        brush =
          Brush.verticalGradient(
            colors = listOf(lineColor.copy(alpha = 0.22f * revealFrac), Color.Transparent)
          )
      )
      drawPath(
        path = revealedPath,
        color = lineColor,
        style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round)
      )

      val visibleCount = (points.size * revealFrac).toInt().coerceIn(1, points.size)
      val dotStrokeColor = lineColor.copy(alpha = 0.25f)
      points.take(visibleCount).forEachIndexed { idx, pt ->
        val isLast = idx == points.lastIndex
        drawCircle(
          color = dotStrokeColor,
          radius = if (isLast) 6.dp.toPx() else 3.5.dp.toPx(),
          center = pt
        )
        drawCircle(
          color = lineColor,
          radius = if (isLast) 3.4.dp.toPx() else 2.dp.toPx(),
          center = pt
        )
      }
    }

    if (labels.isNotEmpty()) {
      Spacer(modifier = Modifier.height(4.dp))
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
          text = labels.firstOrNull().orEmpty(),
          style = MaterialTheme.typography.labelSmall,
          color = labelColor
        )
        Text(
          text = "נוכחי: ${safeValues.last().toInt()}$unitSuffix",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.SemiBold,
          color = lineColor
        )
        Text(
          text = labels.lastOrNull().orEmpty(),
          style = MaterialTheme.typography.labelSmall,
          color = labelColor
        )
      }
    }
  }
}
