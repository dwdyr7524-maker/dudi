package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.AutoMode
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CheckCircleOutline
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FactCheck
import androidx.compose.material.icons.rounded.HealthAndSafety
import androidx.compose.material.icons.rounded.ManageAccounts
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.SdStorage
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.ui.graphics.vector.ImageVector

enum class NexusDestination(
  val route: String,
  val labelHe: String,
  val shortLabelHe: String,
  val icon: ImageVector
) {
  DASHBOARD("dashboard", "לוח פיקוד מרכזי", "פיקוד", Icons.Rounded.Dashboard),
  PERSONAL_LIFE("personal_life", "חיים אישיים ומשימות", "אישי", Icons.Rounded.CheckCircleOutline),
  SMART_STORAGE("smart_storage", "אחסון חכם וכרטיס SD", "אחסון ו-SD", Icons.Rounded.SdStorage),
  DOWNLOADS_MANAGER("downloads_manager", "מנהל הורדות חכם", "הורדות", Icons.Rounded.Download),
  AI_FILE_MANAGER("ai_file_manager", "מנהל קבצים AI וכפילויות", "קבצים AI", Icons.Rounded.AutoAwesome),
  DEVICE_DOCTOR("device_doctor", "רופא המכשיר (אבחון)", "רופא מכשיר", Icons.Rounded.HealthAndSafety),
  SELF_DIAGNOSTICS("self_diagnostics", "אבחון עצמי חכם", "אבחון עצמי", Icons.Rounded.FactCheck),
  APPROVAL_CENTER("approval_center", "מרכז אישורים וגיבוי", "אישורים", Icons.Rounded.VerifiedUser),
  DEEP_CLEAN("deep_clean", "ניקוי חכם (3 רמות)", "ניקוי", Icons.Rounded.CleaningServices),
  ASSISTANT("assistant", "עוזר אישי ואייקו AI", "אייקו", Icons.Rounded.SmartToy),
  ACCOUNTS_HUB("accounts_hub", "מרכז חשבונות ושירותים", "שירותים", Icons.Rounded.ManageAccounts),
  SYSTEM_CONTROL("system_control", "מרכז שליטה", "שליטה", Icons.Rounded.Tune),
  BATTERY("battery", "מרכז סוללה", "סוללה", Icons.Rounded.BatteryChargingFull),
  APPS("apps", "מנהל אפליקציות ונפח", "אפליקציות", Icons.Rounded.Memory),
  SECURITY("security", "מרכז אבטחה ו-APK", "אבטחה", Icons.Rounded.Security),
  AUTOMATION("automation", "אוטומציות חכמות", "אוטומציה", Icons.Rounded.AutoMode),
  REPORTS("reports", "דוחות וניתוח", "דוחות", Icons.Rounded.Assessment)
}
