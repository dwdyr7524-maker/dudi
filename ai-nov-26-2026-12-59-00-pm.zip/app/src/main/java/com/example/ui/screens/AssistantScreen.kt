package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.speech.RecognizerIntent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.ImageSearch
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.ThumbDown
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.ai.LiveVoiceUiState
import com.example.data.ai.TranscriptionUiState
import com.example.data.ai.VisualDiagnosisUiState
import com.example.data.documents.OpenedDocumentState
import com.example.data.local.AssistantMessageEntity
import com.example.data.local.AutomationEntity
import com.example.data.local.LearningRecordEntity
import com.example.data.local.MemoryEntryEntity
import com.example.data.local.OrchestratorTaskEntity
import com.example.data.memory.LearningAnalyticsCalculator
import com.example.data.memory.LearningInsightsSnapshot
import com.example.data.memory.NexusMemoryType
import com.example.data.model.PendingAssistantAction
import com.example.data.model.RobotMood
import com.example.data.orchestrator.NexusToolStatus
import com.example.data.system.NetworkStatusSnapshot
import com.example.data.system.PendingSyncTask
import com.example.data.system.VoiceOptionInfo
import com.example.ui.components.AudioTranscriptionPanel
import com.example.ui.components.LiveVoiceConversationPanel
import com.example.ui.components.MemoryAndLearningPanel
import com.example.ui.components.NexusHairlineDivider
import com.example.ui.components.NexusRobotAvatar
import com.example.ui.components.NexusVoiceWaveformBar
import com.example.ui.components.OrchestratorAgentsPanel
import com.example.ui.components.ToolsAndDocumentsPanel
import com.example.ui.components.VisualDiagnosticsPanel
import com.example.ui.components.VoiceSettingsDialog
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderSubtle
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTitaniumElevated
import com.example.ui.theme.SpaceGroteskFontFamily
import com.example.ui.viewmodel.AssistantUiState

private enum class AssistantSubMode(val titleHe: String) {
  CHAT("צ'אט חכם"),
  AGENTS_TASKS("סוכנים ומשימות"),
  MEMORY_LEARNING("זיכרון ולמידה"),
  TOOLS_DOCS("כלים ומסמכים"),
  TRANSCRIBE("תמלול קולי"),
  LIVE_VOICE("שיחה קולית חיה"),
  VISUAL("אבחון תמונה")
}

private enum class MicTarget {
  SPEECH_INTENT,
  TRANSCRIBE_WAV,
  LIVE_VOICE
}

@Composable
fun AssistantScreen(
  assistantState: AssistantUiState,
  transcriptionState: TranscriptionUiState,
  liveVoiceState: LiveVoiceUiState,
  visualDiagnosisState: VisualDiagnosisUiState,
  messages: List<AssistantMessageEntity>,
  automations: List<AutomationEntity>,
  ttsEnabled: Boolean,
  cloudAiEnabled: Boolean,
  onSendCommand: (String) -> Unit,
  onRetryAiWithFallback: (String, Boolean) -> Unit,
  onDismissAiError: () -> Unit,
  onToggleTts: () -> Unit,
  onToggleCloudAi: () -> Unit,
  onClearHistory: () -> Unit,
  onSetListening: (Boolean) -> Unit,
  onConfirmPendingAction: (PendingAssistantAction) -> Unit,
  onDismissPendingAction: () -> Unit,
  onStartTranscribeRecord: () -> Unit,
  onStopAndTranscribe: () -> Unit,
  onCancelTranscribe: () -> Unit,
  onRetryTranscribe: () -> Unit,
  onResetTranscribe: () -> Unit,
  onStartLiveVoice: () -> Unit,
  onStopLiveVoice: () -> Unit,
  onSendLiveText: (String) -> Unit,
  onAnalyzeImage: (Uri, String) -> Unit,
  onResetVisualDiagnosis: () -> Unit,
  onVoiceError: (String) -> Unit,
  onNotifyInfo: (String) -> Unit,
  onBack: () -> Unit,
  orchestratorTasks: List<OrchestratorTaskEntity> = emptyList(),
  currentlyDoingHe: String? = null,
  onStartOrchestratorTask: (String) -> Unit = {},
  onPauseTask: (Long) -> Unit = {},
  onResumeTask: (Long) -> Unit = {},
  onCancelTask: (Long) -> Unit = {},
  memoryEntries: List<MemoryEntryEntity> = emptyList(),
  memoryAutoSaveEnabled: Boolean = true,
  learningRecords: List<LearningRecordEntity> = emptyList(),
  learningInsights: LearningInsightsSnapshot = LearningAnalyticsCalculator.buildSnapshot(emptyList(), emptyList()),
  onToggleMemoryAutoSave: (Boolean) -> Unit = {},
  onSaveMemory: (NexusMemoryType, String, String, String, Boolean) -> Unit = { _, _, _, _, _ -> },
  onUpdateMemory: (MemoryEntryEntity, String, String, NexusMemoryType, Boolean) -> Unit = { _, _, _, _, _ -> },
  onToggleMemoryPersist: (MemoryEntryEntity) -> Unit = {},
  onDeleteMemory: (Long) -> Unit = {},
  onClearShortTermMemory: () -> Unit = {},
  onUndoLearning: (Long) -> Unit = {},
  onRateAssistantReply: (String, Boolean) -> Unit = { _, _ -> },
  networkStatus: NetworkStatusSnapshot = NetworkStatusSnapshot(),
  pendingSyncQueue: List<PendingSyncTask> = emptyList(),
  toolStatuses: List<NexusToolStatus> = emptyList(),
  openedDocument: OpenedDocumentState? = null,
  isOpeningDocument: Boolean = false,
  isSummarizingDocument: Boolean = false,
  onRefreshToolHealth: () -> Unit = {},
  onOpenDocumentUri: (Uri) -> Unit = {},
  onPrevPdfPage: () -> Unit = {},
  onNextPdfPage: () -> Unit = {},
  onSearchDocument: (String) -> Unit = {},
  onSummarizeDocWithAi: () -> Unit = {},
  onSaveDocumentUri: (Uri, String) -> Unit = { _, _ -> },
  onCloseDocument: () -> Unit = {},
  ttsSpeechRate: Float = 1.0f,
  ttsVoiceName: String? = null,
  ttsAvailableVoices: List<VoiceOptionInfo> = emptyList(),
  isTtsPaused: Boolean = false,
  noiseSuppressionEnabled: Boolean = true,
  floatingHudEnabled: Boolean = true,
  onSetTtsRate: (Float) -> Unit = {},
  onSetTtsVoice: (String?) -> Unit = {},
  onPauseOrResumeTts: () -> Unit = {},
  onStopTts: () -> Unit = {},
  onToggleNoiseSuppression: (Boolean) -> Unit = {},
  onToggleFloatingHud: (Boolean) -> Unit = {},
  onRefreshTtsVoices: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  val context = LocalContext.current
  var inputText by remember { mutableStateOf("") }
  var selectedMode by rememberSaveable { mutableStateOf(AssistantSubMode.CHAT) }
  var pendingMicTarget by remember { mutableStateOf(MicTarget.SPEECH_INTENT) }
  var showVoiceSettingsDialog by rememberSaveable { mutableStateOf(false) }
  val listState = rememberLazyListState()

  if (showVoiceSettingsDialog) {
    VoiceSettingsDialog(
      ttsRate = ttsSpeechRate,
      selectedVoiceName = ttsVoiceName,
      availableVoices = ttsAvailableVoices,
      isSpeaking = assistantState.isSpeaking,
      isTtsPaused = isTtsPaused,
      noiseSuppressionEnabled = noiseSuppressionEnabled,
      floatingHudEnabled = floatingHudEnabled,
      onRateChange = onSetTtsRate,
      onSelectVoice = onSetTtsVoice,
      onPauseOrResumeTts = onPauseOrResumeTts,
      onStopTts = onStopTts,
      onToggleNoiseSuppression = onToggleNoiseSuppression,
      onToggleFloatingHud = onToggleFloatingHud,
      onRefreshVoices = onRefreshTtsVoices,
      onDismiss = { showVoiceSettingsDialog = false }
    )
  }

  LaunchedEffect(messages.size) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  val speechLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
      onSetListening(false)
      if (result.resultCode == Activity.RESULT_OK) {
        val spoken =
          result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
          onSendCommand(spoken)
        }
      }
    }

  val launchSpeechIntent = {
    val intent =
      Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "he-IL")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "דבר אל העוזר של NEXUS...")
      }
    val ok =
      runCatching {
        onSetListening(true)
        speechLauncher.launch(intent)
        true
      }.getOrDefault(false)
    if (!ok) {
      onSetListening(false)
      onVoiceError("זיהוי קול מובנה אינו זמין — השתמש בכרטיסיית התמלול.")
    }
  }

  val micPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      if (granted) {
        when (pendingMicTarget) {
          MicTarget.SPEECH_INTENT -> launchSpeechIntent()
          MicTarget.TRANSCRIBE_WAV -> onStartTranscribeRecord()
          MicTarget.LIVE_VOICE -> onStartLiveVoice()
        }
      } else {
        onSetListening(false)
        onVoiceError("נדרשת הרשאת מיקרופון לשימוש בהקלטה, תמלול ושיחה קולית חיה.")
      }
    }

  val requestMicThenRun: (MicTarget, () -> Unit) -> Unit = { target, action ->
    val granted =
      ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
    if (granted) {
      action()
    } else {
      pendingMicTarget = target
      micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
  }

  val quickCommands =
    remember(automations) {
      listOf(
        "בדוק את מצב הטאבלט שלי",
        "מה מצב האחסון שלי?",
        "מצא אפליקציות שתופסות הרבה מקום",
        "אני רוצה לנקות את המכשיר",
        "בדוק אילו הרשאות יש לאפליקציות",
        "פתח את הגדרות הסוללה",
        "פתח את הגדרות האינטרנט"
      ) + automations.filter { !it.isBuiltIn }.map { it.voicePhrase }
    }

  val activeRobotMood =
    when {
      liveVoiceState is LiveVoiceUiState.Active ->
        if (liveVoiceState.isSpeaking) RobotMood.SPEAKING else RobotMood.LISTENING
      transcriptionState is TranscriptionUiState.Recording -> RobotMood.LISTENING
      transcriptionState is TranscriptionUiState.Processing ||
        visualDiagnosisState is VisualDiagnosisUiState.Analyzing -> RobotMood.THINKING
      assistantState.isThinking -> RobotMood.THINKING
      else -> assistantState.robotMood
    }

  val isVoiceActive =
    activeRobotMood == RobotMood.LISTENING ||
      activeRobotMood == RobotMood.SPEAKING ||
      activeRobotMood == RobotMood.THINKING ||
      assistantState.isThinking ||
      assistantState.isSpeaking ||
      assistantState.isListening

  val statusLabel =
    when {
      liveVoiceState is LiveVoiceUiState.Active -> "שיחה קולית חיה פעילה"
      transcriptionState is TranscriptionUiState.Recording -> "מקליט לתמלול..."
      assistantState.isThinking -> "מנתח ומתכנן תשובה..."
      assistantState.isListening -> "מאזין לפקודה שלך..."
      assistantState.isSpeaking -> "מקריא תשובה..."
      else -> assistantState.lastProviderLabel ?: "מוכן לפקודות טבעיות בעברית"
    }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isWide = maxWidth >= 740.dp

    if (isWide) {
      Row(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp)
      ) {
        // Dark Navy Aiko Studio Sidebar
        Surface(
          color = NexusCharcoal,
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, NexusBorderSubtle),
          modifier = Modifier.weight(0.34f).fillMaxHeight()
        ) {
          Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
              NexusRobotAvatar(mood = activeRobotMood, size = 154.dp)
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = "AIKO STUDIO",
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = SpaceGroteskFontFamily, fontWeight = FontWeight.Bold),
                color = NexusNeonCyan
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = statusLabel,
                style = MaterialTheme.typography.bodySmall,
                color = NexusTextSecondary,
                textAlign = TextAlign.Center
              )
              Spacer(modifier = Modifier.height(12.dp))
              NexusVoiceWaveformBar(
                isActive = isVoiceActive,
                accentColor = NexusNeonCyan,
                secondaryColor = NexusElectricBlue,
                modifier = Modifier.fillMaxWidth(0.85f)
              )
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
              if (!networkStatus.isOnline) {
                Box(
                  modifier =
                    Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(8.dp))
                      .background(NexusAmber.copy(alpha = 0.14f))
                      .border(1.dp, NexusAmber.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                      .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                  Text(
                    text = "מצב לא מקוון • מנוע מקומי פעיל (${pendingSyncQueue.size} בסנכרון)",
                    style = MaterialTheme.typography.labelSmall,
                    color = NexusAmber
                  )
                }
              }
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                  onClick = onToggleCloudAi,
                  shape = RoundedCornerShape(8.dp),
                  border = BorderStroke(1.dp, NexusBorderSubtle),
                  modifier = Modifier.weight(1f).height(48.dp)
                ) {
                  Icon(
                    Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint = if (cloudAiEnabled) NexusNeonCyan else NexusTextSecondary,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(if (cloudAiEnabled) "Gemini" else "מקומי", color = NexusTextPrimary)
                }
                OutlinedButton(
                  onClick = onToggleTts,
                  shape = RoundedCornerShape(8.dp),
                  border = BorderStroke(1.dp, NexusBorderSubtle),
                  modifier = Modifier.weight(1f).height(48.dp)
                ) {
                  Icon(
                    if (ttsEnabled) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                    contentDescription = "הקראה קולית",
                    tint = if (ttsEnabled) NexusNeonCyan else NexusTextSecondary,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(if (ttsEnabled) "הקראה" else "מושתק", color = NexusTextPrimary)
                }
              }
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                  onClick = { onRefreshTtsVoices(); showVoiceSettingsDialog = true },
                  shape = RoundedCornerShape(8.dp),
                  border = BorderStroke(1.dp, NexusBorderSubtle),
                  modifier = Modifier.weight(1f).height(48.dp).testTag("voice_settings_button")
                ) {
                  Icon(Icons.Rounded.Tune, contentDescription = "הגדרות קול", tint = NexusNeonCyan, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("קול ו-HUD", color = NexusTextPrimary)
                }
                if (assistantState.isSpeaking || isTtsPaused) {
                  OutlinedButton(
                    onClick = onPauseOrResumeTts,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.65f)),
                    modifier = Modifier.weight(1f).height(48.dp)
                  ) {
                    Icon(
                      if (isTtsPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                      contentDescription = "השהה או המשך הקראה",
                      tint = NexusAmber,
                      modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isTtsPaused) "המשך" else "השהה", color = NexusAmber)
                  }
                }
              }
              OutlinedButton(
                onClick = onClearHistory,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, NexusBorderSubtle),
                modifier = Modifier.fillMaxWidth().height(48.dp)
              ) {
                Icon(Icons.Rounded.DeleteSweep, contentDescription = null, tint = NexusTextSecondary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("נקה היסטוריית שיחה", color = NexusTextSecondary)
              }
            }
          }
        }

        Column(modifier = Modifier.weight(0.66f).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          AssistantModeTabs(selectedMode = selectedMode, onSelect = { selectedMode = it })

          when (selectedMode) {
            AssistantSubMode.CHAT ->
              AssistantChatPane(
                assistantState = assistantState,
                messages = messages,
                listState = listState,
                quickCommands = quickCommands,
                pendingAction = assistantState.pendingAction,
                inputText = inputText,
                onInputChange = { inputText = it },
                onSend = {
                  onSendCommand(inputText)
                  inputText = ""
                },
                onChipClick = onSendCommand,
                onMicClick = { requestMicThenRun(MicTarget.SPEECH_INTENT, launchSpeechIntent) },
                onConfirmPendingAction = onConfirmPendingAction,
                onDismissPendingAction = onDismissPendingAction,
                onRetryAi = { q -> onRetryAiWithFallback(q, false) },
                onFallbackLocal = { q -> onRetryAiWithFallback(q, true) },
                onDismissAiError = onDismissAiError,
                onRateReply = onRateAssistantReply,
                modifier = Modifier.weight(1f)
              )

            AssistantSubMode.AGENTS_TASKS ->
              OrchestratorAgentsPanel(
                tasks = orchestratorTasks,
                currentlyDoingHe = currentlyDoingHe,
                onStartTask = onStartOrchestratorTask,
                onPauseTask = onPauseTask,
                onResumeTask = onResumeTask,
                onCancelTask = onCancelTask,
                modifier = Modifier.weight(1f)
              )

            AssistantSubMode.MEMORY_LEARNING ->
              MemoryAndLearningPanel(
                memories = memoryEntries,
                memoryAutoSaveEnabled = memoryAutoSaveEnabled,
                learningRecords = learningRecords,
                learningInsights = learningInsights,
                onToggleAutoSave = onToggleMemoryAutoSave,
                onSaveMemory = onSaveMemory,
                onUpdateMemory = onUpdateMemory,
                onTogglePersist = onToggleMemoryPersist,
                onDeleteMemory = onDeleteMemory,
                onClearShortTerm = onClearShortTermMemory,
                onUndoLearning = onUndoLearning,
                modifier = Modifier.weight(1f)
              )

            AssistantSubMode.TOOLS_DOCS ->
              ToolsAndDocumentsPanel(
                networkStatus = networkStatus,
                pendingSyncQueue = pendingSyncQueue,
                toolStatuses = toolStatuses,
                openedDocument = openedDocument,
                isOpeningDocument = isOpeningDocument,
                isSummarizingDocument = isSummarizingDocument,
                onRefreshToolHealth = onRefreshToolHealth,
                onOpenDocumentUri = onOpenDocumentUri,
                onPrevPdfPage = onPrevPdfPage,
                onNextPdfPage = onNextPdfPage,
                onSearchDocument = onSearchDocument,
                onSummarizeDocWithAi = onSummarizeDocWithAi,
                onSaveDocumentUri = onSaveDocumentUri,
                onCloseDocument = onCloseDocument,
                modifier = Modifier.weight(1f)
              )

            AssistantSubMode.TRANSCRIBE ->
              AudioTranscriptionPanel(
                state = transcriptionState,
                onStartRecord = { requestMicThenRun(MicTarget.TRANSCRIBE_WAV, onStartTranscribeRecord) },
                onStopAndTranscribe = onStopAndTranscribe,
                onCancelRecord = onCancelTranscribe,
                onRetry = onRetryTranscribe,
                onUseInChat = { txt ->
                  selectedMode = AssistantSubMode.CHAT
                  onSendCommand(txt)
                  onResetTranscribe()
                },
                onCopySuccess = { onNotifyInfo("התמלול הועתק ללוח.") },
                onReset = onResetTranscribe,
                modifier = Modifier.weight(1f)
              )

            AssistantSubMode.LIVE_VOICE ->
              LiveVoiceConversationPanel(
                state = liveVoiceState,
                onStartLive = { requestMicThenRun(MicTarget.LIVE_VOICE, onStartLiveVoice) },
                onStopLive = onStopLiveVoice,
                onSendLiveText = onSendLiveText,
                modifier = Modifier.weight(1f)
              )

            AssistantSubMode.VISUAL ->
              VisualDiagnosticsPanel(
                state = visualDiagnosisState,
                cloudAiEnabled = cloudAiEnabled,
                onAnalyzeImage = onAnalyzeImage,
                onConfirmAction = onConfirmPendingAction,
                onReset = onResetVisualDiagnosis,
                modifier = Modifier.weight(1f)
              )
          }
        }
      }
    } else {
      Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Compact Dark Navy Aiko Studio Anchor Bar
        Surface(
          color = NexusCharcoal,
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, NexusBorderSubtle),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              NexusRobotAvatar(mood = activeRobotMood, size = 56.dp)
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text("אייקו — AIKO AI", style = MaterialTheme.typography.titleMedium, color = NexusNeonCyan)
                Text(
                  text = statusLabel,
                  style = MaterialTheme.typography.bodySmall,
                  color = NexusTextSecondary,
                  maxLines = 1
                )
              }
            }
            Row {
              if (assistantState.isSpeaking || isTtsPaused) {
                IconButton(onClick = onPauseOrResumeTts, modifier = Modifier.size(48.dp)) {
                  Icon(
                    if (isTtsPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                    contentDescription = "השהה או המשך הקראה",
                    tint = NexusAmber
                  )
                }
              }
              IconButton(
                onClick = { onRefreshTtsVoices(); showVoiceSettingsDialog = true },
                modifier = Modifier.size(48.dp).testTag("voice_settings_button")
              ) {
                Icon(Icons.Rounded.Tune, contentDescription = "הגדרות קול ו-HUD", tint = NexusNeonCyan)
              }
              IconButton(onClick = onToggleCloudAi, modifier = Modifier.size(48.dp)) {
                Icon(
                  Icons.Rounded.AutoAwesome,
                  contentDescription = "ענן או מקומי",
                  tint = if (cloudAiEnabled) NexusNeonCyan else NexusTextSecondary
                )
              }
              IconButton(onClick = onToggleTts, modifier = Modifier.size(48.dp)) {
                Icon(
                  if (ttsEnabled) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                  contentDescription = "הפעל או השתק הקראה",
                  tint = if (ttsEnabled) NexusNeonCyan else NexusTextSecondary
                )
              }
              IconButton(onClick = onClearHistory, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Rounded.DeleteSweep, contentDescription = "נקה היסטוריית שיחה", tint = NexusTextSecondary)
              }
            }
          }
        }

        AssistantModeTabs(selectedMode = selectedMode, onSelect = { selectedMode = it })

        when (selectedMode) {
          AssistantSubMode.CHAT ->
            AssistantChatPane(
              assistantState = assistantState,
              messages = messages,
              listState = listState,
              quickCommands = quickCommands,
              pendingAction = assistantState.pendingAction,
              inputText = inputText,
              onInputChange = { inputText = it },
              onSend = {
                onSendCommand(inputText)
                inputText = ""
              },
              onChipClick = onSendCommand,
              onMicClick = { requestMicThenRun(MicTarget.SPEECH_INTENT, launchSpeechIntent) },
              onConfirmPendingAction = onConfirmPendingAction,
              onDismissPendingAction = onDismissPendingAction,
              onRetryAi = { q -> onRetryAiWithFallback(q, false) },
              onFallbackLocal = { q -> onRetryAiWithFallback(q, true) },
              onDismissAiError = onDismissAiError,
              onRateReply = onRateAssistantReply,
              modifier = Modifier.weight(1f)
            )

          AssistantSubMode.AGENTS_TASKS ->
            OrchestratorAgentsPanel(
              tasks = orchestratorTasks,
              currentlyDoingHe = currentlyDoingHe,
              onStartTask = onStartOrchestratorTask,
              onPauseTask = onPauseTask,
              onResumeTask = onResumeTask,
              onCancelTask = onCancelTask,
              modifier = Modifier.weight(1f)
            )

          AssistantSubMode.MEMORY_LEARNING ->
            MemoryAndLearningPanel(
              memories = memoryEntries,
              memoryAutoSaveEnabled = memoryAutoSaveEnabled,
              learningRecords = learningRecords,
              learningInsights = learningInsights,
              onToggleAutoSave = onToggleMemoryAutoSave,
              onSaveMemory = onSaveMemory,
              onUpdateMemory = onUpdateMemory,
              onTogglePersist = onToggleMemoryPersist,
              onDeleteMemory = onDeleteMemory,
              onClearShortTerm = onClearShortTermMemory,
              onUndoLearning = onUndoLearning,
              modifier = Modifier.weight(1f)
            )

          AssistantSubMode.TOOLS_DOCS ->
            ToolsAndDocumentsPanel(
              networkStatus = networkStatus,
              pendingSyncQueue = pendingSyncQueue,
              toolStatuses = toolStatuses,
              openedDocument = openedDocument,
              isOpeningDocument = isOpeningDocument,
              isSummarizingDocument = isSummarizingDocument,
              onRefreshToolHealth = onRefreshToolHealth,
              onOpenDocumentUri = onOpenDocumentUri,
              onPrevPdfPage = onPrevPdfPage,
              onNextPdfPage = onNextPdfPage,
              onSearchDocument = onSearchDocument,
              onSummarizeDocWithAi = onSummarizeDocWithAi,
              onSaveDocumentUri = onSaveDocumentUri,
              onCloseDocument = onCloseDocument,
              modifier = Modifier.weight(1f)
            )

          AssistantSubMode.TRANSCRIBE ->
            AudioTranscriptionPanel(
              state = transcriptionState,
              onStartRecord = { requestMicThenRun(MicTarget.TRANSCRIBE_WAV, onStartTranscribeRecord) },
              onStopAndTranscribe = onStopAndTranscribe,
              onCancelRecord = onCancelTranscribe,
              onRetry = onRetryTranscribe,
              onUseInChat = { txt ->
                selectedMode = AssistantSubMode.CHAT
                onSendCommand(txt)
                onResetTranscribe()
              },
              onCopySuccess = { onNotifyInfo("התמלול הועתק ללוח.") },
              onReset = onResetTranscribe,
              modifier = Modifier.weight(1f)
            )

          AssistantSubMode.LIVE_VOICE ->
            LiveVoiceConversationPanel(
              state = liveVoiceState,
              onStartLive = { requestMicThenRun(MicTarget.LIVE_VOICE, onStartLiveVoice) },
              onStopLive = onStopLiveVoice,
              onSendLiveText = onSendLiveText,
              modifier = Modifier.weight(1f)
            )

          AssistantSubMode.VISUAL ->
            VisualDiagnosticsPanel(
              state = visualDiagnosisState,
              cloudAiEnabled = cloudAiEnabled,
              onAnalyzeImage = onAnalyzeImage,
              onConfirmAction = onConfirmPendingAction,
              onReset = onResetVisualDiagnosis,
              modifier = Modifier.weight(1f)
            )
        }
      }
    }
  }
}

@Composable
private fun AssistantModeTabs(
  selectedMode: AssistantSubMode,
  onSelect: (AssistantSubMode) -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    AssistantSubMode.entries.forEach { mode ->
      val icon =
        when (mode) {
          AssistantSubMode.CHAT -> Icons.Rounded.Chat
          AssistantSubMode.AGENTS_TASKS -> Icons.Rounded.Psychology
          AssistantSubMode.MEMORY_LEARNING -> Icons.Rounded.Memory
          AssistantSubMode.TOOLS_DOCS -> Icons.Rounded.Build
          AssistantSubMode.TRANSCRIBE -> Icons.Rounded.GraphicEq
          AssistantSubMode.LIVE_VOICE -> Icons.Rounded.RecordVoiceOver
          AssistantSubMode.VISUAL -> Icons.Rounded.ImageSearch
        }
      val tag =
        when (mode) {
          AssistantSubMode.CHAT -> "assistant_mode_chat"
          AssistantSubMode.AGENTS_TASKS -> "assistant_mode_agents"
          AssistantSubMode.MEMORY_LEARNING -> "assistant_mode_memory"
          AssistantSubMode.TOOLS_DOCS -> "assistant_mode_tools"
          AssistantSubMode.TRANSCRIBE -> "assistant_mode_transcribe"
          AssistantSubMode.LIVE_VOICE -> "assistant_mode_live"
          AssistantSubMode.VISUAL -> "assistant_mode_visual"
        }
      FilterChip(
        selected = selectedMode == mode,
        onClick = { onSelect(mode) },
        leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp)) },
        label = { Text(mode.titleHe) },
        shape = RoundedCornerShape(8.dp),
        colors =
          FilterChipDefaults.filterChipColors(
            selectedContainerColor = NexusElectricBlue.copy(alpha = 0.22f),
            selectedLabelColor = MaterialTheme.colorScheme.primary,
            selectedLeadingIconColor = MaterialTheme.colorScheme.primary
          ),
        modifier = Modifier.testTag(tag)
      )
    }
  }
}

@Composable
private fun AssistantChatPane(
  assistantState: AssistantUiState,
  messages: List<AssistantMessageEntity>,
  listState: androidx.compose.foundation.lazy.LazyListState,
  quickCommands: List<String>,
  pendingAction: PendingAssistantAction?,
  inputText: String,
  onInputChange: (String) -> Unit,
  onSend: () -> Unit,
  onChipClick: (String) -> Unit,
  onMicClick: () -> Unit,
  onConfirmPendingAction: (PendingAssistantAction) -> Unit,
  onDismissPendingAction: () -> Unit,
  onRetryAi: (String) -> Unit,
  onFallbackLocal: (String) -> Unit,
  onDismissAiError: () -> Unit,
  onRateReply: (String, Boolean) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(modifier = modifier.fillMaxSize().imePadding()) {
    NexusHairlineDivider()

    if (assistantState.isThinking) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        NexusVoiceWaveformBar(
          isActive = true,
          accentColor = NexusNeonCyan,
          secondaryColor = NexusElectricBlue,
          barCount = 19,
          height = 20.dp,
          modifier = Modifier.width(120.dp)
        )
        Text("אייקו בוחר כלי ומתכנן תשובה...", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
      }
      NexusHairlineDivider()
    }

    // Editorial Chat Stream (no generic heavy bubbles — crisp vertical accent strip + generous spacing)
    LazyColumn(
      state = listState,
      modifier = Modifier.weight(1f).fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(vertical = 12.dp)
    ) {
      items(messages, key = { it.id }) { msg ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = if (msg.isUser) Arrangement.Start else Arrangement.End
        ) {
          val accent = if (msg.isUser) NexusElectricBlue else NexusNeonCyan
          Row(
            modifier =
              Modifier
                .fillMaxWidth(0.90f)
                .height(IntrinsicSize.Min)
                .clip(RoundedCornerShape(10.dp))
                .background(
                  if (msg.isUser) NexusElectricBlue.copy(alpha = 0.09f)
                  else MaterialTheme.colorScheme.surface
                )
                .border(
                  1.dp,
                  if (msg.isUser) NexusElectricBlue.copy(alpha = 0.35f)
                  else MaterialTheme.colorScheme.outline.copy(alpha = 0.65f),
                  RoundedCornerShape(10.dp)
                )
                .padding(12.dp)
          ) {
            Box(
              modifier =
                Modifier
                  .width(3.dp)
                  .fillMaxHeight()
                  .background(accent, RoundedCornerShape(2.dp))
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (msg.isUser) "אתה" else "אייקו",
                style = MaterialTheme.typography.labelSmall,
                color = if (msg.isUser) NexusElectricBlue else MaterialTheme.colorScheme.primary
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = msg.text,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
              )
              if (!msg.isUser) {
                Row(
                  modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                  horizontalArrangement = Arrangement.End
                ) {
                  IconButton(
                    onClick = { onRateReply(msg.text, true) },
                    modifier = Modifier.size(48.dp)
                  ) {
                    Icon(
                      Icons.Rounded.ThumbUp,
                      contentDescription = "תשובה טובה",
                      tint = NexusEmerald,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                  IconButton(
                    onClick = { onRateReply(msg.text, false) },
                    modifier = Modifier.size(48.dp)
                  ) {
                    Icon(
                      Icons.Rounded.ThumbDown,
                      contentDescription = "תשובה לשיפור",
                      tint = NexusAmber,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    if (assistantState.aiError != null) {
      val err = assistantState.aiError
      val failedQuery = assistantState.lastFailedInput
      Spacer(modifier = Modifier.height(6.dp))
      Surface(
        color = NexusCrimson.copy(alpha = 0.11f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(err.messageHe, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!failedQuery.isNullOrBlank()) {
              Button(
                onClick = { onRetryAi(failedQuery) },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
                modifier = Modifier.height(48.dp)
              ) {
                Text("נסה שוב")
              }
              OutlinedButton(
                onClick = { onFallbackLocal(failedQuery) },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(48.dp)
              ) {
                Text("ענה מקומית", color = MaterialTheme.colorScheme.primary)
              }
            }
            OutlinedButton(
              onClick = onDismissAiError,
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.height(48.dp)
            ) {
              Text("סגור", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      }
    }

    if (pendingAction != null) {
      Spacer(modifier = Modifier.height(8.dp))
      Surface(
        color = NexusAmber.copy(alpha = 0.11f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.65f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(text = pendingAction.title, style = MaterialTheme.typography.titleMedium, color = NexusAmber)
          Text(text = pendingAction.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Spacer(modifier = Modifier.height(10.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = { onConfirmPendingAction(pendingAction) },
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.buttonColors(containerColor = NexusEmerald),
              modifier = Modifier.height(48.dp).testTag("assistant_confirm_action")
            ) {
              Text("אשר ובצע", color = NexusObsidian, fontWeight = FontWeight.SemiBold)
            }
            OutlinedButton(
              onClick = onDismissPendingAction,
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.height(48.dp)
            ) {
              Text("בטל", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))
    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      quickCommands.forEach { cmd ->
        Surface(
          color = MaterialTheme.colorScheme.surface,
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f)),
          modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { onChipClick(cmd) }
        ) {
          Text(
            text = cmd,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))
    NexusHairlineDivider()
    Spacer(modifier = Modifier.height(10.dp))

    // Studio Composer
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      IconButton(
        onClick = onMicClick,
        modifier =
          Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(NexusTitaniumElevated)
            .testTag("assistant_mic_button")
      ) {
        Icon(Icons.Rounded.Mic, contentDescription = "הקלדה קולית", tint = NexusNeonCyan)
      }
      OutlinedTextField(
        value = inputText,
        onValueChange = onInputChange,
        modifier = Modifier.weight(1f).testTag("assistant_input"),
        placeholder = { Text("דבר איתי טבעית בעברית...", color = MaterialTheme.colorScheme.onSurfaceVariant) },
        singleLine = true,
        shape = RoundedCornerShape(10.dp),
        colors =
          OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.7f),
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
            focusedTextColor = MaterialTheme.colorScheme.onSurface,
            unfocusedTextColor = MaterialTheme.colorScheme.onSurface
          )
      )
      IconButton(
        onClick = onSend,
        modifier =
          Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(NexusElectricBlue)
            .testTag("assistant_send_button")
      ) {
        Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "שלח פקודה", tint = Color.White)
      }
    }
  }
}
