package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalIsDarkTheme
import com.example.ui.theme.LocalMotionConfig
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusBorderGraphite
import com.example.ui.theme.NexusBorderSubtle
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusLightBorder
import com.example.ui.theme.NexusLightCardElevated
import com.example.ui.theme.NexusLightSurface
import com.example.ui.theme.NexusTitaniumCard
import com.example.ui.theme.NexusTitaniumElevated

/**
 * Architectural graphite surface: crisp 12.dp geometry, 1.dp hairline border, layered tonal contrast.
 */
@Composable
fun NexusHudCard(
  modifier: Modifier = Modifier,
  selected: Boolean = false,
  isAlert: Boolean = false,
  accentColor: Color = NexusBorderGlow,
  contentPadding: Dp = 16.dp,
  content: @Composable ColumnScope.() -> Unit
) {
  val motion = LocalMotionConfig.current
  val isDark = LocalIsDarkTheme.current
  val primaryColor = MaterialTheme.colorScheme.primary
  val errorColor = MaterialTheme.colorScheme.error

  val resolvedAccent =
    if (accentColor == NexusBorderGlow && !isDark) primaryColor else accentColor

  val borderColor by
    animateColorAsState(
      targetValue =
        when {
          isAlert -> errorColor.copy(alpha = 0.78f)
          selected -> resolvedAccent.copy(alpha = 0.88f)
          isDark -> NexusBorderGraphite.copy(alpha = 0.85f)
          else -> NexusLightBorder
        },
      animationSpec = tween(motion.duration(190, 80)),
      label = "arch_surface_border"
    )

  val surfaceColor by
    animateColorAsState(
      targetValue =
        when {
          isDark && selected -> NexusTitaniumElevated
          isDark -> NexusTitaniumCard
          selected -> NexusLightCardElevated
          else -> NexusLightSurface
        },
      animationSpec = tween(motion.duration(190, 80)),
      label = "arch_surface_bg"
    )

  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(12.dp),
    color = surfaceColor,
    tonalElevation = 0.dp,
    shadowElevation = 0.dp,
    border = BorderStroke(if (selected || isAlert) 1.3.dp else 1.dp, borderColor)
  ) {
    Column(modifier = Modifier.padding(contentPadding), content = content)
  }
}

/**
 * Recessed graphite/slate data well for tabular telemetry, hashes, and compact controls.
 */
@Composable
fun NexusDataWell(
  modifier: Modifier = Modifier,
  accentColor: Color? = null,
  contentPadding: Dp = 12.dp,
  content: @Composable ColumnScope.() -> Unit
) {
  val isDark = LocalIsDarkTheme.current
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(10.dp),
    color = MaterialTheme.colorScheme.surfaceContainerLowest,
    tonalElevation = 0.dp,
    shadowElevation = 0.dp,
    border =
      BorderStroke(
        1.dp,
        accentColor?.copy(alpha = if (isDark) 0.42f else 0.30f)
          ?: if (isDark) NexusBorderSubtle else NexusLightBorder
      )
  ) {
    Column(modifier = Modifier.padding(contentPadding), content = content)
  }
}

/**
 * Open editorial panel without boxed walls — uses a slim vertical accent rule and clear hierarchy.
 */
@Composable
fun NexusEditorialSection(
  title: String,
  accentColor: Color = MaterialTheme.colorScheme.primary,
  subtitle: String? = null,
  trailing: (@Composable () -> Unit)? = null,
  modifier: Modifier = Modifier,
  content: @Composable ColumnScope.() -> Unit
) {
  Column(modifier = modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier =
          Modifier
            .width(3.dp)
            .fillMaxHeight()
            .background(accentColor, RoundedCornerShape(2.dp))
      )
      Spacer(modifier = Modifier.width(10.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface
        )
        if (!subtitle.isNullOrBlank()) {
          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
      if (trailing != null) {
        Spacer(modifier = Modifier.width(10.dp))
        trailing()
      }
    }
    Spacer(modifier = Modifier.height(10.dp))
    content()
  }
}

@Composable
fun NexusHairlineDivider(modifier: Modifier = Modifier) {
  HorizontalDivider(
    modifier = modifier.fillMaxWidth(),
    thickness = 1.dp,
    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.72f)
  )
}

@Composable
fun NexusConfirmationDialog(
  title: String,
  message: String,
  confirmText: String,
  cancelText: String = "ביטול",
  isDestructive: Boolean = false,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
    titleContentColor = MaterialTheme.colorScheme.onSurface,
    textContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
    shape = RoundedCornerShape(14.dp),
    title = {
      Text(
        text = title,
        style = MaterialTheme.typography.titleLarge,
        color = if (isDestructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
      )
    },
    text = {
      Text(
        text = message,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    },
    confirmButton = {
      Button(
        onClick = onConfirm,
        shape = RoundedCornerShape(10.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = if (isDestructive) MaterialTheme.colorScheme.error else NexusElectricBlue,
            contentColor = Color.White
          ),
        modifier = Modifier.testTag("dialog_confirm_button")
      ) {
        Text(text = confirmText)
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.testTag("dialog_cancel_button")
      ) {
        Text(text = cancelText, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
  )
}
