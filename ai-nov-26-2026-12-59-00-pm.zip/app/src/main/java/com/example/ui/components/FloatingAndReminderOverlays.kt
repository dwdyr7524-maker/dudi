package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddAlert
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.data.local.OrchestratorTaskEntity
import com.example.data.local.ReminderAlertEntity
import com.example.data.orchestrator.OrchestratorTaskStatus
import com.example.data.system.VoiceOptionInfo
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusBorderSubtle
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import kotlin.math.roundToInt

/**
 * Permission-free in-app draggable Floating Quick-Control HUD.
 * Avoids SYSTEM_ALERT_WINDOW (restricted by Google Play policy & Android 10 OEM limits)
 * while staying accessible across all 13 NEXUS screens.
 */
@Composable
fun FloatingAssistantHud(
  enabled: Boolean,
  savedOffsetX: Float,
  savedOffsetY: Float,
  activeTasks: List<OrchestratorTaskEntity>,
  currentlyDoingHe: String?,
  isSpeaking: Boolean,
  isTtsPaused: Boolean,
  onSaveOffset: (Float, Float) -> Unit,
  onSendQuickCommand: (String) -> Unit,
  onOpenAssistantVoice: () -> Unit,
  onPauseOrResumeTts: () -> Unit,
  onStopTts: () -> Unit,
  onHideFloatingHud: () -> Unit,
  modifier: Modifier = Modifier
) {
  if (!enabled) return

  var offsetX by remember(savedOffsetX) { mutableFloatStateOf(savedOffsetX) }
  var offsetY by remember(savedOffsetY) { mutableFloatStateOf(savedOffsetY) }
  var expanded by rememberSaveable { mutableStateOf(false) }
  var miniInput by rememberSaveable { mutableStateOf("") }

  val runningTask = activeTasks.firstOrNull { it.status == OrchestratorTaskStatus.RUNNING.name }

  if (expanded) {
    AlertDialog(
      onDismissRequest = { expanded = false },
      containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
      shape = RoundedCornerShape(22.dp),
      title = {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Rounded.Psychology, contentDescription = null, tint = NexusNeonCyan)
            Text("פקודה מהירה NEXUS HUD", style = MaterialTheme.typography.titleMedium, color = NexusNeonCyan)
          }
          IconButton(onClick = { expanded = false }) {
            Icon(Icons.Rounded.Close, contentDescription = "סגור")
          }
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          if (runningTask != null || !currentlyDoingHe.isNullOrBlank()) {
            Surface(
              color = NexusNeonCyan.copy(alpha = 0.12f),
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, NexusNeonCyan.copy(alpha = 0.45f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                  text = currentlyDoingHe ?: runningTask?.currentStepLabel ?: "משימה פעילה",
                  style = MaterialTheme.typography.bodySmall,
                  color = NexusNeonCyan
                )
                if (runningTask != null) {
                  LinearProgressIndicator(
                    progress = { (runningTask.progressPercent / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                  )
                }
              }
            }
          }

          OutlinedTextField(
            value = miniInput,
            onValueChange = { miniInput = it },
            placeholder = { Text("שלח פקודה מהירה מכל מסך...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("floating_hud_input")
          )

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
              onClick = {
                if (miniInput.isNotBlank()) {
                  onSendQuickCommand(miniInput)
                  miniInput = ""
                  expanded = false
                }
              },
              enabled = miniInput.isNotBlank(),
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("שלח")
            }
            OutlinedButton(
              onClick = {
                expanded = false
                onOpenAssistantVoice()
              },
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Rounded.Mic, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("עוזר וקול")
            }
          }

          if (isSpeaking || isTtsPaused) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
              OutlinedButton(onClick = onPauseOrResumeTts, modifier = Modifier.weight(1f)) {
                Icon(
                  if (isTtsPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isTtsPaused) "המשך הקראה" else "השהה הקראה")
              }
              OutlinedButton(onClick = onStopTts, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("עצור")
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(
          onClick = {
            expanded = false
            onHideFloatingHud()
          }
        ) {
          Icon(Icons.Rounded.VisibilityOff, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("הסתר כפתור צף")
        }
      },
      dismissButton = {
        TextButton(onClick = { expanded = false }) { Text("סגור") }
      }
    )
  }

  Surface(
    modifier =
      modifier
        .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
        .pointerInput(Unit) {
          detectDragGestures(
            onDragEnd = { onSaveOffset(offsetX, offsetY) }
          ) { change, dragAmount ->
            change.consume()
            offsetX = (offsetX + dragAmount.x).coerceIn(-260f, 260f)
            offsetY = (offsetY + dragAmount.y).coerceIn(-480f, 80f)
          }
        }
        .clip(RoundedCornerShape(28.dp))
        .clickable { expanded = true }
        .testTag("floating_assistant_button"),
    shape = RoundedCornerShape(28.dp),
    color = if (runningTask != null) NexusElectricBlue else MaterialTheme.colorScheme.surfaceContainerHighest,
    border = BorderStroke(1.5.dp, if (runningTask != null) NexusNeonCyan else NexusBorderGlow.copy(alpha = 0.65f)),
    shadowElevation = 8.dp
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Icon(
        imageVector = Icons.Rounded.Psychology,
        contentDescription = "כפתור שליטה מהירה של NEXUS",
        tint = if (runningTask != null) androidx.compose.ui.graphics.Color.White else NexusNeonCyan,
        modifier = Modifier.size(22.dp)
      )
      Text(
        text =
          when {
            runningTask != null -> "משימה ${runningTask.progressPercent}%"
            isSpeaking -> "מקריא..."
            else -> "NEXUS HUD"
          },
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        color = if (runningTask != null) androidx.compose.ui.graphics.Color.White else MaterialTheme.colorScheme.onSurface
      )
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReminderAndNotificationSheet(
  alerts: List<ReminderAlertEntity>,
  onDismissSheet: () -> Unit,
  onCreateReminder: (title: String, message: String, delayMinutes: Long, repeatHours: Int, conditionKey: String) -> Unit,
  onDismissAlert: (Long) -> Unit,
  onCancelAlert: (Long) -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var newTitle by rememberSaveable { mutableStateOf("") }
  var delayMinutes by rememberSaveable { mutableLongStateOf(30L) }
  var conditionKey by rememberSaveable { mutableStateOf("NONE") }

  ModalBottomSheet(
    onDismissRequest = onDismissSheet,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Rounded.NotificationsActive, contentDescription = null, tint = NexusNeonCyan)
        Text("מרכז תזכורות והתראות (WorkManager)", style = MaterialTheme.typography.titleLarge, color = NexusNeonCyan)
      }

      Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, NexusBorderSubtle),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("תזכורת או התראת תנאי חדשה:", style = MaterialTheme.typography.labelLarge)
          OutlinedTextField(
            value = newTitle,
            onValueChange = { newTitle = it },
            label = { Text("נושא התזכורת (למשל: בדוק גיבוי SD)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("reminder_title_input")
          )
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            listOf(
              "NONE" to "בזמן קצוב",
              "BATTERY_LOW" to "סוללה מתחת ל-20%",
              "BATTERY_HOT" to "סוללה מתחממת",
              "STORAGE_FULL" to "אחסון כמעט מלא",
              "NETWORK_RECONNECTED" to "כשחוזר אינטרנט"
            ).forEach { (key, label) ->
              FilterChip(
                selected = conditionKey == key,
                onClick = { conditionKey = key },
                label = { Text(label) }
              )
            }
          }
          if (conditionKey == "NONE") {
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              listOf(5L to "בעוד 5 דק׳", 30L to "30 דק׳", 60L to "שעה", 240L to "4 שעות").forEach { (m, label) ->
                FilterChip(
                  selected = delayMinutes == m,
                  onClick = { delayMinutes = m },
                  label = { Text(label) }
                )
              }
            }
          }
          Button(
            onClick = {
              if (newTitle.isNotBlank()) {
                onCreateReminder(newTitle, "", delayMinutes, 0, conditionKey)
                newTitle = ""
              }
            },
            enabled = newTitle.isNotBlank(),
            modifier = Modifier.fillMaxWidth().testTag("create_reminder_btn")
          ) {
            Icon(Icons.Rounded.AddAlert, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("קבע תזכורת")
          }
        }
      }

      LazyColumn(
        modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        if (alerts.isEmpty()) {
          item {
            Text(
              "אין כרגע תזכורות או התראות פעילות.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        } else {
          items(alerts, key = { it.id }) { alert ->
            val accent =
              when (alert.kind) {
                "FAILURE" -> NexusCrimson
                "COMPLETION" -> NexusEmerald
                else -> NexusAmber
              }
            Surface(
              color = MaterialTheme.colorScheme.surface,
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(alert.title, style = MaterialTheme.typography.titleSmall, color = accent)
                  Text(alert.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text("סטטוס: ${alert.status}", style = MaterialTheme.typography.labelSmall)
                }
                Row {
                  if (alert.status != "DISMISSED") {
                    TextButton(onClick = { onDismissAlert(alert.id) }) { Text("סמן נקרא") }
                  }
                  IconButton(onClick = { onCancelAlert(alert.id) }) {
                    Icon(Icons.Rounded.Delete, contentDescription = "מחק תזכורת", tint = NexusCrimson)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun VoiceSettingsDialog(
  ttsRate: Float,
  selectedVoiceName: String?,
  availableVoices: List<VoiceOptionInfo>,
  isSpeaking: Boolean,
  isTtsPaused: Boolean,
  noiseSuppressionEnabled: Boolean,
  floatingHudEnabled: Boolean,
  onRateChange: (Float) -> Unit,
  onSelectVoice: (String?) -> Unit,
  onPauseOrResumeTts: () -> Unit,
  onStopTts: () -> Unit,
  onToggleNoiseSuppression: (Boolean) -> Unit,
  onToggleFloatingHud: (Boolean) -> Unit,
  onRefreshVoices: () -> Unit,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Rounded.RecordVoiceOver, contentDescription = null, tint = NexusNeonCyan)
        Text("הגדרות קול, סינון רעשים ו-HUD", style = MaterialTheme.typography.titleMedium)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("קצב דיבור (${String.format(java.util.Locale.US, "%.1fx", ttsRate)})", style = MaterialTheme.typography.labelLarge)
        Slider(
          value = ttsRate,
          onValueChange = onRateChange,
          valueRange = 0.6f..1.8f
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
          OutlinedButton(
            onClick = onPauseOrResumeTts,
            enabled = isSpeaking || isTtsPaused,
            modifier = Modifier.weight(1f)
          ) {
            Text(if (isTtsPaused) "המשך הקראה" else "השהה הקראה")
          }
          OutlinedButton(
            onClick = onStopTts,
            enabled = isSpeaking || isTtsPaused,
            modifier = Modifier.weight(1f)
          ) {
            Text("עצור")
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("סינון רעשי רקע חומרתי", style = MaterialTheme.typography.bodyMedium)
            Text("NoiseSuppressor + EchoCanceler ב-AudioRecord", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Switch(checked = noiseSuppressionEnabled, onCheckedChange = onToggleNoiseSuppression)
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("כפתור קול ופקודה צף בתוך NEXUS", style = MaterialTheme.typography.bodyMedium)
            Text("גישה מהירה מכל מסך באפליקציה", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Switch(checked = floatingHudEnabled, onCheckedChange = onToggleFloatingHud)
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("בחירת קול TTS (${availableVoices.size}):", style = MaterialTheme.typography.labelLarge)
          TextButton(onClick = onRefreshVoices) { Text("רענן") }
        }
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          FilterChip(
            selected = selectedVoiceName.isNullOrBlank(),
            onClick = { onSelectVoice(null) },
            label = { Text("ברירת מחדל עברית") }
          )
          availableVoices.forEach { v ->
            FilterChip(
              selected = selectedVoiceName == v.name,
              onClick = { onSelectVoice(v.name) },
              label = { Text(v.labelHe, maxLines = 1) }
            )
          }
        }

        Surface(
          color = NexusAmber.copy(alpha = 0.12f),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "שקיפות Android 10: האזנה רציפה למילת הפעלה כשהמסך כבוי (CAPTURE_AUDIO_HOTWORD) שמורה ב-Android לרכיבי מערכת מובנים בלבד; להפעלה קולית מהירה השתמש בכפתור המיקרופון או בשיחה החיה.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(8.dp)
          )
        }
      }
    },
    confirmButton = {
      Button(onClick = onDismiss) { Text("סיום") }
    }
  )
}
