package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.BatterySaver
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.local.TelemetrySnapshotEntity
import com.example.data.model.SystemTelemetry
import com.example.ui.components.NexusDataWell
import com.example.ui.components.NexusEditorialSection
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusLiveTrendChart
import com.example.ui.components.NexusMetricArcGauge
import com.example.ui.components.NexusToggleSwitch
import com.example.ui.components.nexusInteractive
import com.example.ui.components.nexusStaggeredEntrance
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusTurquoiseBright
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BatteryScreen(
  telemetry: SystemTelemetry,
  snapshots: List<TelemetrySnapshotEntity>,
  backgroundAlertsEnabled: Boolean,
  alertIntervalMinutes: Long,
  onToggleBackgroundAlerts: (Boolean) -> Unit,
  onSelectAlertInterval: (Long) -> Unit,
  onRunBackgroundCheckNow: () -> Unit,
  onOpenBatterySettings: () -> Unit,
  onRecordSnapshotNow: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  val context = LocalContext.current
  val notificationPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      if (granted) {
        onToggleBackgroundAlerts(true)
      }
    }

  val b = telemetry.battery
  val ordered = snapshots.reversed()
  val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
  val labels = ordered.map { timeFmt.format(Date(it.timestampMillis)) }
  val levelValues = ordered.map { it.batteryPercent.toFloat() }
  val tempValues = ordered.map { it.batteryTempC }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isWide = maxWidth >= 740.dp

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      if (b.isAbnormal && b.alertMessage != null) {
        item {
          NexusHudCard(
            isAlert = true,
            accentColor = NexusCrimson,
            modifier = Modifier.nexusStaggeredEntrance(0, "bat_alert")
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = NexusCrimson)
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("התראת סוללה חריגה", style = MaterialTheme.typography.titleMedium, color = NexusCrimson)
                Text(b.alertMessage, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
              }
            }
          }
        }
      }

      item {
        NexusHudCard(
          accentColor = if (b.isAbnormal) NexusCrimson else NexusTurquoiseBright,
          modifier = Modifier.nexusStaggeredEntrance(0, "bat_hero")
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(
                text = "ניהול סוללה וניטור תרמי",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = "${b.levelPercent}% • ${b.chargeSource}",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "טכנולוגיה: ${b.technology} • חיסכון בסוללה: ${if (b.isPowerSaveMode) "פעיל" else "כבוי"}",
                style = MaterialTheme.typography.bodySmall,
                color = if (b.isPowerSaveMode) NexusAmber else MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            NexusMetricArcGauge(
              percent = b.levelPercent,
              accentColor = if (b.isAbnormal) NexusCrimson else MaterialTheme.colorScheme.primary,
              centerText = "${b.levelPercent}%",
              size = 96.dp
            )
          }

          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            NexusDataWell(modifier = Modifier.weight(1f), contentPadding = 10.dp) {
              Text("טמפרטורה", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = "${String.format(Locale.US, "%.1f", b.temperatureC)}°C",
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                color = if (b.temperatureC >= 40f) NexusAmber else MaterialTheme.colorScheme.primary
              )
            }
            NexusDataWell(modifier = Modifier.weight(1f), contentPadding = 10.dp) {
              Text("מתח סוללה", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = "${b.voltageMv} mV",
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
              )
            }
            NexusDataWell(modifier = Modifier.weight(1f), contentPadding = 10.dp) {
              Text("בריאות תא", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = b.healthLabel,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
              onClick = onOpenBatterySettings,
              modifier = Modifier.weight(1f).height(48.dp).nexusInteractive().testTag("battery_open_settings"),
              colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Rounded.BatterySaver, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("הגדרות וחיסכון בסוללה")
            }
            OutlinedButton(
              onClick = onRecordSnapshotNow,
              modifier = Modifier.weight(1f).height(48.dp).nexusInteractive().testTag("battery_record_snapshot"),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Rounded.BatteryChargingFull, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("דגום מדד כעת", color = MaterialTheme.colorScheme.primary)
            }
          }
        }
      }

      item {
        if (isWide) {
          Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.nexusStaggeredEntrance(1, "bat_charts")) {
            NexusHudCard(modifier = Modifier.weight(1f)) {
              Text("מגמת אחוזי סוללה לאורך זמן", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
              Spacer(modifier = Modifier.height(8.dp))
              NexusLiveTrendChart(
                values = levelValues.ifEmpty { listOf(b.levelPercent.toFloat()) },
                labels = labels,
                lineColor = MaterialTheme.colorScheme.primary,
                unitSuffix = "%"
              )
            }
            NexusHudCard(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Thermostat, contentDescription = null, tint = NexusAmber, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("מגמת טמפרטורה (°C)", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
              }
              Spacer(modifier = Modifier.height(8.dp))
              NexusLiveTrendChart(
                values = tempValues.ifEmpty { listOf(b.temperatureC) },
                labels = labels,
                lineColor = NexusAmber,
                unitSuffix = "°C"
              )
            }
          }
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            NexusHudCard {
              Text("מגמת אחוזי סוללה לאורך זמן", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
              Spacer(modifier = Modifier.height(8.dp))
              NexusLiveTrendChart(
                values = levelValues.ifEmpty { listOf(b.levelPercent.toFloat()) },
                labels = labels,
                lineColor = MaterialTheme.colorScheme.primary,
                unitSuffix = "%"
              )
            }
            NexusHudCard {
              Text("מגמת טמפרטורה (°C)", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
              Spacer(modifier = Modifier.height(8.dp))
              NexusLiveTrendChart(
                values = tempValues.ifEmpty { listOf(b.temperatureC) },
                labels = labels,
                lineColor = NexusAmber,
                unitSuffix = "°C"
              )
            }
          }
        }
      }

      item {
        NexusHudCard(
          accentColor = MaterialTheme.colorScheme.primary,
          modifier = Modifier.nexusStaggeredEntrance(2, "bat_monitor")
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Icon(Icons.Rounded.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("ניטור רקע והתראות חום (WorkManager)", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                Text(
                  "התרעה אוטומטית כשהסוללה מתחממת מעל 42°C, יורדת מתחת ל-15% או שהאחסון מלא, וכן סנכרון הווידג׳ט.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
            Spacer(modifier = Modifier.width(12.dp))
            NexusToggleSwitch(
              checked = backgroundAlertsEnabled,
              onCheckedChange = { wantEnable ->
                if (wantEnable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                  val granted =
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                      PackageManager.PERMISSION_GRANTED
                  if (!granted) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    return@NexusToggleSwitch
                  }
                }
                onToggleBackgroundAlerts(wantEnable)
              },
              accentColor = MaterialTheme.colorScheme.primary
            )
          }

          Spacer(modifier = Modifier.height(12.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(15L to "כל 15 דק׳", 30L to "כל 30 דק׳", 60L to "כל שעה").forEach { (mins, label) ->
              FilterChip(
                selected = alertIntervalMinutes == mins,
                onClick = { onSelectAlertInterval(mins) },
                label = { Text(label) },
                shape = RoundedCornerShape(8.dp),
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NexusElectricBlue.copy(alpha = 0.24f),
                    selectedLabelColor = MaterialTheme.colorScheme.primary
                  )
              )
            }
          }
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedButton(
            onClick = {
              if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
              ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
              } else {
                onRunBackgroundCheckNow()
              }
            },
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("battery_test_worker_button")
          ) {
            Text("בצע בדיקת רקע, שלח התראת דוגמה ועדכן וידג׳ט", color = MaterialTheme.colorScheme.primary)
          }
        }
      }

      item {
        NexusEditorialSection(
          title = "המלצת חומרה לדגם הטאבלט",
          accentColor = NexusElectricBlue
        ) {
          NexusDataWell(accentColor = NexusElectricBlue) {
            Text(
              text = "בטאבלט Samsung Galaxy Tab Active Pro מומלץ להימנע מהפעלת עומס גרפי כבד בזמן טעינה מהירה כאשר הטמפרטורה עולה מעל 40°C.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }
  }
}
