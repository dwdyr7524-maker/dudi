package com.example.ui.screens

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.FileCopy
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.SdStorage
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material.icons.rounded.Unarchive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AiOrganizationProposalDraft
import com.example.data.model.ApprovalOperationType
import com.example.data.model.ApprovalRiskLevel
import com.example.data.model.CategoryBreakdown
import com.example.data.model.FileCategory
import com.example.data.model.FileSortMode
import com.example.data.model.FolderStorageSummary
import com.example.data.model.ScannedFileEntry
import com.example.data.model.SmartStorageScanReport
import com.example.data.model.StorageVolumeKind
import com.example.data.model.SystemTelemetry
import com.example.data.system.formatBytes
import com.example.ui.components.NexusDataWell
import com.example.ui.components.NexusEditorialSection
import com.example.ui.components.NexusHairlineDivider
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusWaveProgressBar
import com.example.ui.components.nexusInteractive
import com.example.ui.components.nexusStaggeredEntrance
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusDeepBlueGlow
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusTurquoise
import com.example.ui.theme.NexusTurquoiseBright
import com.example.ui.theme.NexusViolet
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val CATEGORY_COLORS =
  listOf(
    NexusTurquoiseBright,
    NexusElectricBlue,
    NexusEmerald,
    NexusAmber,
    NexusDeepBlueGlow,
    NexusNeonCyan,
    NexusCrimson,
    NexusViolet,
    Color(0xFF64748B)
  )

@Composable
private fun storageFieldColors() =
  OutlinedTextFieldDefaults.colors(
    focusedBorderColor = MaterialTheme.colorScheme.primary,
    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
    focusedTextColor = MaterialTheme.colorScheme.onSurface,
    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
  )

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SmartStorageScreen(
  report: SmartStorageScanReport?,
  telemetry: SystemTelemetry,
  safFolders: Set<String>,
  isScanning: Boolean,
  onRunFullScan: () -> Unit,
  onRequestAddSafFolder: () -> Unit,
  onRemoveSafFolder: (String) -> Unit,
  onStageProposal: (AiOrganizationProposalDraft, Boolean) -> Unit,
  onOpenAiFileManager: () -> Unit,
  onStageBatchCopyMove: (List<ScannedFileEntry>, String, String, Boolean) -> Unit = { _, _, _, _ -> },
  onStageZipCreate: (List<ScannedFileEntry>, String, String?) -> Unit = { _, _, _ -> },
  onStageZipExtract: (ScannedFileEntry, String, Boolean) -> Unit = { _, _, _ -> },
  onStageFolderTransfer: (FolderStorageSummary, String, String, Boolean) -> Unit = { _, _, _, _ -> },
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf<FileCategory?>(null) }
  var sortMode by remember { mutableStateOf(FileSortMode.SIZE_DESC) }
  var volumeFilter by remember { mutableStateOf<StorageVolumeKind?>(null) }

  var selectedFileUris by remember { mutableStateOf(setOf<String>()) }
  var showZipCreateDialog by remember { mutableStateOf(false) }
  var zipArchiveName by remember { mutableStateOf("Nexus_Archive.zip") }
  var batchTransferMove by remember { mutableStateOf<Boolean?>(null) }
  var batchDestFolder by remember { mutableStateOf("NEXUS_Batch") }
  var batchDestTree by remember { mutableStateOf<String?>(null) }

  var extractTarget by remember { mutableStateOf<ScannedFileEntry?>(null) }
  var extractFolderName by remember { mutableStateOf("") }
  var extractOverwrite by remember { mutableStateOf(false) }

  var folderTransferTarget by remember { mutableStateOf<Pair<FolderStorageSummary, Boolean>?>(null) }
  var folderDestTree by remember { mutableStateOf<String?>(null) }
  var folderDestName by remember { mutableStateOf("") }

  var renameTarget by remember { mutableStateOf<ScannedFileEntry?>(null) }
  var renameText by remember { mutableStateOf("") }
  var createFolderTree by remember { mutableStateOf<String?>(null) }
  var createFolderName by remember { mutableStateOf("") }
  var moveTarget by remember { mutableStateOf<ScannedFileEntry?>(null) }
  var moveDestTree by remember { mutableStateOf<String?>(null) }
  var moveDestSubfolder by remember { mutableStateOf("NEXUS_Moved") }

  val filteredFiles =
    remember(report, searchQuery, selectedCategory, sortMode, volumeFilter) {
      val base = report?.files.orEmpty()
      val q = searchQuery.trim().lowercase()
      val filtered =
        base.filter { file ->
          (selectedCategory == null || file.category == selectedCategory) &&
            (volumeFilter == null || file.volumeKind == volumeFilter) &&
            (q.isEmpty() ||
              file.name.lowercase().contains(q) ||
              file.relativePath.lowercase().contains(q))
        }
      when (sortMode) {
        FileSortMode.SIZE_DESC -> filtered.sortedByDescending { it.sizeBytes }
        FileSortMode.DATE_DESC -> filtered.sortedByDescending { it.lastModifiedMillis }
        FileSortMode.NAME_ASC -> filtered.sortedBy { it.name.lowercase() }
        FileSortMode.TYPE -> filtered.sortedBy { it.category.titleHe }
      }
    }

  val sdTreeUris =
    remember(report, safFolders) {
      report?.volumes?.firstOrNull { it.kind == StorageVolumeKind.SD_CARD }?.authorizedTreeUris
        ?: safFolders.filter { !it.contains("primary", ignoreCase = true) }
    }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isWide = maxWidth >= 740.dp

    LazyColumn(
      modifier = Modifier.fillMaxSize().testTag("smart_storage_screen"),
      contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // 1. Storage Console Header & SAF Permissions (Graphite Card)
      item {
        NexusHudCard(
          accentColor = NexusElectricBlue,
          modifier = Modifier.nexusStaggeredEntrance(0, "st_header")
        ) {
          NexusEditorialSection(
            title = "קונסולת אחסון, SAF וכרטיס SD",
            subtitle = "סריקה אמיתית, אימות שלמות SHA-256 לפני מחיקת מקור, והגנת אי-דריסה ב-Android 10.",
            accentColor = NexusElectricBlue,
            trailing = {
              Button(
                onClick = onRunFullScan,
                enabled = !isScanning,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
                modifier = Modifier.height(48.dp).nexusInteractive().testTag("smart_storage_scan_btn")
              ) {
                if (isScanning) {
                  CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    strokeWidth = 2.dp,
                    color = Color.White
                  )
                } else {
                  Icon(Icons.Rounded.Radar, contentDescription = null, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (isScanning) "סורק..." else "סריקת אחסון")
              }
            }
          ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedButton(
                onClick = onRequestAddSafFolder,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
                modifier = Modifier.height(48.dp).nexusInteractive().testTag("smart_storage_add_saf_btn")
              ) {
                Icon(Icons.Rounded.FolderOpen, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("אשר תיקייה / כרטיס SD", color = MaterialTheme.colorScheme.primary)
              }
              if (safFolders.isNotEmpty()) {
                OutlinedButton(
                  onClick = { createFolderTree = safFolders.first() },
                  shape = RoundedCornerShape(10.dp),
                  border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                  modifier = Modifier.height(48.dp).nexusInteractive()
                ) {
                  Icon(Icons.Rounded.CreateNewFolder, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("צור תיקייה (לאישור)", color = MaterialTheme.colorScheme.onSurface)
                }
              }
            }

            if (safFolders.isNotEmpty()) {
              Spacer(modifier = Modifier.height(10.dp))
              FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                safFolders.forEach { uriStr ->
                  val name = Uri.parse(uriStr).lastPathSegment?.substringAfterLast(':') ?: "תיקייה"
                  AssistChip(
                    onClick = { onRemoveSafFolder(uriStr) },
                    shape = RoundedCornerShape(8.dp),
                    label = { Text("תיקייה: $name ×", maxLines = 1) }
                  )
                }
              }
            }
          }
        }
      }

      // 2. Architectural Volume Bands (Internal Storage & SD Card side-by-side on tablet)
      item {
        val volumes = report?.volumes.orEmpty()
        if (volumes.isEmpty()) {
          NexusHudCard(
            accentColor = if (telemetry.storage.usedPercent >= 85) NexusCrimson else MaterialTheme.colorScheme.primary,
            modifier = Modifier.nexusStaggeredEntrance(1, "st_vol_default")
          ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Rounded.Storage, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("אחסון פנימי", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                }
                Text(
                  text = "${telemetry.storage.usedPercent}%",
                  style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                  color = if (telemetry.storage.usedPercent >= 85) NexusCrimson else MaterialTheme.colorScheme.primary
                )
              }
              NexusWaveProgressBar(
                progress = telemetry.storage.usedPercent / 100f,
                accentColor = if (telemetry.storage.usedPercent >= 85) NexusCrimson else MaterialTheme.colorScheme.primary,
                height = 7.dp
              )
              Text(
                "פנוי ${formatBytes(telemetry.storage.freeBytes)} מתוך ${formatBytes(telemetry.storage.totalBytes)} • לחץ על 'סריקת אחסון' לסריקה מלאה.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        } else {
          if (isWide && volumes.size >= 2) {
            Row(
              modifier = Modifier.fillMaxWidth().nexusStaggeredEntrance(1, "st_vol_row"),
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              volumes.forEach { vol ->
                VolumeBandTile(vol = vol, modifier = Modifier.weight(1f))
              }
            }
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
              volumes.forEach { vol ->
                VolumeBandTile(vol = vol, modifier = Modifier.fillMaxWidth())
              }
            }
          }
        }
      }

      // 3. Smart Storage Spectrum Bar + Category Filter Pills + Forecast inside Graphite Card
      if (report != null && report.categories.isNotEmpty()) {
        item {
          NexusHudCard(
            accentColor = NexusTurquoiseBright,
            modifier = Modifier.nexusStaggeredEntrance(2, "st_spectrum")
          ) {
            NexusEditorialSection(
              title = "פילוח נפחים וצפי אחסון",
              accentColor = MaterialTheme.colorScheme.primary
            ) {
              NexusDataWell(contentPadding = 10.dp) {
                SmartStorageTreemapBar(categories = report.categories)
              }
              Spacer(modifier = Modifier.height(10.dp))
              FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                report.categories.forEachIndexed { idx, cat ->
                  val c = CATEGORY_COLORS[idx % CATEGORY_COLORS.size]
                  val isCatSelected = selectedCategory == cat.category
                  Row(
                    modifier =
                      Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isCatSelected) c.copy(alpha = 0.24f) else MaterialTheme.colorScheme.surfaceContainerLowest)
                        .border(1.dp, if (isCatSelected) c else c.copy(alpha = 0.34f), RoundedCornerShape(8.dp))
                        .clickable {
                          selectedCategory = if (isCatSelected) null else cat.category
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Box(modifier = Modifier.size(8.dp).background(c, RoundedCornerShape(2.dp)))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      "${cat.category.titleHe}: ${formatBytes(cat.totalBytes)} (${cat.fileCount})",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }
              Spacer(modifier = Modifier.height(10.dp))
              NexusDataWell(contentPadding = 10.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Rounded.Timeline, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    report.forecast.summaryHe,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }
            }
          }
        }
      }

      // 4. Newly Large Files & Media Integrity Notices
      if (report != null && (report.newlyLargeFiles.isNotEmpty() || report.mediaIssues.isNotEmpty())) {
        item {
          Row(
            modifier =
              Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min)
                .clip(RoundedCornerShape(10.dp))
                .background(NexusAmber.copy(alpha = 0.09f))
                .border(1.dp, NexusAmber.copy(alpha = 0.48f), RoundedCornerShape(10.dp))
                .padding(12.dp)
          ) {
            Box(modifier = Modifier.width(3.dp).fillMaxHeight().background(NexusAmber, RoundedCornerShape(2.dp)))
            Spacer(modifier = Modifier.width(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text("מעקב קבצים גדולים ובדיקת תקינות מדיה", style = MaterialTheme.typography.titleSmall, color = NexusAmber)
              if (report.newlyLargeFiles.isNotEmpty()) {
                Text(
                  "זוהו ${report.newlyLargeFiles.size} קבצים גדולים חדשים (>=15MB):",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurface
                )
                report.newlyLargeFiles.take(3).forEach { f ->
                  Text("• ${f.name} (${formatBytes(f.sizeBytes)})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
              if (report.mediaIssues.isNotEmpty()) {
                Text(
                  "בדיקת מדיה מצאה ${report.mediaIssues.size} קבצים פגומים או לא קריאים:",
                  style = MaterialTheme.typography.bodySmall,
                  color = NexusCrimson
                )
                report.mediaIssues.take(3).forEach { m ->
                  Text("• ${m.name}: ${m.reasonHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }
        }
      }

      // 5. Explorer Tabs
      item {
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          val tabs = listOf("קבצים וחיפוש (${filteredFiles.size})", "תיקיות ו-SD (${report?.folders?.size ?: 0})", "הורדות, APK וישנים")
          tabs.forEachIndexed { idx, label ->
            FilterChip(
              selected = selectedTab == idx,
              onClick = { selectedTab = idx },
              label = { Text(label) },
              shape = RoundedCornerShape(8.dp),
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = NexusElectricBlue.copy(alpha = 0.24f),
                  selectedLabelColor = MaterialTheme.colorScheme.primary
                )
            )
          }
          AssistChip(
            onClick = onOpenAiFileManager,
            shape = RoundedCornerShape(8.dp),
            label = { Text("כפילויות וארגון AI ←") }
          )
        }
      }

      if (selectedTab == 0) {
        item {
          NexusHudCard(accentColor = MaterialTheme.colorScheme.outline, contentPadding = 12.dp) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("חפש קובץ לפי שם או נתיב...", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = storageFieldColors(),
                modifier = Modifier.fillMaxWidth().testTag("smart_storage_search")
              )
              Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FileSortMode.entries.forEach { mode ->
                  FilterChip(
                    selected = sortMode == mode,
                    onClick = { sortMode = mode },
                    shape = RoundedCornerShape(8.dp),
                    colors =
                      FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NexusElectricBlue.copy(alpha = 0.22f),
                        selectedLabelColor = MaterialTheme.colorScheme.primary
                      ),
                    label = { Text(mode.titleHe) }
                  )
                }
                FilterChip(
                  selected = volumeFilter == StorageVolumeKind.SD_CARD,
                  onClick = {
                    volumeFilter = if (volumeFilter == StorageVolumeKind.SD_CARD) null else StorageVolumeKind.SD_CARD
                  },
                  shape = RoundedCornerShape(8.dp),
                  colors =
                    FilterChipDefaults.filterChipColors(
                      selectedContainerColor = NexusTurquoise.copy(alpha = 0.22f),
                      selectedLabelColor = NexusTurquoiseBright
                    ),
                  label = { Text("כרטיס SD בלבד") }
                )
              }
            }
          }
        }

        item {
          AnimatedVisibility(
            visible = selectedFileUris.isNotEmpty(),
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
          ) {
            val chosenEntries = filteredFiles.filter { it.uriString in selectedFileUris }
            NexusHudCard(
              accentColor = MaterialTheme.colorScheme.primary,
              contentPadding = 12.dp
            ) {
              Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                  text = "נבחרו ${chosenEntries.size} קבצים (${formatBytes(chosenEntries.sumOf { it.sizeBytes })})",
                  style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                  color = MaterialTheme.colorScheme.primary
                )
                Row(
                  modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Button(
                    onClick = {
                      zipArchiveName = "Nexus_${System.currentTimeMillis() % 10000}.zip"
                      showZipCreateDialog = true
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
                    modifier = Modifier.height(48.dp).testTag("batch_zip_btn")
                  ) {
                    Icon(Icons.Rounded.Archive, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("דחוס ל-ZIP")
                  }
                  OutlinedButton(
                    onClick = {
                      batchDestTree = safFolders.firstOrNull()
                      batchDestFolder = "NEXUS_BatchCopy"
                      batchTransferMove = false
                    },
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
                    modifier = Modifier.height(48.dp).testTag("batch_copy_btn")
                  ) {
                    Text("העתק מסומנים", color = MaterialTheme.colorScheme.primary)
                  }
                  OutlinedButton(
                    onClick = {
                      batchDestTree = safFolders.firstOrNull()
                      batchDestFolder = "NEXUS_BatchMoved"
                      batchTransferMove = true
                    },
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, NexusTurquoise.copy(alpha = 0.55f)),
                    modifier = Modifier.height(48.dp).testTag("batch_move_btn")
                  ) {
                    Text("העבר מסומנים", color = NexusTurquoiseBright)
                  }
                  TextButton(
                    onClick = { selectedFileUris = emptySet() },
                    modifier = Modifier.height(48.dp)
                  ) {
                    Text("נקה בחירה", color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
              }
            }
          }
        }

        if (filteredFiles.isEmpty()) {
          item {
            NexusDataWell {
              Text(
                text =
                  if (safFolders.isEmpty())
                    "עדיין לא הוענקה הרשאת תיקייה ב-SAF. לחץ למעלה על 'אשר תיקייה / כרטיס SD' כדי לסרוק קבצים."
                  else
                    "אין קבצים התואמים לחיפוש או לסינון הנוכחי.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        } else {
          items(filteredFiles.take(80), key = { it.uriString }) { file ->
            val isChecked = file.uriString in selectedFileUris
            val isZip = file.name.lowercase(Locale.ROOT).endsWith(".zip")
            NexusHudCard(
              selected = isChecked,
              accentColor = if (file.volumeKind == StorageVolumeKind.SD_CARD) NexusTurquoiseBright else MaterialTheme.colorScheme.primary,
              contentPadding = 10.dp
            ) {
              FileActionRow(
                file = file,
                isSelected = isChecked,
                isZip = isZip,
                hasSdTarget = sdTreeUris.isNotEmpty(),
                onToggleSelect = {
                  selectedFileUris =
                    if (isChecked) selectedFileUris - file.uriString
                    else selectedFileUris + file.uriString
                },
                onExtractZip = {
                  extractTarget = file
                  extractFolderName = file.name.substringBeforeLast('.') + "_Extracted"
                  extractOverwrite = false
                },
                onRename = {
                  renameTarget = file
                  renameText = file.name
                },
                onMove = {
                  moveTarget = file
                  moveDestTree = sdTreeUris.firstOrNull() ?: safFolders.firstOrNull()
                  moveDestSubfolder = if (sdTreeUris.isNotEmpty()) "NEXUS_SD_Archive" else "NEXUS_Organized"
                },
                onCopy = {
                  val dstTree = sdTreeUris.firstOrNull() ?: file.treeUriString
                  onStageProposal(
                    AiOrganizationProposalDraft(
                      title = "העתקת קובץ: ${file.name}",
                      reasonHe = "בקשת העתקה של ${file.name} (${formatBytes(file.sizeBytes)}).",
                      targetName = file.name,
                      targetLocation = file.relativePath,
                      operationType = ApprovalOperationType.COPY_SAF_DOCUMENT,
                      riskLevel = ApprovalRiskLevel.LOW,
                      isReversible = true,
                      expectedOutcomeHe = "ייווצר עותק נוסף בתיקיית NEXUS_Copy.",
                      sourceUriString = file.uriString,
                      treeUriString = file.treeUriString,
                      destTreeUriString = dstTree,
                      destFolderName = "NEXUS_Copy",
                      bytesAffected = file.sizeBytes
                    ),
                    false
                  )
                },
                onDelete = {
                  onStageProposal(
                    AiOrganizationProposalDraft(
                      title = "מחיקת קובץ: ${file.name}",
                      reasonHe = "נבחר למחיקה ממנהל האחסון (${file.category.titleHe}).",
                      targetName = file.name,
                      targetLocation = file.relativePath,
                      operationType = ApprovalOperationType.DELETE_SAF_DOCUMENT,
                      riskLevel = ApprovalRiskLevel.HIGH,
                      isReversible = false,
                      expectedOutcomeHe = "מחיקה מהמכשיר ושחרור ${formatBytes(file.sizeBytes)}.",
                      sourceUriString = file.uriString,
                      treeUriString = file.treeUriString,
                      bytesAffected = file.sizeBytes
                    ),
                    true
                  )
                }
              )
            }
          }
        }
      } else if (selectedTab == 1) {
        val folders = report?.folders.orEmpty()
        if (folders.isEmpty()) {
          item {
            NexusDataWell {
              Text(
                "הרץ סריקת אחסון לאחר בחירת תיקייה או כרטיס SD לצפייה בעץ התיקיות והנפחים.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        } else {
          items(folders.take(60), key = { "${it.treeUriString}_${it.docId}" }) { folder ->
            val accent =
              when {
                folder.isEmpty -> NexusAmber
                folder.volumeKind == StorageVolumeKind.SD_CARD -> NexusTurquoiseBright
                else -> MaterialTheme.colorScheme.primary
              }
            NexusHudCard(accentColor = accent, contentPadding = 12.dp) {
              Column {
                Row(
                  modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Box(modifier = Modifier.width(3.dp).fillMaxHeight().background(accent, RoundedCornerShape(2.dp)))
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(folder.folderName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                      "${folder.relativePath} • ${folder.volumeKind.titleHe}",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                  }
                  Column(horizontalAlignment = Alignment.End) {
                    Text(
                      formatBytes(folder.totalBytes),
                      style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                      color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                      if (folder.isEmpty) "תיקייה ריקה" else "${folder.fileCount} קבצים",
                      style = MaterialTheme.typography.labelSmall,
                      color = if (folder.isEmpty) NexusAmber else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(start = 13.dp)) {
                  OutlinedButton(
                    onClick = {
                      folderTransferTarget = folder to false
                      folderDestTree = sdTreeUris.firstOrNull() ?: folder.treeUriString
                      folderDestName = "${folder.folderName}_Copy"
                    },
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.height(48.dp)
                  ) {
                    Text("העתק תיקייה", color = MaterialTheme.colorScheme.primary)
                  }
                  OutlinedButton(
                    onClick = {
                      folderTransferTarget = folder to true
                      folderDestTree = sdTreeUris.firstOrNull() ?: folder.treeUriString
                      folderDestName = folder.folderName
                    },
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, NexusTurquoise.copy(alpha = 0.5f)),
                    modifier = Modifier.height(48.dp)
                  ) {
                    Text("העבר תיקייה", color = NexusTurquoiseBright)
                  }
                  if (folder.isEmpty) {
                    OutlinedButton(
                      onClick = {
                        onStageProposal(
                          AiOrganizationProposalDraft(
                            title = "מחיקת תיקייה ריקה: ${folder.folderName}",
                            reasonHe = "תיקייה ללא תוכן שנסרקה בעץ התיקיות.",
                            targetName = folder.folderName,
                            targetLocation = folder.relativePath,
                            operationType = ApprovalOperationType.DELETE_SAF_DOCUMENT,
                            riskLevel = ApprovalRiskLevel.LOW,
                            isReversible = false,
                            expectedOutcomeHe = "הסרת התיקייה הריקה בלבד.",
                            sourceUriString =
                              android.provider.DocumentsContract.buildDocumentUriUsingTree(
                                Uri.parse(folder.treeUriString),
                                folder.docId
                              ).toString(),
                            treeUriString = folder.treeUriString,
                            bytesAffected = 0L
                          ),
                          false
                        )
                      },
                      shape = RoundedCornerShape(8.dp),
                      border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.55f)),
                      modifier = Modifier.height(48.dp)
                    ) {
                      Text("מחק ריקה", color = NexusAmber)
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        val timelineAndSpecial =
          report?.files
            ?.filter { it.isOldUnused || it.isInstallerApk || it.isLargeFile || it.isTempResidual || it.isBackupArchive }
            ?.sortedByDescending { it.lastModifiedMillis }
            .orEmpty()
        if (timelineAndSpecial.isEmpty()) {
          item {
            NexusDataWell {
              Text(
                "לא אותרו קבצי APK, קבצים ישנים (>90 יום), או קבצים גדולים בתיקיות שנסרקו.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        } else {
          items(timelineAndSpecial.take(50), key = { "spec_${it.uriString}" }) { f ->
            val tag =
              when {
                f.isInstallerApk -> "APK התקנה"
                f.isTempResidual -> "קובץ זמני"
                f.isBackupArchive -> "גיבוי"
                f.isLargeFile -> "גדול מאוד"
                else -> "לא שונה >90 יום"
              }
            val dateStr =
              if (f.lastModifiedMillis > 0)
                SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(Date(f.lastModifiedMillis))
              else "—"
            NexusHudCard(accentColor = NexusAmber, contentPadding = 12.dp) {
              Row(
                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(modifier = Modifier.width(3.dp).fillMaxHeight().background(NexusAmber, RoundedCornerShape(2.dp)))
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(f.name, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                  Text("$tag • תאריך: $dateStr • ${f.relativePath}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                  formatBytes(f.sizeBytes),
                  style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                  color = MaterialTheme.colorScheme.primary
                )
              }
            }
          }
        }
      }
    }
  }

  // Rename -> Approval Center dialog
  renameTarget?.let { target ->
    AlertDialog(
      onDismissRequest = { renameTarget = null },
      containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
      shape = RoundedCornerShape(14.dp),
      title = { Text("שינוי שם (יישלח לאישור)", color = MaterialTheme.colorScheme.primary) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("שם נוכחי: ${target.name}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          OutlinedTextField(
            value = renameText,
            onValueChange = { renameText = it },
            label = { Text("שם חדש כולל סיומת") },
            singleLine = true,
            colors = storageFieldColors()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (renameText.isNotBlank() && renameText != target.name) {
              onStageProposal(
                AiOrganizationProposalDraft(
                  title = "שינוי שם: ${target.name} ← $renameText",
                  reasonHe = "שינוי שם יזום על ידי המשתמש במנהל האחסון.",
                  targetName = target.name,
                  targetLocation = target.relativePath,
                  operationType = ApprovalOperationType.RENAME_SAF_DOCUMENT,
                  riskLevel = ApprovalRiskLevel.LOW,
                  isReversible = true,
                  expectedOutcomeHe = "שינוי שם הקובץ ל-$renameText (הפיך דרך מרכז הביטול).",
                  sourceUriString = target.uriString,
                  treeUriString = target.treeUriString,
                  proposedNewName = renameText.trim(),
                  bytesAffected = target.sizeBytes
                ),
                true
              )
            }
            renameTarget = null
          },
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White)
        ) {
          Text("שלח למרכז האישורים")
        }
      },
      dismissButton = {
        TextButton(onClick = { renameTarget = null }) { Text("ביטול", color = MaterialTheme.colorScheme.onSurfaceVariant) }
      }
    )
  }

  // Create Folder -> Approval Center dialog
  createFolderTree?.let { treeStr ->
    AlertDialog(
      onDismissRequest = { createFolderTree = null },
      containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
      shape = RoundedCornerShape(14.dp),
      title = { Text("יצירת תיקייה חדשה (יישלח לאישור)", color = MaterialTheme.colorScheme.primary) },
      text = {
        OutlinedTextField(
          value = createFolderName,
          onValueChange = { createFolderName = it },
          label = { Text("שם התיקייה החדשה") },
          singleLine = true,
          colors = storageFieldColors()
        )
      },
      confirmButton = {
        Button(
          onClick = {
            val clean = createFolderName.trim()
            if (clean.isNotEmpty()) {
              onStageProposal(
                AiOrganizationProposalDraft(
                  title = "יצירת תיקייה: $clean",
                  reasonHe = "יצירת תיקייה חדשה בתיקיית השורש המאושרת.",
                  targetName = clean,
                  targetLocation = Uri.parse(treeStr).lastPathSegment ?: "תיקייה מאושרת",
                  operationType = ApprovalOperationType.CREATE_SAF_FOLDER,
                  riskLevel = ApprovalRiskLevel.LOW,
                  isReversible = true,
                  expectedOutcomeHe = "תיקייה חדשה '$clean' תיווצר בשורש התיקייה.",
                  treeUriString = treeStr,
                  destFolderName = clean,
                  bytesAffected = 0L
                ),
                true
              )
            }
            createFolderName = ""
            createFolderTree = null
          },
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White)
        ) {
          Text("שלח למרכז האישורים")
        }
      },
      dismissButton = {
        TextButton(onClick = { createFolderTree = null }) { Text("ביטול", color = MaterialTheme.colorScheme.onSurfaceVariant) }
      }
    )
  }

  // Move -> Approval Center dialog
  moveTarget?.let { target ->
    AlertDialog(
      onDismissRequest = { moveTarget = null },
      containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
      shape = RoundedCornerShape(14.dp),
      title = { Text("העברת קובץ (יישלח לאישור)", color = MaterialTheme.colorScheme.primary) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("קובץ: ${target.name} (${formatBytes(target.sizeBytes)})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          OutlinedTextField(
            value = moveDestSubfolder,
            onValueChange = { moveDestSubfolder = it },
            label = { Text("שם תת-תיקיית יעד") },
            singleLine = true,
            colors = storageFieldColors()
          )
          if (safFolders.size > 1) {
            Text("בחר עץ יעד (כולל SD אם אושר):", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            safFolders.forEach { treeUriStr ->
              val label = Uri.parse(treeUriStr).lastPathSegment?.substringAfterLast(':') ?: "תיקייה"
              FilterChip(
                selected = moveDestTree == treeUriStr,
                onClick = { moveDestTree = treeUriStr },
                label = { Text(label) }
              )
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val dest = moveDestTree ?: target.treeUriString
            onStageProposal(
              AiOrganizationProposalDraft(
                title = "העברת קובץ: ${target.name}",
                reasonHe = "העברה לתת-תיקייה '$moveDestSubfolder' עם אימות שלמות SHA-256.",
                targetName = target.name,
                targetLocation = "${target.relativePath} ← $moveDestSubfolder",
                operationType = ApprovalOperationType.MOVE_SAF_DOCUMENT,
                riskLevel = ApprovalRiskLevel.MEDIUM,
                isReversible = true,
                expectedOutcomeHe = "העברה בטוחה ללא מחיקת המקור לפני אימות ההעתקה.",
                sourceUriString = target.uriString,
                treeUriString = target.treeUriString,
                destTreeUriString = dest,
                destFolderName = moveDestSubfolder.trim().ifBlank { "NEXUS_Moved" },
                bytesAffected = target.sizeBytes
              ),
              true
            )
            moveTarget = null
          },
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White)
        ) {
          Text("שלח למרכז האישורים")
        }
      },
      dismissButton = {
        TextButton(onClick = { moveTarget = null }) { Text("ביטול", color = MaterialTheme.colorScheme.onSurfaceVariant) }
      }
    )
  }

  // Batch ZIP Create -> Approval Center dialog
  if (showZipCreateDialog) {
    val chosenEntries = filteredFiles.filter { it.uriString in selectedFileUris }
    AlertDialog(
      onDismissRequest = { showZipCreateDialog = false },
      containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
      shape = RoundedCornerShape(14.dp),
      title = { Text("דחיסת ${chosenEntries.size} קבצים ל-ZIP (לאישור)", color = MaterialTheme.colorScheme.primary) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("גודל מקור כולל: ${formatBytes(chosenEntries.sumOf { it.sizeBytes })}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          OutlinedTextField(
            value = zipArchiveName,
            onValueChange = { zipArchiveName = it },
            label = { Text("שם קובץ הארכיון (.zip)") },
            singleLine = true,
            colors = storageFieldColors()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onStageZipCreate(chosenEntries, zipArchiveName, chosenEntries.firstOrNull()?.treeUriString)
            showZipCreateDialog = false
            selectedFileUris = emptySet()
          },
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White)
        ) { Text("שלח לאישור") }
      },
      dismissButton = {
        TextButton(onClick = { showZipCreateDialog = false }) { Text("ביטול", color = MaterialTheme.colorScheme.onSurfaceVariant) }
      }
    )
  }

  // Batch Copy/Move -> Approval Center dialog
  batchTransferMove?.let { moveMode ->
    val chosenEntries = filteredFiles.filter { it.uriString in selectedFileUris }
    AlertDialog(
      onDismissRequest = { batchTransferMove = null },
      containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
      shape = RoundedCornerShape(14.dp),
      title = { Text(if (moveMode) "העברה מרובה של ${chosenEntries.size} קבצים" else "העתקה מרובה של ${chosenEntries.size} קבצים", color = MaterialTheme.colorScheme.primary) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = batchDestFolder,
            onValueChange = { batchDestFolder = it },
            label = { Text("תיקיית יעד") },
            singleLine = true,
            colors = storageFieldColors()
          )
          if (safFolders.size > 1) {
            safFolders.forEach { t ->
              val label = Uri.parse(t).lastPathSegment?.substringAfterLast(':') ?: "תיקייה"
              FilterChip(selected = batchDestTree == t, onClick = { batchDestTree = t }, label = { Text(label) })
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val dest = batchDestTree ?: chosenEntries.firstOrNull()?.treeUriString
            if (dest != null) {
              onStageBatchCopyMove(chosenEntries, dest, batchDestFolder.trim().ifBlank { "NEXUS_Batch" }, moveMode)
            }
            batchTransferMove = null
            selectedFileUris = emptySet()
          },
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White)
        ) { Text("שלח למרכז האישורים") }
      },
      dismissButton = {
        TextButton(onClick = { batchTransferMove = null }) { Text("ביטול", color = MaterialTheme.colorScheme.onSurfaceVariant) }
      }
    )
  }

  // Extract ZIP -> Approval Center dialog
  extractTarget?.let { zip ->
    AlertDialog(
      onDismissRequest = { extractTarget = null },
      containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
      shape = RoundedCornerShape(14.dp),
      title = { Text("חילוץ ארכיון ZIP (לאישור)", color = MaterialTheme.colorScheme.primary) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("קובץ: ${zip.name} (${formatBytes(zip.sizeBytes)})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          OutlinedTextField(
            value = extractFolderName,
            onValueChange = { extractFolderName = it },
            label = { Text("תיקיית חילוץ") },
            singleLine = true,
            colors = storageFieldColors()
          )
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable { extractOverwrite = !extractOverwrite }
          ) {
            Checkbox(
              checked = extractOverwrite,
              onCheckedChange = { extractOverwrite = it },
              colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
            )
            Text("דרוס קבצים קיימים עם שם זהה", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onStageZipExtract(zip, extractFolderName, extractOverwrite)
            extractTarget = null
          },
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White)
        ) { Text("שלח לאישור") }
      },
      dismissButton = {
        TextButton(onClick = { extractTarget = null }) { Text("ביטול", color = MaterialTheme.colorScheme.onSurfaceVariant) }
      }
    )
  }

  // Recursive Folder Copy/Move -> Approval Center dialog
  folderTransferTarget?.let { (folder, isMove) ->
    AlertDialog(
      onDismissRequest = { folderTransferTarget = null },
      containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
      shape = RoundedCornerShape(14.dp),
      title = { Text(if (isMove) "העברת תיקייה מלאה (לאישור)" else "העתקת תיקייה מלאה (לאישור)", color = MaterialTheme.colorScheme.primary) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("תיקייה: ${folder.folderName} (${folder.fileCount} קבצים)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          OutlinedTextField(
            value = folderDestName,
            onValueChange = { folderDestName = it },
            label = { Text("שם תיקיית היעד") },
            singleLine = true,
            colors = storageFieldColors()
          )
          if (safFolders.size > 1) {
            Text("עץ יעד (פנימי או SD):", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            safFolders.forEach { t ->
              val label = Uri.parse(t).lastPathSegment?.substringAfterLast(':') ?: "תיקייה"
              FilterChip(selected = folderDestTree == t, onClick = { folderDestTree = t }, label = { Text(label) })
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onStageFolderTransfer(
              folder,
              folderDestTree ?: folder.treeUriString,
              folderDestName.trim().ifBlank { folder.folderName },
              isMove
            )
            folderTransferTarget = null
          },
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White)
        ) { Text("שלח למרכז האישורים") }
      },
      dismissButton = {
        TextButton(onClick = { folderTransferTarget = null }) { Text("ביטול", color = MaterialTheme.colorScheme.onSurfaceVariant) }
      }
    )
  }
}

@Composable
private fun VolumeBandTile(
  vol: com.example.data.model.StorageVolumeInfo,
  modifier: Modifier = Modifier
) {
  val isSd = vol.kind == StorageVolumeKind.SD_CARD
  val accent =
    when {
      !vol.isMounted -> MaterialTheme.colorScheme.outline
      isSd -> NexusTurquoiseBright
      else -> MaterialTheme.colorScheme.primary
    }

  NexusHudCard(
    accentColor = accent,
    contentPadding = 14.dp,
    modifier = modifier
  ) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            if (isSd) Icons.Rounded.SdStorage else Icons.Rounded.Storage,
            contentDescription = null,
            tint = accent
          )
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(vol.label, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
            Text(
              if (vol.isMounted) "מחובר וזמין • ${vol.fileCountScanned} קבצים" else "לא מחובר",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
        vol.usedPercent?.let { pct ->
          Text(
            "$pct%",
            style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
            color = if (pct >= 85) NexusCrimson else accent
          )
        }
      }

      if (vol.totalBytes != null && vol.freeBytes != null && vol.usedPercent != null) {
        NexusWaveProgressBar(
          progress = (vol.usedPercent / 100f).coerceIn(0f, 1f),
          accentColor = if (vol.usedPercent >= 85) NexusCrimson else accent,
          height = 6.dp
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text(
            "תפוס: ${formatBytes(vol.usedBytes ?: 0L)}",
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            "פנוי: ${formatBytes(vol.freeBytes)} / ${formatBytes(vol.totalBytes)}",
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
            color = NexusTurquoiseBright
          )
        }
      }

      vol.sdHealthSummaryHe?.let { note ->
        Text(note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
  }
}

@Composable
private fun SmartStorageTreemapBar(categories: List<CategoryBreakdown>) {
  val total = categories.sumOf { it.totalBytes }.coerceAtLeast(1L).toFloat()
  Canvas(
    modifier =
      Modifier
        .fillMaxWidth()
        .height(20.dp)
        .clip(RoundedCornerShape(6.dp))
  ) {
    var curX = 0f
    categories.forEachIndexed { idx, cat ->
      val frac = (cat.totalBytes.toFloat() / total).coerceAtLeast(0.02f)
      val w = (size.width * frac).coerceAtMost(size.width - curX)
      if (w > 1f) {
        drawRoundRect(
          color = CATEGORY_COLORS[idx % CATEGORY_COLORS.size],
          topLeft = Offset(curX, 0f),
          size = Size(w - 2f, size.height),
          cornerRadius = CornerRadius(4f, 4f)
        )
        curX += w
      }
    }
  }
}

@Composable
private fun FileActionRow(
  file: ScannedFileEntry,
  isSelected: Boolean,
  isZip: Boolean,
  hasSdTarget: Boolean,
  onToggleSelect: () -> Unit,
  onExtractZip: () -> Unit,
  onRename: () -> Unit,
  onMove: () -> Unit,
  onCopy: () -> Unit,
  onDelete: () -> Unit
) {
  val accent =
    if (file.volumeKind == StorageVolumeKind.SD_CARD) NexusTurquoiseBright
    else MaterialTheme.colorScheme.primary

  Column(
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier =
          Modifier
            .width(3.dp)
            .fillMaxHeight()
            .background(if (isSelected) accent else accent.copy(alpha = 0.40f), RoundedCornerShape(2.dp))
      )
      Checkbox(
        checked = isSelected,
        onCheckedChange = { onToggleSelect() },
        colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
      )
      Column(modifier = Modifier.weight(1f)) {
        Text(
          file.name,
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          "${file.category.titleHe} • ${file.volumeKind.titleHe} • ${file.relativePath}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        formatBytes(file.sizeBytes),
        style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
        color = MaterialTheme.colorScheme.primary
      )
    }
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.End),
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (isZip) {
        OutlinedButton(
          onClick = onExtractZip,
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          modifier = Modifier.height(48.dp)
        ) {
          Icon(Icons.Rounded.Unarchive, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("חלץ ZIP", color = MaterialTheme.colorScheme.primary)
        }
      }
      IconButton(onClick = onRename, modifier = Modifier.size(48.dp)) {
        Icon(Icons.Rounded.DriveFileRenameOutline, contentDescription = "שנה שם", tint = MaterialTheme.colorScheme.primary)
      }
      IconButton(onClick = onMove, modifier = Modifier.size(48.dp)) {
        Icon(
          Icons.Rounded.DriveFileMove,
          contentDescription = if (hasSdTarget) "העבר ל-SD/תיקייה" else "העבר לתיקייה",
          tint = NexusTurquoiseBright
        )
      }
      IconButton(onClick = onCopy, modifier = Modifier.size(48.dp)) {
        Icon(Icons.Rounded.FileCopy, contentDescription = "העתק", tint = NexusDeepBlueGlow)
      }
      IconButton(onClick = onDelete, modifier = Modifier.size(48.dp)) {
        Icon(Icons.Rounded.DeleteOutline, contentDescription = "מחק (לאישור)", tint = NexusCrimson)
      }
    }
  }
}
