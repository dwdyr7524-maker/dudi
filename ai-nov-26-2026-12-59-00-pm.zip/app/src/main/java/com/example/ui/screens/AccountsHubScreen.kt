package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Launch
import androidx.compose.material.icons.rounded.ManageAccounts
import androidx.compose.material.icons.rounded.NetworkCheck
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ManagedAccountEntity
import com.example.ui.components.NexusConfirmationDialog
import com.example.ui.components.NexusHudCard
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusEmerald
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val ACCOUNT_CATEGORIES = listOf("עבודה", "פיננסים", "ענן", "תקשורת", "קניות", "כלים")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AccountsHubScreen(
  accounts: List<ManagedAccountEntity>,
  connectivityStatusMap: Map<Long, String>,
  onAddAccount: (
    serviceName: String,
    category: String,
    accountLabel: String,
    packageName: String?,
    webUrl: String?,
    reviewIntervalDays: Int,
    notes: String
  ) -> Unit,
  onMarkReviewed: (Long) -> Unit,
  onOpenService: (ManagedAccountEntity) -> Unit,
  onCheckConnectivity: (ManagedAccountEntity) -> Unit,
  onDeleteAccount: (Long) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  var selectedCategory by remember { mutableStateOf<String?>(null) }
  var showAddDialog by remember { mutableStateOf(false) }

  var formServiceName by remember { mutableStateOf("") }
  var formCategory by remember { mutableStateOf("כלים") }
  var formAccountLabel by remember { mutableStateOf("") }
  var formPackageName by remember { mutableStateOf("") }
  var formWebUrl by remember { mutableStateOf("") }
  var formReviewDays by remember { mutableIntStateOf(90) }
  var formNotes by remember { mutableStateOf("") }

  var pendingDeleteTarget by remember { mutableStateOf<ManagedAccountEntity?>(null) }

  val filteredAccounts =
    remember(accounts, selectedCategory) {
      if (selectedCategory == null) accounts
      else accounts.filter { it.category == selectedCategory }
    }

  pendingDeleteTarget?.let { acc ->
    NexusConfirmationDialog(
      title = "מחיקת שירות ממרכז השירותים",
      message = "האם להסיר את \"${acc.serviceName}\" ממעקב השירותים?",
      confirmText = "מחק",
      isDestructive = true,
      onConfirm = {
        onDeleteAccount(acc.id)
        pendingDeleteTarget = null
      },
      onDismiss = { pendingDeleteTarget = null }
    )
  }

  if (showAddDialog) {
    AlertDialog(
      onDismissRequest = { showAddDialog = false },
      containerColor = MaterialTheme.colorScheme.surfaceVariant,
      shape = RoundedCornerShape(22.dp),
      title = {
        Text("הוספת שירות למעקב (ללא סיסמאות)", color = MaterialTheme.colorScheme.primary)
      },
      text = {
        Column(
          modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = "אייקו חוסם שמירה של סיסמאות, קודי PIN או טוקנים — הזן רק שם שירות, כתובת וכינוי.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          OutlinedTextField(
            value = formServiceName,
            onValueChange = { formServiceName = it },
            label = { Text("שם השירות (למשל Google Drive / בנק / GitHub)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("accounts_dialog_name_input")
          )
          Text("קטגוריה:", style = MaterialTheme.typography.labelLarge)
          FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ACCOUNT_CATEGORIES.forEach { cat ->
              FilterChip(
                selected = formCategory == cat,
                onClick = { formCategory = cat },
                label = { Text(cat) }
              )
            }
          }
          OutlinedTextField(
            value = formAccountLabel,
            onValueChange = { formAccountLabel = it },
            label = { Text("תיאור חשבון / כינוי זיהוי (אופציונלי)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = formWebUrl,
            onValueChange = { formWebUrl = it },
            label = { Text("כתובת אתר (https://...)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = formPackageName,
            onValueChange = { formPackageName = it },
            label = { Text("Package Name לפתיחת אפליקציה (אופציונלי)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          Text("תדירות תזכורת ביקורת:", style = MaterialTheme.typography.labelLarge)
          FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(30 to "30 ימים", 60 to "60 ימים", 90 to "90 ימים", 180 to "חצי שנה").forEach { (days, lbl) ->
              FilterChip(
                selected = formReviewDays == days,
                onClick = { formReviewDays = days },
                label = { Text(lbl) }
              )
            }
          }
          OutlinedTextField(
            value = formNotes,
            onValueChange = { formNotes = it },
            label = { Text("הערות ביקורת (ללא מידע רגיש)") },
            maxLines = 3,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (formServiceName.isNotBlank()) {
              onAddAccount(
                formServiceName.trim(),
                formCategory,
                formAccountLabel.trim(),
                formPackageName.trim().takeIf { it.isNotEmpty() },
                formWebUrl.trim().takeIf { it.isNotEmpty() },
                formReviewDays,
                formNotes.trim()
              )
              formServiceName = ""
              formAccountLabel = ""
              formPackageName = ""
              formWebUrl = ""
              formNotes = ""
              showAddDialog = false
            }
          },
          enabled = formServiceName.isNotBlank(),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("accounts_dialog_save_btn")
        ) {
          Text("שמור שירות")
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddDialog = false }) { Text("ביטול") }
      }
    )
  }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      NexusHudCard(accentColor = NexusEmerald) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Shield, contentDescription = null, tint = NexusEmerald)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "מדיניות פרטיות מחמירה — אפס סיסמאות",
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
          Button(
            onClick = { showAddDialog = true },
            modifier = Modifier.minimumInteractiveComponentSize().testTag("accounts_add_btn")
          ) {
            Icon(Icons.Rounded.Add, contentDescription = "הוסף שירות")
            Spacer(modifier = Modifier.width(6.dp))
            Text("הוסף שירות")
          }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "מרכז השירותים אינו שומר סיסמאות, קודי PIN או טוקנים — רק שם שירות, קיצורי דרך ומעקב ביקורת תקופתית.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    item {
      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        FilterChip(
          selected = selectedCategory == null,
          onClick = { selectedCategory = null },
          label = { Text("הכול (${accounts.size})") },
          modifier = Modifier.testTag("accounts_filter_all")
        )
        ACCOUNT_CATEGORIES.forEach { cat ->
          val count = accounts.count { it.category == cat }
          FilterChip(
            selected = selectedCategory == cat,
            onClick = { selectedCategory = if (selectedCategory == cat) null else cat },
            label = { Text("$cat ($count)") },
            modifier = Modifier.testTag("accounts_filter_$cat")
          )
        }
      }
    }

    if (filteredAccounts.isEmpty()) {
      item {
        NexusHudCard(accentColor = MaterialTheme.colorScheme.outline) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Rounded.ManageAccounts, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(
              text = "טרם נשמרו שירותים במעקב",
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "הוסף שירותי ענן, עבודה או בנקאות למעקב ביקורת תקופתית ובדיקת זמינות קישור (ללא סיסמאות).",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(filteredAccounts, key = { it.id }) { acc ->
        AccountServiceCard(
          account = acc,
          liveStatus = connectivityStatusMap[acc.id] ?: acc.lastConnectivityStatusHe,
          onMarkReviewed = { onMarkReviewed(acc.id) },
          onOpenService = { onOpenService(acc) },
          onCheckConnectivity = { onCheckConnectivity(acc) },
          onRequestDelete = { pendingDeleteTarget = acc }
        )
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AccountServiceCard(
  account: ManagedAccountEntity,
  liveStatus: String?,
  onMarkReviewed: () -> Unit,
  onOpenService: () -> Unit,
  onCheckConnectivity: () -> Unit,
  onRequestDelete: () -> Unit
) {
  val now = System.currentTimeMillis()
  val isOverdue =
    account.lastReviewedAtMillis?.let { ((now - it) / 86_400_000L) > account.reviewIntervalDays } ?: true
  val fmt = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

  NexusHudCard(
    accentColor = if (isOverdue) NexusAmber else MaterialTheme.colorScheme.primary,
    contentPadding = 14.dp
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = account.serviceName,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text =
            listOfNotNull(
              account.category,
              account.accountLabel.takeIf { it.isNotBlank() }
            ).joinToString(" • "),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
      IconButton(
        onClick = onRequestDelete,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("account_delete_${account.id}")
      ) {
        Icon(Icons.Rounded.DeleteOutline, contentDescription = "הסר ${account.serviceName}", tint = MaterialTheme.colorScheme.error)
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    Surface(
      shape = RoundedCornerShape(8.dp),
      color = (if (isOverdue) NexusAmber else NexusEmerald).copy(alpha = 0.12f),
      border = BorderStroke(1.dp, (if (isOverdue) NexusAmber else NexusEmerald).copy(alpha = 0.35f))
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = if (isOverdue) Icons.Rounded.WarningAmber else Icons.Rounded.CheckCircle,
          contentDescription = null,
          tint = if (isOverdue) NexusAmber else NexusEmerald
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text =
            if (isOverdue) "מומלץ לרענן ביקורת (כל ${account.reviewIntervalDays} ימים)"
            else "נבדק לאחרונה ב-${account.lastReviewedAtMillis?.let { fmt.format(Date(it)) } ?: "-"}",
          style = MaterialTheme.typography.labelSmall,
          color = if (isOverdue) NexusAmber else NexusEmerald
        )
      }
    }

    if (!account.webUrl.isNullOrBlank()) {
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = account.webUrl,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary
      )
    }

    if (!liveStatus.isNullOrBlank()) {
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "סטטוס זמינות: $liveStatus",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    if (account.notes.isNotBlank()) {
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = account.notes,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    Spacer(modifier = Modifier.height(10.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Button(
        onClick = onOpenService,
        enabled = !account.packageName.isNullOrBlank() || !account.webUrl.isNullOrBlank(),
        modifier = Modifier.minimumInteractiveComponentSize().testTag("account_open_${account.id}")
      ) {
        Icon(Icons.Rounded.Launch, contentDescription = null)
        Spacer(modifier = Modifier.width(6.dp))
        Text("פתח שירות")
      }
      OutlinedButton(
        onClick = onCheckConnectivity,
        enabled = !account.webUrl.isNullOrBlank(),
        modifier = Modifier.minimumInteractiveComponentSize().testTag("account_check_${account.id}")
      ) {
        Icon(Icons.Rounded.NetworkCheck, contentDescription = null)
        Spacer(modifier = Modifier.width(6.dp))
        Text("בדוק זמינות")
      }
      OutlinedButton(
        onClick = onMarkReviewed,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("account_review_${account.id}")
      ) {
        Text("אשר ביקורת")
      }
    }
  }
}
