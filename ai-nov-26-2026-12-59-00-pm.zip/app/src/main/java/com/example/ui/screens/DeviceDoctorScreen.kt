package com.example.ui.screens

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.HealthAndSafety
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DeviceDoctorReport
import com.example.data.model.HealthSeverity
import com.example.data.model.SystemTelemetry
import com.example.data.system.formatBytes
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusSystemHealthRing
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusEmerald

@Composable
fun DeviceDoctorScreen(
  doctorReport: DeviceDoctorReport?,
  telemetry: SystemTelemetry,
  isScanning: Boolean,
  onRunFullScan: () -> Unit,
  onNavigateRoute: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val cpuCores = remember { Runtime.getRuntime().availableProcessors() }
  val primaryAbi = remember { Build.SUPPORTED_ABIS.firstOrNull() ?: "ARM" }

  LazyColumn(
    modifier = modifier.fillMaxSize().testTag("device_doctor_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Score Ring + Formula Explanation
    item {
      NexusHudCard(accentColor = MaterialTheme.colorScheme.primary) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
          NexusSystemHealthRing(
            score = doctorReport?.totalScore ?: telemetry.healthScore,
            statusLabel = telemetry.healthStatusLabel,
            isScanning = isScanning,
            onClick = onRunFullScan,
            ringSize = 138.dp
          )
          Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              "AI Device Doctor — רופא המכשיר",
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              doctorReport?.scoreFormulaSummaryHe
                ?: "ציון הבסיס הוא 100 נקודות ומופחתות נקודות לפי ממצאי אחסון, RAM, סוללה, הרשאות, אפליקציות רדומות וכפילויות.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(onClick = onRunFullScan, enabled = !isScanning) {
              if (isScanning) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
              } else {
                Icon(Icons.Rounded.HealthAndSafety, contentDescription = null)
              }
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isScanning) "מאבחן..." else "הפעל אבחון מכשיר מלא")
            }
          }
        }
      }
    }

    // 2. Real Hardware & CPU Snapshot (Tab Active Pro SM-T545 / Android 10)
    item {
      NexusHudCard(accentColor = MaterialTheme.colorScheme.secondary) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Rounded.Memory, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text("מפרט מעבד, זיכרון ומערכת בזמן אמת", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text("דגם: ${telemetry.device.manufacturer} ${telemetry.device.model} • Android ${telemetry.device.androidRelease} (SDK ${telemetry.device.sdkInt})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
        Text("מעבד: $cpuCores ליבות ($primaryAbi, ${Build.HARDWARE}) • עדכון אבטחה: ${telemetry.device.securityPatch}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("זיכרון RAM: ${formatBytes(telemetry.ram.availableBytes)} פנוי מתוך ${formatBytes(telemetry.ram.totalBytes)} (${telemetry.ram.usedPercent}% בשימוש)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("אחסון פנימי: ${formatBytes(telemetry.storage.freeBytes)} פנוי מתוך ${formatBytes(telemetry.storage.totalBytes)} • סוללה: ${telemetry.battery.levelPercent}% (${String.format("%.1f", telemetry.battery.temperatureC)}°C)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(8.dp))
        Surface(
          color = MaterialTheme.colorScheme.surfaceContainerHigh,
          shape = RoundedCornerShape(10.dp)
        ) {
          Text(
            text = "שקיפות חיישנים (Android 10 ללא Root): קריאות חום הסוללה, המתח וה-RAM אמיתיות. גישה ישירה לחיישני וואט (Wattage) או טמפרטורת ליבות CPU ספציפיות חסומה ברמת מערכת ההפעלה ואינה מזויפת.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(10.dp)
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(
          onClick = { onNavigateRoute(com.example.ui.navigation.NexusDestination.SELF_DIAGNOSTICS.route) },
          modifier = Modifier.fillMaxWidth().testTag("doctor_open_self_diag_btn")
        ) {
          Text("הרץ אבחון עצמי ומבחן מהירות (Benchmark) ←")
        }
      }
    }

    // 3. Score Deductions Breakdown ("איך חושב הציון")
    if (doctorReport != null && doctorReport.scoreBreakdown.isNotEmpty()) {
      item {
        NexusHudCard(accentColor = NexusAmber) {
          Text("פירוט הפחתות הניקוד (למה הציון הוא ${doctorReport.totalScore}%)", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
          Spacer(modifier = Modifier.height(8.dp))
          doctorReport.scoreBreakdown.forEach { b ->
            Surface(
              color = MaterialTheme.colorScheme.surfaceContainerHighest,
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(b.title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                  Text(b.reasonHe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    "${b.pointsDelta}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (b.severity == HealthSeverity.CRITICAL) NexusCrimson else NexusAmber
                  )
                  b.targetRoute?.let { r ->
                    OutlinedButton(onClick = { onNavigateRoute(r) }) { Text("טפל") }
                  }
                }
              }
            }
          }
        }
      }
    }

    // 4. All Diagnostic Checks
    if (doctorReport != null) {
      item {
        Text("בדיקות אבחון מקיפות (${doctorReport.checks.size})", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
      }
      items(doctorReport.checks, key = { it.id }) { chk ->
        val (icon, accent) =
          when (chk.severity) {
            HealthSeverity.CRITICAL -> Icons.Rounded.ErrorOutline to NexusCrimson
            HealthSeverity.WARNING -> Icons.Rounded.WarningAmber to NexusAmber
            HealthSeverity.NOTICE -> Icons.Rounded.WarningAmber to MaterialTheme.colorScheme.primary
            HealthSeverity.OPTIMAL -> Icons.Rounded.CheckCircle to NexusEmerald
          }
        NexusHudCard(accentColor = accent) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Icon(icon, contentDescription = null, tint = accent)
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(chk.categoryTitleHe, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                Text(chk.statusTitleHe, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = accent)
              }
            }
            chk.targetRoute?.let { route ->
              OutlinedButton(onClick = { onNavigateRoute(route) }) { Text("פתח") }
            }
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(chk.detailHe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text("המלצה: ${chk.recommendationHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
        }
      }

      // 5. Maintenance Planner & Smart Recommendations
      if (doctorReport.maintenancePlan.isNotEmpty()) {
        item {
          NexusHudCard(accentColor = NexusEmerald) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Rounded.Build, contentDescription = null, tint = NexusEmerald)
              Spacer(modifier = Modifier.width(8.dp))
              Text("מתכנן תחזוקה מותאם (Maintenance Planner)", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
            }
            Spacer(modifier = Modifier.height(8.dp))
            doctorReport.maintenancePlan.forEach { task ->
              Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text("${task.titleHe} (עדיפות: ${task.priorityHe})", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                  Text(task.reasonHe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OutlinedButton(onClick = { onNavigateRoute(task.targetRoute) }) { Text(task.actionLabelHe) }
              }
            }
          }
        }
      }

      item {
        NexusHudCard(accentColor = MaterialTheme.colorScheme.primary) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("המלצות חכמות לטאבלט שלך", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
          }
          Spacer(modifier = Modifier.height(6.dp))
          doctorReport.smartRecommendations.forEach { rec ->
            Text("• $rec", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 2.dp))
          }
        }
      }
    }
  }
}
