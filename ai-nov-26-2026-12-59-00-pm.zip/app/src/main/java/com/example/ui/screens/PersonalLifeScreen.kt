package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircleOutline
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.ai.AikoBrainEngine
import com.example.data.ai.LifeItemKind
import com.example.data.ai.LifeItemPriority
import com.example.data.local.LifeItemEntity
import com.example.ui.components.NexusConfirmationDialog
import com.example.ui.components.NexusHudCard
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusEmerald
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PersonalLifeScreen(
  items: List<LifeItemEntity>,
  onAddItem: (
    title: String,
    details: String,
    itemType: LifeItemKind,
    priority: LifeItemPriority,
    categoryTag: String,
    repeatIntervalHours: Int,
    projectTag: String
  ) -> Unit,
  onToggleComplete: (LifeItemEntity) -> Unit,
  onUpdateProgress: (LifeItemEntity, Int) -> Unit,
  onDeleteItem: (Long) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  var selectedKindFilter by remember { mutableStateOf<LifeItemKind?>(null) }
  var showCompleted by remember { mutableStateOf(true) }
  var quickNaturalInput by remember { mutableStateOf("") }
  var showAddDialog by remember { mutableStateOf(false) }

  var dialogKind by remember { mutableStateOf(LifeItemKind.TASK) }
  var dialogTitle by remember { mutableStateOf("") }
  var dialogDetails by remember { mutableStateOf("") }
  var dialogCategory by remember { mutableStateOf("אישי") }
  var dialogProject by remember { mutableStateOf("") }
  var dialogPriority by remember { mutableStateOf(LifeItemPriority.NORMAL) }
  var dialogRepeatHours by remember { mutableIntStateOf(0) }

  var pendingDeleteTarget by remember { mutableStateOf<LifeItemEntity?>(null) }

  val openCount = remember(items) { items.count { !it.isCompleted } }
  val completedCount = remember(items) { items.count { it.isCompleted } }

  val filteredItems =
    remember(items, selectedKindFilter, showCompleted) {
      items.filter { item ->
        val matchesKind = selectedKindFilter == null || item.kind == selectedKindFilter?.name
        val matchesStatus = showCompleted || !item.isCompleted
        matchesKind && matchesStatus
      }
    }

  pendingDeleteTarget?.let { target ->
    NexusConfirmationDialog(
      title = "אישור מחיקת פריט",
      message = "האם למחוק את \"${target.title}\" מרשימת החיים האישיים?",
      confirmText = "מחק",
      isDestructive = true,
      onConfirm = {
        onDeleteItem(target.id)
        pendingDeleteTarget = null
      },
      onDismiss = { pendingDeleteTarget = null }
    )
  }

  if (showAddDialog) {
    AlertDialog(
      onDismissRequest = { showAddDialog = false },
      containerColor = MaterialTheme.colorScheme.surfaceVariant,
      shape = RoundedCornerShape(22.dp),
      title = {
        Text("פריט חדש במנהל החיים האישיים", color = MaterialTheme.colorScheme.primary)
      },
      text = {
        Column(
          modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text("סוג פריט:", style = MaterialTheme.typography.labelLarge)
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            LifeItemKind.entries.forEach { kind ->
              FilterChip(
                selected = dialogKind == kind,
                onClick = { dialogKind = kind },
                label = { Text(kind.titleHe) },
                modifier = Modifier.testTag("life_dialog_kind_${kind.name.lowercase()}")
              )
            }
          }

          OutlinedTextField(
            value = dialogTitle,
            onValueChange = { dialogTitle = it },
            label = { Text("כותרת המשימה / הפריט") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("life_dialog_title_input")
          )
          OutlinedTextField(
            value = dialogDetails,
            onValueChange = { dialogDetails = it },
            label = { Text("פירוט או הערות (אופציונלי)") },
            minLines = 2,
            maxLines = 4,
            modifier = Modifier.fillMaxWidth().testTag("life_dialog_details_input")
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
              value = dialogCategory,
              onValueChange = { dialogCategory = it },
              label = { Text("קטגוריה") },
              singleLine = true,
              modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
              value = dialogProject,
              onValueChange = { dialogProject = it },
              label = { Text("תג פרויקט") },
              singleLine = true,
              modifier = Modifier.weight(1f)
            )
          }

          Text("רמת עדיפות:", style = MaterialTheme.typography.labelLarge)
          FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LifeItemPriority.entries.forEach { p ->
              FilterChip(
                selected = dialogPriority == p,
                onClick = { dialogPriority = p },
                label = { Text(p.titleHe) }
              )
            }
          }

          Text("חזרתיות מתוזמנת:", style = MaterialTheme.typography.labelLarge)
          val repeatOptions = listOf(0 to "ללא חזרה", 24 to "יומי", 168 to "שבועי", 720 to "חודשי")
          FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeatOptions.forEach { (hours, label) ->
              FilterChip(
                selected = dialogRepeatHours == hours,
                onClick = { dialogRepeatHours = hours },
                label = { Text(label) }
              )
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (dialogTitle.isNotBlank()) {
              onAddItem(
                dialogTitle.trim(),
                dialogDetails.trim(),
                dialogKind,
                dialogPriority,
                dialogCategory.trim().ifBlank { "כללי" },
                dialogRepeatHours,
                dialogProject.trim()
              )
              dialogTitle = ""
              dialogDetails = ""
              dialogProject = ""
              dialogRepeatHours = 0
              showAddDialog = false
            }
          },
          enabled = dialogTitle.isNotBlank(),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("life_dialog_save_btn")
        ) {
          Text("שמור פריט")
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddDialog = false }) { Text("ביטול") }
      }
    )
  }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      NexusHudCard(accentColor = MaterialTheme.colorScheme.primary) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "מנהל חיים אישיים של אייקו",
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "$openCount פריטים פתוחים • $completedCount הושלמו • שמירה מקומית מאובטחת",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Button(
            onClick = { showAddDialog = true },
            modifier = Modifier.minimumInteractiveComponentSize().testTag("life_open_add_dialog_btn")
          ) {
            Icon(Icons.Rounded.Add, contentDescription = "הוסף פריט חדש")
            Spacer(modifier = Modifier.width(6.dp))
            Text("חדש")
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = quickNaturalInput,
          onValueChange = { quickNaturalInput = it },
          label = { Text("הוספה מהירה בשפה טבעית") },
          placeholder = { Text("לדוגמה: תזכור לי לקנות כבל USB-C דחוף / מטרה: לסדר גיבויים") },
          singleLine = true,
          trailingIcon = {
            Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          },
          modifier = Modifier.fillMaxWidth().testTag("life_quick_input")
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              val raw = quickNaturalInput.trim()
              if (raw.isNotEmpty()) {
                val parsed = AikoBrainEngine.parseLifeItemDraft(raw)
                if (parsed != null) {
                  onAddItem(
                    parsed.title,
                    parsed.details,
                    parsed.itemType,
                    parsed.priority,
                    parsed.categoryTag,
                    parsed.repeatIntervalDays * 24,
                    ""
                  )
                } else {
                  onAddItem(
                    raw,
                    "נוסף במהירות ממנהל החיים האישיים",
                    selectedKindFilter ?: LifeItemKind.TASK,
                    LifeItemPriority.NORMAL,
                    "אישי",
                    0,
                    ""
                  )
                }
                quickNaturalInput = ""
              }
            },
            enabled = quickNaturalInput.isNotBlank(),
            modifier = Modifier.minimumInteractiveComponentSize().testTag("life_quick_add_btn")
          ) {
            Text("הוסף")
          }
          OutlinedButton(
            onClick = { showCompleted = !showCompleted },
            modifier = Modifier.minimumInteractiveComponentSize().testTag("life_toggle_completed_btn")
          ) {
            Text(if (showCompleted) "הסתר שהושלמו" else "הצג שהושלמו ($completedCount)")
          }
        }
      }
    }

    item {
      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        FilterChip(
          selected = selectedKindFilter == null,
          onClick = { selectedKindFilter = null },
          label = { Text("הכול (${items.size})") },
          modifier = Modifier.testTag("life_filter_all")
        )
        LifeItemKind.entries.forEach { kind ->
          val countForKind = items.count { it.kind == kind.name }
          FilterChip(
            selected = selectedKindFilter == kind,
            onClick = { selectedKindFilter = if (selectedKindFilter == kind) null else kind },
            label = { Text("${kind.titleHe} ($countForKind)") },
            modifier = Modifier.testTag("life_filter_${kind.name.lowercase()}")
          )
        }
      }
    }

    if (filteredItems.isEmpty()) {
      item {
        NexusHudCard(accentColor = MaterialTheme.colorScheme.outline) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(
              imageVector = Icons.Rounded.CheckCircleOutline,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary
            )
            Text(
              text = "אין כרגע פריטים בסינון הנוכחי",
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "אפשר לכתוב למעלה בשפה טבעית (למשל \"לקנות סוללות\" או \"משימה: לבדוק גיבוי\") או ללחוץ על \"חדש\".",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(filteredItems, key = { it.id }) { item ->
        LifeItemCard(
          item = item,
          onToggleComplete = { onToggleComplete(item) },
          onUpdateProgress = { pct -> onUpdateProgress(item, pct) },
          onRequestDelete = { pendingDeleteTarget = item }
        )
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LifeItemCard(
  item: LifeItemEntity,
  onToggleComplete: () -> Unit,
  onUpdateProgress: (Int) -> Unit,
  onRequestDelete: () -> Unit
) {
  val kindEnum = remember(item.kind) { LifeItemKind.entries.firstOrNull { it.name == item.kind } ?: LifeItemKind.TASK }
  val priorityEnum = remember(item.priority) {
    LifeItemPriority.entries.firstOrNull { it.name == item.priority } ?: LifeItemPriority.NORMAL
  }
  val priorityColor =
    when (priorityEnum) {
      LifeItemPriority.URGENT -> NexusCrimson
      LifeItemPriority.HIGH -> NexusAmber
      LifeItemPriority.NORMAL -> MaterialTheme.colorScheme.primary
      LifeItemPriority.LOW -> MaterialTheme.colorScheme.onSurfaceVariant
    }

  var sliderProgress by remember(item.id, item.progressPercent) {
    mutableIntStateOf(item.progressPercent)
  }
  val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }

  NexusHudCard(
    accentColor = if (item.isCompleted) NexusEmerald else priorityColor,
    contentPadding = 14.dp
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Checkbox(
        checked = item.isCompleted,
        onCheckedChange = { onToggleComplete() },
        modifier = Modifier.minimumInteractiveComponentSize().testTag("life_item_check_${item.id}")
      )
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = item.title,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.SemiBold,
          textDecoration = if (item.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
          color = if (item.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
        )
        if (item.details.isNotBlank()) {
          Text(
            text = item.details,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
      IconButton(
        onClick = onRequestDelete,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("life_item_delete_${item.id}")
      ) {
        Icon(
          imageVector = Icons.Rounded.DeleteOutline,
          contentDescription = "מחק פריט ${item.title}",
          tint = MaterialTheme.colorScheme.error
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      LifeBadgeChip(label = kindEnum.titleHe, tint = MaterialTheme.colorScheme.primary)
      LifeBadgeChip(label = "עדיפות ${priorityEnum.titleHe}", tint = priorityColor)
      if (item.categoryTag.isNotBlank()) {
        LifeBadgeChip(label = item.categoryTag, tint = MaterialTheme.colorScheme.secondary)
      }
      if (item.projectTag.isNotBlank()) {
        LifeBadgeChip(label = "פרויקט: ${item.projectTag}", tint = NexusEmerald)
      }
      if (item.repeatIntervalHours > 0) {
        val repeatText =
          when {
            item.repeatIntervalHours <= 24 -> "חוזר כל יום"
            item.repeatIntervalHours <= 168 -> "חוזר כל שבוע"
            else -> "חוזר כל ${item.repeatIntervalHours / 24} ימים"
          }
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = NexusAmber.copy(alpha = 0.12f),
          border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.35f))
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Rounded.Repeat, contentDescription = null, tint = NexusAmber)
            Spacer(modifier = Modifier.width(4.dp))
            Text(repeatText, style = MaterialTheme.typography.labelSmall, color = NexusAmber)
          }
        }
      }
      Text(
        text = "עודכן ${fmt.format(Date(item.updatedAtMillis))}",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.align(Alignment.CenterVertically)
      )
    }

    if (kindEnum == LifeItemKind.GOAL || item.progressPercent in 1..99) {
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("התקדמות יעד:", style = MaterialTheme.typography.labelMedium)
        Text("${sliderProgress}%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
      }
      LinearProgressIndicator(
        progress = { sliderProgress / 100f },
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
      )
      Slider(
        value = sliderProgress.toFloat(),
        onValueChange = { sliderProgress = it.roundToInt() },
        onValueChangeFinished = { onUpdateProgress(sliderProgress) },
        valueRange = 0f..100f,
        steps = 9,
        modifier = Modifier.fillMaxWidth().testTag("life_goal_slider_${item.id}")
      )
    }
  }
}

@Composable
private fun LifeBadgeChip(label: String, tint: androidx.compose.ui.graphics.Color) {
  Surface(
    shape = RoundedCornerShape(8.dp),
    color = tint.copy(alpha = 0.12f),
    border = BorderStroke(1.dp, tint.copy(alpha = 0.32f))
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = tint,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
    )
  }
}
