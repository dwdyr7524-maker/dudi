package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.AutoMode
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.HealthAndSafety
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material.icons.rounded.SdStorage
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ActionAuditEntity
import com.example.data.local.CleanHistoryEntity
import com.example.data.local.TelemetrySnapshotEntity
import com.example.data.model.HealthSeverity
import com.example.data.model.RobotMood
import com.example.data.model.SmartStorageScanReport
import com.example.data.model.SystemTelemetry
import com.example.data.system.formatBytes
import com.example.data.system.formatUptime
import com.example.ui.components.NexusDataWell
import com.example.ui.components.NexusEditorialSection
import com.example.ui.components.NexusHairlineDivider
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusLiveTrendChart
import com.example.ui.components.NexusMetricArcGauge
import com.example.ui.components.NexusRobotAvatar
import com.example.ui.components.NexusScanBeamOverlay
import com.example.ui.components.NexusSystemHealthRing
import com.example.ui.components.NexusVoiceWaveformBar
import com.example.ui.components.nexusInteractive
import com.example.ui.components.nexusStaggeredEntrance
import com.example.ui.navigation.NexusDestination
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalIsDarkTheme
import com.example.ui.theme.LocalMotionConfig
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderGraphite
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusDataWellDark
import com.example.ui.theme.NexusDeepBlueGlow
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import com.example.ui.theme.NexusObsidian
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTitaniumCard
import com.example.ui.theme.NexusTitaniumDark
import com.example.ui.theme.NexusTurquoise
import com.example.ui.theme.NexusTurquoiseBright
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
  telemetry: SystemTelemetry,
  isRefreshing: Boolean,
  lastMaintenanceMillis: Long?,
  recentCleanHistory: List<CleanHistoryEntity>,
  recentAuditLogs: List<ActionAuditEntity>,
  onRefreshTelemetry: () -> Unit,
  onNavigate: (String) -> Unit,
  onQuickCleanLaunch: () -> Unit,
  onAssistantQuickCommand: (String) -> Unit,
  smartStorageReport: SmartStorageScanReport? = null,
  pendingApprovalsCount: Int = 0,
  isScanningFullDevice: Boolean = false,
  lastFullScanMillis: Long? = null,
  onRunFullDeviceScan: () -> Unit = {},
  openLifeItemsCount: Int = 0,
  nextLifeTaskTitle: String? = null,
  telemetrySnapshots: List<TelemetrySnapshotEntity> = emptyList(),
  assistantMood: RobotMood = RobotMood.IDLE,
  modifier: Modifier = Modifier
) {
  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isTabletWide = maxWidth >= 760.dp

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
      // 1. Live Operational Status Bar (Graphite Strip)
      item {
        val sdMounted = smartStorageReport?.hasSdCard == true
        val scanFmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        val lastScanLabel = lastFullScanMillis?.let { scanFmt.format(Date(it)) } ?: "טרם בוצעה סריקה"
        NexusHudCard(
          accentColor = NexusTurquoise,
          contentPadding = 14.dp,
          modifier = Modifier.fillMaxWidth().nexusStaggeredEntrance(0, "dash_ctx")
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              modifier = Modifier.weight(1f),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              Box(
                modifier =
                  Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(if (isScanningFullDevice || isRefreshing) NexusAmber else NexusTurquoiseBright)
              )
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text =
                    if (smartStorageReport != null)
                      "${smartStorageReport.files.size} קבצים מאונדקסים • ${smartStorageReport.duplicateGroups.size} כפילויות • SD: ${if (sdMounted) "מחובר" else "לא מזוהה"}"
                    else if (!nextLifeTaskTitle.isNullOrBlank())
                      "משימה פתוחה: \"$nextLifeTaskTitle\" • $openLifeItemsCount משימות ממתינות"
                    else
                      "טאבלט ${telemetry.device.manufacturer} ${telemetry.device.model} • Android ${telemetry.device.androidRelease} • API ${telemetry.device.sdkInt}",
                  style = MaterialTheme.typography.titleSmall,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = "סריקה אחרונה: $lastScanLabel • $openLifeItemsCount פריטי חיים אישיים",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
            if (pendingApprovalsCount > 0) {
              Spacer(modifier = Modifier.width(12.dp))
              OutlinedButton(
                onClick = { onNavigate(NexusDestination.APPROVAL_CENTER.route) },
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.7f)),
                modifier = Modifier.height(48.dp).nexusInteractive()
              ) {
                Icon(
                  Icons.Rounded.VerifiedUser,
                  contentDescription = null,
                  tint = NexusAmber,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("$pendingApprovalsCount ממתינים לאישור", color = NexusAmber)
              }
            }
          }
        }
      }

      // 2. Asymmetric Tablet Command Hero: Aiko Graphite Studio + Live Telemetry Deck
      item {
        if (isTabletWide) {
          Row(
            modifier = Modifier.fillMaxWidth().nexusStaggeredEntrance(1, "dash_hero"),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            verticalAlignment = Alignment.Top
          ) {
            AikoPresenceStudioAnchor(
              lastMaintenanceMillis = lastMaintenanceMillis,
              openLifeItemsCount = openLifeItemsCount,
              mood = assistantMood,
              onOpenAssistant = { onNavigate(NexusDestination.ASSISTANT.route) },
              onOpenControl = { onNavigate(NexusDestination.SYSTEM_CONTROL.route) },
              onQuickCommand = onAssistantQuickCommand,
              modifier = Modifier.weight(0.92f)
            )
            DeviceTelemetryDeck(
              telemetry = telemetry,
              snapshots = telemetrySnapshots,
              isRefreshing = isRefreshing,
              isScanningFullDevice = isScanningFullDevice,
              onRefreshTelemetry = onRefreshTelemetry,
              onQuickCleanLaunch = onQuickCleanLaunch,
              onRunFullDeviceScan = onRunFullDeviceScan,
              onNavigate = onNavigate,
              modifier = Modifier.weight(1.18f)
            )
          }
        } else {
          Column(
            modifier = Modifier.fillMaxWidth().nexusStaggeredEntrance(1, "dash_hero_col"),
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            AikoPresenceStudioAnchor(
              lastMaintenanceMillis = lastMaintenanceMillis,
              openLifeItemsCount = openLifeItemsCount,
              mood = assistantMood,
              onOpenAssistant = { onNavigate(NexusDestination.ASSISTANT.route) },
              onOpenControl = { onNavigate(NexusDestination.SYSTEM_CONTROL.route) },
              onQuickCommand = onAssistantQuickCommand
            )
            DeviceTelemetryDeck(
              telemetry = telemetry,
              snapshots = telemetrySnapshots,
              isRefreshing = isRefreshing,
              isScanningFullDevice = isScanningFullDevice,
              onRefreshTelemetry = onRefreshTelemetry,
              onQuickCleanLaunch = onQuickCleanLaunch,
              onRunFullDeviceScan = onRunFullDeviceScan,
              onNavigate = onNavigate
            )
          }
        }
      }

      // 3. Quick Actions — Graphite Deck with Circular Medallion Controls
      item {
        NexusHudCard(
          accentColor = NexusTurquoise,
          modifier = Modifier.fillMaxWidth().nexusStaggeredEntrance(2, "dash_actions")
        ) {
          NexusEditorialSection(
            title = "פעולות מהירות",
            accentColor = MaterialTheme.colorScheme.primary,
            subtitle = "גישה מיידית לכלים המרכזיים"
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              MedallionQuickAction(
                label = "ניקוי מערכת",
                icon = Icons.Rounded.RocketLaunch,
                accent = NexusAmber,
                onClick = onQuickCleanLaunch,
                modifier = Modifier.weight(1f)
              )
              MedallionQuickAction(
                label = "בדיקת אבטחה",
                icon = Icons.Rounded.Security,
                accent = NexusTurquoiseBright,
                onClick = { onNavigate(NexusDestination.SECURITY.route) },
                modifier = Modifier.weight(1f)
              )
              MedallionQuickAction(
                label = "נהל אפליקציות",
                icon = Icons.Rounded.Memory,
                accent = NexusDeepBlueGlow,
                onClick = { onNavigate(NexusDestination.APPS.route) },
                modifier = Modifier.weight(1f)
              )
              MedallionQuickAction(
                label = "נהל קבצים",
                icon = Icons.Rounded.FolderOpen,
                accent = NexusElectricBlue,
                onClick = { onNavigate(NexusDestination.SMART_STORAGE.route) },
                modifier = Modifier.weight(1f)
              )
            }
          }
        }
      }

      // 4. Alerts & Recent Verified Activity — Graphite Dual Panes
      item {
        if (isTabletWide) {
          Row(
            modifier = Modifier.fillMaxWidth().nexusStaggeredEntrance(3, "dash_panels"),
            horizontalArrangement = Arrangement.spacedBy(18.dp)
          ) {
            ImportantAlertsCard(
              telemetry = telemetry,
              onNavigate = onNavigate,
              modifier = Modifier.weight(1f)
            )
            SystemAndActivityCard(
              telemetry = telemetry,
              recentCleanHistory = recentCleanHistory,
              recentAuditLogs = recentAuditLogs,
              onOpenReports = { onNavigate(NexusDestination.REPORTS.route) },
              modifier = Modifier.weight(1f)
            )
          }
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            ImportantAlertsCard(telemetry = telemetry, onNavigate = onNavigate)
            SystemAndActivityCard(
              telemetry = telemetry,
              recentCleanHistory = recentCleanHistory,
              recentAuditLogs = recentAuditLogs,
              onOpenReports = { onNavigate(NexusDestination.REPORTS.route) }
            )
          }
        }
      }

      // 5. All Modules Architectural Index (3-column tablet grid of graphite tiles)
      item {
        val modules =
          listOf(
            Triple(NexusDestination.PERSONAL_LIFE, "משימות, תזכורות, פתקים, קניות ויומן ($openLifeItemsCount פתוחים)", NexusDestination.PERSONAL_LIFE.icon),
            Triple(NexusDestination.SMART_STORAGE, "פנימי + SD, ZIP, העברת תיקיות ואצווה", Icons.Rounded.SdStorage),
            Triple(NexusDestination.DOWNLOADS_MANAGER, "סינון הורדות אחרונות, דחיסה וארגון", NexusDestination.DOWNLOADS_MANAGER.icon),
            Triple(NexusDestination.AI_FILE_MANAGER, "כפילויות SHA-256, ארגון הורדות ותוכניות AI", Icons.Rounded.AutoAwesome),
            Triple(NexusDestination.DEVICE_DOCTOR, "אבחון מלא, מעבד, RAM ומתכנן תחזוקה", Icons.Rounded.HealthAndSafety),
            Triple(NexusDestination.SELF_DIAGNOSTICS, "בדיקת DB, מסלולים, AI ו-Benchmark", NexusDestination.SELF_DIAGNOSTICS.icon),
            Triple(NexusDestination.APPROVAL_CENTER, "אישורים ממתינים ($pendingApprovalsCount), גיבוי ו-Undo", Icons.Rounded.VerifiedUser),
            Triple(NexusDestination.ACCOUNTS_HUB, "שירותים, קיצורים ובדיקת חיבוריות — ללא סיסמאות", NexusDestination.ACCOUNTS_HUB.icon),
            Triple(NexusDestination.DEEP_CLEAN, "סריקת אחסון, מטמון וניקוי ב-3 רמות", Icons.Rounded.CleaningServices),
            Triple(NexusDestination.SYSTEM_CONTROL, "12+ קיצורי דרך רשמיים ל-Android 10", Icons.Rounded.Tune),
            Triple(NexusDestination.APPS, "ניהול יישומים, אפליקציות דומות ורדומות", Icons.Rounded.Memory),
            Triple(NexusDestination.SECURITY, "ביקורת הרשאות, בדיקת APK ואבחון ענן AI", Icons.Rounded.Security),
            Triple(NexusDestination.AUTOMATION, "בניית אוטומציה בשפה טבעית ותזמון רקע", Icons.Rounded.AutoMode),
            Triple(NexusDestination.REPORTS, "היסטוריה, גיבוי v3 (מיזוג/החלפה) וייצוא", Icons.Rounded.Storage)
          )

        NexusHudCard(
          accentColor = NexusElectricBlue,
          modifier = Modifier.fillMaxWidth().nexusStaggeredEntrance(4, "dash_modules")
        ) {
          NexusEditorialSection(
            title = "מודולי המערכת (${NexusDestination.entries.size})",
            accentColor = NexusDeepBlueGlow,
            subtitle = "ניווט מהיר לכל תתי-המערכות של NEXUS AI"
          ) {
            val chunkSize = if (isTabletWide) 3 else 2
            Column(
              modifier = Modifier.fillMaxWidth(),
              verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              modules.chunked(chunkSize).forEach { rowItems ->
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                  rowItems.forEach { (dest, desc, icon) ->
                    ModuleDirectoryRow(
                      destination = dest,
                      description = desc,
                      icon = icon,
                      onClick = { onNavigate(dest.route) },
                      modifier = Modifier.weight(1f)
                    )
                  }
                  repeat(chunkSize - rowItems.size) { Spacer(modifier = Modifier.weight(1f)) }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AikoPresenceStudioAnchor(
  lastMaintenanceMillis: Long?,
  openLifeItemsCount: Int,
  mood: RobotMood,
  onOpenAssistant: () -> Unit,
  onOpenControl: () -> Unit,
  onQuickCommand: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var quickQuery by rememberSaveable { mutableStateOf("") }
  val timeSince =
    if (lastMaintenanceMillis == null) "טרם בוצעה תחזוקה"
    else "תחזוקה אחרונה: ${SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(lastMaintenanceMillis))}"

  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    color = NexusTitaniumCard,
    border = BorderStroke(1.dp, NexusTurquoise.copy(alpha = 0.34f))
  ) {
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .background(
            Brush.radialGradient(
              colors =
                listOf(
                  NexusElectricBlue.copy(alpha = 0.16f),
                  NexusTitaniumCard,
                  NexusTitaniumDark
                )
            )
          )
          .padding(18.dp)
    ) {
      Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Tier 1 + Tier 2: Presence & Live Voice Status
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          NexusRobotAvatar(
            mood = mood,
            size = 116.dp,
            isPlanning = mood == RobotMood.THINKING
          )
          Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Surface(
              color = NexusTurquoise.copy(alpha = 0.14f),
              shape = RoundedCornerShape(6.dp),
              border = BorderStroke(1.dp, NexusTurquoise.copy(alpha = 0.36f))
            ) {
              Text(
                text = "אייקו • מוח מרכזי פעיל",
                style = MaterialTheme.typography.labelSmall,
                color = NexusTurquoiseBright,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
            Text(
              text = "שלום! אני אייקו",
              style = MaterialTheme.typography.headlineMedium,
              color = NexusTextPrimary
            )
            Text(
              text = "העוזר האישי והטכני שלך. שאל בשפה חופשית או הזנק פקודת מכשיר.",
              style = MaterialTheme.typography.bodySmall,
              color = NexusTextSecondary
            )
            NexusVoiceWaveformBar(
              isActive = mood == RobotMood.SPEAKING || mood == RobotMood.LISTENING || mood == RobotMood.THINKING,
              accentColor = NexusTurquoiseBright,
              secondaryColor = NexusElectricBlue,
              barCount = 24,
              height = 22.dp,
              modifier = Modifier.fillMaxWidth()
            )
            Text(
              text = "$timeSince • $openLifeItemsCount משימות פתוחות",
              style = MaterialTheme.typography.labelSmall,
              color = NexusNeonCyan
            )
          }
        }

        // Recessed Composer Input Pill
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = NexusDataWellDark,
          border = BorderStroke(1.dp, NexusElectricBlue.copy(alpha = 0.45f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            IconButton(
              onClick = onOpenAssistant,
              modifier =
                Modifier
                  .size(48.dp)
                  .nexusInteractive()
                  .clip(CircleShape)
                  .background(NexusElectricBlue)
            ) {
              Icon(
                imageVector = Icons.Rounded.Mic,
                contentDescription = "פתח דיבור עם אייקו",
                tint = Color.White
              )
            }
            BasicTextField(
              value = quickQuery,
              onValueChange = { quickQuery = it },
              singleLine = true,
              textStyle = MaterialTheme.typography.bodyLarge.copy(color = NexusTextPrimary),
              cursorBrush = SolidColor(NexusTurquoiseBright),
              decorationBox = { inner ->
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
                  if (quickQuery.isBlank()) {
                    Text(
                      text = "דבר איתי... (למשל: העתק תמונה ל-SD)",
                      style = MaterialTheme.typography.bodyMedium,
                      color = Color(0xFF8392A8),
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                  }
                  inner()
                }
              },
              modifier = Modifier.weight(1f).testTag("dashboard_aiko_input")
            )
            IconButton(
              onClick = {
                val cmd = quickQuery.trim().ifBlank { "בדוק את מצב הטאבלט והצע איך לפנות מקום" }
                quickQuery = ""
                onQuickCommand(cmd)
              },
              modifier =
                Modifier
                  .size(48.dp)
                  .nexusInteractive()
                  .clip(RoundedCornerShape(10.dp))
                  .background(NexusTurquoise.copy(alpha = 0.18f))
                  .border(1.dp, NexusTurquoise.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                  .testTag("dashboard_aiko_send")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Rounded.Send,
                contentDescription = "שלח פקודה לאייקו",
                tint = NexusTurquoiseBright
              )
            }
          }
        }

        // Prompt Suggestion Pills
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          DarkQuickChip(
            label = "מצב הטאבלט",
            onClick = { onQuickCommand("בדוק את מצב הטאבלט") },
            modifier = Modifier.weight(1f)
          )
          DarkQuickChip(
            label = "סרוק הורדות",
            onClick = { onQuickCommand("מצא קבצים מיותרים בהורדות") },
            modifier = Modifier.weight(1f)
          )
          DarkQuickChip(
            label = "בדיקת אבטחה",
            onClick = { onQuickCommand("בדוק אבטחה והרשאות") },
            modifier = Modifier.weight(1f)
          )
        }

        // Tier 3: Primary & Secondary Actions
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Button(
            onClick = onOpenAssistant,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
            modifier = Modifier.weight(1f).height(48.dp).nexusInteractive().testTag("open_assistant_button")
          ) {
            Text("פתח מרחב אייקו", maxLines = 1)
          }
          OutlinedButton(
            onClick = onOpenControl,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, NexusTurquoiseBright.copy(alpha = 0.50f)),
            modifier = Modifier.weight(1f).height(48.dp).nexusInteractive().testTag("open_control_button")
          ) {
            Text("מרכז שליטה", color = NexusTurquoiseBright, maxLines = 1)
          }
        }
      }
    }
  }
}

@Composable
private fun DarkQuickChip(
  label: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    color = NexusCharcoal,
    shape = RoundedCornerShape(8.dp),
    border = BorderStroke(1.dp, NexusBorderGraphite),
    modifier = modifier.height(48.dp).nexusInteractive().clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick)
  ) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 6.dp)) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = NexusTextSecondary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )
    }
  }
}

@Composable
private fun DeviceTelemetryDeck(
  telemetry: SystemTelemetry,
  snapshots: List<TelemetrySnapshotEntity>,
  isRefreshing: Boolean,
  isScanningFullDevice: Boolean,
  onRefreshTelemetry: () -> Unit,
  onQuickCleanLaunch: () -> Unit,
  onRunFullDeviceScan: () -> Unit,
  onNavigate: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val batteryAlert = telemetry.battery.isAbnormal || telemetry.battery.levelPercent <= 15
  val storageAlert = telemetry.storage.usedPercent >= 85
  val ramAlert = telemetry.ram.isLowMemory || telemetry.ram.usedPercent >= 88
  var selectedTrendIdx by rememberSaveable { mutableIntStateOf(0) }
  val motion = LocalMotionConfig.current

  NexusHudCard(
    accentColor = NexusElectricBlue,
    contentPadding = 18.dp,
    modifier = modifier.fillMaxWidth()
  ) {
    Box(modifier = Modifier.fillMaxWidth()) {
      NexusScanBeamOverlay(isScanning = isRefreshing || isScanningFullDevice, beamColor = NexusTurquoiseBright)
      Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Tier 1: Section Title & Live Connectivity Pill
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "מצב המכשיר בזמן אמת",
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text =
                if (telemetry.hasUsageAccessPermission) "Usage Access פעיל • ניטור יישומים וטלמטריה מלאה"
                else "טלמטריית ליבה פעילה (RAM, סוללה, אחסון, רשת)",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Surface(
            color =
              if (telemetry.network.isConnected) NexusTurquoise.copy(alpha = 0.14f)
              else NexusCrimson.copy(alpha = 0.14f),
            shape = RoundedCornerShape(8.dp),
            border =
              BorderStroke(
                1.dp,
                if (telemetry.network.isConnected) NexusTurquoise.copy(alpha = 0.50f)
                else NexusCrimson.copy(alpha = 0.55f)
              ),
            modifier =
              Modifier
                .height(48.dp)
                .nexusInteractive()
                .clip(RoundedCornerShape(8.dp))
                .clickable { onNavigate(NexusDestination.SYSTEM_CONTROL.route) }
                .testTag("card_network")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(
                Icons.Rounded.Wifi,
                contentDescription = "רשת",
                tint = if (telemetry.network.isConnected) NexusTurquoiseBright else NexusCrimson,
                modifier = Modifier.size(16.dp)
              )
              Text(
                text = telemetry.network.transportLabel,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }

        // Tier 2: Core Health Dial + 3 Recessed Graphite Metric Wells
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          NexusSystemHealthRing(
            score = telemetry.healthScore,
            statusLabel = telemetry.healthStatusLabel,
            isScanning = isRefreshing || isScanningFullDevice,
            onClick = onRefreshTelemetry,
            ringSize = 156.dp
          )

          Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              MetricWellGaugeTile(
                title = "סוללה",
                percent = telemetry.battery.levelPercent,
                centerText = "${telemetry.battery.levelPercent}%",
                subValue = "${String.format(Locale.US, "%.1f", telemetry.battery.temperatureC)}°C",
                accent = if (batteryAlert) NexusCrimson else NexusTurquoiseBright,
                onClick = { onNavigate(NexusDestination.BATTERY.route) },
                modifier = Modifier.weight(1f).testTag("card_battery")
              )
              MetricWellGaugeTile(
                title = "RAM",
                percent = telemetry.ram.usedPercent,
                centerText = "${telemetry.ram.usedPercent}%",
                subValue = formatBytes(telemetry.ram.availableBytes) + " זמין",
                accent = if (ramAlert) NexusAmber else NexusDeepBlueGlow,
                onClick = { onNavigate(NexusDestination.APPS.route) },
                modifier = Modifier.weight(1f).testTag("card_ram")
              )
              MetricWellGaugeTile(
                title = "אחסון",
                percent = telemetry.storage.usedPercent,
                centerText = "${telemetry.storage.usedPercent}%",
                subValue = formatBytes(telemetry.storage.freeBytes) + " פנוי",
                accent = if (storageAlert) NexusAmber else NexusNeonCyan,
                onClick = { onNavigate(NexusDestination.SMART_STORAGE.route) },
                modifier = Modifier.weight(1f).testTag("card_storage")
              )
            }

            // Tier 3: Action Strip
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Button(
                onClick = onRunFullDeviceScan,
                enabled = !isScanningFullDevice,
                shape = RoundedCornerShape(10.dp),
                colors =
                  ButtonDefaults.buttonColors(
                    containerColor = NexusElectricBlue,
                    contentColor = Color.White
                  ),
                modifier =
                  Modifier
                    .weight(1f)
                    .height(48.dp)
                    .nexusInteractive()
                    .testTag("dashboard_full_scan_button")
              ) {
                if (isScanningFullDevice) {
                  CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("סורק...")
                } else {
                  Icon(Icons.Rounded.Radar, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("סריקת מכשיר", maxLines = 1)
                }
              }
              OutlinedButton(
                onClick = onQuickCleanLaunch,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
                modifier =
                  Modifier
                    .weight(0.95f)
                    .height(48.dp)
                    .nexusInteractive()
                    .testTag("dashboard_clean_all_button")
              ) {
                Icon(
                  Icons.Rounded.CleaningServices,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("ניקוי מהיר", color = MaterialTheme.colorScheme.primary, maxLines = 1)
              }
            }
          }
        }

        NexusHairlineDivider()

        // Real Room Telemetry Trend Chart inside recessed well
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "מגמת ביצועים אמיתית",
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.onSurface
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              listOf("בריאות", "RAM", "סוללה").forEachIndexed { idx, label ->
                val selected = selectedTrendIdx == idx
                val chipColor by animateColorAsState(
                  targetValue = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                  animationSpec = tween(motion.duration(180, 70)),
                  label = "trend_chip_$idx"
                )
                Surface(
                  color = chipColor,
                  shape = RoundedCornerShape(8.dp),
                  border =
                    BorderStroke(
                      1.dp,
                      if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                    ),
                  modifier =
                    Modifier
                      .height(34.dp)
                      .clip(RoundedCornerShape(8.dp))
                      .clickable { selectedTrendIdx = idx }
                ) {
                  Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 10.dp)) {
                    Text(
                      text = label,
                      style = MaterialTheme.typography.labelSmall,
                      color =
                        if (selected) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }
              }
            }
          }

          val ordered = remember(snapshots) { snapshots.take(12).reversed() }
          val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
          val chartValues =
            when (selectedTrendIdx) {
              1 ->
                if (ordered.size >= 2) ordered.map { it.ramUsedPercent.toFloat() }
                else listOf(telemetry.ram.usedPercent.toFloat(), telemetry.ram.usedPercent.toFloat())
              2 ->
                if (ordered.size >= 2) ordered.map { it.batteryPercent.toFloat() }
                else listOf(telemetry.battery.levelPercent.toFloat(), telemetry.battery.levelPercent.toFloat())
              else ->
                if (ordered.size >= 2) ordered.map { it.healthScore.toFloat() }
                else listOf(telemetry.healthScore.toFloat(), telemetry.healthScore.toFloat())
            }
          val chartLabels =
            if (ordered.size >= 2) ordered.map { fmt.format(Date(it.timestampMillis)) }
            else listOf("פתיחה", "עכשיו")
          val chartColor =
            when (selectedTrendIdx) {
              1 -> NexusDeepBlueGlow
              2 -> NexusEmerald
              else -> NexusTurquoiseBright
            }

          NexusDataWell(contentPadding = 10.dp) {
            NexusLiveTrendChart(
              values = chartValues,
              labels = chartLabels,
              lineColor = chartColor,
              unitSuffix = "%",
              chartHeight = 108.dp
            )
          }
        }
      }
    }
  }
}

@Composable
private fun MetricWellGaugeTile(
  title: String,
  percent: Int,
  centerText: String,
  subValue: String,
  accent: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  NexusDataWell(
    accentColor = accent,
    contentPadding = 8.dp,
    modifier =
      modifier
        .nexusInteractive()
        .clip(RoundedCornerShape(10.dp))
        .clickable(onClick = onClick)
  ) {
    Column(
      modifier = Modifier.fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      NexusMetricArcGauge(
        percent = percent,
        accentColor = accent,
        centerText = centerText,
        size = 58.dp
      )
      Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1
      )
      Text(
        text = subValue,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center
      )
    }
  }
}

@Composable
private fun MedallionQuickAction(
  label: String,
  icon: ImageVector,
  accent: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier =
      modifier
        .clip(RoundedCornerShape(12.dp))
        .nexusInteractive()
        .clickable(onClick = onClick)
        .padding(vertical = 8.dp, horizontal = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    Box(
      modifier =
        Modifier
          .size(56.dp)
          .clip(CircleShape)
          .background(accent.copy(alpha = 0.14f))
          .border(1.4.dp, accent.copy(alpha = 0.55f), CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = accent,
        modifier = Modifier.size(25.dp)
      )
    }
    Text(
      text = label,
      style = MaterialTheme.typography.labelLarge,
      color = MaterialTheme.colorScheme.onSurface,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
      textAlign = TextAlign.Center
    )
  }
}

@Composable
private fun ImportantAlertsCard(
  telemetry: SystemTelemetry,
  onNavigate: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val accent = if (telemetry.issues.isEmpty()) NexusTurquoise else NexusAmber
  NexusHudCard(
    accentColor = accent,
    modifier = modifier.fillMaxWidth()
  ) {
    NexusEditorialSection(
      title = "התראות חשובות",
      accentColor = accent,
      subtitle = if (telemetry.issues.isEmpty()) "כל המדדים בטווח תקין" else "${telemetry.issues.size} נושאים לבדיקה"
    ) {
      if (telemetry.issues.isEmpty()) {
        NexusDataWell(accentColor = NexusTurquoise) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = NexusTurquoiseBright, modifier = Modifier.size(20.dp))
            Text(
              text = "לא זוהו חריגות חום, זיכרון או אחסון בטאבלט.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      } else {
        Column(modifier = Modifier.fillMaxWidth()) {
          telemetry.issues.forEachIndexed { idx, issue ->
            if (idx > 0) NexusHairlineDivider()
            val severityColor =
              when (issue.severity) {
                HealthSeverity.CRITICAL -> NexusCrimson
                HealthSeverity.WARNING -> NexusAmber
                HealthSeverity.NOTICE -> NexusDeepBlueGlow
                HealthSeverity.OPTIMAL -> NexusTurquoiseBright
              }
            Row(
              modifier =
                Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .clickable { if (issue.targetRoute.isNotBlank()) onNavigate(issue.targetRoute) }
                  .padding(vertical = 10.dp, horizontal = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Icon(
                Icons.Rounded.WarningAmber,
                contentDescription = null,
                tint = severityColor,
                modifier = Modifier.size(20.dp)
              )
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = issue.title,
                  style = MaterialTheme.typography.titleSmall,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = issue.detail,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              if (issue.actionLabel.isNotBlank()) {
                Text(
                  text = issue.actionLabel,
                  style = MaterialTheme.typography.labelMedium,
                  color = severityColor
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun SystemAndActivityCard(
  telemetry: SystemTelemetry,
  recentCleanHistory: List<CleanHistoryEntity>,
  recentAuditLogs: List<ActionAuditEntity>,
  onOpenReports: () -> Unit,
  modifier: Modifier = Modifier
) {
  val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
  NexusHudCard(
    accentColor = NexusElectricBlue,
    modifier = modifier.fillMaxWidth()
  ) {
    NexusEditorialSection(
      title = "מידע חומרה ויומן פעילות",
      accentColor = NexusDeepBlueGlow,
      subtitle = "זמן פעילות: ${formatUptime(telemetry.device.uptimeMillis)} • טלאי אבטחה: ${telemetry.device.securityPatch}",
      trailing = {
        Text(
          text = "כל הדוחות",
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.primary,
          modifier =
            Modifier
              .clip(RoundedCornerShape(8.dp))
              .clickable(onClick = onOpenReports)
              .padding(horizontal = 8.dp, vertical = 6.dp)
        )
      }
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "מכשיר: ${telemetry.device.manufacturer} ${telemetry.device.model}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = if (telemetry.device.hasSamsungDeviceCare) "Samsung One UI" else "Android ${telemetry.device.androidRelease}",
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
            color = MaterialTheme.colorScheme.primary
          )
        }
        NexusHairlineDivider()
        val lastClean = recentCleanHistory.firstOrNull()
        if (lastClean != null) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "ניקוי אחרון: ${lastClean.summary}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.weight(1f),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = fmt.format(Date(lastClean.timestampMillis)),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          NexusHairlineDivider()
        }
        val logsToShow = recentAuditLogs.take(3)
        if (logsToShow.isEmpty()) {
          Text(
            text = "טרם נרשמו פעולות ביומן הבקרה.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 8.dp)
          )
        } else {
          logsToShow.forEachIndexed { idx, log ->
            if (idx > 0) NexusHairlineDivider()
            Row(
              modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Box(
                modifier =
                  Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (log.succeeded) NexusEmerald else NexusCrimson)
              )
              Text(
                text = "${log.category}: ${log.actionTitle}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
              )
              Text(
                text = fmt.format(Date(log.timestampMillis)),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ModuleDirectoryRow(
  destination: NexusDestination,
  description: String,
  icon: ImageVector,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isDark = LocalIsDarkTheme.current
  Surface(
    color = MaterialTheme.colorScheme.surfaceContainerLowest,
    shape = RoundedCornerShape(10.dp),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.78f else 0.9f)),
    modifier =
      modifier
        .nexusInteractive()
        .clip(RoundedCornerShape(10.dp))
        .clickable(onClick = onClick)
        .testTag("module_${destination.route}")
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Box(
        modifier =
          Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.13f))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.28f), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = destination.labelHe,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(21.dp)
        )
      }
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = destination.labelHe,
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}
