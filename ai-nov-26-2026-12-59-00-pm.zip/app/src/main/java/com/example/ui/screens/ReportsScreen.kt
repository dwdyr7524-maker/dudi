package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.ActionAuditEntity
import com.example.data.local.CleanHistoryEntity
import com.example.data.local.TelemetrySnapshotEntity
import com.example.data.system.formatBytes
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusLiveTrendChart
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

@Composable
fun ReportsScreen(
  cleanHistory: List<CleanHistoryEntity>,
  snapshots: List<TelemetrySnapshotEntity>,
  auditLogs: List<ActionAuditEntity>,
  onBuildReportText: () -> String,
  onExportJsonBackup: suspend () -> String,
  onRestoreBackupJson: (String) -> Unit,
  onNotifyResult: (String) -> Unit,
  onBack: () -> Unit,
  onRestoreBackupWithMode: ((String, Boolean) -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var pendingRestoreJson by remember { mutableStateOf<String?>(null) }

  pendingRestoreJson?.let { rawJson ->
    AlertDialog(
      onDismissRequest = { pendingRestoreJson = null },
      title = { Text("אופן שחזור הגיבוי (Merge / Replace)") },
      text = {
        Text(
          "האם למזג את האוטומציות, הזיכרון, המשימות והשירותים מהגיבוי אל הנתונים הקיימים (מומלץ), או להחליף את הנתונים הקיימים לפני השחזור?"
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (onRestoreBackupWithMode != null) onRestoreBackupWithMode(rawJson, false)
            else onRestoreBackupJson(rawJson)
            pendingRestoreJson = null
          },
          modifier = Modifier.testTag("restore_merge_btn")
        ) { Text("מזג עם הקיים") }
      },
      dismissButton = {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          TextButton(
            onClick = {
              if (onRestoreBackupWithMode != null) onRestoreBackupWithMode(rawJson, true)
              else onRestoreBackupJson(rawJson)
              pendingRestoreJson = null
            },
            modifier = Modifier.testTag("restore_replace_btn")
          ) {
            Text("דרוס והחלף", color = NexusCrimson)
          }
          TextButton(onClick = { pendingRestoreJson = null }) {
            Text("ביטול")
          }
        }
      }
    )
  }

  val createDocumentLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
      if (uri != null) {
        val ok =
          runCatching {
            context.contentResolver.openOutputStream(uri)?.use { stream ->
              stream.write(onBuildReportText().toByteArray(Charsets.UTF_8))
            }
            true
          }.getOrDefault(false)
        onNotifyResult(if (ok) "הדוח נשמר לקובץ בהצלחה." else "שמירת הדוח נכשלה.")
      }
    }

  val createBackupLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
      if (uri != null) {
        scope.launch {
          val ok =
            runCatching {
              val json = onExportJsonBackup()
              context.contentResolver.openOutputStream(uri)?.use { stream ->
                stream.write(json.toByteArray(Charsets.UTF_8))
              }
              true
            }.getOrDefault(false)
          onNotifyResult(if (ok) "קובץ הגיבוי (v3) נשמר בהצלחה." else "שמירת הגיבוי נכשלה.")
        }
      }
    }

  val openBackupLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) {
        val raw =
          runCatching {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
          }.getOrNull()
        if (!raw.isNullOrBlank()) {
          pendingRestoreJson = raw
        } else {
          onNotifyResult("לא ניתן לקרוא את קובץ הגיבוי שנבחר.")
        }
      }
    }

  val totalFreed = cleanHistory.sumOf { it.bytesFreed }
  val ordered = snapshots.reversed()
  val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
  val labels = ordered.map { fmt.format(Date(it.timestampMillis)) }
  val storageUsedValues = ordered.map { it.storageUsedPercent.toFloat() }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      NexusHudCard(accentColor = MaterialTheme.colorScheme.primary) {
        Text("REPORTS & TELEMETRY ANALYTICS", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "סך מקום שהתפנה בפועל: ${formatBytes(totalFreed)} • ניקיונות שבוצעו: ${cleanHistory.size} • פעולות מתועדות: ${auditLogs.size}",
          style = MaterialTheme.typography.bodyLarge,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          Button(
            onClick = {
              val shareIntent =
                Intent(Intent.ACTION_SEND).apply {
                  type = "text/plain"
                  putExtra(Intent.EXTRA_SUBJECT, "דוח מערכת NEXUS AI")
                  putExtra(Intent.EXTRA_TEXT, onBuildReportText())
                }
              context.startActivity(Intent.createChooser(shareIntent, "שתף דוח NEXUS"))
            },
            modifier = Modifier.weight(1f).testTag("export_share_report"),
            shape = RoundedCornerShape(14.dp)
          ) {
            Icon(Icons.Rounded.Share, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("שתף דוח")
          }
          OutlinedButton(
            onClick = {
              val dateTag = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
              createDocumentLauncher.launch("NEXUS_Report_$dateTag.txt")
            },
            modifier = Modifier.weight(1f).testTag("export_file_report"),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            shape = RoundedCornerShape(14.dp)
          ) {
            Icon(Icons.Rounded.Download, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(6.dp))
            Text("ייצא לקובץ TXT", color = MaterialTheme.colorScheme.primary)
          }
        }
      }
    }

    item {
      NexusHudCard(accentColor = NexusEmerald) {
        Text("גיבוי ושחזור מלא v3 (JSON מאובטח)", style = MaterialTheme.typography.titleLarge, color = NexusEmerald)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "מגבה ומאפשר שחזור של אוטומציות, העדפות, זיכרון ארוך טווח, תזכורות, חיים אישיים ושירותים (ללא סיסמאות כלל).",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
        Surface(
          color = MaterialTheme.colorScheme.surfaceContainerHigh,
          shape = RoundedCornerShape(10.dp)
        ) {
          Text(
            text = "גבולות Android 10 (ללא Root): הגיבוי מכסה את כל נתוני NEXUS ותיקיות SAF המאושרות. תיקיות פרטיות של אפליקציות צד שלישי (/data/data) אינן נגישות לגיבוי.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(10.dp)
          )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          Button(
            onClick = {
              val dateTag = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
              createBackupLauncher.launch("NEXUS_Backup_$dateTag.json")
            },
            modifier = Modifier.weight(1f).testTag("backup_export_button"),
            colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue, contentColor = Color.White),
            shape = RoundedCornerShape(14.dp)
          ) {
            Icon(Icons.Rounded.Backup, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("שמור גיבוי")
          }
          OutlinedButton(
            onClick = { openBackupLauncher.launch(arrayOf("application/json", "*/*")) },
            modifier = Modifier.weight(1f).testTag("backup_restore_button"),
            border = BorderStroke(1.dp, NexusEmerald.copy(alpha = 0.6f)),
            shape = RoundedCornerShape(14.dp)
          ) {
            Icon(Icons.Rounded.Restore, contentDescription = null, tint = NexusEmerald)
            Spacer(modifier = Modifier.width(6.dp))
            Text("שחזר מגיבוי", color = NexusEmerald)
          }
        }
      }
    }

    item {
      NexusHudCard {
        Text("מצב אחסון לאורך זמן (% בשימוש)", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
        Spacer(modifier = Modifier.height(8.dp))
        NexusLiveTrendChart(
          values = storageUsedValues.ifEmpty { listOf(0f, 0f) },
          labels = labels,
          lineColor = MaterialTheme.colorScheme.primary,
          unitSuffix = "%"
        )
      }
    }

    item {
      Text("היסטוריית ניקיונות (${cleanHistory.size})", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
    }

    if (cleanHistory.isEmpty()) {
      item {
        NexusHudCard {
          Text("טרם בוצעו ניקיונות. הפעל ניקוי מערכת ב-NEXUS Deep Clean כדי לתעד חיסכון אמיתי.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    } else {
      items(cleanHistory, key = { it.id }) { item ->
        NexusHudCard(accentColor = NexusEmerald, contentPadding = 12.dp) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(item.summary, style = MaterialTheme.typography.titleMedium, color = NexusEmerald, modifier = Modifier.weight(1f))
            Text(fmt.format(Date(item.timestampMillis)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Text(
            text = "לפני: ${formatBytes(item.freeBeforeBytes)} ← אחרי: ${formatBytes(item.freeAfterBytes)}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          item.failureReason?.let { reason ->
            Text("פריטים שלא נמחקו: $reason", style = MaterialTheme.typography.bodyMedium, color = NexusAmber)
          }
        }
      }
    }

    item {
      Text("יומן פעולות, כישלונות וסיבות (${auditLogs.size})", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
    }

    items(auditLogs, key = { it.id }) { log ->
      NexusHudCard(
        isAlert = !log.succeeded,
        accentColor = if (log.succeeded) NexusElectricBlue else NexusCrimson,
        contentPadding = 12.dp
      ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text(
            text = "${log.category} • ${log.actionTitle}",
            style = MaterialTheme.typography.titleMedium,
            color = if (log.succeeded) MaterialTheme.colorScheme.onSurface else NexusCrimson,
            modifier = Modifier.weight(1f)
          )
          Text(fmt.format(Date(log.timestampMillis)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(log.details, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        log.failureReason?.let { reason ->
          Text("סיבת כישלון: $reason", style = MaterialTheme.typography.bodyMedium, color = NexusCrimson)
        }
      }
    }
  }
}
