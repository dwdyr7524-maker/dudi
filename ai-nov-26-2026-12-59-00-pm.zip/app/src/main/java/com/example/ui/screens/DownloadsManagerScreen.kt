package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Unarchive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AiOrganizationProposalDraft
import com.example.data.model.ApprovalOperationType
import com.example.data.model.ApprovalRiskLevel
import com.example.data.model.FileCategory
import com.example.data.model.FileSortMode
import com.example.data.model.ScannedFileEntry
import com.example.data.model.SmartStorageScanReport
import com.example.data.system.ZipSecurityGuard
import com.example.data.system.formatBytes
import com.example.ui.components.NexusHudCard
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusEmerald
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class DownloadsFilterKind(val titleHe: String) {
  ALL("הכול"),
  IMAGES("תמונות"),
  DOCUMENTS("מסמכים"),
  APK("קובצי APK"),
  ARCHIVE("ZIP וארכיון"),
  LAST_WEEK("השבוע האחרון")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DownloadsManagerScreen(
  report: SmartStorageScanReport?,
  safFolders: Set<String>,
  isScanning: Boolean,
  onRunFullScan: () -> Unit,
  onRequestAddSafFolder: () -> Unit,
  onQuickOrganizeDownloads: () -> Unit,
  onStageProposal: (AiOrganizationProposalDraft, Boolean) -> Unit,
  onStageBatchCopyMove: (List<ScannedFileEntry>, String, String, Boolean) -> Unit,
  onStageZipCreate: (List<ScannedFileEntry>, String, String?) -> Unit,
  onStageZipExtract: (ScannedFileEntry, String, Boolean) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  var searchQuery by remember { mutableStateOf("") }
  var filterKind by remember { mutableStateOf(DownloadsFilterKind.ALL) }
  var sortMode by remember { mutableStateOf(FileSortMode.DATE_DESC) }
  var selectedUris by remember { mutableStateOf(setOf<String>()) }

  var renameTarget by remember { mutableStateOf<ScannedFileEntry?>(null) }
  var renameText by remember { mutableStateOf("") }

  var moveTarget by remember { mutableStateOf<ScannedFileEntry?>(null) }
  var moveDestTree by remember { mutableStateOf<String?>(null) }
  var moveDestSubfolder by remember { mutableStateOf("הורדות מאורגנות") }

  var showZipCreateDialog by remember { mutableStateOf(false) }
  var zipArchiveName by remember { mutableStateOf("Downloads_Backup.zip") }

  var batchMoveMode by remember { mutableStateOf<Boolean?>(null) }
  var batchDestTree by remember { mutableStateOf<String?>(null) }
  var batchDestFolder by remember { mutableStateOf("הורדות מאורגנות") }

  var extractTarget by remember { mutableStateOf<ScannedFileEntry?>(null) }
  var extractFolderName by remember { mutableStateOf("") }
  var extractOverwrite by remember { mutableStateOf(false) }

  val downloadFiles =
    remember(report) {
      ZipSecurityGuard.filterDownloads(report?.files.orEmpty())
    }

  val filteredFiles =
    remember(downloadFiles, searchQuery, filterKind, sortMode) {
      val now = System.currentTimeMillis()
      val sevenDaysAgo = now - 7L * 86_400_000L
      val q = searchQuery.trim().lowercase(Locale.ROOT)
      val filtered =
        downloadFiles.filter { entry ->
          val matchesQuery = q.isEmpty() || entry.name.lowercase(Locale.ROOT).contains(q)
          val matchesFilter =
            when (filterKind) {
              DownloadsFilterKind.ALL -> true
              DownloadsFilterKind.IMAGES -> entry.category == FileCategory.IMAGES
              DownloadsFilterKind.DOCUMENTS -> entry.category == FileCategory.DOCUMENTS
              DownloadsFilterKind.APK -> entry.isInstallerApk || entry.category == FileCategory.APK_INSTALLERS
              DownloadsFilterKind.ARCHIVE ->
                entry.name.lowercase(Locale.ROOT).endsWith(".zip") || entry.isBackupArchive
              DownloadsFilterKind.LAST_WEEK -> entry.lastModifiedMillis >= sevenDaysAgo
            }
          matchesQuery && matchesFilter
        }
      when (sortMode) {
        FileSortMode.SIZE_DESC -> filtered.sortedByDescending { it.sizeBytes }
        FileSortMode.DATE_DESC -> filtered.sortedByDescending { it.lastModifiedMillis }
        FileSortMode.NAME_ASC -> filtered.sortedBy { it.name.lowercase(Locale.ROOT) }
        FileSortMode.TYPE -> filtered.sortedBy { it.category.titleHe }
      }
    }

  val selectedEntries =
    remember(filteredFiles, selectedUris) {
      filteredFiles.filter { it.uriString in selectedUris }
    }

  renameTarget?.let { file ->
    AlertDialog(
      onDismissRequest = { renameTarget = null },
      title = { Text("שינוי שם קובץ בהורדות") },
      text = {
        OutlinedTextField(
          value = renameText,
          onValueChange = { renameText = it },
          label = { Text("שם קובץ חדש") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (renameText.isNotBlank()) {
              onStageProposal(
                AiOrganizationProposalDraft(
                  title = "שינוי שם: ${file.name} ← $renameText",
                  reasonHe = "שמירה על שם ברור ומאורגן בתיקיית ההורדות.",
                  targetName = file.name,
                  targetLocation = file.relativePath,
                  operationType = ApprovalOperationType.RENAME_SAF_DOCUMENT,
                  riskLevel = ApprovalRiskLevel.LOW,
                  isReversible = true,
                  expectedOutcomeHe = "שינוי שם הקובץ באישורך במרכז האישורים.",
                  sourceUriString = file.uriString,
                  treeUriString = file.treeUriString,
                  proposedNewName = renameText.trim(),
                  bytesAffected = file.sizeBytes
                ),
                true
              )
              renameTarget = null
            }
          },
          modifier = Modifier.minimumInteractiveComponentSize()
        ) { Text("העבר לאישור") }
      },
      dismissButton = {
        TextButton(onClick = { renameTarget = null }) { Text("ביטול") }
      }
    )
  }

  moveTarget?.let { file ->
    val availableTrees = safFolders.toList()
    AlertDialog(
      onDismissRequest = { moveTarget = null },
      title = { Text("העברת קובץ לתיקייה") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("קובץ: ${file.name}")
          availableTrees.forEachIndexed { idx, uriStr ->
            FilterChip(
              selected = (moveDestTree ?: file.treeUriString) == uriStr,
              onClick = { moveDestTree = uriStr },
              label = { Text("יעד SAF #${idx + 1}: ${uriStr.substringAfterLast('/')}") }
            )
          }
          OutlinedTextField(
            value = moveDestSubfolder,
            onValueChange = { moveDestSubfolder = it },
            label = { Text("שם תיקיית היעד") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onStageProposal(
              AiOrganizationProposalDraft(
                title = "העברה מהורדות: ${file.name}",
                reasonHe = "סידור קובץ מתיקיית ההורדות אל תיקיית היעד.",
                targetName = file.name,
                targetLocation = file.relativePath,
                operationType = ApprovalOperationType.MOVE_SAF_DOCUMENT,
                riskLevel = ApprovalRiskLevel.MEDIUM,
                isReversible = true,
                expectedOutcomeHe = "הקובץ יועתק ליעד ויועבר בהסכמה ממנהל ההורדות.",
                sourceUriString = file.uriString,
                treeUriString = file.treeUriString,
                destTreeUriString = moveDestTree ?: file.treeUriString,
                destFolderName = moveDestSubfolder.trim().ifBlank { "הורדות מאורגנות" },
                bytesAffected = file.sizeBytes
              ),
              true
            )
            moveTarget = null
          },
          modifier = Modifier.minimumInteractiveComponentSize()
        ) { Text("העבר למרכז האישורים") }
      },
      dismissButton = {
        TextButton(onClick = { moveTarget = null }) { Text("ביטול") }
      }
    )
  }

  if (showZipCreateDialog && selectedEntries.isNotEmpty()) {
    AlertDialog(
      onDismissRequest = { showZipCreateDialog = false },
      title = { Text("דחיסת ${selectedEntries.size} קבצים ל-ZIP") },
      text = {
        OutlinedTextField(
          value = zipArchiveName,
          onValueChange = { zipArchiveName = it },
          label = { Text("שם ארכיון ה-ZIP") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(
          onClick = {
            onStageZipCreate(
              selectedEntries,
              zipArchiveName.trim().ifBlank { "Downloads_Backup.zip" },
              selectedEntries.first().treeUriString
            )
            selectedUris = emptySet()
            showZipCreateDialog = false
          },
          modifier = Modifier.minimumInteractiveComponentSize()
        ) { Text("הכן דחיסה לאישור") }
      },
      dismissButton = {
        TextButton(onClick = { showZipCreateDialog = false }) { Text("ביטול") }
      }
    )
  }

  batchMoveMode?.let { isMove ->
    val availableTrees = safFolders.toList()
    AlertDialog(
      onDismissRequest = { batchMoveMode = null },
      title = { Text(if (isMove) "העברה מרובה של ${selectedEntries.size} קבצים" else "העתקה מרובה") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          availableTrees.forEachIndexed { idx, uriStr ->
            FilterChip(
              selected = (batchDestTree ?: selectedEntries.firstOrNull()?.treeUriString) == uriStr,
              onClick = { batchDestTree = uriStr },
              label = { Text("שורש SAF #${idx + 1}: ${uriStr.substringAfterLast('/')}") }
            )
          }
          OutlinedTextField(
            value = batchDestFolder,
            onValueChange = { batchDestFolder = it },
            label = { Text("שם תיקיית היעד") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val destTree = batchDestTree ?: selectedEntries.firstOrNull()?.treeUriString
            if (destTree != null && selectedEntries.isNotEmpty()) {
              onStageBatchCopyMove(
                selectedEntries,
                destTree,
                batchDestFolder.trim().ifBlank { "הורדות מאורגנות" },
                isMove
              )
              selectedUris = emptySet()
            }
            batchMoveMode = null
          },
          modifier = Modifier.minimumInteractiveComponentSize()
        ) { Text("העבר לאישור") }
      },
      dismissButton = {
        TextButton(onClick = { batchMoveMode = null }) { Text("ביטול") }
      }
    )
  }

  extractTarget?.let { zip ->
    AlertDialog(
      onDismissRequest = { extractTarget = null },
      title = { Text("חילוץ ארכיון ZIP מאובטח") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("ארכיון: ${zip.name}")
          OutlinedTextField(
            value = extractFolderName,
            onValueChange = { extractFolderName = it },
            label = { Text("שם תיקיית היעד לחילוץ") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = extractOverwrite, onCheckedChange = { extractOverwrite = it })
            Text("דרוס קבצים קיימים באותו שם", style = MaterialTheme.typography.bodySmall)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onStageZipExtract(
              zip,
              extractFolderName.trim().ifBlank { zip.name.substringBeforeLast('.') },
              extractOverwrite
            )
            extractTarget = null
          },
          modifier = Modifier.minimumInteractiveComponentSize()
        ) { Text("הכן חילוץ לאישור") }
      },
      dismissButton = {
        TextButton(onClick = { extractTarget = null }) { Text("ביטול") }
      }
    )
  }

  val totalDownloadsBytes = remember(downloadFiles) { downloadFiles.sumOf { it.sizeBytes } }
  val fmt = remember { SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault()) }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      NexusHudCard(accentColor = MaterialTheme.colorScheme.primary) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "מנהל הורדות חכם (Downloads)",
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "${downloadFiles.size} קבצים מתיקיות Downloads • סה״כ ${formatBytes(totalDownloadsBytes)}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Icon(Icons.Rounded.Download, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        }
        Spacer(modifier = Modifier.height(10.dp))
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = onRequestAddSafFolder,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("downloads_add_saf_btn")
          ) {
            Icon(Icons.Rounded.FolderOpen, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("אשר תיקיית הורדות (SAF)")
          }
          OutlinedButton(
            onClick = onRunFullScan,
            enabled = !isScanning,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("downloads_scan_btn")
          ) {
            if (isScanning) {
              CircularProgressIndicator(modifier = Modifier.width(18.dp).height(18.dp), strokeWidth = 2.dp)
            } else {
              Icon(Icons.Rounded.Radar, contentDescription = null)
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text("הרץ סריקת אחסון")
          }
          OutlinedButton(
            onClick = onQuickOrganizeDownloads,
            enabled = downloadFiles.isNotEmpty(),
            modifier = Modifier.minimumInteractiveComponentSize().testTag("downloads_ai_organize_btn")
          ) {
            Icon(Icons.Rounded.AutoAwesome, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("ארגון הורדות AI")
          }
        }
      }
    }

    if (safFolders.isEmpty() || downloadFiles.isEmpty()) {
      item {
        NexusHudCard(accentColor = NexusAmber) {
          Text(
            text =
              if (safFolders.isEmpty()) "טרם אושרה תיקיית הורדות (Download) ב-SAF"
              else "לא זוהו עדיין קבצים מתיקיית הורדות בסריקה האחרונה",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text =
              "לחץ על \"אשר תיקיית הורדות (SAF)\", בחר את תיקיית Download במכשיר, ולאחר מכן לחץ על \"הרץ סריקת אחסון\".",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    } else {
      item {
        NexusHudCard(accentColor = MaterialTheme.colorScheme.outline) {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            singleLine = true,
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            placeholder = { Text("חיפוש בהורדות...") },
            modifier = Modifier.fillMaxWidth().testTag("downloads_search_input")
          )
          Spacer(modifier = Modifier.height(8.dp))
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            DownloadsFilterKind.entries.forEach { fk ->
              FilterChip(
                selected = filterKind == fk,
                onClick = { filterKind = fk },
                label = { Text(fk.titleHe) },
                modifier = Modifier.testTag("downloads_filter_${fk.name.lowercase()}")
              )
            }
          }
          Spacer(modifier = Modifier.height(6.dp))
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            FileSortMode.entries.forEach { sm ->
              FilterChip(
                selected = sortMode == sm,
                onClick = { sortMode = sm },
                label = { Text(sm.titleHe) }
              )
            }
          }
        }
      }

      if (selectedEntries.isNotEmpty()) {
        item {
          NexusHudCard(accentColor = NexusEmerald) {
            Text(
              text = "נבחרו ${selectedEntries.size} קבצים (${formatBytes(selectedEntries.sumOf { it.sizeBytes })})",
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(
                onClick = { showZipCreateDialog = true },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("downloads_batch_zip_btn")
              ) {
                Icon(Icons.Rounded.Archive, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("דחוס ל-ZIP")
              }
              OutlinedButton(
                onClick = { batchMoveMode = true },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("downloads_batch_move_btn")
              ) {
                Icon(Icons.Rounded.DriveFileMove, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("העבר מסומנים")
              }
              TextButton(onClick = { selectedUris = emptySet() }) { Text("נקה בחירה") }
            }
          }
        }
      }

      items(filteredFiles, key = { it.uriString }) { file ->
        val isZip = file.name.lowercase(Locale.ROOT).endsWith(".zip")
        val isSelected = file.uriString in selectedUris
        NexusHudCard(selected = isSelected, contentPadding = 12.dp) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Checkbox(
              checked = isSelected,
              onCheckedChange = { checked ->
                selectedUris =
                  if (checked) selectedUris + file.uriString else selectedUris - file.uriString
              },
              modifier = Modifier.minimumInteractiveComponentSize()
            )
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = file.name,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "${file.category.titleHe} • ${formatBytes(file.sizeBytes)} • ${fmt.format(Date(file.lastModifiedMillis))}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            if (isZip) {
              IconButton(
                onClick = {
                  extractTarget = file
                  extractFolderName = file.name.substringBeforeLast('.').ifBlank { "Extracted" }
                  extractOverwrite = false
                },
                modifier = Modifier.minimumInteractiveComponentSize()
              ) {
                Icon(Icons.Rounded.Unarchive, contentDescription = "חלץ ZIP", tint = NexusEmerald)
              }
            }
            IconButton(
              onClick = {
                renameTarget = file
                renameText = file.name
              },
              modifier = Modifier.minimumInteractiveComponentSize()
            ) {
              Icon(Icons.Rounded.DriveFileRenameOutline, contentDescription = "שנה שם")
            }
            IconButton(
              onClick = {
                moveTarget = file
                moveDestTree = file.treeUriString
              },
              modifier = Modifier.minimumInteractiveComponentSize()
            ) {
              Icon(Icons.Rounded.DriveFileMove, contentDescription = "העבר")
            }
            IconButton(
              onClick = {
                onStageProposal(
                  AiOrganizationProposalDraft(
                    title = "מחיקה מהורדות: ${file.name}",
                    reasonHe = "נבחר למחיקה ממנהל ההורדות (ממתין לאישור סופי).",
                    targetName = file.name,
                    targetLocation = file.relativePath,
                    operationType = ApprovalOperationType.DELETE_SAF_DOCUMENT,
                    riskLevel = ApprovalRiskLevel.HIGH,
                    isReversible = false,
                    expectedOutcomeHe = "הקובץ יימחק לצמיתות רק לאחר אישור במרכז האישורים.",
                    sourceUriString = file.uriString,
                    treeUriString = file.treeUriString,
                    bytesAffected = file.sizeBytes
                  ),
                  true
                )
              },
              modifier = Modifier.minimumInteractiveComponentSize()
            ) {
              Icon(Icons.Rounded.DeleteOutline, contentDescription = "מחק (לאישור)", tint = MaterialTheme.colorScheme.error)
            }
          }
        }
      }
    }
  }
}
