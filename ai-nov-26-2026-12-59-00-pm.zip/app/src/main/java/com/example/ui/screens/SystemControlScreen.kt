package com.example.ui.screens

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.BatteryStd
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Brightness6
import androidx.compose.material.icons.rounded.DisplaySettings
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PhonelinkSetup
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.SystemShortcutId
import com.example.data.model.SystemShortcutItem
import com.example.data.model.SystemTelemetry
import com.example.ui.components.NexusDataWell
import com.example.ui.components.NexusEditorialSection
import com.example.ui.components.NexusHudCard
import com.example.ui.components.nexusInteractive
import com.example.ui.components.nexusStaggeredEntrance
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NexusDeepBlueGlow
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusTurquoiseBright
import kotlin.math.roundToInt

@Composable
fun SystemControlScreen(
  shortcuts: List<SystemShortcutItem>,
  telemetry: SystemTelemetry,
  onOpenShortcut: (SystemShortcutId) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  val context = LocalContext.current
  val activity = context as? Activity
  val audioInfo = remember(context) {
    val am = context.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
    val mediaCurr = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
    val mediaMax = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
    val ringCurr = am.getStreamVolume(android.media.AudioManager.STREAM_RING)
    val ringMax = am.getStreamMaxVolume(android.media.AudioManager.STREAM_RING).coerceAtLeast(1)
    val sysBrightness =
      runCatching {
        android.provider.Settings.System.getInt(
          context.contentResolver,
          android.provider.Settings.System.SCREEN_BRIGHTNESS
        )
      }.getOrDefault(180)
    Triple((mediaCurr * 100) / mediaMax, (ringCurr * 100) / ringMax, (sysBrightness * 100) / 255)
  }
  var windowBrightness by remember {
    mutableFloatStateOf(
      activity?.window?.attributes?.screenBrightness?.takeIf { it >= 0f }
        ?: (audioInfo.third / 100f).coerceIn(0.1f, 1f)
    )
  }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val columns = if (maxWidth >= 820.dp) 3 else if (maxWidth >= 560.dp) 2 else 1

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        NexusHudCard(
          accentColor = NexusTurquoiseBright,
          modifier = Modifier.nexusStaggeredEntrance(0, "sys_hero")
        ) {
          Text(
            text = "מרכז בקרת מערכת והגדרות",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "גישה ישירה ומיידית להגדרות Android 10 באמצעות Intents רשמיים — ללא עקיפת אבטחת מערכת.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            NexusDataWell(modifier = Modifier.weight(1f), contentPadding = 10.dp) {
              Text("עוצמת מדיה", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = "${audioInfo.first}%",
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
              )
            }
            NexusDataWell(modifier = Modifier.weight(1f), contentPadding = 10.dp) {
              Text("עוצמת צלצול", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = "${audioInfo.second}%",
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                color = NexusDeepBlueGlow
              )
            }
            NexusDataWell(modifier = Modifier.weight(1f), contentPadding = 10.dp) {
              Text("בהירות מערכת", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = "${audioInfo.third}%",
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
          Spacer(modifier = Modifier.height(12.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "בהירות תצוגה באפליקציה",
              style = MaterialTheme.typography.labelLarge,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "${(windowBrightness * 100).roundToInt()}%",
              style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.primary
            )
          }
          Slider(
            value = windowBrightness,
            onValueChange = { value ->
              windowBrightness = value
              activity?.window?.let { win ->
                val lp = win.attributes
                lp.screenBrightness = value.coerceIn(0.08f, 1f)
                win.attributes = lp
              }
            },
            colors =
              SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = NexusElectricBlue,
                inactiveTrackColor = MaterialTheme.colorScheme.surfaceContainerHighest
              )
          )
        }
      }

      item {
        NexusEditorialSection(
          title = "קיצורי שליטה ישירים (${shortcuts.size})",
          subtitle = "פתיחת מסכי הגדרות רשמיים בטאבלט",
          accentColor = NexusElectricBlue
        ) {}
      }

      val rows = shortcuts.chunked(columns)
      items(rows.size) { rowIdx ->
        val rowItems = rows[rowIdx]
        Row(
          modifier = Modifier.fillMaxWidth().nexusStaggeredEntrance((rowIdx + 1).coerceAtMost(6), "sys_row_$rowIdx"),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          rowItems.forEach { item ->
            ShortcutTileCard(
              item = item,
              icon = shortcutIconFor(item.id),
              accent =
                if (item.id == SystemShortcutId.SAMSUNG_DEVICE_CARE) NexusTurquoiseBright
                else NexusDeepBlueGlow,
              onClick = { onOpenShortcut(item.id) },
              modifier = Modifier.weight(1f)
            )
          }
          repeat(columns - rowItems.size) {
            Spacer(modifier = Modifier.weight(1f))
          }
        }
      }

      item {
        NexusDataWell(accentColor = MaterialTheme.colorScheme.outline) {
          Text(
            text =
              "סטטוס חומרה נוכחי: ${telemetry.device.manufacturer} ${telemetry.device.model} | רשת: ${telemetry.network.transportLabel} | הרשאת נתוני שימוש: ${if (telemetry.hasUsageAccessPermission) "פעילה" else "לא פעילה"}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}

@Composable
private fun ShortcutTileCard(
  item: SystemShortcutItem,
  icon: ImageVector,
  accent: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  NexusHudCard(
    modifier =
      modifier
        .nexusInteractive()
        .clip(RoundedCornerShape(12.dp))
        .clickable(onClick = onClick)
        .testTag("shortcut_${item.id.name.lowercase()}"),
    accentColor = accent,
    contentPadding = 14.dp
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier =
          Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(accent.copy(alpha = 0.14f))
            .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
      ) {
        Icon(icon, contentDescription = item.title, tint = accent, modifier = Modifier.size(22.dp))
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(text = item.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        Text(text = item.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
  }
}

private fun shortcutIconFor(id: SystemShortcutId): ImageVector =
  when (id) {
    SystemShortcutId.WIFI -> Icons.Rounded.Wifi
    SystemShortcutId.BLUETOOTH -> Icons.Rounded.Bluetooth
    SystemShortcutId.DISPLAY -> Icons.Rounded.DisplaySettings
    SystemShortcutId.BRIGHTNESS -> Icons.Rounded.Brightness6
    SystemShortcutId.SOUND -> Icons.AutoMirrored.Rounded.VolumeUp
    SystemShortcutId.BATTERY -> Icons.Rounded.BatteryStd
    SystemShortcutId.STORAGE -> Icons.Rounded.Storage
    SystemShortcutId.APPS -> Icons.Rounded.Apps
    SystemShortcutId.PERMISSIONS -> Icons.Rounded.Lock
    SystemShortcutId.NOTIFICATIONS -> Icons.Rounded.Notifications
    SystemShortcutId.ACCESSIBILITY -> Icons.Rounded.AccessibilityNew
    SystemShortcutId.SYSTEM_SETTINGS -> Icons.Rounded.Settings
    SystemShortcutId.USAGE_ACCESS -> Icons.Rounded.VerifiedUser
    SystemShortcutId.SAMSUNG_DEVICE_CARE -> Icons.Rounded.PhonelinkSetup
  }
