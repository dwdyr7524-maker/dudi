package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.FolderSpecial
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AiOrganizationPlanReport
import com.example.data.model.AiOrganizationProposalDraft
import com.example.data.model.ApprovalOperationType
import com.example.data.model.ApprovalRiskLevel
import com.example.data.model.DuplicateGroup
import com.example.data.model.SmartStorageScanReport
import com.example.data.system.formatBytes
import com.example.ui.components.NexusHudCard
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusEmerald

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiFileManagerScreen(
  report: SmartStorageScanReport?,
  orgPlan: AiOrganizationPlanReport?,
  aiInsights: String?,
  isScanning: Boolean,
  onRunFullScan: () -> Unit,
  onStageAllProposals: () -> Unit,
  onStageSingleProposal: (AiOrganizationProposalDraft, Boolean) -> Unit,
  onQuickDuplicateVideos: () -> Unit,
  onQuickOrganizeDownloads: () -> Unit,
  onQuickCleanupPlan: () -> Unit,
  onOpenApprovalCenter: () -> Unit,
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier.fillMaxSize().testTag("ai_file_manager_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Header + Natural Language Quick Automation Commands
    item {
      NexusHudCard(accentColor = MaterialTheme.colorScheme.primary) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              "מנהל קבצים AI ואיתור כפילויות",
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              "ניתוח מבנה תיקיות, ארגון הורדות, שמות לא ברורים, והשוואת כפילויות SHA-256 צד-לצד. שום קובץ לא נמחק או זז ללא אישורך.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(onClick = onRunFullScan, enabled = !isScanning) {
            if (isScanning) {
              CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
            } else {
              Icon(Icons.Rounded.AutoAwesome, contentDescription = null)
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (isScanning) "מנתח..." else "נתח תיקיות")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text("אוטומציה חכמה בפקודה ישירה (מעבירה למרכז האישורים בלבד):", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(6.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          AssistChip(
            onClick = onQuickDuplicateVideos,
            leadingIcon = { Icon(Icons.Rounded.VideoLibrary, contentDescription = null, modifier = Modifier.size(16.dp)) },
            label = { Text("תמצא לי סרטונים כפולים") }
          )
          AssistChip(
            onClick = onQuickOrganizeDownloads,
            leadingIcon = { Icon(Icons.Rounded.FolderSpecial, contentDescription = null, modifier = Modifier.size(16.dp)) },
            label = { Text("תארגן לי את ההורדות") }
          )
          AssistChip(
            onClick = onQuickCleanupPlan,
            leadingIcon = { Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp)) },
            label = { Text("תכין תוכנית ניקוי וארגון") }
          )
        }
      }
    }

    // 2. AI Insights & Folder Intelligence Summary
    if (orgPlan != null || aiInsights != null) {
      item {
        NexusHudCard(accentColor = NexusEmerald) {
          Text("תוכנית ארגון אישית (Folder Intelligence)", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
          orgPlan?.let { plan ->
            Spacer(modifier = Modifier.height(6.dp))
            Text(plan.summaryHe, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (plan.suggestedFolders.isNotEmpty()) {
              Spacer(modifier = Modifier.height(8.dp))
              Text("תיקיות מוצעות:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
              FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                plan.suggestedFolders.forEach { folder ->
                  Surface(
                    color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(8.dp)
                  ) {
                    Text(folder, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                  }
                }
              }
            }
          }
          if (!aiInsights.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Surface(color = MaterialTheme.colorScheme.surfaceContainerHighest, shape = RoundedCornerShape(12.dp)) {
              Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
                Text("תובנות Gemini AI:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(aiInsights, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
              }
            }
          }
          if (orgPlan != null && orgPlan.proposals.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(
                onClick = onStageAllProposals,
                colors = ButtonDefaults.buttonColors(containerColor = NexusEmerald, contentColor = MaterialTheme.colorScheme.onTertiary),
                modifier = Modifier.testTag("stage_all_ai_proposals_btn")
              ) {
                Text("שלח את כל ${orgPlan.proposals.size} ההצעות לאישור")
              }
              OutlinedButton(onClick = onOpenApprovalCenter) {
                Text("פתח מרכז אישורים")
              }
            }
          }
        }
      }
    }

    // 3. Individual AI Proposals Preview
    if (orgPlan != null && orgPlan.proposals.isNotEmpty()) {
      item {
        Text(
          "הצעות שינוי של סוכן ה-AI (${orgPlan.proposals.size})",
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface
        )
      }
      items(orgPlan.proposals.take(20), key = { "${it.operationType}_${it.sourceUriString}_${it.title}" }) { draft ->
        NexusHudCard(accentColor = MaterialTheme.colorScheme.outline) {
          Text(draft.title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
          Spacer(modifier = Modifier.height(4.dp))
          Text(draft.reasonHe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Text("מיקום: ${draft.targetLocation}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Spacer(modifier = Modifier.height(8.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(draft.riskLevel.titleHe, style = MaterialTheme.typography.labelSmall, color = if (draft.riskLevel == ApprovalRiskLevel.HIGH) NexusCrimson else NexusAmber)
            OutlinedButton(onClick = { onStageSingleProposal(draft, false) }) {
              Text("העבר לאישור בלבד")
            }
          }
        }
      }
    }

    // 4. Duplicate Detector (SHA-256 Side-by-Side Comparison)
    item {
      val groups = report?.duplicateGroups.orEmpty()
      Text(
        "מנוע איתור כפילויות SHA-256 (${groups.size} קבוצות • בזבוז ${formatBytes(report?.totalDuplicateWasteBytes ?: 0L)})",
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurface
      )
    }

    val dupGroups = report?.duplicateGroups.orEmpty()
    if (dupGroups.isEmpty()) {
      item {
        NexusHudCard {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.ContentCopy, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              if (report == null)
                "לחץ על 'נתח תיקיות' כדי לבצע השוואת גודל, תוכן וחתימת SHA-256 לכל התמונות, הסרטונים, המסמכים וה-APK."
              else
                "לא נמצאו קבצים כפולים בעלי תוכן זהה בתיקיות שנסרקו.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(dupGroups, key = { it.id }) { group ->
        DuplicateGroupSideBySideCard(
          group = group,
          onSendCopyForDeletionApproval = { copy ->
            onStageSingleProposal(
              AiOrganizationProposalDraft(
                title = "מחיקת עותק כפול: ${copy.name}",
                reasonHe = "זוהה קובץ זהה בתוכן SHA-256 (${group.sha256.take(12)}). העותק המומלץ יישאר.",
                targetName = copy.name,
                targetLocation = copy.relativePath,
                operationType = ApprovalOperationType.DELETE_SAF_DOCUMENT,
                riskLevel = ApprovalRiskLevel.HIGH,
                isReversible = false,
                expectedOutcomeHe = "פינוי ${formatBytes(copy.sizeBytes)} מהאחסון.",
                sourceUriString = copy.uriString,
                treeUriString = copy.treeUriString,
                bytesAffected = copy.sizeBytes
              ),
              true
            )
          }
        )
      }
    }
  }
}

@Composable
private fun DuplicateGroupSideBySideCard(
  group: DuplicateGroup,
  onSendCopyForDeletionApproval: (com.example.data.model.DuplicateCopyItem) -> Unit
) {
  NexusHudCard(accentColor = NexusAmber) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          "${group.category.titleHe} • ${group.copies.size} עותקים זהים",
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          "SHA-256: ${group.sha256.take(16)}... • ${if (group.hasDifferentNames) "שמות שונים ותוכן זהה!" else "שם ותוכן זהים"}",
          style = MaterialTheme.typography.bodySmall,
          color = if (group.hasDifferentNames) NexusAmber else MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
      Text(
        "חיסכון: ${formatBytes(group.reclaimableBytes)}",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = NexusEmerald
      )
    }

    Spacer(modifier = Modifier.height(10.dp))
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      group.copies.forEach { copy ->
        Surface(
          color =
            if (copy.recommendedKeep) NexusEmerald.copy(alpha = 0.12f)
            else MaterialTheme.colorScheme.surfaceContainerHighest,
          shape = RoundedCornerShape(12.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                if (copy.recommendedKeep) {
                  Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = NexusEmerald, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                }
                Text(copy.name, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
              }
              Text("${copy.volumeKind.titleHe}: ${copy.relativePath}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              copy.keepReasonHe?.let { reason ->
                Text(reason, style = MaterialTheme.typography.labelSmall, color = if (copy.recommendedKeep) NexusEmerald else MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
            if (!copy.recommendedKeep) {
              Spacer(modifier = Modifier.width(8.dp))
              OutlinedButton(onClick = { onSendCopyForDeletionApproval(copy) }) {
                Icon(Icons.Rounded.DeleteOutline, contentDescription = null, tint = NexusCrimson, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("לאישור מחיקה", color = NexusCrimson)
              }
            }
          }
        }
      }
    }
  }
}
