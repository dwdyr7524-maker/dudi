package com.example.ui.theme

import android.provider.Settings
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Immutable
data class NexusMotionConfig(
  val performanceMode: Boolean = false,
  val reduceMotion: Boolean = false,
  val systemAnimationsDisabled: Boolean = false
) {
  /** True when ambient/background decorative loops (bobbing, breathing, subtle pulse) may run. */
  val allowAmbientMotion: Boolean
    get() = !performanceMode && !reduceMotion && !systemAnimationsDisabled

  /** True when user-triggered feedback transitions (press scale, progress, charts) should animate. */
  val allowMicroMotion: Boolean
    get() = !reduceMotion && !systemAnimationsDisabled

  fun duration(normalMs: Int, reducedMs: Int = 90): Int =
    when {
      reduceMotion || systemAnimationsDisabled -> 0
      performanceMode -> reducedMs.coerceAtMost(normalMs)
      else -> normalMs
    }
}

val LocalPerformanceMode = staticCompositionLocalOf { false }
val LocalReduceMotion = staticCompositionLocalOf { false }
val LocalMotionConfig = staticCompositionLocalOf { NexusMotionConfig() }
val LocalIsDarkTheme = staticCompositionLocalOf { true }

private val NexusDarkColorScheme =
  darkColorScheme(
    primary = NexusTurquoiseBright,
    onPrimary = NexusObsidian,
    primaryContainer = NexusElectricBlue,
    onPrimaryContainer = Color.White,
    secondary = NexusDeepBlueGlow,
    onSecondary = Color.White,
    secondaryContainer = NexusTitaniumElevated,
    onSecondaryContainer = NexusTextPrimary,
    tertiary = NexusNeonCyan,
    onTertiary = NexusObsidian,
    background = NexusObsidian,
    onBackground = NexusTextPrimary,
    surface = NexusCharcoal,
    onSurface = NexusTextPrimary,
    surfaceVariant = NexusTitaniumElevated,
    onSurfaceVariant = NexusTextSecondary,
    surfaceContainerLowest = NexusDataWellDark,
    surfaceContainerLow = NexusTitaniumDark,
    surfaceContainer = NexusCharcoal,
    surfaceContainerHigh = NexusTitaniumElevated,
    surfaceContainerHighest = NexusDarkSurfaceHighest,
    outline = NexusBorderSubtle,
    outlineVariant = NexusBorderGlow.copy(alpha = 0.36f),
    error = NexusRoseBright,
    onError = NexusObsidian
  )

private val NexusLightColorScheme =
  lightColorScheme(
    primary = NexusLightPrimary,
    onPrimary = NexusLightSurface,
    primaryContainer = NexusLightCardElevated,
    onPrimaryContainer = NexusLightTextPrimary,
    secondary = NexusLightSecondary,
    onSecondary = NexusLightSurface,
    secondaryContainer = Color(0xFFCCFBF1),
    onSecondaryContainer = Color(0xFF134E4A),
    tertiary = NexusLightTertiary,
    onTertiary = NexusLightSurface,
    background = NexusLightBackground,
    onBackground = NexusLightTextPrimary,
    surface = NexusLightSurface,
    onSurface = NexusLightTextPrimary,
    surfaceVariant = NexusLightCardElevated,
    onSurfaceVariant = NexusLightTextSecondary,
    surfaceContainerLowest = NexusLightBackground,
    surfaceContainerLow = NexusLightSurface,
    surfaceContainer = NexusLightCard,
    surfaceContainerHigh = NexusLightCardElevated,
    surfaceContainerHighest = NexusLightCardHighest,
    outline = NexusLightBorder,
    outlineVariant = NexusLightPrimary.copy(alpha = 0.22f),
    error = NexusLightCrimson,
    onError = NexusLightSurface
  )

// Crisp architectural radii (replaces generic puffy 24-30dp everywhere)
private val NexusShapes =
  Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(14.dp),
    extraLarge = RoundedCornerShape(16.dp)
  )

@Composable
fun MyApplicationTheme(
  performanceMode: Boolean = false,
  reduceMotion: Boolean = false,
  darkTheme: Boolean = true,
  content: @Composable () -> Unit
) {
  val context = LocalContext.current
  val systemAnimDisabled =
    remember(context) {
      runCatching {
        val scale =
          Settings.Global.getFloat(
            context.contentResolver,
            Settings.Global.ANIMATOR_DURATION_SCALE,
            1f
          )
        scale <= 0f
      }.getOrDefault(false)
    }
  val motionConfig =
    remember(performanceMode, reduceMotion, systemAnimDisabled) {
      NexusMotionConfig(
        performanceMode = performanceMode,
        reduceMotion = reduceMotion,
        systemAnimationsDisabled = systemAnimDisabled
      )
    }

  CompositionLocalProvider(
    LocalPerformanceMode provides (performanceMode || reduceMotion || systemAnimDisabled),
    LocalReduceMotion provides (reduceMotion || systemAnimDisabled),
    LocalMotionConfig provides motionConfig,
    LocalIsDarkTheme provides darkTheme
  ) {
    MaterialTheme(
      colorScheme = if (darkTheme) NexusDarkColorScheme else NexusLightColorScheme,
      typography = NexusTypography,
      shapes = NexusShapes,
      content = content
    )
  }
}
