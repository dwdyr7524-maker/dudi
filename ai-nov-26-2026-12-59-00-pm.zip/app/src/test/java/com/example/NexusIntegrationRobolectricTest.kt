package com.example

import android.content.Context
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AutomationEntity
import com.example.data.local.NexusDatabase
import com.example.data.local.OrchestratorTaskEntity
import com.example.data.local.ReminderAlertEntity
import com.example.data.memory.MemorySaveResult
import com.example.data.memory.NexusLearningEngine
import com.example.data.memory.NexusMemoryManager
import com.example.data.memory.NexusMemoryType
import com.example.data.model.SystemTelemetry
import com.example.data.orchestrator.NexusToolHealthState
import com.example.data.orchestrator.NexusToolRegistry
import com.example.data.orchestrator.OrchestratorTaskStatus
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NexusIntegrationRobolectricTest {

  private lateinit var context: Context
  private lateinit var memDb: NexusDatabase

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    memDb =
      Room.inMemoryDatabaseBuilder(context, NexusDatabase::class.java)
        .allowMainThreadQueries()
        .build()
  }

  @After
  fun tearDown() {
    memDb.close()
  }

  @Test
  fun `room migration 3 to 4 preserves existing user data and creates all v4 tables`() = runBlocking {
    val dbName = "migration_v3_v4_test_${System.nanoTime()}.db"
    context.deleteDatabase(dbName)

    val helperFactory = FrameworkSQLiteOpenHelperFactory()
    val helperConfig =
      SupportSQLiteOpenHelper.Configuration.builder(context)
        .name(dbName)
        .callback(
          object : SupportSQLiteOpenHelper.Callback(3) {
            override fun onCreate(db: SupportSQLiteDatabase) {
              db.execSQL("CREATE TABLE IF NOT EXISTS clean_history (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, timestampMillis INTEGER NOT NULL, itemsDeleted INTEGER NOT NULL, itemsFailed INTEGER NOT NULL, bytesFreed INTEGER NOT NULL, freeBeforeBytes INTEGER NOT NULL, freeAfterBytes INTEGER NOT NULL, summary TEXT NOT NULL, failureReason TEXT)")
              db.execSQL("CREATE TABLE IF NOT EXISTS telemetry_snapshots (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, timestampMillis INTEGER NOT NULL, batteryPercent INTEGER NOT NULL, batteryTempC REAL NOT NULL, batteryVoltageMv INTEGER NOT NULL, ramUsedPercent INTEGER NOT NULL, storageUsedPercent INTEGER NOT NULL, storageFreeBytes INTEGER NOT NULL, healthScore INTEGER NOT NULL)")
              db.execSQL("CREATE TABLE IF NOT EXISTS assistant_messages (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, timestampMillis INTEGER NOT NULL, isUser INTEGER NOT NULL, text TEXT NOT NULL, actionTag TEXT)")
              db.execSQL("CREATE TABLE IF NOT EXISTS automations (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, voicePhrase TEXT NOT NULL, description TEXT NOT NULL, stepsSerialized TEXT NOT NULL, isBuiltIn INTEGER NOT NULL, lastRunMillis INTEGER, scheduleIntervalHours INTEGER NOT NULL DEFAULT 0)")
              db.execSQL("CREATE TABLE IF NOT EXISTS action_audit (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, timestampMillis INTEGER NOT NULL, category TEXT NOT NULL, actionTitle TEXT NOT NULL, succeeded INTEGER NOT NULL, details TEXT NOT NULL, failureReason TEXT)")
              db.execSQL("CREATE TABLE IF NOT EXISTS approval_proposals (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, createdAtMillis INTEGER NOT NULL, title TEXT NOT NULL, reasonHe TEXT NOT NULL, targetName TEXT NOT NULL, targetLocation TEXT NOT NULL, operationType TEXT NOT NULL, riskLevel TEXT NOT NULL, isReversible INTEGER NOT NULL, expectedOutcomeHe TEXT NOT NULL, sourceUriString TEXT, treeUriString TEXT, destTreeUriString TEXT, destFolderName TEXT, proposedNewName TEXT, packageName TEXT, bytesAffected INTEGER NOT NULL, status TEXT NOT NULL, resultMessageHe TEXT)")
              db.execSQL("CREATE TABLE IF NOT EXISTS undo_records (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, createdAtMillis INTEGER NOT NULL, actionTitle TEXT NOT NULL, undoType TEXT NOT NULL, targetUriString TEXT, originalParentDocId TEXT, originalTreeUriString TEXT, previousName TEXT, backupManifestId INTEGER, isUndoable INTEGER NOT NULL, undone INTEGER NOT NULL, noteHe TEXT NOT NULL)")
              db.execSQL("CREATE TABLE IF NOT EXISTS backup_records (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, createdAtMillis INTEGER NOT NULL, sourceLabel TEXT NOT NULL, sourceTreeUri TEXT NOT NULL, destTreeUri TEXT NOT NULL, destFolderDocId TEXT NOT NULL, destFolderName TEXT NOT NULL, fileCount INTEGER NOT NULL, totalBytes INTEGER NOT NULL, verifiedOk INTEGER NOT NULL, integritySummaryHe TEXT NOT NULL, manifestJson TEXT NOT NULL)")
            }

            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
          }
        )
        .build()

    helperFactory.create(helperConfig).writableDatabase.use { v3Db ->
      v3Db.execSQL(
        "INSERT INTO automations (name, voicePhrase, description, stepsSerialized, isBuiltIn, scheduleIntervalHours) VALUES ('שגרת בוקר שמורה', 'בוקר טוב', 'תיאור', 'SYSTEM_SCAN', 0, 12)"
      )
      v3Db.execSQL(
        "INSERT INTO assistant_messages (timestampMillis, isUser, text, actionTag) VALUES (1000, 1, 'היסטוריית שיחה קודמת', NULL)"
      )
    }

    val migratedDb =
      Room.databaseBuilder(context, NexusDatabase::class.java, dbName)
        .addMigrations(
          NexusDatabase.MIGRATION_1_2,
          NexusDatabase.MIGRATION_2_3,
          NexusDatabase.MIGRATION_3_4,
          NexusDatabase.MIGRATION_4_5
        )
        .allowMainThreadQueries()
        .build()

    try {
      val preservedAutomations = migratedDb.automationDao().getAllOnce()
      assertEquals(1, preservedAutomations.size)
      assertEquals("שגרת בוקר שמורה", preservedAutomations.first().name)
      assertEquals(12, preservedAutomations.first().scheduleIntervalHours)

      val preservedMessages = migratedDb.assistantMessageDao().getRecentOnce(10)
      assertEquals(1, preservedMessages.size)
      assertEquals("היסטוריית שיחה קודמת", preservedMessages.first().text)

      // Write into new v4 tables to ensure schema matches entity definitions 1:1
      val memManager = NexusMemoryManager(migratedDb.memoryEntryDao())
      val saved = memManager.saveMemory(NexusMemoryType.PROJECT, "בדיקת שדרוג", "נשמר אחרי מיגרציה")
      assertTrue(saved is MemorySaveResult.Saved)

      val reminderId =
        migratedDb.reminderAlertDao().insert(
          ReminderAlertEntity(
            title = "בדיקת גיבוי",
            message = "לבדוק SD",
            kind = "REMINDER",
            status = "ACTIVE",
            createdAtMillis = 5000L
          )
        )
      assertTrue(reminderId > 0L)
      assertEquals(1, migratedDb.reminderAlertDao().getActiveOnce().size)
    } finally {
      migratedDb.close()
      context.deleteDatabase(dbName)
    }
  }

  @Test
  fun `memory manager persists entries across database reopen and rejects secrets`() = runBlocking {
    val dbName = "memory_persist_test_${System.nanoTime()}.db"
    context.deleteDatabase(dbName)

    val db1 =
      Room.databaseBuilder(context, NexusDatabase::class.java, dbName)
        .addMigrations(
          NexusDatabase.MIGRATION_1_2,
          NexusDatabase.MIGRATION_2_3,
          NexusDatabase.MIGRATION_3_4,
          NexusDatabase.MIGRATION_4_5
        )
        .allowMainThreadQueries()
        .build()
    val mgr1 = NexusMemoryManager(db1.memoryEntryDao())

    val blocked = mgr1.saveMemory(NexusMemoryType.LONG_TERM, "סיסמה", "password=MyTopSecretPass123")
    assertTrue(blocked is MemorySaveResult.BlockedSecret)

    val ok = mgr1.saveMemory(NexusMemoryType.PREFERENCE, "שפה", "תמיד בעברית עם המלצות מעשיות")
    assertTrue(ok is MemorySaveResult.Saved)
    db1.close()

    val db2 =
      Room.databaseBuilder(context, NexusDatabase::class.java, dbName)
        .addMigrations(
          NexusDatabase.MIGRATION_1_2,
          NexusDatabase.MIGRATION_2_3,
          NexusDatabase.MIGRATION_3_4,
          NexusDatabase.MIGRATION_4_5
        )
        .allowMainThreadQueries()
        .build()
    try {
      val mgr2 = NexusMemoryManager(db2.memoryEntryDao())
      val promptCtx = mgr2.buildContextForPrompt()
      assertTrue(promptCtx.contains("תמיד בעברית עם המלצות מעשיות"))
      assertFalse(promptCtx.contains("MyTopSecretPass123"))
    } finally {
      db2.close()
      context.deleteDatabase(dbName)
    }
  }

  @Test
  fun `learning engine records tool failures feedback and reversible undo`() = runBlocking {
    val engine = NexusLearningEngine(memDb.learningRecordDao(), memDb.toolUsageDao())
    repeat(3) {
      engine.recordToolRun("smart_storage", "מנהל אחסון", false, 45L, "no saf", "אין גישת SAF")
    }
    engine.recordAssistantFeedback("בדיקת סוללה", positive = true, providerLabel = "Gemini")
    engine.recordAssistantFeedback("תשובה ארוכה", positive = false, providerLabel = "Gemini")

    val beforeUndo = engine.computeInsights()
    assertEquals(1, beforeUndo.degradedTools.size)
    assertEquals(1, beforeUndo.positiveFeedbackCount)
    assertEquals(1, beforeUndo.negativeFeedbackCount)

    val negRec = memDb.learningRecordDao().getRecentOnce().first { it.userRating < 0 }
    assertTrue(engine.undoLearningChange(negRec.id))

    val afterUndo = engine.computeInsights()
    assertEquals(0, afterUndo.negativeFeedbackCount)
  }

  @Test
  fun `orchestrator recovers running task on restart and prevents silent data loss`() = runBlocking {
    val dao = memDb.orchestratorTaskDao()
    val id =
      dao.insert(
        OrchestratorTaskEntity(
          goal = "סריקת מערכת מלאה",
          status = OrchestratorTaskStatus.RUNNING.name,
          progressPercent = 40,
          currentAgent = "RESEARCHER",
          currentStepLabel = "אוסף נתונים",
          stepsJson = "[]",
          requiresNetwork = false,
          createdAtMillis = 1000L,
          updatedAtMillis = 1000L
        )
      )

    // Emulate NexusOrchestratorEngine.recoverInterruptedTasks behavior directly on active tasks
    val stuck = dao.getActiveOnce()
    assertEquals(1, stuck.size)
    stuck.forEach { task ->
      dao.update(task.copy(status = OrchestratorTaskStatus.PAUSED.name))
    }

    val recovered = dao.getById(id)
    assertNotNull(recovered)
    assertEquals(OrchestratorTaskStatus.PAUSED.name, recovered!!.status)
  }

  @Test
  fun `tool registry accurately reflects offline and permission states`() {
    val telemetry =
      SystemTelemetry(
        battery = com.example.data.model.BatteryTelemetry(80, false, "סוללה", 30f, 3900, "תקין", "Li-ion", false, false, null),
        ram = com.example.data.model.RamTelemetry(4_000_000_000L, 2_000_000_000L, 2_000_000_000L, 50, false),
        storage = com.example.data.model.StorageTelemetry(64_000_000_000L, 20_000_000_000L, 44_000_000_000L, 68, 1_000_000_000L),
        network = com.example.data.model.NetworkTelemetry(false, "לא מחובר", false, 0, 0, null, null),
        device = com.example.data.model.DeviceIdentity("Samsung", "SM-T545", "10", 29, "2023-01-01", 10000L, true, false, true),
        healthScore = 85,
        healthStatusLabel = "תקין",
        issues = emptyList(),
        hasUsageAccessPermission = false,
        authorizedFolderCount = 0,
        capturedAtMillis = 1000L
      )
    val statuses =
      NexusToolRegistry.inspectTools(
        context = context,
        telemetry = telemetry,
        safFoldersCount = 0,
        cloudAiEnabled = true,
        usageLogs = emptyList()
      )
    assertEquals(9, statuses.size)
    val storageTool = statuses.first { it.definition.id == "smart_storage" }
    assertEquals(NexusToolHealthState.PERMISSION_NEEDED, storageTool.healthState)

    val cloudTool = statuses.first { it.definition.id == "cloud_gemini_ai" }
    assertEquals(NexusToolHealthState.OFFLINE_LIMITED, cloudTool.healthState)
  }

  @Test
  fun `orchestrator step serialization roundtrips accurately on Android org json`() {
    val steps =
      com.example.data.orchestrator.OrchestratorPlanner.decomposeGoal(
        "אבחון טאבלט מלא",
        isOnline = false,
        cloudAiEnabled = false
      )
    val modified =
      steps.mapIndexed { idx, s ->
        if (idx == 0) s.copy(status = com.example.data.orchestrator.OrchestratorStepStatus.SUCCEEDED, outputHe = "אושר")
        else s
      }
    val json = com.example.data.orchestrator.OrchestratorSerialization.encodeSteps(modified)
    val decoded = com.example.data.orchestrator.OrchestratorSerialization.decodeSteps(json)
    assertEquals(modified.size, decoded.size)
    assertEquals(com.example.data.orchestrator.OrchestratorStepStatus.SUCCEEDED, decoded[0].status)
    assertEquals("אושר", decoded[0].outputHe)
  }
}
