package com.example

import android.content.Context
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.data.ai.AikoBrainEngine
import com.example.data.ai.AikoLocalResult
import com.example.data.ai.LifeItemKind
import com.example.data.ai.LifeItemPriority
import com.example.data.backup.NexusBackupManager
import com.example.data.local.AutomationEntity
import com.example.data.local.LifeItemEntity
import com.example.data.local.ManagedAccountEntity
import com.example.data.local.NexusDatabase
import com.example.data.local.PreferencesManager
import com.example.data.model.AssistantActionType
import com.example.data.model.AutomationStepType
import com.example.data.model.FileCategory
import com.example.data.model.ScannedFileEntry
import com.example.data.model.StorageVolumeKind
import com.example.data.system.ZipSecurityGuard
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MasterUpgradeTests {

  private lateinit var context: Context
  private lateinit var db: NexusDatabase

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    db =
      Room.inMemoryDatabaseBuilder(context, NexusDatabase::class.java)
        .allowMainThreadQueries()
        .build()
  }

  @After
  fun tearDown() {
    db.close()
  }

  @Test
  fun `room migration 4 to 5 preserves v4 rows and enables lifeItems and managedAccounts CRUD`() = runBlocking {
    val dbName = "migration_v4_v5_test_${System.nanoTime()}.db"
    context.deleteDatabase(dbName)

    val helperFactory = FrameworkSQLiteOpenHelperFactory()
    val helperConfig =
      SupportSQLiteOpenHelper.Configuration.builder(context)
        .name(dbName)
        .callback(
          object : SupportSQLiteOpenHelper.Callback(4) {
            override fun onCreate(sDb: SupportSQLiteDatabase) {
              sDb.execSQL("CREATE TABLE IF NOT EXISTS clean_history (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, timestampMillis INTEGER NOT NULL, itemsDeleted INTEGER NOT NULL, itemsFailed INTEGER NOT NULL, bytesFreed INTEGER NOT NULL, freeBeforeBytes INTEGER NOT NULL, freeAfterBytes INTEGER NOT NULL, summary TEXT NOT NULL, failureReason TEXT)")
              sDb.execSQL("CREATE TABLE IF NOT EXISTS telemetry_snapshots (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, timestampMillis INTEGER NOT NULL, batteryPercent INTEGER NOT NULL, batteryTempC REAL NOT NULL, batteryVoltageMv INTEGER NOT NULL, ramUsedPercent INTEGER NOT NULL, storageUsedPercent INTEGER NOT NULL, storageFreeBytes INTEGER NOT NULL, healthScore INTEGER NOT NULL)")
              sDb.execSQL("CREATE TABLE IF NOT EXISTS assistant_messages (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, timestampMillis INTEGER NOT NULL, isUser INTEGER NOT NULL, text TEXT NOT NULL, actionTag TEXT)")
              sDb.execSQL("CREATE TABLE IF NOT EXISTS automations (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, voicePhrase TEXT NOT NULL, description TEXT NOT NULL, stepsSerialized TEXT NOT NULL, isBuiltIn INTEGER NOT NULL, lastRunMillis INTEGER, scheduleIntervalHours INTEGER NOT NULL DEFAULT 0)")
              sDb.execSQL("CREATE TABLE IF NOT EXISTS action_audit (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, timestampMillis INTEGER NOT NULL, category TEXT NOT NULL, actionTitle TEXT NOT NULL, succeeded INTEGER NOT NULL, details TEXT NOT NULL, failureReason TEXT)")
              sDb.execSQL("CREATE TABLE IF NOT EXISTS approval_proposals (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, createdAtMillis INTEGER NOT NULL, title TEXT NOT NULL, reasonHe TEXT NOT NULL, targetName TEXT NOT NULL, targetLocation TEXT NOT NULL, operationType TEXT NOT NULL, riskLevel TEXT NOT NULL, isReversible INTEGER NOT NULL, expectedOutcomeHe TEXT NOT NULL, sourceUriString TEXT, treeUriString TEXT, destTreeUriString TEXT, destFolderName TEXT, proposedNewName TEXT, packageName TEXT, bytesAffected INTEGER NOT NULL, status TEXT NOT NULL, resultMessageHe TEXT)")
              sDb.execSQL("CREATE TABLE IF NOT EXISTS undo_records (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, createdAtMillis INTEGER NOT NULL, actionTitle TEXT NOT NULL, undoType TEXT NOT NULL, targetUriString TEXT, originalParentDocId TEXT, originalTreeUriString TEXT, previousName TEXT, backupManifestId INTEGER, isUndoable INTEGER NOT NULL, undone INTEGER NOT NULL, noteHe TEXT NOT NULL)")
              sDb.execSQL("CREATE TABLE IF NOT EXISTS backup_records (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, createdAtMillis INTEGER NOT NULL, sourceLabel TEXT NOT NULL, sourceTreeUri TEXT NOT NULL, destTreeUri TEXT NOT NULL, destFolderDocId TEXT NOT NULL, destFolderName TEXT NOT NULL, fileCount INTEGER NOT NULL, totalBytes INTEGER NOT NULL, verifiedOk INTEGER NOT NULL, integritySummaryHe TEXT NOT NULL, manifestJson TEXT NOT NULL)")
              sDb.execSQL("CREATE TABLE IF NOT EXISTS memory_entries (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, memoryType TEXT NOT NULL, title TEXT NOT NULL, content TEXT NOT NULL, categoryTag TEXT NOT NULL, canPersist INTEGER NOT NULL, importanceScore INTEGER NOT NULL, createdAtMillis INTEGER NOT NULL, updatedAtMillis INTEGER NOT NULL, lastAccessedMillis INTEGER NOT NULL)")
              sDb.execSQL("CREATE TABLE IF NOT EXISTS orchestrator_tasks (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, goal TEXT NOT NULL, status TEXT NOT NULL, progressPercent INTEGER NOT NULL, currentAgent TEXT NOT NULL, currentStepLabel TEXT NOT NULL, stepsJson TEXT NOT NULL, resultSummary TEXT, errorMessage TEXT, requiresNetwork INTEGER NOT NULL, createdAtMillis INTEGER NOT NULL, updatedAtMillis INTEGER NOT NULL)")
              sDb.execSQL("CREATE TABLE IF NOT EXISTS learning_records (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, category TEXT NOT NULL, targetKey TEXT NOT NULL, summaryHe TEXT NOT NULL, succeeded INTEGER NOT NULL, userRating INTEGER NOT NULL, reversiblePatchJson TEXT, undone INTEGER NOT NULL, createdAtMillis INTEGER NOT NULL)")
              sDb.execSQL("CREATE TABLE IF NOT EXISTS tool_usage (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, toolId TEXT NOT NULL, toolNameHe TEXT NOT NULL, succeeded INTEGER NOT NULL, latencyMs INTEGER NOT NULL, summaryHe TEXT NOT NULL, errorHe TEXT, timestampMillis INTEGER NOT NULL)")
              sDb.execSQL("CREATE TABLE IF NOT EXISTS reminder_alerts (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, title TEXT NOT NULL, message TEXT NOT NULL, kind TEXT NOT NULL, triggerAtMillis INTEGER, repeatIntervalHours INTEGER NOT NULL, conditionKey TEXT NOT NULL, status TEXT NOT NULL, targetRoute TEXT NOT NULL, createdAtMillis INTEGER NOT NULL, lastTriggeredMillis INTEGER)")
            }

            override fun onUpgrade(sDb: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
          }
        )
        .build()

    helperFactory.create(helperConfig).writableDatabase.use { v4Db ->
      v4Db.execSQL(
        "INSERT INTO memory_entries (memoryType, title, content, categoryTag, canPersist, importanceScore, createdAtMillis, updatedAtMillis, lastAccessedMillis) VALUES ('PREFERENCE', 'שמירת היסטוריה', 'לשמור תמיד העדפות v4', 'העדפה', 1, 90, 1000, 1000, 1000)"
      )
    }

    val migrated =
      Room.databaseBuilder(context, NexusDatabase::class.java, dbName)
        .addMigrations(
          NexusDatabase.MIGRATION_1_2,
          NexusDatabase.MIGRATION_2_3,
          NexusDatabase.MIGRATION_3_4,
          NexusDatabase.MIGRATION_4_5
        )
        .allowMainThreadQueries()
        .build()

    try {
      val preservedMem = migrated.memoryEntryDao().getAllOnce()
      assertEquals(1, preservedMem.size)
      assertEquals("שמירת היסטוריה", preservedMem.first().title)

      val lifeId =
        migrated.lifeItemDao().insert(
          LifeItemEntity(
            kind = LifeItemKind.GOAL.name,
            title = "סיום פרויקט NEXUS",
            details = "אימות סופי",
            categoryTag = "עבודה",
            priority = LifeItemPriority.HIGH.name,
            progressPercent = 40,
            createdAtMillis = 2000L,
            updatedAtMillis = 2000L
          )
        )
      assertTrue(lifeId > 0L)
      migrated.lifeItemDao().setCompleted(lifeId, true, 100, 3000L)
      val loadedLife = migrated.lifeItemDao().getById(lifeId)
      assertNotNull(loadedLife)
      assertTrue(loadedLife!!.isCompleted)
      assertEquals(100, loadedLife.progressPercent)

      val accId =
        migrated.managedAccountDao().insert(
          ManagedAccountEntity(
            serviceName = "Google Drive",
            category = "ענן",
            accountLabel = "אחסון טאבלט",
            webUrl = "https://drive.google.com",
            reviewIntervalDays = 90,
            createdAtMillis = 4000L
          )
        )
      assertTrue(accId > 0L)
      migrated.managedAccountDao().markReviewed(accId, 5000L)
      migrated.managedAccountDao().updateConnectivityStatus(accId, 5500L, "זמין (HTTP 200)")
      val loadedAcc = migrated.managedAccountDao().getById(accId)
      assertNotNull(loadedAcc)
      assertEquals(5000L, loadedAcc!!.lastReviewedAtMillis)
      assertEquals("זמין (HTTP 200)", loadedAcc.lastConnectivityStatusHe)
    } finally {
      migrated.close()
      context.deleteDatabase(dbName)
    }
  }

  @Test
  fun `aiko brain handles natural hebrew life items, automations, clarification, and guardrails`() {
    val existingOpen =
      listOf(
        LifeItemEntity(
          id = 1L,
          kind = LifeItemKind.SHOPPING.name,
          title = "כבל USB-C",
          createdAtMillis = 100L,
          updatedAtMillis = 100L
        )
      )

    val addRes =
      AikoBrainEngine.interpret(
        rawInput = "תזכור לי לקנות מטען מהיר דחוף",
        lifeItems = existingOpen,
        telemetry = null,
        apps = emptyList(),
        securityReport = null,
        customAutomations = emptyList()
      )
    assertTrue(addRes is AikoLocalResult.AddLifeItem)
    val addedDraft = (addRes as AikoLocalResult.AddLifeItem).draft
    assertEquals(LifeItemKind.REMINDER, addedDraft.itemType)
    assertEquals(LifeItemPriority.URGENT, addedDraft.priority)
    assertTrue(addedDraft.title.contains("מטען"))

    val completeRes =
      AikoBrainEngine.interpret(
        rawInput = "סיימתי כבל USB-C",
        lifeItems = existingOpen,
        telemetry = null,
        apps = emptyList(),
        securityReport = null,
        customAutomations = emptyList()
      )
    assertTrue(completeRes is AikoLocalResult.CompleteLifeItem)
    assertEquals("כבל USB-C", (completeRes as AikoLocalResult.CompleteLifeItem).matchQuery)

    val nlAutoRes =
      AikoBrainEngine.interpret(
        rawInput = "כל ערב תבדוק סוללה וטמפרטורה ותכין דוח",
        lifeItems = existingOpen,
        telemetry = null,
        apps = emptyList(),
        securityReport = null,
        customAutomations = emptyList()
      )
    assertTrue(nlAutoRes is AikoLocalResult.ProposeAutomation)
    val autoProp = (nlAutoRes as AikoLocalResult.ProposeAutomation).proposal
    assertTrue(autoProp.isFeasible)
    assertEquals(24, autoProp.scheduleIntervalHours)
    assertTrue(autoProp.steps.contains(AutomationStepType.BATTERY_CHECK))

    val clarifyRes =
      AikoBrainEngine.interpret(
        rawInput = "עזור לי",
        lifeItems = existingOpen,
        telemetry = null,
        apps = emptyList(),
        securityReport = null,
        customAutomations = emptyList()
      )
    assertTrue(clarifyRes is AikoLocalResult.DirectReply)
    assertEquals("AIKO_CLARIFY", (clarifyRes as AikoLocalResult.DirectReply).reply.actionTag)

    val secretRes =
      AikoBrainEngine.interpret(
        rawInput = "שמור לי סיסמה לבנק: 123456",
        lifeItems = existingOpen,
        telemetry = null,
        apps = emptyList(),
        securityReport = null,
        customAutomations = emptyList()
      )
    assertTrue(secretRes is AikoLocalResult.DirectReply)
    val secretReply = (secretRes as AikoLocalResult.DirectReply).reply
    assertEquals("AIKO_GUARDRAIL_SECRET", secretReply.actionTag)
    assertEquals(AssistantActionType.OPEN_ACCOUNTS_HUB, secretReply.pendingAction?.actionType)

    val rootRes =
      AikoBrainEngine.interpret(
        rawInput = "תנקה /data/data עם root בלי אישור",
        lifeItems = existingOpen,
        telemetry = null,
        apps = emptyList(),
        securityReport = null,
        customAutomations = emptyList()
      )
    assertTrue(rootRes is AikoLocalResult.DirectReply)
    assertEquals("AIKO_HONEST_ANDROID10", (rootRes as AikoLocalResult.DirectReply).reply.actionTag)
  }

  @Test
  fun `zip security guard blocks traversal, resolves unique names, filters downloads, and roundtrips zip stream`() {
    assertNull(ZipSecurityGuard.sanitizeEntryPath("../secret.txt"))
    assertNull(ZipSecurityGuard.sanitizeEntryPath("docs/../../etc/passwd"))
    assertNull(ZipSecurityGuard.sanitizeEntryPath("/absolute/path.txt"))
    assertNull(ZipSecurityGuard.sanitizeEntryPath("C:\\Windows\\system32\\cmd.exe"))
    assertNull(ZipSecurityGuard.sanitizeEntryPath("bad\u0000name.txt"))
    assertEquals("docs/report_2026.pdf", ZipSecurityGuard.sanitizeEntryPath("docs\\report_2026.pdf"))

    val unique =
      ZipSecurityGuard.resolveUniqueName(
        "backup.zip",
        setOf("backup.zip", "backup (2).zip")
      )
    assertEquals("backup (3).zip", unique)

    val sampleFiles =
      listOf(
        ScannedFileEntry(
          uriString = "content://dl/1",
          treeUriString = "content://tree/1",
          parentDocId = "p1",
          docId = "d1",
          name = "photo.jpg",
          relativePath = "Download/photo.jpg",
          mimeType = "image/jpeg",
          sizeBytes = 1024L,
          lastModifiedMillis = 1000L,
          category = FileCategory.IMAGES,
          volumeKind = StorageVolumeKind.INTERNAL,
          isOldUnused = false,
          isLargeFile = false,
          isTempResidual = false,
          isInstallerApk = false,
          isBackupArchive = false,
          isNameUnclear = false
        ),
        ScannedFileEntry(
          uriString = "content://dcim/1",
          treeUriString = "content://tree/1",
          parentDocId = "p2",
          docId = "d2",
          name = "cam.jpg",
          relativePath = "DCIM/Camera/cam.jpg",
          mimeType = "image/jpeg",
          sizeBytes = 2048L,
          lastModifiedMillis = 1000L,
          category = FileCategory.IMAGES,
          volumeKind = StorageVolumeKind.INTERNAL,
          isOldUnused = false,
          isLargeFile = false,
          isTempResidual = false,
          isInstallerApk = false,
          isBackupArchive = false,
          isNameUnclear = false
        )
      )
    val downloadsOnly = ZipSecurityGuard.filterDownloads(sampleFiles)
    assertEquals(1, downloadsOnly.size)
    assertEquals("photo.jpg", downloadsOnly.first().name)

    // Real streaming ZIP roundtrip validating sanitized extraction
    val zipOutBytes = ByteArrayOutputStream()
    ZipOutputStream(zipOutBytes).use { zos ->
      zos.putNextEntry(ZipEntry("safe/notes.txt"))
      zos.write("שלום טאבלט SM-T545".toByteArray(Charsets.UTF_8))
      zos.closeEntry()
      zos.putNextEntry(ZipEntry("../../evil.txt"))
      zos.write("blocked".toByteArray(Charsets.UTF_8))
      zos.closeEntry()
    }
    val extracted = mutableMapOf<String, String>()
    var rejected = 0
    ZipInputStream(ByteArrayInputStream(zipOutBytes.toByteArray())).use { zis ->
      var entry = zis.nextEntry
      while (entry != null) {
        val safePath = ZipSecurityGuard.sanitizeEntryPath(entry.name)
        if (safePath == null) {
          rejected++
        } else {
          extracted[safePath] = zis.readBytes().toString(Charsets.UTF_8)
        }
        zis.closeEntry()
        entry = zis.nextEntry
      }
    }
    assertEquals(1, rejected)
    assertEquals("שלום טאבלט SM-T545", extracted["safe/notes.txt"])
  }

  @Test
  fun `backup manager v3 supports merge vs replace and blocks secret items`() = runBlocking {
    val prefs = PreferencesManager(context)
    prefs.clearAll()
    val mgr = NexusBackupManager(db, prefs)

    val now = System.currentTimeMillis()
    db.automationDao().insert(
      AutomationEntity(
        name = "בדיקת ענן ראשונה",
        voicePhrase = "בדיקת ענן",
        description = "סריקה",
        stepsSerialized = "SYSTEM_SCAN",
        isBuiltIn = false,
        scheduleIntervalHours = 24
      )
    )
    db.lifeItemDao().insert(
      LifeItemEntity(
        kind = LifeItemKind.TASK.name,
        title = "לגבות תמונות",
        details = "בבטחה ל-SD",
        createdAtMillis = now,
        updatedAtMillis = now
      )
    )
    db.managedAccountDao().insert(
      ManagedAccountEntity(
        serviceName = "Nextcloud",
        category = "ענן",
        accountLabel = "אחסון פרטי",
        webUrl = "https://cloud.example.org",
        createdAtMillis = now
      )
    )

    val exportedJson = mgr.exportJsonBackup()
    assertTrue(exportedJson.contains("\"version\": 3"))
    assertTrue(exportedJson.contains("לגבות תמונות"))
    assertTrue(exportedJson.contains("Nextcloud"))

    // Add a local item after export, then test MERGE (replaceExisting = false)
    db.lifeItemDao().insert(
      LifeItemEntity(
        kind = LifeItemKind.NOTE.name,
        title = "פתק מקומי חדש",
        createdAtMillis = now + 10,
        updatedAtMillis = now + 10
      )
    )
    val mergeRes = mgr.restoreFromJson(exportedJson, replaceExisting = false)
    assertTrue(mergeRes.isSuccess)
    assertEquals(2, db.lifeItemDao().getAllOnce().size)

    // Test REPLACE (replaceExisting = true): removes post-export note and restores snapshot items
    val replaceRes = mgr.restoreFromJson(exportedJson, replaceExisting = true)
    assertTrue(replaceRes.isSuccess)
    val afterReplaceLife = db.lifeItemDao().getAllOnce()
    assertEquals(1, afterReplaceLife.size)
    assertEquals("לגבות תמונות", afterReplaceLife.first().title)

    // Verify secret filtering on malicious/unsafe JSON backup entry
    val tamperedJson =
      exportedJson.replace("לגבות תמונות", "password=SuperSecretLeak123")
    mgr.restoreFromJson(tamperedJson, replaceExisting = true)
    assertTrue(db.lifeItemDao().getAllOnce().isEmpty())
  }

  @Test
  fun `preferences manager defaults to dark premium theme`() = runBlocking {
    val prefs = PreferencesManager(context)
    prefs.clearAll()
    assertTrue(prefs.darkThemeEnabledFlow.first())
  }
}
