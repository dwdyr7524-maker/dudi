package com.example

import android.Manifest
import android.app.Application
import android.content.pm.ProviderInfo
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.DocumentsProvider
import android.util.Log
import androidx.test.core.app.ApplicationProvider
import androidx.work.Configuration
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.example.data.ai.AikoBrainEngine
import com.example.data.ai.AikoRequestedOperation
import com.example.data.ai.NexusAikoToolEngine
import com.example.data.local.ApprovalProposalEntity
import com.example.data.local.AutomationEntity
import com.example.data.local.NexusDatabase
import com.example.data.model.ApprovalOperationType
import com.example.data.model.FileCategory
import com.example.data.model.FolderStorageSummary
import com.example.data.model.ScannedFileEntry
import com.example.data.model.SmartStorageScanReport
import com.example.data.model.StorageVolumeInfo
import com.example.data.model.StorageVolumeKind
import com.example.data.system.SmartStorageEngine
import com.example.data.system.StorageClassificationMath
import com.example.data.worker.NexusWorkScheduler
import com.example.ui.viewmodel.CommanderDelegate
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Phase1DeviceActionEngineTests {

  companion object {
    const val TEST_DOCS_AUTHORITY = "com.example.phase1.testdocs"
  }

  private lateinit var app: NexusApp
  private lateinit var provider: InMemorySafDocumentsProvider
  private lateinit var smartStorageEngine: SmartStorageEngine
  private lateinit var commanderDelegate: CommanderDelegate
  private lateinit var db: NexusDatabase

  @Before
  fun setUp() {
    app = ApplicationProvider.getApplicationContext<Application>() as NexusApp
    Shadows.shadowOf(app).grantPermissions(Manifest.permission.MANAGE_DOCUMENTS)

    val info =
      ProviderInfo().apply {
        authority = TEST_DOCS_AUTHORITY
        exported = true
        grantUriPermissions = true
        readPermission = Manifest.permission.MANAGE_DOCUMENTS
        writePermission = Manifest.permission.MANAGE_DOCUMENTS
      }
    provider =
      Robolectric.buildContentProvider(InMemorySafDocumentsProvider::class.java)
        .create(info)
        .get()

    if (!WorkManager.isInitialized()) {
      WorkManager.initialize(
        app,
        Configuration.Builder().setMinimumLoggingLevel(Log.DEBUG).build()
      )
    }

    db = app.database
    smartStorageEngine = app.smartStorageEngine
    commanderDelegate = CommanderDelegate(app)
  }

  @After
  fun tearDown() {
    runBlocking {
      app.preferencesManager.clearAll()
      db.approvalProposalDao().clearPending()
    }
    provider.cleanupTempDir()
  }

  @Test
  fun `saf subfolder copy move sha256 verification non-overwrite and exact MOVE_BACK undo work end-to-end`() =
    runBlocking {
      val internalRootId = "primary:NEXUS_Root"
      val photosDirId = "primary:NEXUS_Root/Photos"
      val archiveDirId = "primary:NEXUS_Root/Archive"
      val sdRootId = "1A2B-3C4D:SD_Root"

      provider.resetWithTrees(
        roots = listOf(internalRootId, sdRootId),
        backingDir = File(app.cacheDir, "saf_test_${System.nanoTime()}").apply { mkdirs() }
      )
      provider.addDirectory(internalRootId, photosDirId, "Photos")
      provider.addDirectory(internalRootId, archiveDirId, "Archive")

      val jpegBytes = ByteArray(8192) { idx -> ((idx * 31) and 0xFF).toByte() }
      val vacationDocId =
        provider.addFile(
          parentId = photosDirId,
          docId = "$photosDirId/vacation.jpg",
          displayName = "vacation.jpg",
          mimeType = "application/octet-stream", // Intentionally generic in provider to test real MIME resolution
          content = jpegBytes
        )

      val internalTreeUri = DocumentsContract.buildTreeDocumentUri(TEST_DOCS_AUTHORITY, internalRootId)
      val sdTreeUri = DocumentsContract.buildTreeDocumentUri(TEST_DOCS_AUTHORITY, sdRootId)
      val vacationUri = DocumentsContract.buildDocumentUriUsingTree(internalTreeUri, vacationDocId)

      app.preferencesManager.addSafTreeUri(internalTreeUri.toString())
      app.preferencesManager.addSafTreeUri(sdTreeUri.toString())

      // 1. Real parentDocId resolution inside subfolder (must NOT return rootDocId)
      val resolvedParent = smartStorageEngine.resolveParentDocId(internalTreeUri, vacationUri)
      assertEquals(photosDirId, resolvedParent)

      // 2. Real MIME resolution by extension instead of application/octet-stream
      val resolvedMime =
        smartStorageEngine.resolveMimeType(
          docUri = vacationUri,
          fileName = "vacation.jpg",
          explicitMime = "application/octet-stream"
        )
      assertEquals("image/jpeg", resolvedMime)

      // 3. Verified copy into Archive subfolder + Non-overwrite protection
      val copyRes =
        smartStorageEngine.copySafDocumentVerified(
          sourceDocUri = vacationUri,
          destTreeUri = internalTreeUri,
          destParentDocId = archiveDirId,
          targetName = "vacation.jpg",
          mimeType = resolvedMime,
          allowOverwrite = false
        )
      assertNotNull("Copy into Archive subfolder should succeed", copyRes.uri)
      assertEquals("image/jpeg", copyRes.usedMimeType)
      assertEquals(jpegBytes.sha256Hex(), copyRes.verifiedSha256)
      assertTrue("Source file must still exist after copy", provider.exists(vacationDocId))

      val secondCopyBlocked =
        smartStorageEngine.copySafDocumentVerified(
          sourceDocUri = vacationUri,
          destTreeUri = internalTreeUri,
          destParentDocId = archiveDirId,
          targetName = "vacation.jpg",
          mimeType = resolvedMime,
          allowOverwrite = false
        )
      assertNull("Duplicate copy without allowOverwrite must be blocked", secondCopyBlocked.uri)
      assertTrue(secondCopyBlocked.errorReasonHe.orEmpty().contains("קיים"))

      // 4. Cross-volume Move (Internal Photos subfolder -> SD Card) via CommanderDelegate + Exact MOVE_BACK Undo
      val moveProposal =
        ApprovalProposalEntity(
          createdAtMillis = System.currentTimeMillis(),
          title = "העברת vacation.jpg לכרטיס SD",
          reasonHe = "בדיקת העברה בין נפחים",
          targetName = "vacation.jpg",
          targetLocation = "NEXUS_Root/Photos/vacation.jpg",
          operationType = ApprovalOperationType.MOVE_SAF_DOCUMENT.name,
          riskLevel = "MEDIUM",
          isReversible = true,
          expectedOutcomeHe = "יועבר לשורש SD",
          sourceUriString = vacationUri.toString(),
          treeUriString = internalTreeUri.toString(),
          destTreeUriString = sdTreeUri.toString(),
          destFolderName = ".",
          bytesAffected = jpegBytes.size.toLong(),
          status = "PENDING"
        )
      val insertedMoveId = db.approvalProposalDao().insert(moveProposal)
      val savedMoveProposal = db.approvalProposalDao().getById(insertedMoveId)!!

      val (moveOk, moveMsg) = commanderDelegate.approveAndExecuteProposal(savedMoveProposal)
      assertTrue("Move to SD failed: $moveMsg", moveOk)
      assertFalse("Source in Photos must be removed only after verified SD copy", provider.exists(vacationDocId))
      val sdCopyId = provider.findChildDocId(sdRootId, "vacation.jpg")
      assertNotNull("Moved file must exist on SD volume", sdCopyId)
      assertEquals(jpegBytes.sha256Hex(), provider.readBytes(sdCopyId!!).sha256Hex())
      assertEquals("image/jpeg", provider.getMime(sdCopyId))

      // Verify Undo record captured exact subfolder parentDocId (Photos, NOT internal root!)
      val undoRecords = db.undoRecordDao().observeUndoRecords().first()
      val moveBackUndo = undoRecords.firstOrNull { it.undoType == "MOVE_BACK" && !it.undone }
      assertNotNull("MOVE_BACK undo record must be recorded", moveBackUndo)
      assertEquals(photosDirId, moveBackUndo!!.originalParentDocId)

      // Execute Undo and verify restoration into exact Photos subfolder
      val (undoOk, undoMsg) = commanderDelegate.executeUndo(moveBackUndo)
      assertTrue("Undo MOVE_BACK failed: $undoMsg", undoOk)
      assertNull("File on SD should be removed after Undo", provider.findChildDocId(sdRootId, "vacation.jpg"))
      val restoredInPhotosId = provider.findChildDocId(photosDirId, "vacation.jpg")
      assertNotNull("File must be restored back inside Photos subfolder, not root", restoredInPhotosId)
      assertNull("File should not be dumped in internal root", provider.findChildDocId(internalRootId, "vacation.jpg"))
      assertEquals(jpegBytes.sha256Hex(), provider.readBytes(restoredInPhotosId!!).sha256Hex())
    }

  @Test
  fun `moveSafDocumentVerified keeps source untouched when destination write fails`() {
    val internalRootId = "primary:NEXUS_FailTest"
    val lockedDirId = "primary:NEXUS_FailTest/ReadOnly"
    provider.resetWithTrees(
      roots = listOf(internalRootId),
      backingDir = File(app.cacheDir, "saf_fail_${System.nanoTime()}").apply { mkdirs() }
    )
    provider.addDirectory(internalRootId, lockedDirId, "ReadOnly")
    provider.failWriteParentDocIds.add(lockedDirId)

    val origBytes = "critical-document-payload".toByteArray()
    val srcDocId =
      provider.addFile(
        parentId = internalRootId,
        docId = "$internalRootId/contract.pdf",
        displayName = "contract.pdf",
        mimeType = "application/pdf",
        content = origBytes
      )
    val treeUri = DocumentsContract.buildTreeDocumentUri(TEST_DOCS_AUTHORITY, internalRootId)
    val srcUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, srcDocId)

    val moveRes =
      smartStorageEngine.moveSafDocumentVerified(
        sourceDocUri = srcUri,
        sourceParentDocId = internalRootId,
        sourceTreeUri = treeUri,
        destTreeUri = treeUri,
        destParentDocId = lockedDirId,
        targetName = "contract.pdf",
        mimeType = "application/pdf",
        allowOverwrite = false
      )

    assertNull("Failed transfer must return null uri", moveRes.uri)
    assertNotNull("Failure should explain error in Hebrew", moveRes.errorReasonHe)
    assertTrue("Source must never be deleted when destination copy fails", provider.exists(srcDocId))
    assertEquals(origBytes.sha256Hex(), provider.readBytes(srcDocId).sha256Hex())
  }

  @Test
  fun `aiko parameterized file engine parses hebrew requests blocks ambiguity or missing sd and gates on confirmation`() {
    val internalTree = "content://$TEST_DOCS_AUTHORITY/tree/primary%3AStorage"
    val sdTree = "content://$TEST_DOCS_AUTHORITY/tree/9988-7766%3ASD"

    val photoFile =
      ScannedFileEntry(
        uriString = "$internalTree/document/primary%3AStorage%2FDownload%2Fphoto.jpg",
        treeUriString = internalTree,
        parentDocId = "primary:Storage/Download",
        docId = "primary:Storage/Download/photo.jpg",
        name = "photo.jpg",
        relativePath = "Storage/Download/photo.jpg",
        mimeType = "image/jpeg",
        sizeBytes = 512_000L,
        lastModifiedMillis = 1_700_000_000_000L,
        category = FileCategory.IMAGES,
        volumeKind = StorageVolumeKind.INTERNAL,
        isOldUnused = false,
        isLargeFile = false,
        isTempResidual = false,
        isInstallerApk = false,
        isBackupArchive = false,
        isNameUnclear = false
      )
    val dupReport1 =
      photoFile.copy(
        uriString = "$internalTree/document/primary%3AStorage%2FDownload%2Freport_jan.pdf",
        docId = "primary:Storage/Download/report_jan.pdf",
        name = "report_jan.pdf",
        relativePath = "Storage/Download/report_jan.pdf",
        mimeType = "application/pdf",
        category = FileCategory.DOCUMENTS
      )
    val dupReport2 =
      photoFile.copy(
        uriString = "$internalTree/document/primary%3AStorage%2FDocuments%2Freport_feb.pdf",
        parentDocId = "primary:Storage/Documents",
        docId = "primary:Storage/Documents/report_feb.pdf",
        name = "report_feb.pdf",
        relativePath = "Storage/Documents/report_feb.pdf",
        mimeType = "application/pdf",
        category = FileCategory.DOCUMENTS
      )

    val picturesFolder =
      FolderStorageSummary(
        treeUriString = internalTree,
        docId = "primary:Storage/Pictures",
        folderName = "Pictures",
        relativePath = "Storage/Pictures",
        volumeKind = StorageVolumeKind.INTERNAL,
        fileCount = 0,
        totalBytes = 0L,
        isEmpty = false
      )

    val reportNoSd =
      SmartStorageScanReport(
        scannedAtMillis = 1_700_000_000_000L,
        volumes =
          listOf(
            StorageVolumeInfo(
              id = "int",
              label = "אחסון פנימי",
              kind = StorageVolumeKind.INTERNAL,
              isMounted = true,
              totalBytes = 64_000_000_000L,
              freeBytes = 32_000_000_000L,
              usedBytes = 32_000_000_000L,
              usedPercent = 50,
              authorizedTreeUris = listOf(internalTree)
            )
          ),
        files = listOf(photoFile, dupReport1, dupReport2),
        folders = listOf(picturesFolder),
        emptyFolders = emptyList(),
        categories = emptyList(),
        duplicateGroups = emptyList(),
        mediaIssues = emptyList(),
        unreadableCount = 0,
        newlyLargeFiles = emptyList(),
        forecast = StorageClassificationMath.computeStorageForecast(emptyList(), 10_000_000_000L),
        totalScannedFilesBytes = 1_500_000L,
        totalDuplicateWasteBytes = 0L,
        totalTempWasteBytes = 0L
      )

    // 1. Copy specific image to Pictures folder -> resolved with 8 steps & requiresConfirmation = true
    val copyParams =
      NexusAikoToolEngine.parseFileToolParameters(
        "תמצא את קובץ התמונה photo.jpg ותעתיק אותו לתיקיית התמונות"
      )
    assertNotNull(copyParams)
    assertEquals(AikoRequestedOperation.COPY_FILE, copyParams!!.operation)
    assertEquals("photo.jpg", copyParams.fileNameQuery)
    assertEquals(FileCategory.IMAGES, copyParams.fileCategoryHint)
    assertEquals("התמונות", copyParams.destFolderHint)

    val copyPlan =
      NexusAikoToolEngine.resolveFileToolPlan(
        params = copyParams,
        safTreeUris = setOf(internalTree),
        report = reportNoSd
      )
    assertNull(copyPlan.rejectionReasonHe)
    assertTrue(copyPlan.requiresConfirmation)
    assertEquals(8, copyPlan.plannedStepsHe.size)
    assertEquals(ApprovalOperationType.COPY_SAF_DOCUMENT, copyPlan.proposalDraft!!.operationType)
    assertEquals("primary:Storage/Pictures", copyPlan.destFolderDocId)

    // 2. Ambiguity guard (2 files matching "report") -> must block cleanly
    val ambigParams =
      NexusAikoToolEngine.parseFileToolParameters("העבר את הדוח report לתיקיית התמונות")!!
    val ambigPlan =
      NexusAikoToolEngine.resolveFileToolPlan(
        params = ambigParams,
        safTreeUris = setOf(internalTree),
        report = reportNoSd
      )
    assertNotNull(ambigPlan.rejectionReasonHe)
    assertFalse(ambigPlan.requiresConfirmation)
    assertEquals(2, ambigPlan.candidateFiles.size)

    // 3. Missing SD card guard -> blocked safely when SD is absent, allowed when SD is mounted & authorized
    val sdMoveParams =
      NexusAikoToolEngine.parseFileToolParameters("העבר את photo.jpg לכרטיס SD")!!
    val blockedSdPlan =
      NexusAikoToolEngine.resolveFileToolPlan(
        params = sdMoveParams,
        safTreeUris = setOf(internalTree),
        report = reportNoSd
      )
    assertNotNull(blockedSdPlan.rejectionReasonHe)
    assertFalse(blockedSdPlan.requiresConfirmation)

    val reportWithSd =
      reportNoSd.copy(
        volumes =
          reportNoSd.volumes +
            StorageVolumeInfo(
              id = "sd",
              label = "כרטיס SD",
              kind = StorageVolumeKind.SD_CARD,
              isMounted = true,
              totalBytes = 32_000_000_000L,
              freeBytes = 20_000_000_000L,
              usedBytes = 12_000_000_000L,
              usedPercent = 37,
              authorizedTreeUris = listOf(sdTree)
            )
      )
    val allowedSdPlan =
      NexusAikoToolEngine.resolveFileToolPlan(
        params = sdMoveParams,
        safTreeUris = setOf(internalTree, sdTree),
        report = reportWithSd
      )
    assertNull(allowedSdPlan.rejectionReasonHe)
    assertTrue(allowedSdPlan.requiresConfirmation)
    assertEquals(sdTree, allowedSdPlan.destTreeUriString)
    assertEquals(ApprovalOperationType.MOVE_SAF_DOCUMENT, allowedSdPlan.proposalDraft!!.operationType)
  }

  @Test
  fun `automation interval parsing and WorkManager scheduling and cancellation behave accurately`() {
    val sixHourProp = AikoBrainEngine.parseNaturalAutomationRule("כל 6 שעות בדוק אחסון וסוללה")
    assertTrue(sixHourProp.isFeasible)
    assertEquals(6, sixHourProp.scheduleIntervalHours)

    val hourlyProp = AikoBrainEngine.parseNaturalAutomationRule("כל שעה בדוק סוללה")
    assertTrue(hourlyProp.isFeasible)
    assertEquals(1, hourlyProp.scheduleIntervalHours)

    val manualProp = AikoBrainEngine.parseNaturalAutomationRule("בדוק סוללה ידני")
    assertTrue(manualProp.isFeasible)
    assertEquals(0, manualProp.scheduleIntervalHours)

    val autoEntity =
      AutomationEntity(
        id = 77L,
        name = sixHourProp.name,
        voicePhrase = sixHourProp.voicePhrase,
        description = "בדיקת תזמון",
        stepsSerialized = sixHourProp.steps.joinToString(",") { it.name },
        isBuiltIn = false,
        scheduleIntervalHours = sixHourProp.scheduleIntervalHours
      )

    val schedRes = NexusWorkScheduler.syncScheduledAutomation(app, autoEntity)
    assertTrue("Expected WorkManager enqueue to succeed: ${schedRes.errorHe}", schedRes.succeeded)
    assertEquals(6, schedRes.intervalHours)

    val wm = WorkManager.getInstance(app)
    val enqueuedInfos = wm.getWorkInfosForUniqueWork(schedRes.workName).get(5, TimeUnit.SECONDS)
    assertTrue(enqueuedInfos.any { it.state == WorkInfo.State.ENQUEUED || it.state == WorkInfo.State.RUNNING })

    // Now set interval = 0 (manual) and verify cancellation
    val cancelRes = NexusWorkScheduler.syncScheduledAutomation(app, autoEntity.copy(scheduleIntervalHours = 0))
    assertTrue(cancelRes.succeeded)
    assertEquals(0, cancelRes.intervalHours)

    val afterCancelInfos = wm.getWorkInfosForUniqueWork(cancelRes.workName).get(5, TimeUnit.SECONDS)
    assertTrue(
      "Work must be cancelled when scheduleIntervalHours == 0",
      afterCancelInfos.isEmpty() || afterCancelInfos.all { it.state == WorkInfo.State.CANCELLED }
    )
  }

  private fun ByteArray.sha256Hex(): String =
    java.security.MessageDigest.getInstance("SHA-256")
      .digest(this)
      .joinToString("") { "%02x".format(it) }

  /**
   * Real in-memory + temp-file-backed DocumentsProvider enabling end-to-end SAF DocumentContract testing under Robolectric.
   */
  class InMemorySafDocumentsProvider : DocumentsProvider() {
    data class DocNode(
      val docId: String,
      var parentId: String?,
      var displayName: String,
      val mimeType: String,
      val isDir: Boolean,
      val file: File? = null,
      val lastModified: Long = System.currentTimeMillis()
    )

    private val nodes = linkedMapOf<String, DocNode>()
    private val roots = mutableListOf<String>()
    private var backingDir: File? = null
    val failWriteParentDocIds = hashSetOf<String>()

    fun resetWithTrees(roots: List<String>, backingDir: File) {
      nodes.clear()
      this.roots.clear()
      failWriteParentDocIds.clear()
      this.backingDir = backingDir
      backingDir.mkdirs()
      roots.forEach { r ->
        this.roots += r
        nodes[r] =
          DocNode(
            docId = r,
            parentId = null,
            displayName = r.substringAfterLast(':'),
            mimeType = DocumentsContract.Document.MIME_TYPE_DIR,
            isDir = true
          )
      }
    }

    fun cleanupTempDir() {
      backingDir?.deleteRecursively()
      backingDir = null
    }

    fun addDirectory(parentId: String, docId: String, name: String): String {
      nodes[docId] =
        DocNode(
          docId = docId,
          parentId = parentId,
          displayName = name,
          mimeType = DocumentsContract.Document.MIME_TYPE_DIR,
          isDir = true
        )
      return docId
    }

    fun addFile(
      parentId: String,
      docId: String,
      displayName: String,
      mimeType: String,
      content: ByteArray
    ): String {
      val f = File(backingDir!!, UUID.randomUUID().toString() + ".bin")
      f.writeBytes(content)
      nodes[docId] =
        DocNode(
          docId = docId,
          parentId = parentId,
          displayName = displayName,
          mimeType = mimeType,
          isDir = false,
          file = f
        )
      return docId
    }

    fun exists(docId: String): Boolean = nodes.containsKey(docId)

    fun findChildDocId(parentId: String, displayName: String): String? =
      nodes.values.firstOrNull {
        it.parentId == parentId && it.displayName.equals(displayName, ignoreCase = true)
      }?.docId

    fun readBytes(docId: String): ByteArray = nodes[docId]?.file?.readBytes() ?: ByteArray(0)

    fun getMime(docId: String): String? = nodes[docId]?.mimeType

    override fun onCreate(): Boolean = true

    override fun isChildDocument(parentDocumentId: String?, documentId: String?): Boolean {
      var cur = nodes[documentId]
      while (cur != null) {
        if (cur.docId == parentDocumentId) return true
        cur = cur.parentId?.let { nodes[it] }
      }
      return false
    }

    override fun queryRoots(projection: Array<out String>?): Cursor {
      val cols =
        projection ?: arrayOf(
          DocumentsContract.Root.COLUMN_ROOT_ID,
          DocumentsContract.Root.COLUMN_TITLE,
          DocumentsContract.Root.COLUMN_DOCUMENT_ID,
          DocumentsContract.Root.COLUMN_FLAGS
        )
      val cursor = MatrixCursor(cols)
      roots.forEach { r ->
        val row = cursor.newRow()
        cols.forEach { c ->
          when (c) {
            DocumentsContract.Root.COLUMN_ROOT_ID -> row.add(r)
            DocumentsContract.Root.COLUMN_TITLE -> row.add(r)
            DocumentsContract.Root.COLUMN_DOCUMENT_ID -> row.add(r)
            DocumentsContract.Root.COLUMN_FLAGS ->
              row.add(DocumentsContract.Root.FLAG_SUPPORTS_CREATE or DocumentsContract.Root.FLAG_SUPPORTS_IS_CHILD)
            else -> row.add(null)
          }
        }
      }
      return cursor
    }

    override fun queryDocument(documentId: String?, projection: Array<out String>?): Cursor {
      val cols = projection ?: DEFAULT_DOC_PROJECTION
      val cursor = MatrixCursor(cols)
      val node = nodes[documentId] ?: return cursor
      appendNodeRow(cursor, cols, node)
      return cursor
    }

    override fun queryChildDocuments(
      parentDocumentId: String?,
      projection: Array<out String>?,
      sortOrder: String?
    ): Cursor {
      val cols = projection ?: DEFAULT_DOC_PROJECTION
      val cursor = MatrixCursor(cols)
      nodes.values.filter { it.parentId == parentDocumentId }.forEach { node ->
        appendNodeRow(cursor, cols, node)
      }
      return cursor
    }

    override fun createDocument(
      parentDocumentId: String?,
      mimeType: String?,
      displayName: String?
    ): String {
      val parent = parentDocumentId ?: error("Missing parent")
      if (parent in failWriteParentDocIds) {
        throw SecurityException("Read-only test directory")
      }
      val name = displayName ?: "untitled"
      val isDir = mimeType == DocumentsContract.Document.MIME_TYPE_DIR
      val newId = "$parent/$name#${UUID.randomUUID().toString().take(6)}"
      val f = if (isDir) null else File(backingDir!!, UUID.randomUUID().toString() + ".bin").apply { createNewFile() }
      nodes[newId] =
        DocNode(
          docId = newId,
          parentId = parent,
          displayName = name,
          mimeType = mimeType ?: "application/octet-stream",
          isDir = isDir,
          file = f
        )
      return newId
    }

    override fun deleteDocument(documentId: String?) {
      val node = nodes.remove(documentId) ?: return
      node.file?.delete()
    }

    override fun renameDocument(documentId: String?, displayName: String?): String {
      val node = nodes[documentId] ?: throw IllegalArgumentException("Not found")
      if (!displayName.isNullOrBlank()) {
        node.displayName = displayName
      }
      return node.docId
    }

    override fun moveDocument(
      sourceDocumentId: String?,
      sourceParentDocumentId: String?,
      targetParentDocumentId: String?
    ): String {
      if (targetParentDocumentId in failWriteParentDocIds) {
        throw SecurityException("Read-only test directory")
      }
      val node = nodes[sourceDocumentId] ?: throw IllegalArgumentException("Missing source")
      require(node.parentId == sourceParentDocumentId) {
        "Wrong sourceParentDocumentId: expected=${node.parentId}, actual=$sourceParentDocumentId"
      }
      node.parentId = targetParentDocumentId
      return node.docId
    }

    override fun openDocument(
      documentId: String?,
      mode: String?,
      signal: CancellationSignal?
    ): ParcelFileDescriptor {
      val node = nodes[documentId] ?: throw IllegalArgumentException("Document not found: $documentId")
      val file = node.file ?: throw IllegalArgumentException("Not a file: $documentId")
      val pfdMode =
        if (mode?.contains("w") == true) ParcelFileDescriptor.MODE_READ_WRITE or ParcelFileDescriptor.MODE_TRUNCATE
        else ParcelFileDescriptor.MODE_READ_ONLY
      return ParcelFileDescriptor.open(file, pfdMode)
    }

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
      return super.call(method, arg, extras)
    }

    private fun appendNodeRow(cursor: MatrixCursor, cols: Array<out String>, node: DocNode) {
      val row = cursor.newRow()
      val flags =
        DocumentsContract.Document.FLAG_SUPPORTS_DELETE or
          DocumentsContract.Document.FLAG_SUPPORTS_WRITE or
          DocumentsContract.Document.FLAG_SUPPORTS_RENAME or
          DocumentsContract.Document.FLAG_SUPPORTS_MOVE or
          if (node.isDir) DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE else 0
      cols.forEach { col ->
        when (col) {
          DocumentsContract.Document.COLUMN_DOCUMENT_ID -> row.add(node.docId)
          DocumentsContract.Document.COLUMN_DISPLAY_NAME -> row.add(node.displayName)
          DocumentsContract.Document.COLUMN_MIME_TYPE -> row.add(node.mimeType)
          DocumentsContract.Document.COLUMN_SIZE -> row.add(node.file?.length() ?: 0L)
          DocumentsContract.Document.COLUMN_LAST_MODIFIED -> row.add(node.lastModified)
          DocumentsContract.Document.COLUMN_FLAGS -> row.add(flags)
          else -> row.add(null)
        }
      }
    }

    companion object {
      private val DEFAULT_DOC_PROJECTION =
        arrayOf(
          DocumentsContract.Document.COLUMN_DOCUMENT_ID,
          DocumentsContract.Document.COLUMN_DISPLAY_NAME,
          DocumentsContract.Document.COLUMN_MIME_TYPE,
          DocumentsContract.Document.COLUMN_SIZE,
          DocumentsContract.Document.COLUMN_LAST_MODIFIED,
          DocumentsContract.Document.COLUMN_FLAGS
        )
    }
  }
}
