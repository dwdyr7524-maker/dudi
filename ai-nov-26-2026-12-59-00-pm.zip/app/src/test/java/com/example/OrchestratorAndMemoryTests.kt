package com.example

import com.example.data.documents.DocumentTextAnalyzer
import com.example.data.documents.NexusDocumentKind
import com.example.data.local.LearningRecordEntity
import com.example.data.local.MemoryEntryEntity
import com.example.data.local.ToolUsageEntity
import com.example.data.memory.LearningAnalyticsCalculator
import com.example.data.memory.MemoryContextBuilder
import com.example.data.memory.NexusMemorySecretFilter
import com.example.data.memory.NexusMemoryType
import com.example.data.orchestrator.NexusAgentRole
import com.example.data.orchestrator.OrchestratorPlanner
import com.example.data.orchestrator.OrchestratorSerialization
import com.example.data.orchestrator.OrchestratorStepStatus
import com.example.data.system.OfflineCapabilityMatrix
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OrchestratorAndMemoryTests {

  @Test
  fun `secret filter blocks API keys, JWTs, PEM blocks, and passwords`() {
    val apiKeyCheck = NexusMemorySecretFilter.inspect("גישה", "המפתח שלי הוא AIzaSyD89fK23mQp99xLs823abcDEF")
    assertTrue(apiKeyCheck.containsSensitiveData)
    assertFalse(apiKeyCheck.sanitizedPreview.contains("AIzaSyD89"))

    val pwdCheck = NexusMemorySecretFilter.inspect("כניסה", "הסיסמה שלי: SuperSecret123")
    assertTrue(pwdCheck.containsSensitiveData)

    val enPwdCheck = NexusMemorySecretFilter.inspect("note", "password=my_secret_value")
    assertTrue(enPwdCheck.containsSensitiveData)

    val safeCheck = NexusMemorySecretFilter.inspect("העדפה", "אני מעדיף דוחות קצרים בעברית עם ממצאי סוללה.")
    assertFalse(safeCheck.containsSensitiveData)
  }

  @Test
  fun `memory context builder excludes short term and unpersistable entries`() {
    val entries =
      listOf(
        MemoryEntryEntity(
          id = 1,
          memoryType = NexusMemoryType.PREFERENCE.name,
          title = "שפת מערכת",
          content = "תמיד ענה בעברית קצרה וברורה",
          categoryTag = "העדפה",
          canPersist = true,
          importanceScore = 90,
          createdAtMillis = 100L,
          updatedAtMillis = 100L,
          lastAccessedMillis = 100L
        ),
        MemoryEntryEntity(
          id = 2,
          memoryType = NexusMemoryType.SHORT_TERM.name,
          title = "זמני",
          content = "לא צריך להיכנס להקשר ארוך טווח",
          categoryTag = "זמני",
          canPersist = true,
          importanceScore = 99,
          createdAtMillis = 200L,
          updatedAtMillis = 200L,
          lastAccessedMillis = 200L
        ),
        MemoryEntryEntity(
          id = 3,
          memoryType = NexusMemoryType.PROJECT.name,
          title = "מוקפא",
          content = "משתמש ביטל שמירה",
          categoryTag = "פרויקט",
          canPersist = false,
          importanceScore = 80,
          createdAtMillis = 300L,
          updatedAtMillis = 300L,
          lastAccessedMillis = 300L
        )
      )

    val ctx = MemoryContextBuilder.buildPromptContext(entries)
    assertTrue(ctx.contains("שפת מערכת"))
    assertFalse(ctx.contains("לא צריך להיכנס"))
    assertFalse(ctx.contains("משתמש ביטל שמירה"))
  }

  @Test
  fun `memory auto extractor detects explicit preference and project phrases`() {
    val explicit = MemoryContextBuilder.detectAutoMemoryCandidate("זכור שהטאבלט הזה משמש ללימודים בערב")
    assertNotNull(explicit)
    assertEquals(NexusMemoryType.LONG_TERM, explicit!!.first)
    assertTrue(explicit.third.contains("טאבלט"))

    val pref = MemoryContextBuilder.detectAutoMemoryCandidate("אני מעדיף לקבל סיכום בנקודות קצרות")
    assertNotNull(pref)
    assertEquals(NexusMemoryType.PREFERENCE, pref!!.first)

    val regular = MemoryContextBuilder.detectAutoMemoryCandidate("מה מצב הסוללה?")
    assertNull(regular)
  }

  @Test
  fun `orchestrator planner assigns specialized agents without duplicate dedupKeys`() {
    val steps =
      OrchestratorPlanner.decomposeGoal(
        rawGoal = "בדוק אחסון כפילויות ורשת, תכנן קוד JSON והפק דוח סיכום",
        isOnline = true,
        cloudAiEnabled = true
      )
    assertTrue(steps.size >= 5)
    assertEquals(NexusAgentRole.PLANNER, steps.first().agent)
    assertEquals(NexusAgentRole.TASK_MANAGER, steps.last().agent)
    assertTrue(steps.any { it.agent == NexusAgentRole.RESEARCHER })
    assertTrue(steps.any { it.agent == NexusAgentRole.CODER })
    assertTrue(steps.any { it.agent == NexusAgentRole.TESTER })
    // Every step must have unique dedupKey
    assertEquals(steps.size, steps.map { it.dedupKey }.distinct().size)
  }

  @Test
  fun `document text analyzer classifies searches and summarizes cleanly`() {
    assertEquals(NexusDocumentKind.PDF, DocumentTextAnalyzer.classifyKind("guide.PDF", "application/octet-stream"))
    assertEquals(NexusDocumentKind.MARKDOWN, DocumentTextAnalyzer.classifyKind("notes.md", "text/plain"))
    assertEquals(NexusDocumentKind.JSON, DocumentTextAnalyzer.classifyKind("config.json", "application/json"))

    val sample = "שורה 1: בדיקת מערכת\nשורה 2: אחסון SD תקין\nשורה 3: סוללה 85 אחוז"
    val matches = DocumentTextAnalyzer.searchLines(sample, "אחסון")
    assertEquals(1, matches.size)
    assertEquals(2, matches[0].lineNumber)

    val sum = DocumentTextAnalyzer.summarizeTextLocally("report.txt", sample, NexusDocumentKind.TEXT)
    assertTrue(sum.contains("3 שורות"))
  }

  @Test
  fun `learning analytics detects degraded tools recurring tasks and ignores undone feedback`() {
    val usage =
      listOf(
        ToolUsageEntity(toolId = "bad_tool", toolNameHe = "כלי בדיקה", succeeded = false, latencyMs = 120, summaryHe = "fail 1", errorHe = "timeout", timestampMillis = 1),
        ToolUsageEntity(toolId = "bad_tool", toolNameHe = "כלי בדיקה", succeeded = false, latencyMs = 150, summaryHe = "fail 2", errorHe = "timeout", timestampMillis = 2),
        ToolUsageEntity(toolId = "bad_tool", toolNameHe = "כלי בדיקה", succeeded = false, latencyMs = 140, summaryHe = "fail 3", errorHe = "timeout", timestampMillis = 3),
        ToolUsageEntity(toolId = "ok_tool", toolNameHe = "כלי תקין", succeeded = true, latencyMs = 50, summaryHe = "ok", timestampMillis = 4)
      )
    val records =
      listOf(
        LearningRecordEntity(category = "ASSISTANT_FEEDBACK", targetKey = "q1", summaryHe = "pos", succeeded = true, userRating = 1, undone = false, createdAtMillis = 10),
        LearningRecordEntity(category = "ASSISTANT_FEEDBACK", targetKey = "q2", summaryHe = "neg undone", succeeded = false, userRating = -1, undone = true, createdAtMillis = 11),
        LearningRecordEntity(category = "RECURRING_TASK", targetKey = "בדיקת סוללה", summaryHe = "run 1", succeeded = true, userRating = 0, undone = false, createdAtMillis = 12),
        LearningRecordEntity(category = "RECURRING_TASK", targetKey = "בדיקת סוללה", summaryHe = "run 2", succeeded = true, userRating = 0, undone = false, createdAtMillis = 13)
      )

    val snap = LearningAnalyticsCalculator.buildSnapshot(usage, records)
    assertEquals(1, snap.degradedTools.size)
    assertEquals("bad_tool", snap.degradedTools.first().toolId)
    assertEquals(1, snap.positiveFeedbackCount)
    assertEquals(0, snap.negativeFeedbackCount) // Undone record must not count!
    assertEquals(1, snap.recurringSuggestions.size)
  }

  @Test
  fun `offline capability matrix clearly separates local and cloud items`() {
    assertTrue(OfflineCapabilityMatrix.items.any { it.worksOffline })
    assertTrue(OfflineCapabilityMatrix.items.any { !it.worksOffline })
  }
}
